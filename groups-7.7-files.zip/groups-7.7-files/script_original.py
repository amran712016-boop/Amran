#!/usr/bin/env python3
"""One-file Flask page to verify an X session and act on a chat group's tweets.

Saved sessions (auth token + the account username) are written beside this
script and survive a restart. Job progress is kept too, so leaving the browser
and coming back shows whether the work is still running, where it stopped,
or that it finished. The token is not returned except to this same page.
"""
from __future__ import annotations

import atexit
import base64
import gzip
import hashlib
import hmac
import concurrent.futures
import importlib.util
import itertools
import json
import logging
import math
import os
import queue
import random
import re
import secrets
import shutil
import socket
import subprocess
import sys
import traceback
import threading
import time
import urllib.error
import urllib.request
from collections import defaultdict, deque
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import quote

from flask import Flask, abort, jsonify, make_response, redirect, render_template_string, request, session
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import Page, sync_playwright
from werkzeug.serving import make_server

app = Flask(__name__)
app.secret_key = secrets.token_bytes(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Strict",
    SESSION_COOKIE_SECURE=os.getenv("X_APP_SECURE_COOKIE", "0") == "1",
    MAX_CONTENT_LENGTH=64 * 1024,
)
# Every request stays under 8 KB, except starting a task from «روابط التغريدات» (up to 1000 links).
SMALL_REQUEST_BYTES = 8 * 1024

ACCESS_PATH = os.getenv("X_ACCESS_PATH", "desk")
# This copy's version. In users' copies it is the version the owner published from «توزيع البرنامج»
# (g.py writes it into the file it hands out); in the owner's copy it does not change.
APP_VERSION = "1.0"
# In a copy given to a user: the owner's address to take updates from, and that user's key.
# The owner's copy fills both in when it hands the program out; both stay empty in the owner's copy.
UPDATE_SOURCE = ""
UPDATE_KEY = ""
# In a copy given to a user: the owner's content.py («إنشاء محتوى»), packed in by g.py when it hands the
# program out (gzip, then base64), so the user's copy has the page with no file of its own. Empty in the
# owner's copy, which uses content.py beside it.
CONTENT_EMBEDDED = ""
# On users' copies, the posts «إنشاء محتوى» may make in one day (Saudi time). The owner's copy has no limit.
USER_POSTS_PER_DAY = 1
ATTEMPT_WINDOW_SECONDS = 300
MAX_ATTEMPTS_PER_CLIENT = 5
MAX_REPOSTS_REQUEST = 1000
jobs: dict[str, dict] = {}
attempts: dict[str, deque[float]] = defaultdict(deque)
attempts_lock = threading.Lock()
jobs_lock = threading.Lock()
sessions_lock = threading.Lock()
gemini_lock = threading.Lock()
JOB_TTL_SECONDS = 86400
DATA_DIR = Path(__file__).resolve().with_name("data")
CLICK_LOG_PATH = DATA_DIR / "click-log.txt"
_click_log_lock = threading.Lock()


# Each account is kept apart as if it were a copy of the program of its own: its own browser, its own folder
# of data (data/accounts/<its key>/: what its panel showed, its groups, its log), its own tasks. The work of
# a thread is one account's: account_context says which, and its log lines, its groups' ids… go there.
ACCOUNTS_DIR = DATA_DIR / "accounts"
account_context = threading.local()


def current_account() -> str:
    """The account the running work belongs to (its profile key), or "" for the program's own work."""
    return getattr(account_context, "key", "") or ""


def account_dir(key: str) -> Path:
    return ACCOUNTS_DIR / key


def set_account_context(key: str) -> None:
    account_context.key = key or ""
    if os.environ.get("GG_IN_APP") == "1":
        try:
            import ggapp                          # the app's side: what this thread prints is this account's
            ggapp.set_thread_account(key or "")
        except Exception:
            pass


class as_account:
    """with as_account(key): what follows is that account's work (nested uses give back the one before)."""

    def __init__(self, key: str):
        self.key = key or ""
        self.before = ""

    def __enter__(self):
        self.before = current_account()
        set_account_context(self.key)
        return self

    def __exit__(self, *exc):
        set_account_context(self.before)
        return False


def trace_click(message: str) -> None:
    """One line in the account's click log (data/accounts/<key>/click-log.txt; data/click-log.txt for the
    program's own work) and in the app's «السجل», so a failed press can be read afterwards."""
    line = time.strftime("%H:%M:%S ") + str(message).replace("\n", " ")[:500]
    print("نقر: " + line, flush=True)
    key = current_account()
    path = account_dir(key) / "click-log.txt" if key else CLICK_LOG_PATH
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with _click_log_lock:
            with path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
            if path.stat().st_size > 180_000:
                kept = path.read_text(encoding="utf-8")[-120_000:]
                path.write_text(kept, encoding="utf-8")
    except Exception:
        pass


def trace_page(page, why: str) -> None:
    try:
        snap = page.evaluate(
            """() => {
              const tests = [...document.querySelectorAll("[data-testid]")].slice(0, 40)
                .map((el) => el.getAttribute("data-testid"));
              return {url: location.href, w: innerWidth, h: innerHeight, dpr: window.devicePixelRatio || 1, tests};
            }"""
        )
    except Exception as exc:
        snap = type(exc).__name__ + ": " + str(exc)[:160]
    trace_click(why + " | " + str(snap)[:450])
SESSIONS_PATH = DATA_DIR / "sessions.json"
JOBS_PATH = DATA_DIR / "jobs.json"
GEMINI_PATH = DATA_DIR / "gemini.json"
saved_sessions: list[dict] = []
saved_gemini = {"api_key": "", "model": "gemini-3.5-flash"}
JOB_FIELDS = (
    "owner", "client_id", "created_at", "updated_at", "status", "phase", "kind",
    "collected", "done", "requested", "message", "success",
    "username", "actions", "items", "results", "key_hash", "auth_digest", "account",
)
logging.getLogger("werkzeug").disabled = True

def load_page() -> str:
    external = Path(__file__).with_name("templates").joinpath("index.html")
    if external.is_file():
        return external.read_text(encoding="utf-8")
    return EMBEDDED_PAGE


EMBEDDED_PAGE = r'''<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title>مراجعة إعادات النشر</title>
  <style>
    /* ------------------------------------------------------------------ type: IBM Plex Sans Arabic, served by
       this program itself (SIL Open Font License 1.1, (c) IBM Corp.), so the page looks the same on every phone. */
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 400; font-display: swap;
      src: url("/fonts/plex-arabic-400.woff2") format("woff2");
      unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+0897-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 500; font-display: swap;
      src: url("/fonts/plex-arabic-500.woff2") format("woff2");
      unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+0897-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 600; font-display: swap;
      src: url("/fonts/plex-arabic-600.woff2") format("woff2");
      unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+0897-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 400; font-display: swap;
      src: url("/fonts/plex-latin-400.woff2") format("woff2");
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 500; font-display: swap;
      src: url("/fonts/plex-latin-500.woff2") format("woff2");
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 600; font-display: swap;
      src: url("/fonts/plex-latin-600.woff2") format("woff2");
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

    /* ------------------------------------------------------------------ design tokens */
    :root {
      --bg: #f3f5fa;                 /* = the app's own background around the page */
      --surface: #ffffff;
      --surface-2: #f7f8fb;
      --surface-3: #eef1f6;
      --line: #e6e9f0;
      --line-2: #d5dae3;
      --text: #101828;
      --text-2: #344054;
      --text-3: #667085;
      --text-4: #98a2b3;
      --brand: #2f5bea;
      --brand-2: #2447c8;
      --brand-3: #6d4aff;
      --brand-soft: #eef2fe;
      --brand-line: #c7d4fc;
      --ring: rgba(47, 91, 234, 0.2);
      --ok: #079455;
      --ok-soft: #ecfdf3;
      --ok-line: #abefc6;
      --warn: #b54708;
      --warn-soft: #fffaeb;
      --warn-line: #fedf89;
      --bad: #d92d20;
      --bad-soft: #fef3f2;
      --bad-line: #fecdca;
      --c-repost: #12b76a;
      --c-like: #f63d68;
      --c-bookmark: #f79009;
      --c-comment: #7a5af8;
      --r-sm: 8px;
      --r: 11px;
      --r-lg: 16px;
      --h: 36px;
      --sh-1: 0 1px 2px rgba(16, 24, 40, 0.05);
      --sh-2: 0 1px 2px rgba(16, 24, 40, 0.04), 0 6px 16px -6px rgba(16, 24, 40, 0.08);
      --sh-3: 0 18px 40px -12px rgba(16, 24, 40, 0.28), 0 6px 12px -6px rgba(16, 24, 40, 0.1);
      --ease: cubic-bezier(0.2, 0.8, 0.2, 1);
      --font: "Plex Arabic", system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", Tahoma, sans-serif;
      --mono: ui-monospace, "SFMono-Regular", Menlo, Consolas, "Liberation Mono", monospace;
      color-scheme: light;

      /* icons (24 x 24, drawn with currentColor through a mask) */
      --ic-check: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 6 9 17l-5-5'/%3E%3C/svg%3E");
      --ic-x: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.2' stroke-linecap='round'%3E%3Cpath d='M18 6 6 18M6 6l12 12'/%3E%3C/svg%3E");
      --ic-zap: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' d='M13.2 2.2 4.6 13.1a.8.8 0 0 0 .6 1.3h5.9l-1 7.2c-.1.8.9 1.2 1.4.6l8.6-10.9a.8.8 0 0 0-.6-1.3h-5.9l1-7.2c.1-.8-.9-1.2-1.4-.6z'/%3E%3C/svg%3E");
      --ic-repeat: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m17 2 4 4-4 4'/%3E%3Cpath d='M3 11v-1a4 4 0 0 1 4-4h14'/%3E%3Cpath d='m7 22-4-4 4-4'/%3E%3Cpath d='M21 13v1a4 4 0 0 1-4 4H3'/%3E%3C/svg%3E");
      --ic-heart: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z'/%3E%3C/svg%3E");
      --ic-bookmark: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z'/%3E%3C/svg%3E");
      --ic-msg: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M7.9 20A9 9 0 1 0 4 16.1L2 22z'/%3E%3C/svg%3E");
      --ic-users: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2'/%3E%3Ccircle cx='9' cy='7' r='4'/%3E%3Cpath d='M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8'/%3E%3C/svg%3E");
      --ic-link: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7'/%3E%3Cpath d='M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7'/%3E%3C/svg%3E");
      --ic-shield: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10z'/%3E%3Cpath d='m9 12 2 2 4-4'/%3E%3C/svg%3E");
      --ic-login: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4'/%3E%3Cpath d='m10 17 5-5-5-5M15 12H3'/%3E%3C/svg%3E");
      --ic-sliders: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 7h-9M14 17H5'/%3E%3Ccircle cx='17' cy='17' r='3'/%3E%3Ccircle cx='7' cy='7' r='3'/%3E%3C/svg%3E");
      --ic-play: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' d='M7 4.6v14.8a1.2 1.2 0 0 0 1.8 1l12-7.4a1.2 1.2 0 0 0 0-2L8.8 3.6A1.2 1.2 0 0 0 7 4.6z'/%3E%3C/svg%3E");
      --ic-stop: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Crect x='6' y='6' width='12' height='12' rx='2.5' fill='%23000'/%3E%3C/svg%3E");
      --ic-rotate: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 12a9 9 0 1 0 3-6.7L3 8'/%3E%3Cpath d='M3 3v5h5'/%3E%3C/svg%3E");
      --ic-copy: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='8' y='8' width='13' height='13' rx='2'/%3E%3Cpath d='M4 16a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2'/%3E%3C/svg%3E");
      --ic-alert: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z'/%3E%3Cpath d='M12 9v4M12 17h.01'/%3E%3C/svg%3E");
      --ic-ok: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='9.5'/%3E%3Cpath d='m8 12.5 2.8 2.8L16.5 9.5'/%3E%3C/svg%3E");
      --ic-download: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/%3E%3Cpath d='m7 10 5 5 5-5M12 15V3'/%3E%3C/svg%3E");
      --ic-activity: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M22 12h-4l-3 9L9 3l-3 9H2'/%3E%3C/svg%3E");
      --ic-list: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round'%3E%3Cpath d='M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01'/%3E%3C/svg%3E");
      --ic-sparkle: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linejoin='round'%3E%3Cpath d='M11 3.5 12.9 9 18.5 11l-5.6 2L11 18.5 9.1 13 3.5 11l5.6-2z'/%3E%3Cpath d='M18.5 15.5l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z'/%3E%3C/svg%3E");
      --ic-user: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/svg%3E");
      --ic-target: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2'%3E%3Ccircle cx='12' cy='12' r='9'/%3E%3Ccircle cx='12' cy='12' r='5'/%3E%3Ccircle cx='12' cy='12' r='1' fill='%23000'/%3E%3C/svg%3E");
      --ic-chart: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 3v18h18'/%3E%3Cpath d='m7 15 4-4 3 3 5-6'/%3E%3C/svg%3E");
      --ic-layers: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m12 2 10 5-10 5L2 7z'/%3E%3Cpath d='m2 17 10 5 10-5M2 12l10 5 10-5'/%3E%3C/svg%3E");
      --ic-key: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='7.5' cy='15.5' r='4.5'/%3E%3Cpath d='m10.7 12.3 9.8-9.8M17 6l3 3M14.5 8.5l2 2'/%3E%3C/svg%3E");
      --ic-clip: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m21.4 11-9.2 9.2a6 6 0 0 1-8.5-8.5l8.6-8.6a4 4 0 0 1 5.7 5.7l-8.6 8.6a2 2 0 0 1-2.8-2.8l8.5-8.5'/%3E%3C/svg%3E");
      --ic-send: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m22 2-7 20-4-9-9-4z'/%3E%3Cpath d='M22 2 11 13'/%3E%3C/svg%3E");
      --ic-headset: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z'/%3E%3Cpath d='M21 16v2a4 4 0 0 1-4 4h-5'/%3E%3C/svg%3E");
      --ic-wifi-off: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m2 2 20 20M8.5 16.4a5 5 0 0 1 7 0M2 8.8a15 15 0 0 1 4.2-2.7M10.7 5A15 15 0 0 1 22 8.8M5 12.9a10 10 0 0 1 5.2-2.7M16.9 11.6a10 10 0 0 1 2.1 1.3M12 20h.01'/%3E%3C/svg%3E");
      --ic-hash: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round'%3E%3Cpath d='M4 9h16M4 15h16M10 3 8 21M16 3l-2 18'/%3E%3C/svg%3E");
      --ic-terminal: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m4 17 6-6-6-6M12 19h8'/%3E%3C/svg%3E");
    }

    /* the page in an ordinary browser (the app itself is always light) */
    @media (prefers-color-scheme: dark) {
      :root:not([data-theme="light"]) {
        --bg: #0b1020;
        --surface: #121a2e;
        --surface-2: #162036;
        --surface-3: #1c2740;
        --line: #24304a;
        --line-2: #2f3d5c;
        --text: #eef2fb;
        --text-2: #c9d2e5;
        --text-3: #94a1bd;
        --text-4: #6b7896;
        --brand: #6b8cff;
        --brand-2: #8aa4ff;
        --brand-soft: #1b2752;
        --brand-line: #34478f;
        --ring: rgba(107, 140, 255, 0.28);
        --ok: #47cd89;
        --ok-soft: #0f2a20;
        --ok-line: #1f5a3f;
        --warn: #fdb022;
        --warn-soft: #2d2210;
        --warn-line: #5c4210;
        --bad: #f97066;
        --bad-soft: #2f1416;
        --bad-line: #6a2a2a;
        --sh-2: 0 1px 2px rgba(0, 0, 0, 0.3), 0 6px 16px -6px rgba(0, 0, 0, 0.45);
        color-scheme: dark;
      }
    }

    /* ------------------------------------------------------------------ base */
    *, *::before, *::after { box-sizing: border-box; }
    html {
      -webkit-text-size-adjust: 100%;
      text-size-adjust: 100%;
      -webkit-font-smoothing: antialiased;
      -webkit-tap-highlight-color: transparent;
      background: var(--bg);
    }
    body {
      margin: 0;
      min-height: 100vh;
      min-height: 100dvh;
      background: var(--bg);
      color: var(--text);
      font-family: var(--font);
      font-size: 14px;
      line-height: 1.5;
      overflow-x: hidden;
      font-feature-settings: "kern";
    }
    [hidden] { display: none !important; }
    h1, h2, h3, p { margin: 0; }
    a { color: var(--brand); }
    button, input, textarea, select { font: inherit; color: inherit; }
    button, [role="button"], label.choice { cursor: pointer; -webkit-user-select: none; user-select: none; }
    button:disabled { cursor: progress; }
    :focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
    ::selection { background: var(--brand-soft); }
    .lede, .block-head p, .choice-copy, .gemini-fields .hint, .footnote { display: none; }

    /* Invisible spot in the top-left corner: asks for the password that resets the comment cost. */
    .cost-reset {
      position: absolute; top: 0; left: 0; z-index: 5;
      width: 40px; height: 40px; padding: 0; border: 0;
      background: transparent; opacity: 0; cursor: default;
    }

    .page {
      width: min(560px, 100%);
      margin: 0 auto;
      padding: calc(8px + env(safe-area-inset-top)) 12px calc(18px + env(safe-area-inset-bottom));
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    /* ------------------------------------------------------------------ icons */
    .i, .ic::before {
      display: inline-block;
      flex: none;
      width: 16px;
      height: 16px;
      background: currentColor;
      -webkit-mask: var(--m) center / contain no-repeat;
      mask: var(--m) center / contain no-repeat;
    }
    .ic::before { content: ""; width: 15px; height: 15px; }
    .i-check { --m: var(--ic-check); } .i-x { --m: var(--ic-x); } .i-zap { --m: var(--ic-zap); }
    .i-repeat { --m: var(--ic-repeat); } .i-heart { --m: var(--ic-heart); } .i-bookmark { --m: var(--ic-bookmark); }
    .i-msg { --m: var(--ic-msg); } .i-users { --m: var(--ic-users); } .i-link { --m: var(--ic-link); }
    .i-shield { --m: var(--ic-shield); } .i-login { --m: var(--ic-login); } .i-sliders { --m: var(--ic-sliders); }
    .i-play { --m: var(--ic-play); } .i-stop { --m: var(--ic-stop); } .i-rotate { --m: var(--ic-rotate); }
    .i-copy { --m: var(--ic-copy); } .i-alert { --m: var(--ic-alert); } .i-ok { --m: var(--ic-ok); }
    .i-download { --m: var(--ic-download); } .i-activity { --m: var(--ic-activity); } .i-list { --m: var(--ic-list); }
    .i-sparkle { --m: var(--ic-sparkle); } .i-user { --m: var(--ic-user); } .i-target { --m: var(--ic-target); }
    .i-chart { --m: var(--ic-chart); } .i-layers { --m: var(--ic-layers); } .i-key { --m: var(--ic-key); }
    .i-clip { --m: var(--ic-clip); } .i-send { --m: var(--ic-send); } .i-headset { --m: var(--ic-headset); }
    .i-terminal { --m: var(--ic-terminal); } .i-hash { --m: var(--ic-hash); }

    /* ------------------------------------------------------------------ hero */
    .mast {
      position: relative;
      isolation: isolate;
      overflow: hidden;
      padding: 12px;
      border-radius: 18px;
      color: #fff;
      background:
        radial-gradient(120% 95% at 100% 0%, rgba(92, 132, 255, 0.5) 0%, rgba(92, 132, 255, 0) 58%),
        radial-gradient(85% 90% at 0% 100%, rgba(141, 98, 255, 0.42) 0%, rgba(141, 98, 255, 0) 62%),
        linear-gradient(158deg, #0c1640 0%, #13215e 52%, #1b2675 100%);
      box-shadow: 0 16px 32px -18px rgba(19, 33, 94, 0.75), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }
    .mast::before {
      content: "";
      position: absolute;
      inset: 0;
      z-index: -1;
      background-image:
        linear-gradient(rgba(255, 255, 255, 0.055) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.055) 1px, transparent 1px);
      background-size: 20px 20px;
      -webkit-mask-image: linear-gradient(200deg, #000 0%, transparent 70%);
      mask-image: linear-gradient(200deg, #000 0%, transparent 70%);
    }
    .brand { display: flex; align-items: center; gap: 10px; min-width: 0; }
    body[data-app="1"] .brand { padding-inline-end: 42px; }     /* the app's «الدعم» button sits in that corner */
    .mark {
      position: relative;
      display: grid;
      place-items: center;
      flex: none;
      width: 38px;
      height: 38px;
      border-radius: 12px;
      color: #fff;
      background: linear-gradient(135deg, #5b8cff 0%, #7c5cff 100%);
      box-shadow: 0 8px 18px -6px rgba(91, 140, 255, 0.75), inset 0 1px 0 rgba(255, 255, 255, 0.4);
    }
    .mark .i { width: 19px; height: 19px; }
    .brand-text { min-width: 0; display: grid; gap: 1px; }
    .eyebrow {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      line-height: 1.4;
      color: rgba(255, 255, 255, 0.66);
      white-space: nowrap;
    }
    h1 {
      font-size: 15.5px;
      line-height: 1.35;
      font-weight: 600;
      letter-spacing: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .net {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      height: 17px;
      padding: 0 7px 0 8px;
      border-radius: 999px;
      font-size: 10.5px;
      font-weight: 500;
      color: #a6f4c5;
      background: rgba(18, 183, 106, 0.16);
      border: 1px solid rgba(50, 213, 131, 0.28);
    }
    .net > i {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #32d583;
      box-shadow: 0 0 0 0 rgba(50, 213, 131, 0.7);
      animation: live 2.4s var(--ease) infinite;
    }
    .net[data-state="retry"] { color: #fedf89; background: rgba(247, 144, 9, 0.16); border-color: rgba(253, 176, 34, 0.3); }
    .net[data-state="retry"] > i { background: #fdb022; animation: blink 1s steps(2, start) infinite; }
    .net[data-state="off"] { color: #fecdca; background: rgba(240, 68, 56, 0.18); border-color: rgba(249, 112, 102, 0.32); }
    .net[data-state="off"] > i { background: #f97066; animation: none; }

    .counts {
      list-style: none;
      margin: 11px 0 0;
      padding: 0;
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 6px;
    }
    .kpi {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      grid-template-areas: "num num" "ic lbl";
      align-items: center;
      gap: 1px 5px;
      padding: 7px 8px 6px;
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.07);
      border: 1px solid rgba(255, 255, 255, 0.1);
      min-width: 0;
    }
    .kpi .i { grid-area: ic; width: 12px; height: 12px; }
    .kpi b {
      grid-area: num;
      font-size: 17px;
      line-height: 1.2;
      font-weight: 600;
      font-variant-numeric: tabular-nums;
      color: #fff;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .kpi-label {
      grid-area: lbl;
      font-size: 10.5px;
      color: rgba(255, 255, 255, 0.64);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .k-repost .i { color: #6ce9a6; }
    .k-like .i { color: #fda4af; }
    .k-bookmark .i { color: #fec84b; }
    .k-comment .i { color: #bdb4fe; }

    .mast-links {
      display: flex;
      gap: 6px;
      margin: 10px -12px 0;
      padding: 0 12px;
      overflow-x: auto;
      scrollbar-width: none;
      overscroll-behavior-x: contain;
    }
    .mast-links::-webkit-scrollbar { display: none; }
    .chip {
      flex: none;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      height: 30px;
      padding: 0 10px;
      border-radius: 999px;
      border: 1px solid rgba(255, 255, 255, 0.16);
      background: rgba(255, 255, 255, 0.09);
      color: #fff;
      font-size: 11.5px;
      font-weight: 500;
      text-decoration: none;
      white-space: nowrap;
      transition: background 0.15s, transform 0.12s var(--ease);
    }
    .chip:active { transform: scale(0.97); background: rgba(255, 255, 255, 0.16); }
    .chip.ic::before { width: 13px; height: 13px; opacity: 0.9; }
    .usage-cost {
      display: inline-flex;
      align-items: center;
      height: 19px;
      padding: 0 7px;
      border-radius: 999px;
      background: #7a4a1d;
      color: #fff;
      font-size: 10.5px;
      font-weight: 600;
      font-variant-numeric: tabular-nums;
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.18);
    }

    /* ------------------------------------------------------------------ cards and sections */
    .sheet {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--r-lg);
      box-shadow: var(--sh-2);
    }
    .sheet-inner { padding: 12px; }
    .block + .block { margin-top: 11px; padding-top: 11px; border-top: 1px solid var(--line); }
    body[data-app="1"] .accounts-block { display: none; }
    body[data-app="1"] .accounts-block + .block { margin-top: 0; padding-top: 0; border-top: 0; }
    .block-head { margin-bottom: 8px; }
    .sheet h2, .block-head h2 {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      line-height: 1.4;
      font-weight: 600;
      color: var(--text);
    }
    .sec {
      display: grid;
      place-items: center;
      flex: none;
      width: 24px;
      height: 24px;
      border-radius: 8px;
      color: var(--brand);
      background: var(--brand-soft);
      box-shadow: inset 0 0 0 1px var(--brand-line);
    }
    .sec .i { width: 13px; height: 13px; }
    .field-label, label.field-label {
      display: block;
      margin: 10px 0 5px;
      font-size: 12px;
      font-weight: 500;
      color: var(--text-2);
    }
    .hint { font-size: 11.5px; color: var(--text-3); line-height: 1.6; }

    /* ------------------------------------------------------------------ controls */
    .btn {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      min-height: var(--h);
      padding: 0 12px;
      border-radius: var(--r);
      border: 1px solid transparent;
      font-size: 12.5px;
      font-weight: 500;
      line-height: 1.2;
      white-space: nowrap;
      text-decoration: none;
      transition: background 0.15s, border-color 0.15s, box-shadow 0.15s, color 0.15s, transform 0.12s var(--ease);
    }
    .btn:active:not(:disabled) { transform: scale(0.97); }
    .btn:disabled { opacity: 0.62; }
    .btn-ghost {
      background: var(--surface);
      border-color: var(--line-2);
      color: var(--text-2);
      box-shadow: var(--sh-1);
    }
    .btn-ghost:hover:not(:disabled) { background: var(--surface-2); }
    .btn-ghost.ic::before { color: var(--text-3); }
    .btn-pine {
      color: #fff;
      background: linear-gradient(180deg, #4a74ff 0%, var(--brand) 100%);
      border-color: rgba(36, 71, 200, 0.6);
      box-shadow: 0 8px 18px -10px rgba(47, 91, 234, 0.9), inset 0 1px 0 rgba(255, 255, 255, 0.22);
    }
    .btn-pine:hover:not(:disabled) { background: linear-gradient(180deg, #3f6bff 0%, var(--brand-2) 100%); }
    .btn-wide { width: 100%; min-height: 44px; margin-top: 12px; border-radius: 13px; font-size: 14px; font-weight: 600; }
    .btn-wide.ic::before { width: 14px; height: 14px; }
    /* a button that waits for the program shows it is working */
    .btn:disabled::after {
      content: "";
      width: 13px;
      height: 13px;
      border-radius: 50%;
      border: 2px solid currentColor;
      border-inline-end-color: transparent;
      animation: spin 0.7s linear infinite;
    }
    .btn.ic:disabled::before { display: none; }
    .link-button { color: var(--brand); text-decoration: none; font-weight: 500; }

    input[type="password"], input[type="text"], input[type="number"], textarea {
      width: 100%;
      min-height: var(--h);
      padding: 0 11px;
      border: 1px solid var(--line-2);
      border-radius: var(--r);
      background: var(--surface);
      color: var(--text);
      font-size: 13px;
      outline: none;
      box-shadow: var(--sh-1);
      text-overflow: ellipsis;
      transition: border-color 0.15s, box-shadow 0.15s, background 0.15s;
    }
    input::placeholder, textarea::placeholder { color: var(--text-4); }
    input:focus, textarea:focus { border-color: var(--brand); box-shadow: 0 0 0 3px var(--ring); }
    input[readonly] { background: var(--surface-2); box-shadow: none; }
    #stop-tweet, #gemini-model, #claude-model, #auth_token { direction: ltr; text-align: right; }
    #stop-tweet:placeholder-shown { direction: rtl; }
    input[type="number"] { -moz-appearance: textfield; appearance: textfield; }
    input[type="number"]::-webkit-outer-spin-button, input[type="number"]::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

    .token-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
    .token-row > input { flex: 1 1 96px; min-width: 0; }
    .token-row > .btn { flex: 0 0 auto; padding: 0 9px; gap: 5px; }
    .token-row > .btn.ic::before { width: 14px; height: 14px; }

    /* «الجلسة»: the account as a field with its picture */
    #account-name {
      padding-right: 31px;
      padding-left: 9px;
      font-weight: 500;
      background: var(--surface-2) no-repeat right 11px center / 16px;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2398a2b3' stroke-width='2' stroke-linecap='round'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/svg%3E");
      cursor: default;
    }
    #account-settings { width: var(--h); padding: 0; gap: 0; font-size: 0; }
    #account-settings::before { width: 16px; height: 16px; }
    #account-settings[aria-expanded="true"] { background: var(--brand-soft); border-color: var(--brand-line); }
    #account-settings[aria-expanded="true"]::before { color: var(--brand); }
    .session-account { margin-top: 8px; font-size: 12px; color: var(--text-3); }
    #account-panel { margin-top: 2px; }

    /* «القروب» */
    .groups-row > #groups-button { flex: 1 1 auto; }
    .wait-groups {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      height: var(--h);
      padding: 0 10px;
      border: 1px solid var(--line-2);
      border-radius: var(--r);
      background: var(--surface);
      box-shadow: var(--sh-1);
      font-size: 12px;
      color: var(--text-2);
      white-space: nowrap;
    }
    .wait-groups input[type="checkbox"] {
      -webkit-appearance: none;
      appearance: none;
      position: relative;
      flex: none;
      width: 28px;
      height: 16px;
      margin: 0;
      border-radius: 999px;
      background: var(--line-2);
      transition: background 0.18s;
      cursor: pointer;
    }
    .wait-groups input[type="checkbox"]::after {
      content: "";
      position: absolute;
      top: 2px;
      right: 2px;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #fff;
      box-shadow: 0 1px 2px rgba(16, 24, 40, 0.25);
      transition: transform 0.18s var(--ease);
    }
    .wait-groups input[type="checkbox"]:checked { background: var(--brand); }
    .wait-groups input[type="checkbox"]:checked::after { transform: translateX(-12px); }
    input.wait-sec {
      width: 38px;
      min-height: 24px;
      height: 24px;
      padding: 0 4px;
      border-radius: 7px;
      text-align: center;
      font-size: 12.5px;
      font-weight: 600;
      font-variant-numeric: tabular-nums;
      box-shadow: none;
    }
    .links-button[aria-pressed="true"] { background: var(--brand-soft); border-color: var(--brand-line); color: var(--brand-2); }
    .links-button[aria-pressed="true"].ic::before { color: var(--brand); }

    #group-box { margin-top: 8px; }
    #group-box .field-label { margin-top: 0; }
    .saved-list { list-style: none; margin: 0; padding: 0; }
    #group-list {
      display: grid;
      grid-auto-flow: column;
      grid-auto-columns: max-content;
      gap: 6px;
      overflow-x: auto;
      overscroll-behavior-x: contain;
      scrollbar-width: none;
      padding: 1px 1px 3px;
      scroll-snap-type: x proximity;
    }
    #group-list::-webkit-scrollbar { display: none; }
    #group-list li { scroll-snap-align: start; }
    .pick {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      max-width: 72vw;
      height: 32px;
      padding: 0 12px;
      border-radius: 999px;
      border: 1px solid var(--line-2);
      background: var(--surface);
      color: var(--text-2);
      font-size: 12.5px;
      font-weight: 500;
      box-shadow: var(--sh-1);
      transition: background 0.15s, color 0.15s, border-color 0.15s;
    }
    .pick .who { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .pick.is-on {
      color: #fff;
      border-color: transparent;
      background: linear-gradient(180deg, #4a74ff, var(--brand));
      box-shadow: 0 6px 14px -8px rgba(47, 91, 234, 0.9);
    }
    .pick.is-on::before {
      content: "";
      width: 13px;
      height: 13px;
      background: currentColor;
      -webkit-mask: var(--ic-check) center / contain no-repeat;
      mask: var(--ic-check) center / contain no-repeat;
    }
    .pick .meta { font-size: 11px; color: var(--text-3); }

    .links-box { margin-top: 8px; }
    #tweet-links {
      display: block;
      min-height: 112px;
      padding: 9px 11px;
      resize: vertical;
      line-height: 1.6;
      direction: ltr;
      text-align: left;
      font-family: var(--mono);
      font-size: 12px;
    }
    #tweet-links:placeholder-shown { direction: rtl; text-align: right; font-family: var(--font); }
    .links-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 6px; font-size: 12px; color: var(--text-3); }
    .links-foot .btn { min-height: 30px; padding: 0 10px; font-size: 12px; }
    #links-count.is-bad { color: var(--bad); font-weight: 500; }

    .stop-row { position: relative; margin-top: 8px; }
    .stop-row::before {
      content: "";
      position: absolute;
      top: 50%;
      right: 11px;
      width: 16px;
      height: 16px;
      margin-top: -8px;
      background: var(--text-4);
      -webkit-mask: var(--ic-target) center / contain no-repeat;
      mask: var(--ic-target) center / contain no-repeat;
      pointer-events: none;
    }
    .stop-row input { padding-right: 34px; }

    /* ------------------------------------------------------------------ «الإجراءات»: four tiles */
    .choices { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 6px; }
    .choice {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 5px;
      min-height: 56px;
      padding: 7px 4px 6px;
      border-radius: 13px;
      border: 1px solid var(--line);
      background: var(--surface-2);
      color: var(--text-3);
      text-align: center;
      transition: background 0.18s, border-color 0.18s, color 0.18s, box-shadow 0.18s, transform 0.12s var(--ease);
    }
    .choice:active { transform: scale(0.97); }
    .choice > input {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      margin: 0;
      opacity: 0;
      cursor: pointer;
    }
    .choice > .i { width: 19px; height: 19px; transition: transform 0.25s var(--ease); }
    .choice-title { font-size: 11.5px; font-weight: 500; line-height: 1.2; white-space: nowrap; }
    .choice:has(input:focus-visible) { outline: 2px solid var(--brand); outline-offset: 2px; }
    .choices .choice:has(input:checked) {
      background: var(--surface);
      border-color: var(--tint, var(--brand));
      color: var(--text);
      box-shadow: 0 0 0 1px var(--tint, var(--brand)) inset, 0 8px 18px -12px var(--tint, var(--brand));
    }
    .choices .choice:has(input:checked) > .i { color: var(--tint, var(--brand)); transform: scale(1.08); }
    .choices .choice::after {
      content: "";
      position: absolute;
      top: 5px;
      left: 5px;
      width: 14px;
      height: 14px;
      border-radius: 50%;
      border: 1.5px solid var(--line-2);
      background: var(--surface);
      transition: background 0.18s, border-color 0.18s;
    }
    .choices .choice:has(input:checked)::after {
      border-color: var(--tint, var(--brand));
      background: var(--tint, var(--brand)) center / 9px no-repeat;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='3.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 6 9 17l-5-5'/%3E%3C/svg%3E");
    }
    .c-repost { --tint: var(--c-repost); }
    .c-like { --tint: var(--c-like); }
    .c-bookmark { --tint: var(--c-bookmark); }
    .c-comment { --tint: var(--c-comment); }

    .reply-voice { display: flex; align-items: center; gap: 10px; margin-top: 10px; }
    .voice-label { font-size: 12px; font-weight: 500; color: var(--text-2); white-space: nowrap; }
    .voices {
      flex: 1;
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 3px;
      padding: 3px;
      border-radius: 11px;
      background: var(--surface-3);
    }
    .voices .choice {
      min-height: 30px;
      padding: 0 6px;
      flex-direction: row;
      border: 0;
      border-radius: 8px;
      background: transparent;
      color: var(--text-3);
    }
    .voices .choice::after { display: none; }
    .voices .choice:has(input:checked) {
      background: var(--surface);
      color: var(--text);
      box-shadow: var(--sh-1), 0 0 0 1px var(--line);
    }
    .voices .choice-title { font-size: 12px; }

    .engine-note, .claude-now, .gemini-owner { display: block; margin-top: 8px; font-size: 11.5px; color: var(--text-3); }
    #show-gemini, #show-claude { margin-top: 8px; }
    .gemini-edit { min-height: 30px; padding: 0 10px; font-size: 12px; }
    .gemini-fields {
      display: grid;
      gap: 2px;
      margin-top: 10px;
      padding: 10px 11px 11px;
      border-radius: 12px;
      border: 1px dashed var(--line-2);
      background: var(--surface-2);
    }
    .gemini-fields .field-label { margin-top: 4px; }
    .claude-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin-top: 8px; }

    /* ------------------------------------------------------------------ tasks, progress */
    #task-list { display: grid; gap: 8px; margin-top: 10px; }
    .task-card {
      position: relative;
      overflow: hidden;
      padding: 11px 12px 11px 11px;
      border: 1px solid var(--line);
      border-radius: 14px;
      background: var(--surface);
      animation: rise 0.35s var(--ease) both;
    }
    .task-card::before {
      content: "";
      position: absolute;
      inset-block: 0;
      inset-inline-start: 0;
      width: 3px;
      background: var(--state, var(--brand));
    }
    .task-card[data-status="done"] { --state: var(--ok); }
    .task-card[data-status="failed"] { --state: var(--bad); }
    .task-card[data-status="stopped"], .task-card[data-status="interrupted"] { --state: #f79009; }
    .task-card h3 { font-size: 13px; font-weight: 600; line-height: 1.4; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .progress-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
    .progress-top > div:first-child { min-width: 0; flex: 1; }
    .task-phase {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 500;
      color: var(--brand-2);
      background: var(--brand-soft);
    }
    .task-phase::before {
      content: "";
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: currentColor;
    }
    .task-card[data-status="running"] .task-phase::before { animation: live 2s var(--ease) infinite; box-shadow: 0 0 0 0 rgba(47, 91, 234, 0.55); }
    .task-card[data-status="done"] .task-phase { color: var(--ok); background: var(--ok-soft); }
    .task-card[data-status="failed"] .task-phase { color: var(--bad); background: var(--bad-soft); }
    .task-card[data-status="stopped"] .task-phase, .task-card[data-status="interrupted"] .task-phase { color: var(--warn); background: var(--warn-soft); }
    .task-msg { margin-top: 5px; font-size: 12px; line-height: 1.55; color: var(--text-3); }
    .task-count {
      flex: none;
      direction: ltr;
      font-size: 17px;
      font-weight: 600;
      line-height: 1.2;
      font-variant-numeric: tabular-nums;
      color: var(--text);
    }
    .task-card .meter { margin-top: 9px; }
    .task-actions { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 9px; }
    .task-actions:not(:has(.btn:not([hidden]))) { display: none; }
    .task-actions .btn { min-height: 30px; padding: 0 10px; font-size: 12px; border-radius: 9px; }
    .task-actions .btn.ic::before { width: 13px; height: 13px; }
    .task-stop { color: var(--bad) !important; border-color: var(--bad-line) !important; background: var(--bad-soft) !important; box-shadow: none !important; }
    .task-stop.ic::before { color: var(--bad) !important; }
    .task-retry { color: var(--brand-2); background: var(--brand-soft); border-color: var(--brand-line); }
    .task-retry-failed { color: var(--warn); background: var(--warn-soft); border-color: var(--warn-line); }

    .meter {
      position: relative;
      overflow: hidden;
      height: 6px;
      border-radius: 999px;
      background: var(--surface-3);
    }
    .meter > span {
      display: block;
      height: 100%;
      width: 0;
      border-radius: inherit;
      background: linear-gradient(90deg, var(--brand-3), var(--brand));
      transition: width 0.45s var(--ease);
    }
    .meter.is-indeterminate > span {
      width: 38% !important;
      animation: slide 1.25s var(--ease) infinite;
    }
    #progress-panel .progress-top h2 { font-size: 14px; }
    #progress-panel .progress-top p { margin-top: 3px; font-size: 12px; color: var(--text-3); }
    .progress-figure { flex: none; direction: ltr; display: flex; align-items: baseline; gap: 2px; }
    .figure { font-size: 26px; line-height: 1; font-weight: 600; font-variant-numeric: tabular-nums; color: var(--text); }
    .denom { font-size: 13px; color: var(--text-3); font-variant-numeric: tabular-nums; }
    #progress-panel .meter { height: 8px; margin-top: 10px; }
    .progress-note { margin-top: 8px; font-size: 11.5px; color: var(--text-3); }

    /* ------------------------------------------------------------------ results */
    .stats { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; margin-top: 10px; }
    .stat {
      display: grid;
      gap: 1px;
      padding: 8px 10px;
      border-radius: 12px;
      border: 1px solid var(--line);
      background: var(--surface-2);
    }
    .stat b { font-size: 18px; line-height: 1.2; font-weight: 600; font-variant-numeric: tabular-nums; }
    .stat span { font-size: 11px; color: var(--text-3); }
    .stat:nth-child(1) { background: var(--ok-soft); border-color: var(--ok-line); }
    .stat:nth-child(1) b { color: var(--ok); }
    .stat:nth-child(3) { background: var(--bad-soft); border-color: var(--bad-line); }
    .stat:nth-child(3) b { color: var(--bad); }
    .post-list { list-style: none; margin: 10px 0 0; padding: 0; display: grid; gap: 6px; }
    .post-list li {
      padding: 9px 10px;
      border-radius: 12px;
      border: 1px solid var(--line);
      background: var(--surface);
      content-visibility: auto;
      contain-intrinsic-size: auto 72px;
    }
    .post-top { display: flex; align-items: center; gap: 8px; min-width: 0; }
    .idx {
      display: grid;
      place-items: center;
      flex: none;
      min-width: 22px;
      height: 22px;
      padding: 0 5px;
      border-radius: 7px;
      background: var(--surface-3);
      color: var(--text-3);
      font-size: 11px;
      font-weight: 600;
      font-variant-numeric: tabular-nums;
    }
    .post-list a {
      min-width: 0;
      direction: ltr;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: 12px;
      font-weight: 500;
      color: var(--brand);
      text-decoration: none;
    }
    .pills { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 7px; }
    .pill {
      display: inline-flex;
      align-items: center;
      min-height: 22px;
      padding: 1px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 500;
      line-height: 1.5;
      border: 1px solid transparent;
    }
    .pill.is-will { color: var(--ok); background: var(--ok-soft); border-color: var(--ok-line); }
    .pill.is-skip { color: var(--text-3); background: var(--surface-3); }
    .pill.is-fail { color: var(--bad); background: var(--bad-soft); border-color: var(--bad-line); }
    .excerpt {
      margin-top: 7px;
      padding: 6px 10px;
      border-radius: 9px;
      border-inline-start: 3px solid var(--brand-line);
      background: var(--surface-2);
      font-size: 12px;
      line-height: 1.65;
      color: var(--text-2);
    }

    /* ------------------------------------------------------------------ messages */
    .notice {
      position: fixed;
      z-index: 70;
      inset-inline: 12px;
      bottom: calc(14px + env(safe-area-inset-bottom));
      margin: 0 auto;
      max-width: 536px;
      display: flex;
      align-items: flex-start;
      gap: 9px;
      padding: 11px 13px;
      border-radius: 14px;
      background: #101828;
      color: #f2f4f7;
      font-size: 12.5px;
      line-height: 1.6;
      box-shadow: var(--sh-3);
      animation: toast 0.28s var(--ease) both;
      cursor: pointer;
    }
    .notice::before {
      content: "";
      flex: none;
      width: 17px;
      height: 17px;
      margin-top: 1px;
      background: #32d583;
      -webkit-mask: var(--ic-ok) center / contain no-repeat;
      mask: var(--ic-ok) center / contain no-repeat;
    }
    .notice.is-bad::before { background: #f97066; -webkit-mask-image: var(--ic-alert); mask-image: var(--ic-alert); }
    .notice.is-out { animation: toast-out 0.2s ease-in both; }

    .net-banner {
      position: fixed;
      z-index: 75;
      top: calc(8px + env(safe-area-inset-top));
      left: 50%;
      transform: translateX(-50%);
      display: inline-flex;
      align-items: center;
      gap: 8px;
      max-width: calc(100% - 24px);
      padding: 7px 13px;
      border-radius: 999px;
      background: #101828;
      color: #fef0c7;
      font-size: 12px;
      font-weight: 500;
      white-space: nowrap;
      box-shadow: var(--sh-3);
      animation: drop 0.3s var(--ease) both;
    }
    .net-banner::before {
      content: "";
      width: 12px;
      height: 12px;
      border-radius: 50%;
      border: 2px solid #fdb022;
      border-inline-end-color: transparent;
      animation: spin 0.8s linear infinite;
    }

    .update-bar {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 9px 10px 9px 12px;
      border-radius: 14px;
      border: 1px solid var(--brand-line);
      background: linear-gradient(90deg, var(--brand-soft), var(--surface));
      box-shadow: var(--sh-2);
      font-size: 12.5px;
      font-weight: 500;
      color: var(--text);
      animation: rise 0.35s var(--ease) both;
    }
    .update-bar .ub-ic {
      display: grid;
      place-items: center;
      flex: none;
      width: 30px;
      height: 30px;
      border-radius: 10px;
      color: #fff;
      background: linear-gradient(135deg, #4a74ff, var(--brand-3));
    }
    .update-bar .ub-ic .i { width: 15px; height: 15px; }
    #update-text { flex: 1; min-width: 0; }
    .update-bar .btn { min-height: 32px; padding: 0 12px; font-size: 12px; }

    /* ------------------------------------------------------------------ sheets (dialogs) */
    .pc-backdrop {
      position: fixed;
      inset: 0;
      z-index: 80;
      display: flex;
      align-items: flex-end;
      justify-content: center;
      padding: 0;
      background: rgba(9, 14, 30, 0.52);
      animation: fade 0.2s ease-out both;
    }
    .usage-sheet, .pc-term {
      position: relative;
      width: min(560px, 100%);
      max-height: 88vh;
      max-height: 88dvh;
      overflow: auto;
      overscroll-behavior: contain;
      border-radius: 22px 22px 0 0;
      box-shadow: var(--sh-3);
      animation: sheet 0.32s var(--ease) both;
    }
    .usage-sheet {
      padding: 22px 16px calc(16px + env(safe-area-inset-bottom));
      background: var(--surface);
      color: var(--text);
    }
    .usage-sheet::before {
      content: "";
      position: absolute;
      top: 8px;
      left: 50%;
      width: 38px;
      height: 4px;
      margin-left: -19px;
      border-radius: 999px;
      background: var(--line-2);
    }
    .usage-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 6px; }
    .usage-head b { font-size: 15.5px; font-weight: 600; }
    .usage-x, .pc-x {
      display: grid;
      place-items: center;
      flex: none;
      width: 30px;
      height: 30px;
      padding: 0;
      border: 0;
      border-radius: 50%;
      background: var(--surface-3);
      color: var(--text-3);
      font-size: 0;
    }
    .usage-x::before, .pc-x::before {
      content: "";
      width: 14px;
      height: 14px;
      background: currentColor;
      -webkit-mask: var(--ic-x) center / contain no-repeat;
      mask: var(--ic-x) center / contain no-repeat;
    }
    .usage-note { margin-bottom: 12px; font-size: 12.5px; line-height: 1.7; color: var(--text-3); }
    .usage-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 12.5px; border: 1px solid var(--line); border-radius: 12px; overflow: hidden; }
    .usage-table th, .usage-table td { padding: 9px 11px; text-align: right; border-bottom: 1px solid var(--line); }
    .usage-table thead th { font-size: 11px; font-weight: 500; color: var(--text-3); background: var(--surface-2); }
    .usage-table tbody tr:last-child td { border-bottom: 0; }
    .usage-table tfoot th { font-weight: 600; background: var(--surface-2); border-top: 1px solid var(--line); border-bottom: 0; }
    .usage-table .num { text-align: left; direction: ltr; font-variant-numeric: tabular-nums; }
    .usage-table .who { font-weight: 500; }
    .usage-table .empty { padding: 18px; text-align: center; color: var(--text-3); }
    .usage-foot { display: flex; gap: 8px; margin-top: 14px; }
    .usage-foot .btn { flex: 1; min-height: 40px; }

    .guide-steps { list-style: none; margin: 4px 0 0; padding: 0; display: grid; gap: 0; }
    .guide-steps li { position: relative; display: flex; gap: 12px; padding-bottom: 14px; }
    .guide-steps li:not(:last-child)::before {
      content: "";
      position: absolute;
      top: 28px;
      bottom: 2px;
      right: 13px;
      width: 2px;
      border-radius: 2px;
      background: var(--brand-line);
    }
    .guide-steps b {
      display: grid;
      place-items: center;
      flex: none;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      color: #fff;
      font-size: 13px;
      font-weight: 600;
      background: linear-gradient(135deg, #4a74ff, var(--brand-3));
      box-shadow: 0 6px 12px -6px rgba(47, 91, 234, 0.8);
    }
    .guide-steps div { display: grid; gap: 2px; padding-top: 3px; }
    .guide-steps strong { font-size: 13.5px; font-weight: 600; }
    .guide-steps span { font-size: 12.5px; line-height: 1.7; color: var(--text-3); }

    .help-label { display: block; margin: 4px 0 6px; font-size: 12.5px; font-weight: 500; color: var(--text-2); }
    .help-text { min-height: 112px; padding: 10px 12px; line-height: 1.7; resize: vertical; }
    .help-attach {
      width: 100%;
      margin-top: 10px;
      border-style: dashed !important;
      border-color: var(--brand-line) !important;
      color: var(--brand-2) !important;
      background: var(--brand-soft) !important;
      box-shadow: none !important;
    }
    .help-attach.ic::before { color: var(--brand) !important; }
    .help-list { list-style: none; margin: 10px 0 0; padding: 0; display: grid; gap: 6px; }
    .help-list li {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 7px 8px;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: var(--surface-2);
    }
    .help-list .thumb { width: 40px; height: 40px; flex: none; border-radius: 9px; object-fit: cover; background: var(--surface-3); }
    .help-list .name { flex: 1; min-width: 0; display: grid; gap: 2px; font-size: 12px; font-weight: 500; overflow: hidden; }
    .help-list .name small { font-size: 11px; font-weight: 400; color: var(--text-3); }
    .help-list .bar { display: block; height: 4px; border-radius: 999px; background: var(--surface-3); overflow: hidden; }
    .help-list .bar i { display: block; height: 100%; width: 0; background: var(--brand); transition: width 0.2s; }
    .help-sheet .hint { margin-top: 8px; }
    .help-status { margin-top: 10px; padding: 8px 11px; border-radius: 10px; font-size: 12.5px; background: var(--brand-soft); color: var(--brand-2); }
    .help-status.is-bad { background: var(--bad-soft); color: var(--bad); }
    .help-status.is-ok { background: var(--ok-soft); color: var(--ok); }
    .help-open.ic::before { width: 13px; height: 13px; }

    /* «فحص قدرة الهاتف»: a terminal */
    .pc-term {
      display: flex;
      flex-direction: column;
      background: #0a0f1d;
      color: #d0d5dd;
      border: 1px solid #1d2742;
      border-bottom: 0;
    }
    .pc-bar {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 14px;
      border-bottom: 1px solid #1d2742;
      background: linear-gradient(180deg, #111a33, #0d1428);
    }
    .pc-bar b { flex: 1; font-size: 13px; font-weight: 600; color: #fff; }
    .pc-dots { display: inline-flex; gap: 6px; direction: ltr; }
    .pc-dots i { width: 10px; height: 10px; border-radius: 50%; background: #f97066; }
    .pc-dots i:nth-child(2) { background: #fdb022; }
    .pc-dots i:nth-child(3) { background: #32d583; }
    .pc-x { background: rgba(255, 255, 255, 0.08); color: #d0d5dd; }
    .pc-screen {
      flex: 1;
      min-height: 240px;
      max-height: 58vh;
      overflow: auto;
      padding: 12px 14px 16px;
      cursor: pointer;
      /* (monospace fonts with no Arabic first: digits and Latin text are monospaced, Arabic keeps the page's font) */
      font-family: "Liberation Mono", "Noto Sans Mono", "Droid Sans Mono", "SFMono-Regular", Menlo, Consolas, "Courier New", var(--font);
      font-size: 12.5px;
      line-height: 1.75;
      background: repeating-linear-gradient(0deg, rgba(255, 255, 255, 0.018) 0 1px, transparent 1px 3px), #0a0f1d;
    }
    .pc-line { white-space: pre-wrap; overflow-wrap: anywhere; }
    .pc-line .pc-p { color: #6b8cff; }
    .pc-line.is-dim { color: #7c8aa5; padding-inline-start: 1.4em; }
    .pc-line.is-head { color: #fff; font-weight: 600; margin-top: 6px; }
    .pc-tag { display: inline-block; margin-inline-start: 6px; padding: 0 6px; border-radius: 5px; font-size: 10.5px; font-weight: 600; }
    .pc-tag.is-ok { color: #32d583; background: rgba(50, 213, 131, 0.12); }
    .pc-tag.is-warn { color: #fdb022; background: rgba(253, 176, 34, 0.12); }
    .pc-tag.is-bad { color: #f97066; background: rgba(249, 112, 102, 0.12); }
    .pc-cursor { display: inline-block; width: 7px; height: 13px; margin-left: 2px; vertical-align: -2px; background: #6b8cff; animation: blink 1s steps(2, start) infinite; }
    .pc-final {
      display: flex;
      align-items: center;
      gap: 12px;
      margin: 12px 0 4px;
      padding: 10px 12px;
      border-radius: 12px;
      background: rgba(50, 213, 131, 0.1);
      border: 1px solid rgba(50, 213, 131, 0.25);
      font-family: var(--font);
      font-size: 12.5px;
      color: #d1fadf;
    }
    .pc-final b { flex: none; font-size: 28px; line-height: 1; font-weight: 600; color: #32d583; }
    .pc-final.is-mid, .pc-final.is-mid b { color: #fdb022; }
    .pc-final.is-mid { background: rgba(253, 176, 34, 0.1); border-color: rgba(253, 176, 34, 0.25); }
    .pc-final.is-low, .pc-final.is-low b { color: #f97066; }
    .pc-final.is-low { background: rgba(249, 112, 102, 0.1); border-color: rgba(249, 112, 102, 0.25); }
    .pc-final span { font-size: 13px; font-weight: 600; line-height: 1.6; }
    .pc-actions { display: flex; gap: 8px; padding: 12px 14px calc(14px + env(safe-area-inset-bottom)); border-top: 1px solid #1d2742; }
    .pc-btn {
      flex: 1;
      min-height: 40px;
      border: 1px solid #2a3656;
      border-radius: 11px;
      background: #141d36;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      transition: transform 0.12s var(--ease), background 0.15s;
    }
    .pc-btn:active { transform: scale(0.97); background: #1b2645; }

    /* ------------------------------------------------------------------ accounts (in an ordinary browser) */
    .accounts-bar { display: flex; flex-wrap: wrap; gap: 6px; }
    .acct-chip, .acct-add {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      height: 32px;
      padding: 0 8px 0 12px;
      border-radius: 999px;
      border: 1px solid var(--line-2);
      background: var(--surface);
      color: var(--text-2);
      font-size: 12.5px;
      font-weight: 500;
      box-shadow: var(--sh-1);
    }
    .acct-chip.is-on { background: var(--brand-soft); border-color: var(--brand-line); color: var(--brand-2); }
    .acct-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--line-2); }
    .acct-chip.is-on .acct-dot { background: var(--brand); }
    .acct-chip.is-running .acct-dot { background: #12b76a; animation: live 2s var(--ease) infinite; box-shadow: 0 0 0 0 rgba(18, 183, 106, 0.6); }
    .acct-who { max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; direction: ltr; }
    .acct-x { display: grid; place-items: center; width: 20px; height: 20px; border-radius: 50%; color: var(--text-4); font-size: 14px; line-height: 1; }
    .acct-x:hover { background: var(--surface-3); color: var(--bad); }
    .acct-add { padding: 0 12px; border-style: dashed; border-color: var(--brand-line); color: var(--brand-2); background: var(--brand-soft); box-shadow: none; }
    .acct-add:disabled { opacity: 0.5; }
    .acct-empty { font-size: 12px; color: var(--text-3); }

    /* ------------------------------------------------------------------ footer */
    .version-line {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: center;
      gap: 6px 10px;
      margin-top: 2px;
      font-size: 11px;
      color: var(--text-4);
    }
    .version-line > span:first-child { font-variant-numeric: tabular-nums; }
    #update-state:empty { display: none; }
    .tool-link {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      height: 26px;
      padding: 0 10px;
      border: 1px solid var(--line);
      border-radius: 999px;
      background: var(--surface);
      color: var(--text-3);
      font-size: 11px;
      font-weight: 500;
    }
    .tool-link.ic::before { width: 12px; height: 12px; }
    .tool-link:active { transform: scale(0.97); }

    /* ------------------------------------------------------------------ motion */
    .mast, #repost-form { animation: rise 0.42s var(--ease) both; }
    #repost-form { animation-delay: 0.05s; }
    @keyframes rise { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
    @keyframes fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes sheet { from { transform: translateY(24px); opacity: 0.6; } to { transform: none; opacity: 1; } }
    @keyframes toast { from { opacity: 0; transform: translateY(14px) scale(0.98); } to { opacity: 1; transform: none; } }
    @keyframes toast-out { to { opacity: 0; transform: translateY(10px); } }
    @keyframes drop { from { opacity: 0; transform: translate(-50%, -10px); } to { opacity: 1; transform: translate(-50%, 0); } }
    @keyframes spin { to { transform: rotate(360deg); } }
    @keyframes blink { to { visibility: hidden; } }
    @keyframes live { 0% { box-shadow: 0 0 0 0 rgba(50, 213, 131, 0.55); } 70% { box-shadow: 0 0 0 6px rgba(50, 213, 131, 0); } 100% { box-shadow: 0 0 0 0 rgba(50, 213, 131, 0); } }
    @keyframes slide { from { transform: translateX(170%); } to { transform: translateX(-270%); } }

    /* ------------------------------------------------------------------ wider screens (the owner's browser) */
    @media (min-width: 760px) {
      body { font-size: 14.5px; }
      .page { padding-top: 28px; gap: 12px; }
      .pc-backdrop { align-items: center; padding: 24px; }
      .usage-sheet, .pc-term { border-radius: 20px; }
      .pc-term { border-bottom: 1px solid #1d2742; }
      .usage-sheet::before { display: none; }
    }
    @media (max-width: 379px) {
      #session-block .token-row > input { flex-basis: 100%; }
      #session-block .token-row > .btn:not(#account-settings) { flex: 1 1 0; }
      #groups-button::before { display: none; }
      .groups-row .btn { padding: 0 9px; }
      .wait-groups { padding: 0 8px; gap: 5px; }
    }
    @media (max-width: 359px) {
      .page { padding-inline: 8px; }
      .kpi { padding: 6px; }
      .kpi b { font-size: 15px; }
      .choice-title { font-size: 10.5px; }
      .chip { padding: 0 8px; font-size: 11px; }
    }
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { animation: none !important; transition: none !important; }
    }
  </style>
</head>
<body{% if in_app %} data-app="1"{% endif %}>
  {% if owner_copy %}<button id="cost-reset" class="cost-reset" type="button" tabindex="-1" aria-hidden="true"></button>{% endif %}
  <main class="page">
    <header class="mast">
      <div class="brand">
        <span class="mark" aria-hidden="true"><i class="i i-zap"></i></span>
        <div class="brand-text">
          <p class="eyebrow">من قروب الدردشة <span id="net-state" class="net" data-state="ok" role="status" aria-live="polite"><i aria-hidden="true"></i><span id="net-text">متصل</span></span></p>
          <h1>تنفيذ على تغريدات القروب</h1>
        </div>
      </div>
      <ol class="counts" aria-label="الإجراءات الناجحة">
        <li class="kpi k-repost"><i class="i i-repeat" aria-hidden="true"></i><b id="count-repost">0</b><span class="kpi-label">الرتويت</span></li>
        <li class="kpi k-like"><i class="i i-heart" aria-hidden="true"></i><b id="count-like">0</b><span class="kpi-label">الإعجاب</span></li>
        <li class="kpi k-bookmark"><i class="i i-bookmark" aria-hidden="true"></i><b id="count-bookmark">0</b><span class="kpi-label">المرجعية</span></li>
        <li class="kpi k-comment"><i class="i i-msg" aria-hidden="true"></i><b id="count-comment">0</b><span class="kpi-label">التعليقات</span></li>
      </ol>
      <div class="mast-links">
        {% if not tweets_in_content %}<a class="chip ic i-list" href="{{ api_root }}/tweets">عرض التغريدات</a>{% endif %}
        {% if content_ready %}<a class="chip ic i-sparkle" href="{{ api_root }}/content">إنشاء محتوى</a>{% endif %}
        <button id="usage-pill" class="chip usage-pill ic i-msg" type="button" aria-haspopup="dialog" title="التعليقات والتكلفة لكل حساب">
          <span id="usage-count">التعليقات (0)</span>
          <bdi id="usage-cost" class="usage-cost" dir="ltr">$0.00</bdi>
        </button>
        {% if control_on and not in_app %}<button id="help-open" class="chip help-open ic i-headset" type="button" aria-haspopup="dialog">مساعدة</button>{% endif %}
      </div>
    </header>
    <p class="lede">يُفتح تبويب إعادات النشر ويُمرَّر حتى يكتمل العدد أو ينتهي الخط. ترى حالة كل إجراء، ثم تقرر. لا يُمس الحساب قبل «تأكيد التنفيذ».</p>

    <div id="update-bar" class="update-bar" role="status" hidden>
      <span class="ub-ic" aria-hidden="true"><i class="i i-download"></i></span>
      <span id="update-text"></span>
      <button id="update-button" class="btn btn-pine" type="button">تحديث</button>
    </div>

    <div id="notice" class="notice" role="status" aria-live="polite" hidden></div>
    <div id="net-banner" class="net-banner" role="status" hidden>جارٍ إعادة الاتصال بالبرنامج…</div>

    <form id="repost-form" class="sheet" autocomplete="off" novalidate>
      <div class="sheet-inner">
        <input id="csrf_token" type="hidden" value="{{ csrf_token }}">
        <section class="block accounts-block">
          <div class="block-head">
            <h2><span class="sec" aria-hidden="true"><i class="i i-users"></i></span>الحسابات</h2>
            <p>حتى {{ max_accounts }} حسابات. لكل حساب مهمّته الخاصة، وتعمل المهام في الوقت نفسه.</p>
          </div>
          <div id="accounts-bar" class="accounts-bar" role="tablist" aria-label="الحسابات"></div>
        </section>

        <section id="session-block" class="block">
          <div class="block-head">
            <h2 id="session-title"><span class="sec" aria-hidden="true"><i class="i i-user"></i></span>الجلسة</h2>
            <p>سجّل الدخول من المتصفح، ثم اضغط تحقق. تُحفظ الجلسة مع اسم الحساب على هذا الجهاز.</p>
          </div>
          <div class="token-row">
            <input id="account-name" type="text" readonly tabindex="-1" dir="auto" placeholder="الحساب" aria-label="الحساب">
            <button id="quick-verify" class="btn btn-ghost ic i-shield" type="button">تحقق</button>
            {% if in_app %}<button id="browser-login" class="btn btn-ghost ic i-login" type="button">تسجيل الدخول</button>{% endif %}
            <button id="account-settings" class="btn btn-ghost ic i-sliders" type="button" aria-expanded="false" aria-controls="account-panel" title="إعداد الحساب">إعداد الحساب</button>
          </div>
          <div id="account-panel" hidden>
            <input id="auth_token" name="auth_token" type="hidden" value="">
            <p id="session-account" class="session-account" hidden></p>
            <div id="saved-sessions" class="saved-sessions" hidden>
              <p class="field-label">الحساب المحفوظ</p>
              <ul id="saved-session-list" class="saved-list"></ul>
            </div>
            <label class="field-label" for="chat-pin">رمز الدردشة</label>
            <input id="chat-pin" name="chat_pin" type="password" inputmode="numeric" maxlength="8" required
                   autocomplete="off" spellcheck="false" placeholder="٤ أرقام" aria-label="رمز الدردشة">
          </div>
        </section>

        <section class="block">
          <div class="block-head">
            <h2><span class="sec" aria-hidden="true"><i class="i i-hash"></i></span>القروب</h2>
            <p>يُفتح صندوق الدردشة، وتُعرض القروبات فقط. اختر واحدًا ثم العدد.</p>
          </div>
          <div class="token-row groups-row">
            <button id="groups-button" class="btn btn-ghost ic i-hash" type="button">عرض القروبات</button>
            <label id="wait-groups-label" class="wait-groups" for="wait-groups">
              <input id="wait-groups" type="checkbox" checked>
              انتظار
              <input id="wait-groups-sec" class="wait-sec" type="number" min="1" max="120" step="1" value="30" inputmode="numeric" aria-label="ثواني الانتظار قبل التقاط القروبات">
              ث
            </label>
            <button id="links-button" class="btn btn-ghost links-button ic i-link" type="button" aria-pressed="false" aria-controls="links-box" title="روابط التغريدات" aria-label="روابط التغريدات">الروابط</button>
          </div>
          <div id="group-box" class="saved-sessions" hidden>
            <p class="field-label">اختر قروبًا</p>
            <ul id="group-list" class="saved-list"></ul>
          </div>
          <div id="links-box" class="links-box" hidden>
            <textarea id="tweet-links" rows="5" maxlength="200000" autocomplete="off" autocapitalize="off" spellcheck="false"
                      placeholder="الصق روابط التغريدات هنا، كل رابط في سطر" aria-label="روابط التغريدات"></textarea>
            <div class="links-foot">
              <span id="links-count" aria-live="polite"></span>
              <button id="links-clear" class="btn btn-ghost ic i-x" type="button">مسح</button>
            </div>
          </div>
          <div id="stop-row" class="stop-row">
            <input id="stop-tweet" name="stop_tweet" type="text" maxlength="300" autocomplete="off" spellcheck="false"
                   placeholder="رابط التغريدة المحددة" aria-label="التغريدة المحددة">
          </div>
        </section>

        <section class="block">
          <div class="block-head">
            <h2><span class="sec" aria-hidden="true"><i class="i i-zap"></i></span>الإجراءات</h2>
            <p>تُطبَّق مباشرة على التغريدات المستخرجة من القروب.</p>
          </div>
          <div class="choices" role="group" aria-label="الإجراءات">
            <label class="choice c-repost" title="فقط إذا لم تكن الإعادة مفعّلة."><input id="action-repost" type="checkbox" checked><i class="i i-repeat" aria-hidden="true"></i><span class="choice-title">إعادة النشر</span></label>
            <label class="choice c-like" title="فقط إذا لم يكن الإعجاب موجودًا."><input id="action-like" type="checkbox" checked><i class="i i-heart" aria-hidden="true"></i><span class="choice-title">إعجاب</span></label>
            <label class="choice c-bookmark" title="فقط إذا لم يكن المنشور محفوظًا."><input id="action-bookmark" type="checkbox" checked><i class="i i-bookmark" aria-hidden="true"></i><span class="choice-title">المرجعية</span></label>
            <label class="choice c-comment" title="يُنشر رد على التغريدة المستخرجة."><input id="action-comment" type="checkbox"><i class="i i-msg" aria-hidden="true"></i><span class="choice-title">التعليقات</span></label>
          </div>
          <div id="reply-voice" class="reply-voice" hidden>
            <span class="voice-label">صيغة الرد</span>
            <div class="voices" role="radiogroup" aria-label="صيغة الرد">
              <label class="choice"><input type="radio" name="reply-voice" value="male" checked><span class="choice-title">مذكر</span></label>
              <label class="choice"><input type="radio" name="reply-voice" value="female"><span class="choice-title">مؤنث</span></label>
              <label class="choice"><input type="radio" name="reply-voice" value="neutral"><span class="choice-title">عام</span></label>
            </div>
            {% if owner_copy %}<button id="show-gemini" class="btn btn-ghost gemini-edit ic i-key" type="button" aria-expanded="false" hidden>مفتاح Gemini</button>
            {% if claude_here %}<button id="show-claude" class="btn btn-ghost gemini-edit ic i-key" type="button" aria-expanded="false" hidden>مفتاح Claude</button>
            <span id="comments-by-grok" class="engine-note" hidden>التعليقات بواسطة Claude، بالمفتاح المحفوظ في «مفتاح Claude».</span>
            {% else %}<span id="comments-by-grok" class="engine-note" data-text="التعليقات بواسطة {engine}، كما اخترت للمستخدمين في «توزيع البرنامج»." hidden>التعليقات بواسطة Grok، كما اخترت للمستخدمين في «توزيع البرنامج».</span>{% endif %}{% endif %}
          </div>
          <div id="gemini-fields" class="gemini-fields" hidden>
            {% if not owner_copy %}<p class="gemini-owner">يضبط صاحب البرنامج مفتاح التعليقات ونموذجها.</p>{% endif %}
            <div>
              <label class="field-label" for="gemini-key">مفتاح Gemini</label>
              <input id="gemini-key" type="password" maxlength="256" autocomplete="off" spellcheck="false" readonly
                     placeholder="المفتاح" aria-label="مفتاح Gemini API">
            </div>
            <div>
              <label class="field-label" for="gemini-model">النموذج</label>
              <div class="token-row">
                <input id="gemini-model" type="text" maxlength="80" autocomplete="off" spellcheck="false" readonly
                       value="gemini-3.5-flash" placeholder="gemini-3.5-flash" aria-label="نموذج Gemini">
                <button id="edit-gemini" class="btn btn-ghost gemini-edit" type="button" aria-pressed="false">تحرير</button>
              </div>
            </div>
            <p class="hint">يُحفظ المفتاح واسم النموذج على هذا الخادم بعد أول إدخال، ويظهران تلقائيًا حتى بعد إغلاق الصفحة أو إعادة تشغيل السكربت.</p>
          </div>
          {% if claude_here %}<div id="claude-fields" class="gemini-fields" hidden>
            <div>
              <label class="field-label" for="claude-key">مفتاح Claude</label>
              <input id="claude-key" type="password" maxlength="260" autocomplete="off" spellcheck="false" placeholder="المفتاح" aria-label="مفتاح Claude API">
            </div>
            <div>
              <label class="field-label" for="claude-model">النموذج</label>
              <input id="claude-model" type="text" maxlength="60" autocomplete="off" spellcheck="false" value="{{ claude_default }}" placeholder="{{ claude_default }}" aria-label="نموذج Claude">
            </div>
            <div class="claude-actions">
              <button id="save-claude" class="btn btn-ghost gemini-edit" type="button">حفظ</button>
              <button id="delete-claude" class="btn btn-ghost gemini-edit" type="button" hidden>حذف</button>
              <span id="claude-now" class="claude-now">بدون مفتاح Claude تُكتب التعليقات بواسطة Gemini.</span>
            </div>
          </div>{% endif %}
          <button id="reposts-button" class="btn btn-pine btn-wide ic i-play" type="submit">تنفيذ</button>
        </section>
      </div>
    </form>

    <section id="task-board" class="sheet" hidden>
      <div class="sheet-inner">
        <h2><span class="sec" aria-hidden="true"><i class="i i-layers"></i></span>المهام</h2>
        <div id="task-list"></div>
      </div>
    </section>

    <section id="progress-panel" class="sheet" hidden>
      <div class="sheet-inner">
        <div class="progress-top">
          <div>
            <h2 id="progress-title">الجمع</h2>
            <p id="progress-message">جارٍ العمل…</p>
          </div>
          <div class="progress-figure" aria-hidden="true">
            <span id="progress-count" class="figure">0</span>
            <span id="progress-denom" class="denom"></span>
          </div>
        </div>
        <div id="meter" class="meter is-indeterminate" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="تقدم العملية">
          <span id="meter-bar"></span>
        </div>
        <p id="progress-note" class="progress-note">لا يُنفَّذ أي إجراء خلال الجمع.</p>
      </div>
    </section>

    <section id="repost-results" class="sheet" hidden>
      <div class="sheet-inner">
        <h2 id="repost-heading"><span class="sec" aria-hidden="true"><i class="i i-chart"></i></span>نتيجة التنفيذ</h2>
        <div class="stats" id="result-stats"></div>
        <ol id="repost-list" class="post-list"></ol>
        <p id="no-reposts" class="hint" hidden>لم تُرجع العملية أي صفوف.</p>
      </div>
    </section>

    <p class="version-line">
      <span>الإصدار {{ app_version }}</span>
      <span id="update-state"></span>
      <a id="dist-link" class="link-button" target="_blank" rel="noopener" hidden>توزيع البرنامج</a>
      <button id="phone-check" class="tool-link ic i-activity" type="button">فحص قدرة الهاتف</button>
    </p>

    <p class="footnote">الأعداد الكبيرة تأخذ وقتًا لأن كل دفعة تُنتظر حتى تظهر. إذا أغلقت المتصفح أثناء العملية فافتح الصفحة نفسها لاحقًا: يظهر التقدم من حيث بلغ، أو النتيجة إن اكتملت. الجلسات المحفوظة تبقى بعد إعادة تشغيل السكربت.</p>
  </main>
<div id="login-guide" class="pc-backdrop" hidden>
  <div class="usage-sheet guide-sheet" role="dialog" aria-modal="true" aria-labelledby="guide-title">
    <div class="usage-head">
      <b id="guide-title">قبل أن تبدأ تسجيل الدخول</b>
      <button id="guide-close" class="usage-x" type="button" aria-label="إغلاق">×</button>
    </div>
    <p class="usage-note">سيُفتح تبويب «المتصفح». اتبع هذه الخطوات بالترتيب:</p>
    <ol class="guide-steps">
      <li><b>1</b><div><strong>سجّل الدخول إلى حسابك في X</strong><span>في تبويب «المتصفح»، بحسابك واسم المستخدم وكلمة المرور كالمعتاد.</span></div></li>
      <li><b>2</b><div><strong>ادخل على الدردشة وأدخل رمز الدردشة</strong><span>افتح الرسائل (الدردشة) في X، وأدخل رمز الدردشة (٤ أرقام) حين يطلبه منك، حتى تُفتح المحادثات.</span></div></li>
      <li><b>3</b><div><strong>ارجع واضغط «تحقق»</strong><span>عُد إلى تبويب «اللوحة»، ثم اضغط «تحقق» ليُحفظ الحساب.</span></div></li>
    </ol>
    <div class="usage-foot">
      <button id="guide-cancel" class="btn btn-ghost" type="button">إلغاء</button>
      <button id="guide-go" class="btn btn-pine ic i-login" type="button">فهمت، افتح المتصفح</button>
    </div>
  </div>
</div>
{% if control_on %}<div id="help-box" class="pc-backdrop" hidden>
  <div class="usage-sheet help-sheet" role="dialog" aria-modal="true" aria-labelledby="help-title">
    <div class="usage-head">
      <b id="help-title">المساعدة</b>
      <button id="help-close" class="usage-x" type="button" aria-label="إغلاق">×</button>
    </div>
    <p class="usage-note">صف المشكلة التي تواجهك، وأرفق صورًا أو فيديو قصيرًا إن أمكن. تصل رسالتك إلى صاحب البرنامج، ويصلك ردّه في قائمة التنبيهات.</p>
    <label class="help-label" for="help-text">وصف المشكلة</label>
    <textarea id="help-text" class="help-text" rows="5" maxlength="2000" placeholder="مثال: المهمة تتوقف عند التغريدة ١٣ وتظهر رسالة «تعذّر فتح التغريدة»."></textarea>
    <input id="help-files" type="file" accept="image/*,video/*" multiple hidden>
    <button id="help-attach" class="btn btn-ghost help-attach ic i-clip" type="button">إرفاق صور أو فيديو</button>
    <ul id="help-list" class="help-list" hidden></ul>
    <p class="hint">حتى ٥ ملفات: الصورة حتى ٨ ميجابايت، والفيديو القصير حتى ٢٥ ميجابايت. يُرفق تلقائيًا إصدار التطبيق ونوع الجهاز وآخر سطور السجل، لتسهيل معرفة المشكلة.</p>
    <p id="help-status" class="help-status" role="status" hidden></p>
    <div class="usage-foot">
      <button id="help-cancel" class="btn btn-ghost" type="button">إلغاء</button>
      <button id="help-send" class="btn btn-pine ic i-send" type="button">إرسال</button>
    </div>
  </div>
</div>{% endif %}
<div id="usage-box" class="pc-backdrop" hidden>
  <div class="usage-sheet" role="dialog" aria-modal="true" aria-labelledby="usage-title">
    <div class="usage-head">
      <b id="usage-title">التعليقات والتكلفة</b>
      <button id="usage-close" class="usage-x" type="button" aria-label="إغلاق">×</button>
    </div>
    <p id="usage-note" class="usage-note"></p>
    <table class="usage-table">
      <thead><tr><th>الحساب</th><th class="num">التعليقات</th><th class="num">التكلفة</th></tr></thead>
      <tbody id="usage-rows"></tbody>
      <tfoot><tr><th>المجموع</th><th class="num" id="usage-total-n">0</th><th class="num" id="usage-total-cost">$0.00</th></tr></tfoot>
    </table>
    <div class="usage-foot">
      <button id="usage-refresh" class="btn btn-ghost ic i-rotate" type="button">تحديث</button>
      <button id="usage-done" class="btn btn-pine" type="button">إغلاق</button>
    </div>
  </div>
</div>
<div id="phone-check-box" class="pc-backdrop" hidden>
  <div class="pc-term" role="dialog" aria-modal="true" aria-labelledby="pc-title">
    <div class="pc-bar">
      <span class="pc-dots" aria-hidden="true"><i></i><i></i><i></i></span>
      <b id="pc-title">فحص قدرة الهاتف</b>
      <button id="pc-close" class="pc-x" type="button" aria-label="إغلاق">×</button>
    </div>
    <div id="pc-screen" class="pc-screen" aria-live="polite" title="المس الشاشة لإظهار النص كله"></div>
    <div class="pc-actions">
      <button id="pc-again" class="pc-btn" type="button" hidden>إعادة الفحص</button>
      <button id="pc-done" class="pc-btn" type="button">إغلاق</button>
    </div>
  </div>
</div>

<script>
(() => {
  const apiRoot = {{ api_root|tojson }};
  const LABELS = {repost: "إعادة النشر", like: "إعجاب", bookmark: "المرجعية", comment: "تعليق"};
  const tokenField = document.getElementById("auth_token");
  function lockToken() {}
  const stopField = document.getElementById("stop-tweet");
  const pinField = document.getElementById("chat-pin");
  const groupsButton = document.getElementById("groups-button");
  const waitGroups = document.getElementById("wait-groups");
  const waitGroupsSec = document.getElementById("wait-groups-sec");
  function rememberWaits() {
    try {
      localStorage.setItem("x_wait_settings_v5", JSON.stringify({
        groupsOn: waitGroups.checked, groupsSec: waitGroupsSec.value
      }));
    } catch (_) {}
  }
  try {
    // "_v2": choices saved before the current defaults (30 s waits ticked) are not restored.
    const latest = localStorage.getItem("x_wait_settings_v5");
    const before = latest || localStorage.getItem("x_wait_settings_v4") || localStorage.getItem("x_wait_settings_v3");
    const savedWaits = JSON.parse(before || localStorage.getItem("x_wait_settings_v2") || "null");
    if (savedWaits) {
      waitGroups.checked = !!savedWaits.groupsOn;
      if (savedWaits.groupsSec) waitGroupsSec.value = savedWaits.groupsSec;
    }
  } catch (_) {}
  [waitGroups, waitGroupsSec].forEach((node) => node.addEventListener("change", rememberWaits));
  function secondsFrom(field, min, max, fallback) {
    const value = Number.parseInt(field.value, 10);
    if (!Number.isInteger(value)) return fallback;
    return Math.max(min, Math.min(max, value));
  }
  const groupBox = document.getElementById("group-box");
  const groupList = document.getElementById("group-list");
  // «روابط التغريدات»: instead of a group, the task runs on the tweets pasted in this box. Meanwhile the
  // groups, the group's tweet and the waits hide, and «عرض القروبات» reads «القروبات»: it brings back
  // the groups already shown, without opening the browser and the chat again.
  const linksButton = document.getElementById("links-button");
  const linksBox = document.getElementById("links-box");
  const linksField = document.getElementById("tweet-links");
  const linksCount = document.getElementById("links-count");
  const stopRow = document.getElementById("stop-row");
  const waitGroupsLabel = document.getElementById("wait-groups-label");
  const MAX_LINKS = {{ max_links|tojson }};
  const MAX_ACCOUNTS = {{ max_accounts|tojson }};
  let linksMode = false;
  // Each tweet in the pasted text once, in order: "handle/id", or "id" for a link without the
  // author's name (x.com/i/web/status/…) or a bare tweet number.
  function pastedTweets(text) {
    const seen = new Set();
    const found = [];
    const add = (handle, id) => {
      if (seen.has(id)) return;
      seen.add(id);
      found.push(handle && !/^(i|web)$/i.test(handle) ? handle + "/" + id : id);
    };
    for (const token of String(text || "").split(/[\s,،]+/)) {
      const pattern = /(?:x|twitter)\.com\/([A-Za-z0-9_]{1,15})(?:\/web)?\/status(?:es)?\/(\d{6,25})/gi;
      let match;
      let any = false;
      while ((match = pattern.exec(token))) {
        any = true;
        add(match[1], match[2]);
      }
      if (!any && /^\d{15,25}$/.test(token)) add("", token);
    }
    return found;
  }
  function showLinksCount() {
    const count = pastedTweets(linksField.value).length;
    linksCount.textContent = count ? count + " تغريدة" + (count > MAX_LINKS ? " · الحد الأقصى " + MAX_LINKS : "") : "لم يُلصق أي رابط بعد";
    linksCount.classList.toggle("is-bad", count > MAX_LINKS);
  }
  function setLinksMode(on) {
    linksMode = on;
    linksButton.setAttribute("aria-pressed", on ? "true" : "false");
    linksBox.hidden = !on;
    stopRow.hidden = on;
    waitGroupsLabel.hidden = on;
    groupsButton.textContent = on ? "القروبات" : "عرض القروبات";
    groupBox.hidden = on || groupNames.length === 0;
    if (on) showLinksCount();
  }
  linksButton.addEventListener("click", () => {
    setLinksMode(!linksMode);
    if (linksMode && !linksField.value.trim()) linksField.focus();
  });
  // (the pasted links are the shown account's own: kept with its setup, see snapshotActive)
  linksField.addEventListener("input", () => {
    showLinksCount();
    if (typeof snapshotActive === "function") snapshotActive();
  });
  document.getElementById("links-clear").addEventListener("click", () => {
    linksField.value = "";
    if (typeof snapshotActive === "function") snapshotActive();
    showLinksCount();
    linksField.focus();
  });
  const commentToggle = document.getElementById("action-comment");
  const geminiFields = document.getElementById("gemini-fields");
  const geminiKey = document.getElementById("gemini-key");
  const geminiModel = document.getElementById("gemini-model");
  const usagePill = document.getElementById("usage-pill");
  const usageCount = document.getElementById("usage-count");
  const usageCost = document.getElementById("usage-cost");
  const usageBox = document.getElementById("usage-box");
  const usageRows = document.getElementById("usage-rows");
  const usageNote = document.getElementById("usage-note");
  const editGemini = document.getElementById("edit-gemini");
  const replyVoice = document.getElementById("reply-voice");
  // The owner's copy only: opens the Gemini key and model fields.
  const showGemini = document.getElementById("show-gemini");
  // A user's copy: the owner sets the Gemini key and model; here they are only shown.
  const geminiByOwner = {{ (not owner_copy)|tojson }};
  const controlOn = {{ control_on|tojson }};
  editGemini.hidden = geminiByOwner;
  // The owner's copy: Grok writes its comments when it is the one chosen in «توزيع البرنامج» (as the script says).
  // (Grok or Claude, chosen in «توزيع البرنامج»: no Gemini key is asked for then.)
  let commentsByOther = false;
  const engineNote = document.getElementById("comments-by-grok");
  function showCommentsEngine(engine) {
    commentsByOther = engine === "grok" || engine === "claude";
    if (!engineNote) return;
    engineNote.hidden = !commentsByOther;
    if (commentsByOther && engineNote.dataset.text) {
      engineNote.textContent = engineNote.dataset.text.replace("{engine}", engine === "claude" ? "Claude" : "Grok");
    }
  }
  // A copy with no «توزيع البرنامج»: its own «مفتاح Claude», typed here, writes its comments when saved.
  const claudeFields = document.getElementById("claude-fields");
  const showClaude = document.getElementById("show-claude");
  function showOwnClaude(data) {
    if (!claudeFields) return;
    const saved = data.claude_key || "";
    document.getElementById("claude-now").textContent = saved
      ? "محفوظ: " + saved + " · " + (data.claude_model || "") + " — التعليقات بواسطة Claude."
      : "بدون مفتاح Claude تُكتب التعليقات بواسطة Gemini.";
    document.getElementById("delete-claude").hidden = !saved;
    const claudeModel = document.getElementById("claude-model");
    if (data.claude_model && document.activeElement !== claudeModel) claudeModel.value = data.claude_model;
  }
  function lockGemini(locked) {
    geminiKey.readOnly = locked;
    geminiModel.readOnly = locked;
    editGemini.textContent = locked ? "تحرير" : "تم";
    editGemini.setAttribute("aria-pressed", locked ? "false" : "true");
  }
  lockGemini(true);
  const csrf = document.getElementById("csrf_token").value;
  const loginButton = document.getElementById("login-button");
  const accountName = document.getElementById("account-name");
  const quickVerify = document.getElementById("quick-verify");
  const accountSettings = document.getElementById("account-settings");
  const accountPanel = document.getElementById("account-panel");
  const repostButton = document.getElementById("reposts-button");
  const notice = document.getElementById("notice");
  const progressPanel = document.getElementById("progress-panel");
  const taskBoard = document.getElementById("task-board");
  const taskList = document.getElementById("task-list");
  const liveTasks = new Map();
  const progressTitle = document.getElementById("progress-title");
  const progressMessage = document.getElementById("progress-message");
  const progressCount = document.getElementById("progress-count");
  const progressDenom = document.getElementById("progress-denom");
  const progressNote = document.getElementById("progress-note");
  const meter = document.getElementById("meter");
  const meterBar = document.getElementById("meter-bar");
  const repostResults = document.getElementById("repost-results");
  const resultStats = document.getElementById("result-stats");
  const repostList = document.getElementById("repost-list");
  const noReposts = document.getElementById("no-reposts");
  const sessionAccount = document.getElementById("session-account");
  const savedSessions = document.getElementById("saved-sessions");
  const savedSessionList = document.getElementById("saved-session-list");
  const accountsBar = document.getElementById("accounts-bar");
  let progressStarted = 0;
  let sessionRows = [];
  let groupNames = [];
  // (each account's chosen group, groups, links and setup are its own: see accountState and its panel)
  let selectedGroup = "";
  try {
    ["x_selected_group", "x_tweet_links", "x_links_mode"].forEach((name) => localStorage.removeItem(name));
  } catch (_) {}

  function clientId() {
    const key = "x_desk_client";
    let id = localStorage.getItem(key) || "";
    if (!/^[A-Za-z0-9_-]{16,80}$/.test(id)) {
      const bytes = new Uint8Array(18);
      crypto.getRandomValues(bytes);
      id = btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
      localStorage.setItem(key, id);
    }
    return id;
  }

  function readTasks() {
    try {
      const parsed = JSON.parse(localStorage.getItem("x_reposts_tasks") || "[]");
      return Array.isArray(parsed) ? parsed.filter((row) => row && row.id && row.key) : [];
    } catch (_) {
      return [];
    }
  }

  function writeTasks(rows) {
    localStorage.setItem("x_reposts_tasks", JSON.stringify(rows.slice(0, 12)));
  }

  // Whether the program answers: «متصل» at the top, and a strip that says it is reconnecting when it does not
  // (so the page never just looks frozen).
  const netState = document.getElementById("net-state");
  const netText = document.getElementById("net-text");
  const netBanner = document.getElementById("net-banner");
  let netFails = 0;
  function paintNet(state) {
    if (netState && netState.dataset.state !== state) {
      netState.dataset.state = state;
      netText.textContent = state === "ok" ? "متصل" : (state === "retry" ? "إعادة الاتصال…" : "غير متصل");
    }
    if (netBanner) netBanner.hidden = state === "ok";
  }
  function netOk() {
    if (netFails) { netFails = 0; paintNet("ok"); }
  }
  function netFail() {
    netFails += 1;
    if (netFails >= 2) paintNet(netFails >= 6 ? "off" : "retry");
  }
  // A wait the page can cut short: when the phone comes back, the tasks it follows ask at once (see resume()).
  const sleepers = new Set();
  function nap(ms) {
    return new Promise((resolve) => {
      let timer = 0;
      const done = () => { clearTimeout(timer); sleepers.delete(done); resolve(); };
      timer = setTimeout(done, ms);
      sleepers.add(done);
    });
  }
  function wakeAll() { Array.from(sleepers).forEach((done) => done()); }
  // A request with no answer in its time is dropped so the page can ask again, instead of waiting on one that
  // was cut while the phone was away or switching networks. Reads left over from before the phone went away
  // are dropped when it comes back (and asked again at once).
  const inFlight = new Set();
  async function fetchWithTimeout(url, options, ms = 15000, keep = false) {
    const controller = new AbortController();
    const entry = {controller, at: Date.now(), read: !keep && !(options && options.method && options.method !== "GET"), dropped: false};
    inFlight.add(entry);
    const timer = setTimeout(() => controller.abort(), ms);
    try {
      const response = await fetch(url, {...options, signal: controller.signal});
      netOk();
      return response;
    } catch (error) {
      if (!entry.dropped) netFail();
      throw error;
    } finally {
      clearTimeout(timer);
      inFlight.delete(entry);
    }
  }

  // Pages opened over plain http (a server IP) have no navigator.clipboard, so fall back to execCommand.
  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch (_) {}
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.cssText = "position: fixed; top: 0; left: 0; opacity: 0; font-size: 16px;";
    document.body.appendChild(area);
    area.select();
    area.setSelectionRange(0, text.length);
    let copied = false;
    try {
      copied = document.execCommand("copy");
    } catch (_) {}
    area.remove();
    return copied;
  }

  function followTask(task) {
    if (!task || !task.id || liveTasks.has(task.id)) return;
    task.key = task.key || "";
    liveTasks.set(task.id, true);
    if (task.token) markAccountRunning(task.token, true);
    if (task.key) {
      const rows = readTasks().filter((row) => row.id !== task.id);
      rows.unshift(task);
      writeTasks(rows);
    }
    taskBoard.hidden = false;
    const card = document.createElement("article");
    card.className = "task-card";
    card.dataset.token = task.token || "";
    card.innerHTML = '<div class="progress-top"><div><h3></h3><p class="task-phase"></p><p class="task-msg"></p></div><b class="task-count">0</b></div><div class="meter is-indeterminate"><span class="task-bar"></span></div><div class="task-actions"><button class="btn btn-ghost task-stop ic i-stop" type="button">إيقاف هذه المهمة</button><button class="btn btn-ghost task-copy ic i-copy" type="button" hidden>نسخ التغريدات</button><button class="btn task-retry ic i-rotate" type="button" hidden>إعادة المحاولة</button><button class="btn task-retry-failed ic i-rotate" type="button" hidden>إعادة المحاولة للفاشلة</button></div>';
    card.querySelector("h3").textContent = task.title || "مهمة";
    const stopButton = card.querySelector(".task-stop");
    const retryButton = card.querySelector(".task-retry");
    const copyButton = card.querySelector(".task-copy");
    const retryFailedButton = card.querySelector(".task-retry-failed");
    let links = [];
    let linksWanted = true;
    copyButton.addEventListener("click", async () => {
      if (!links.length) return;
      const count = links.length;
      if (await copyText(links.join("\n"))) {
        copyButton.textContent = "نُسخت " + count + " تغريدة";
        setTimeout(() => { copyButton.textContent = "نسخ التغريدات"; }, 1500);
      } else {
        showNotice("تعذّر النسخ من هذا المتصفح.", false);
      }
    });
    // While the task runs the polls leave out the tweet list, so ask for its links once.
    const loadLinks = async () => {
      linksWanted = false;
      try {
        const response = await fetchWithTimeout(apiRoot + "/jobs/" + encodeURIComponent(task.id) + "?light=1&links=1", {
          headers: {"X-CSRF-Token": csrf, "X-Job-Key": task.key, "X-Client-Id": clientId()},
          cache: "no-store"
        });
        const data = await response.json();
        if (response.ok && Array.isArray(data.links) && data.links.length) {
          links = data.links;
          copyButton.hidden = false;
          return;
        }
      } catch (_) {}
      linksWanted = true;
    };
    stopButton.addEventListener("click", async () => {
      stopButton.disabled = true;
      try {
        await postJson("/stop", {job_id: task.id, job_key: task.key});
      } catch (_) {
        stopButton.disabled = false;
      }
    });
    retryButton.addEventListener("click", async () => {
      retryButton.disabled = true;
      try {
        const data = await postJson("/retry", {job_id: task.id, job_key: task.key});
        if (!data.success) {
          showNotice(data.message || "تعذّرت إعادة المحاولة.", false);
          retryButton.disabled = false;
          return;
        }
        retryButton.hidden = true;
        stopButton.disabled = false;
        showTaskNotice(task, (task.title ? task.title + ": " : "") + (data.message || "بدأت إعادة المحاولة."), true);
        if (!liveTasks.has(task.id)) {
          liveTasks.set(task.id, true);
          const rows = readTasks().filter((row) => row.id !== task.id);
          rows.unshift(task);
          writeTasks(rows);
          watch();
        }
      } catch (_) {
        showNotice("تعذّر الاتصال أثناء إعادة المحاولة.", false);
        retryButton.disabled = false;
      }
    });
    // «إعادة المحاولة للفاشلة»: a new task with only the tweets whose actions failed, each with only those actions.
    retryFailedButton.addEventListener("click", async () => {
      retryFailedButton.disabled = true;
      try {
        const data = await postJson("/retry-failed", {job_id: task.id, job_key: task.key});
        if (!data.success || !data.job_id || !data.job_key) {
          showNotice(data.message || "تعذّرت إعادة المحاولة للفاشلة.", false);
          retryFailedButton.disabled = false;
          return;
        }
        retryFailedButton.hidden = true;
        writeTasks(readTasks().filter((row) => row.id !== task.id));
        const base = (task.title || "مهمة").replace(/^إعادة الفاشلة · /, "");
        followTask({id: data.job_id, key: data.job_key, token: task.token, title: "إعادة الفاشلة · " + base, startedAt: Date.now()});
        showTaskNotice(task, base + ": " + (data.message || "بدأت إعادة المحاولة للفاشلة."), true);
      } catch (_) {
        showNotice("تعذّر الاتصال أثناء إعادة المحاولة للفاشلة.", false);
        retryFailedButton.disabled = false;
      }
    });
    taskList.prepend(card);
    filterTaskCards();
    const paint = (data) => {
      const phase = data.phase || "collect";
      card.dataset.status = data.status === "running" ? "running"
        : (data.status === "interrupted" ? "interrupted" : (data.success ? "done" : "failed"));
      const titles = {queue: "في الانتظار", login: "فتح القروب", prepare: "تجهيز", collect: "جمع", act: "تنفيذ"};
      card.querySelector(".task-phase").textContent = data.status === "running" ? (titles[phase] || "جارٍ العمل")
        : ({done: "اكتملت", failed: "لم تكتمل", interrupted: "توقفت"})[card.dataset.status];
      card.querySelector(".task-msg").textContent = data.message || "";
      const current = phase === "act" ? (data.done || 0) : (data.collected || 0);
      const total = data.requested || 0;
      card.querySelector(".task-count").textContent = total ? current + " / " + total : String(current);
      const meter = card.querySelector(".meter");
      const indeterminate = data.status === "running" && (phase === "queue" || phase === "login" || phase === "prepare" || !total);
      meter.classList.toggle("is-indeterminate", indeterminate);
      card.querySelector(".task-bar").style.width = indeterminate ? "" : Math.max(0, Math.min(100, total ? Math.round((current / total) * 100) : 100)) + "%";
      stopButton.hidden = data.status !== "running";
      retryButton.hidden = !(data.status !== "running" && data.resumable);
      retryButton.disabled = false;
      const failedCount = data.status !== "running" ? Number(data.retry_failed || 0) : 0;
      retryFailedButton.hidden = !failedCount;
      if (failedCount) retryFailedButton.textContent = "إعادة المحاولة للفاشلة (" + failedCount + ")";
      if (Array.isArray(data.items) && data.items.length) links = data.items.map((item) => item && item.url).filter(Boolean);
      if (!links.length && linksWanted && phase === "act") loadLinks();
      copyButton.hidden = !links.length;
    };
    const watch = async () => {
      try {
        for (;;) {
          let response;
          let data;
          try {
            response = await fetchWithTimeout(apiRoot + "/jobs/" + encodeURIComponent(task.id) + "?light=1", {
              headers: {"X-CSRF-Token": csrf, "X-Job-Key": task.key, "X-Client-Id": clientId()},
              cache: "no-store"
            });
            data = await response.json();
          } catch (_) {
            // No answer (the phone was away, the network changed): keep trying instead of stopping.
            card.querySelector(".task-msg").textContent = "انقطع الاتصال لحظيًا. جارٍ إعادة الاتصال…";
            await nap(document.hidden ? 5000 : 1500);
            continue;
          }
          if (response.status === 404) writeTasks(readTasks().filter((row) => row.id !== task.id));
          if (!response.ok) throw new Error(data.message || "تعذّر متابعة المهمة.");
          paint(data);
          if (data.status !== "running") {
            showTaskNotice(task, (task.title ? task.title + ": " : "") + (data.message || ""), Boolean(data.success));
            // (its results show on its own account's panel only: elsewhere they wait for it, see loadAccountFromServer)
            if (Array.isArray(data.results) && data.results.length && (!task.token || task.token === tokenField.value.trim())) renderResults(data);
            // A task stopped with a retry button stays in the saved task list so it is still there after a reload.
            // (and one with failed actions to retry, so its «إعادة المحاولة للفاشلة» is there after a reload too)
            if (!data.resumable && !data.retry_failed) writeTasks(readTasks().filter((row) => row.id !== task.id));
            loadActionCounts();
            break;
          }
          await nap(document.hidden ? 4000 : 700);
        }
      } catch (error) {
        card.querySelector(".task-msg").textContent = error.message || "انقطع متابعة المهمة.";
      } finally {
        liveTasks.delete(task.id);
        if (task.token) markAccountRunning(task.token, false);
      }
    };
    watch();
  }

  function showAccount(text) {
    sessionAccount.textContent = text || "";
    sessionAccount.hidden = !text;
  }

  // The one-row view: the account's username; the token, its buttons and the chat PIN sit behind "إعداد الحساب".
  function syncAccountName() {
    const token = tokenField.value.trim();
    const row = sessionRows.find((item) => item.token === token);
    accountName.value = row && row.username ? "@" + row.username : (token ? "حساب غير معروف" : "");
  }

  function setAccountPanel(open) {
    accountPanel.hidden = !open;
    accountSettings.textContent = open ? "إخفاء الإعداد" : "إعداد الحساب";
    accountSettings.setAttribute("aria-expanded", open ? "true" : "false");
  }

  // Focus a field, opening the account settings first when it is inside them.
  function revealField(field) {
    if (accountPanel.contains(field)) setAccountPanel(true);
    field.focus();
  }

  function formatWhen(epoch) {
    if (!epoch) return "";
    const minutes = Math.round(Math.max(0, Date.now() - epoch * 1000) / 60000);
    if (minutes < 1) return "الآن";
    if (minutes < 60) return "قبل " + minutes + " د";
    const hours = Math.round(minutes / 60);
    if (hours < 24) return "قبل " + hours + " س";
    const days = Math.round(hours / 24);
    if (days < 14) return "قبل " + days + " ي";
    return new Date(epoch * 1000).toLocaleDateString("ar");
  }

  // ==== الحسابات (قائمة جانبية، حتى MAX_ACCOUNTS): لكل حساب إعداده ومهمته المستقلة ====
  let accountState = {};
  try { accountState = JSON.parse(localStorage.getItem("x_account_state") || "{}") || {}; } catch (_) { accountState = {}; }
  function saveAccountStates() {
    try { localStorage.setItem("x_account_state", JSON.stringify(accountState)); } catch (_) {}
  }
  // Which accounts have a task working now (token -> number of live tasks): shows the dot on the chip.
  const runningAccounts = new Map();
  function markAccountRunning(token, on) {
    if (!token) return;
    const next = (runningAccounts.get(token) || 0) + (on ? 1 : -1);
    if (next > 0) runningAccounts.set(token, next); else runningAccounts.delete(token);
    renderAccounts();
  }
  let activeToken = tokenField.value.trim();
  function snapshotActive() {
    if (!activeToken) return;
    accountState[activeToken] = {
      group: selectedGroup,
      groups: groupNames.slice(0, 200),
      stop: stopField.value.trim(),
      pin: pinField.value.trim(),
      actions: selectedActions(),
      links: linksMode,
      linksText: linksField.value.slice(0, 200000)
    };
    saveAccountStates();
  }
  function applyAccountSetup(token) {
    const state = accountState[token] || null;
    if (state) {
      groupNames = Array.isArray(state.groups) ? state.groups : [];
      selectedGroup = state.group || "";
      stopField.value = state.stop || "";
      if (Array.isArray(state.actions) && state.actions.length) {
        ["repost", "like", "bookmark", "comment"].forEach((key) => {
          const box = document.getElementById("action-" + key);
          if (box) box.checked = state.actions.includes(key);
        });
      }
      linksField.value = state.linksText || "";
      renderGroups();
      setLinksMode(!!state.links);
      syncGemini();
    } else {
      groupNames = [];
      selectedGroup = "";
      stopField.value = "";
      linksField.value = "";
      setLinksMode(false);
      renderGroups();
    }
  }
  // The shown account's last task, on its own panel (no other account's results are shown there).
  function hideAccountResults() {
    progressPanel.hidden = true;
    repostResults.hidden = true;
  }
  function showAccountLastJob(job) {
    if (!job || !job.status || job.status === "running") return;
    renderProgress(job);
    if (job.kind === "execute" && Array.isArray(job.results) && job.results.length) renderResults(job);
  }
  // The account's own panel and tasks as the server keeps them in its folder: its groups, its group, its
  // tweet, its actions, its working and waiting tasks, its last task.
  async function loadAccountFromServer(token) {
    let data = null;
    try {
      const response = await fetchWithTimeout(apiRoot + "/state", {headers: {"X-Account-Token": token}, cache: "no-store"});
      data = await response.json();
    } catch (_) {}
    if (!data || !data.success || tokenField.value.trim() !== token) return;
    const pin = pinField.value;
    applyScreen(data);
    if (!data.chat_pin) pinField.value = pin;
    snapshotActive();
    (data.running_jobs || []).forEach((job) => followTask({
      id: job.id,
      key: data.job_id === job.id ? (data.job_key || "") : "",
      token: token,
      title: job.username || data.group || "مهمة"
    }));
    filterTaskCards();
    showAccountLastJob(data.job);
  }
  function selectAccount(token) {
    if (token === activeToken) { setAccountPanel(false); return; }
    snapshotActive();
    activeToken = token;
    const row = sessionRows.find((item) => item.token === token);
    tokenField.value = token;
    lockToken(true);
    pinField.value = (row && row.chat_pin) || (accountState[token] && accountState[token].pin) || "";
    applyAccountSetup(token);
    showAccount(row && row.username ? "الحساب: @" + row.username : "تم اختيار حساب محفوظ.");
    renderAccounts();
    setCounts(null);           // the chosen account's own counters, tasks, results and notices only
    hideAccountResults();
    notice.hidden = true;
    showWaitingNotice(token);
    loadActionCounts();
    filterTaskCards();
    pushScreen();
    loadAccountFromServer(token);
  }
  function addAccountFlow() {
    if (sessionRows.length >= MAX_ACCOUNTS) {
      showNotice("الحد الأقصى " + MAX_ACCOUNTS + " حسابات. احذف حسابًا لإضافة آخر.", false);
      return;
    }
    snapshotActive();
    activeToken = "";
    tokenField.value = "";
    lockToken(true);
    pinField.value = "";
    stopField.value = "";
    groupNames = [];
    selectedGroup = "";
    setLinksMode(false);
    renderGroups();
    showAccount("");
    linksField.value = "";
    renderAccounts();
    setCounts(null);
    hideAccountResults();
    notice.hidden = true;
    filterTaskCards();
    pushScreen();
    setAccountPanel(true);
    showNotice("سجّل الدخول بالحساب الجديد من «تسجيل الدخول»، ثم اضغط «تحقق».", true);
    const block = document.getElementById("session-block");
    if (block) block.scrollIntoView({block: "start", behavior: "smooth"});
  }
  async function deleteAccount(row) {
    try {
      const data = await postJson("/sessions/delete", {id: row.id});
      if (!data.success) {
        showNotice(data.message || "تعذّر حذف الحساب.", false);
        return;
      }
      delete accountState[row.token];
      saveAccountStates();
      if (activeToken === row.token || tokenField.value.trim() === row.token) {
        activeToken = "";
        tokenField.value = "";
        lockToken(true);
        pinField.value = "";
        showAccount("");
        pushScreen();
      }
      showNotice("حُذف الحساب من هذا الخادم.", true);
      await loadSessions();
    } catch (_) {
      showNotice("تعذّر الاتصال أثناء الحذف.", false);
    }
  }
  function renderAccounts() {
    savedSessions.hidden = true;                 // the old inner list is replaced by the accounts bar
    savedSessionList.replaceChildren();
    const token = tokenField.value.trim();
    if (!accountsBar) return;
    accountsBar.replaceChildren();
    sessionRows.forEach((row) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "acct-chip" + (row.token === token ? " is-on" : "") + (runningAccounts.has(row.token) ? " is-running" : "");
      chip.setAttribute("role", "tab");
      chip.setAttribute("aria-selected", row.token === token ? "true" : "false");
      const dot = document.createElement("span");
      dot.className = "acct-dot";
      dot.setAttribute("aria-hidden", "true");
      const who = document.createElement("span");
      who.className = "acct-who";
      who.textContent = row.username ? "@" + row.username : "حساب";
      const close = document.createElement("span");
      close.className = "acct-x";
      close.setAttribute("role", "button");
      close.setAttribute("tabindex", "0");
      close.setAttribute("aria-label", "حذف الحساب" + (row.username ? " @" + row.username : ""));
      close.textContent = "×";
      const removeAccount = () => {
        if (runningAccounts.has(row.token)) { showNotice("لهذا الحساب مهمة تعمل الآن. أوقفها قبل حذفه.", false); return; }
        deleteAccount(row);
      };
      close.addEventListener("click", (event) => { event.stopPropagation(); removeAccount(); });
      close.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") { event.preventDefault(); event.stopPropagation(); removeAccount(); }
      });
      chip.append(dot, who, close);
      chip.addEventListener("click", () => selectAccount(row.token));
      accountsBar.appendChild(chip);
    });
    if (sessionRows.length < MAX_ACCOUNTS) {
      const add = document.createElement("button");
      add.type = "button";
      add.className = "acct-add";
      add.id = "add-account";
      add.textContent = sessionRows.length ? "＋ إضافة حساب" : "＋ أضف حسابك الأول";
      add.addEventListener("click", addAccountFlow);
      accountsBar.appendChild(add);
    } else {
      const note = document.createElement("p");
      note.className = "acct-empty";
      note.textContent = "الحد الأقصى " + MAX_ACCOUNTS + " حسابات.";
      accountsBar.appendChild(note);
    }
    syncAccountName();
    pushAccountsToNative();
  }
  // Inside the app, the accounts live in the app's own side drawer; it reports them here and drives them.
  function pushAccountsToNative() {
    try {
      if (!window.GroupsNative || typeof window.GroupsNative.accounts !== "function") return;
      const token = tokenField.value.trim();
      const list = sessionRows.map((row) => ({ name: row.username || "", running: runningAccounts.has(row.token) }));
      const active = sessionRows.findIndex((row) => row.token === token);
      let anyRunning = false;
      sessionRows.forEach((row) => { if (runningAccounts.has(row.token)) anyRunning = true; });
      window.GroupsNative.accounts(JSON.stringify(list), active, MAX_ACCOUNTS, anyRunning);
    } catch (_) {}
  }
  // The app's side drawer calls these to switch, add or remove an account (by its position in the list).
  window.__groupsAccounts = {
    select: (index) => { const row = sessionRows[index]; if (row) selectAccount(row.token); },
    add: () => addAccountFlow(),
    remove: (index) => { const row = sessionRows[index]; if (row) deleteAccount(row); }
  };
  // Each account sees only its own task cards (a card knows its account from data-token).
  function filterTaskCards() {
    const token = tokenField.value.trim();
    let shown = 0;
    taskList.querySelectorAll(".task-card").forEach((card) => {
      const cardToken = card.dataset.token || "";
      const show = !cardToken || cardToken === token;
      card.hidden = !show;
      if (show) shown += 1;
    });
    taskBoard.hidden = shown === 0;
  }
  // Older call sites still call renderSessions(); point it at the accounts bar.
  function renderSessions() { renderAccounts(); }

  async function loadSessions() {
    try {
      const response = await fetchWithTimeout(apiRoot + "/sessions", {
        headers: {"X-CSRF-Token": csrf, "X-Client-Id": clientId()},
        cache: "no-store"
      });
      const data = await response.json();
      if (!response.ok) return;
      sessionRows = data.sessions || [];
      if (!activeToken) activeToken = tokenField.value.trim();
      renderSessions();
      showCommentsEngine(data.comments_engine);
      showOwnClaude(data);
      if (geminiByOwner) {
        geminiKey.value = data.gemini_api_key || "";
        geminiModel.value = data.gemini_model || "";
      } else {
        if (data.gemini_api_key && document.activeElement !== geminiKey) {
          geminiKey.value = data.gemini_api_key;
          localStorage.setItem("x_gemini_key", data.gemini_api_key);
        }
        if (data.gemini_model && document.activeElement !== geminiModel) {
          geminiModel.value = data.gemini_model;
          localStorage.setItem("x_gemini_model", data.gemini_model);
        }
      }
    } catch (_) {}
  }

  // Who writes the comments now (it may have changed in «توزيع البرنامج» since the page opened); nothing else
  // on the page is touched.
  async function loadCommentsEngine() {
    try {
      const response = await fetchWithTimeout(apiRoot + "/sessions", {
        headers: {"X-CSRF-Token": csrf, "X-Client-Id": clientId()},
        cache: "no-store"
      });
      const data = await response.json();
      if (response.ok) showCommentsEngine(data.comments_engine);
    } catch (_) {}
  }

  // Successful actions of all tasks so far (kept on the server), shown at the top of the page.
  function setCounts(counts) {
    ["repost", "like", "bookmark", "comment"].forEach((key) => {
      document.getElementById("count-" + key).textContent = Number((counts && counts[key]) || 0).toLocaleString("en-US");
    });
  }
  // The top counters show the chosen account's own successes only (its token tells the server which).
  async function loadActionCounts() {
    const token = tokenField.value.trim();
    if (!token) { setCounts(null); return; }
    try {
      const response = await fetchWithTimeout(apiRoot + "/stats", {
        headers: {"X-CSRF-Token": csrf, "X-Account-Token": token}, cache: "no-store"
      });
      const data = await response.json();
      if (!response.ok || !data.success) return;
      // (ignore a late answer for an account that is no longer the chosen one)
      if (tokenField.value.trim() === token) setCounts(data.counts);
    } catch (_) {}
  }

  function reveal(node) {
    node.hidden = false;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    node.scrollIntoView({block: "start", behavior: reduce ? "auto" : "smooth"});
  }

  // A message floats at the bottom and goes by itself; one that says something is under way («…») stays until
  // the next one. A tap closes it.
  let noticeTimer = 0;
  function showNotice(message, success) {
    clearTimeout(noticeTimer);
    notice.textContent = message;
    notice.className = "notice " + (success ? "is-ok" : "is-bad");
    notice.hidden = false;
    notice.style.animation = "none";
    void notice.offsetWidth;
    notice.style.animation = "";
    if (!/…\s*$/.test(String(message))) noticeTimer = setTimeout(hideNotice, success ? 4500 : 8000);
  }
  function hideNotice() {
    clearTimeout(noticeTimer);
    if (notice.hidden) return;
    notice.classList.add("is-out");
    noticeTimer = setTimeout(() => { notice.hidden = true; notice.classList.remove("is-out"); }, 190);
  }
  notice.addEventListener("click", hideNotice);
  // رسائل لوحة التحكّم (تنبيهات صاحب البرنامج وردوده) إلى قائمة التنبيهات داخل التطبيق (الجرس في الشريط العلوي).
  // تنبيهات الصفحة نفسها (اختيار قروب، نتيجة مهمة…) تبقى في الصفحة ولا تُعدّ في الجرس.
  function pushNative(message, kind) {
    try {
      if (window.GroupsNative && typeof window.GroupsNative.notify === "function") {
        window.GroupsNative.notify(kind || "info", String(message == null ? "" : message));
      }
    } catch (e) {}
  }
  // A notice about a task (stopped, ended, retried) belongs to the task's account: it shows on that account's
  // panel only. One that comes while another account is shown waits until its account is shown again.
  const waitingNotices = new Map();
  function showTaskNotice(task, message, success) {
    const token = task && task.token;
    if (!token || token === tokenField.value.trim()) {
      showNotice(message, success);
      return;
    }
    waitingNotices.set(token, {message, success});
  }
  function showWaitingNotice(token) {
    const waiting = waitingNotices.get(token);
    waitingNotices.delete(token);
    if (waiting) showNotice(waiting.message, waiting.success);
  }

  function selectedActions() {
    return ["repost", "like", "bookmark", "comment"].filter((key) => document.getElementById("action-" + key).checked);
  }

  function syncGemini() {
    replyVoice.hidden = !commentToggle.checked;
    if (!commentToggle.checked) {
      openGemini(false);
      if (claudeFields) { claudeFields.hidden = true; showClaude.setAttribute("aria-expanded", "false"); }
    }
  }

  function openGemini(open) {
    geminiFields.hidden = !open;
    if (showGemini) showGemini.setAttribute("aria-expanded", open ? "true" : "false");
  }

  function selectedVoice() {
    return (document.querySelector('input[name="reply-voice"]:checked') || {}).value || "male";
  }

  // Total comments written by the model, and their price, read from the server.
  // The comments written for this copy and their cost: from the control server when this copy has one (kept
  // there by X account, so they stay when the app is installed again), else counted here.
  let usageData = null;
  function money(value) { return "$" + Number(value || 0).toFixed(2); }
  function renderUsage() {
    if (!usageData) return;
    usageCount.textContent = "التعليقات (" + Number(usageData.total || 0).toLocaleString("en-US") + ")";
    usageCost.textContent = money(usageData.cost);
    // Brown at $0, redder as the cost grows, fully red from $10.
    const brown = [139, 69, 19];
    const red = [211, 47, 47];
    const share = Math.max(0, Math.min(1, Number(usageData.cost || 0) / 10));
    usageCost.style.backgroundColor = "rgb(" + brown.map((value, i) => Math.round(value + (red[i] - value) * share)).join(", ") + ")";
    usageRows.replaceChildren();
    const accounts = Array.isArray(usageData.accounts) ? usageData.accounts : [];
    if (!accounts.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.className = "empty";
      cell.colSpan = 3;
      cell.textContent = usageData.source === "control" ? "لا تعليقات بعد." : "التفصيل لكل حساب يأتي من لوحة التحكم.";
      row.append(cell);
      usageRows.append(row);
    }
    accounts.forEach((account) => {
      const row = document.createElement("tr");
      const who = document.createElement("td");
      who.className = "who";
      const name = document.createElement("bdi");
      name.dir = "ltr";
      name.textContent = account.name ? "@" + account.name : "حساب بلا اسم";
      who.append(name);
      const count = document.createElement("td");
      count.className = "num";
      count.textContent = Number(account.n || 0).toLocaleString("en-US");
      const cost = document.createElement("td");
      cost.className = "num";
      cost.textContent = money(account.cost);
      row.append(who, count, cost);
      usageRows.append(row);
    });
    document.getElementById("usage-total-n").textContent = Number(usageData.total || 0).toLocaleString("en-US");
    document.getElementById("usage-total-cost").textContent = money(usageData.cost);
    const price = Number(usageData.price || 0.01);
    usageNote.textContent = usageData.source === "control"
      ? (usageData.stale ? "آخر قراءة من لوحة التحكم (الخادم غير متاح الآن). " : "من لوحة التحكم: تُحسب لكل حساب، وتبقى حتى لو أُعيد تثبيت التطبيق. ")
        + money(price) + " لكل تعليق."
      : "محسوبة في هذه النسخة: " + money(price) + " لكل تعليق.";
  }
  async function loadCommentsUsage(fresh) {
    try {
      const response = await fetchWithTimeout(apiRoot + "/comments-usage" + (fresh ? "?fresh=1" : ""), {headers: {"X-CSRF-Token": csrf}, cache: "no-store"});
      const data = await response.json();
      if (!response.ok || !data.success) return;
      usageData = data;
      renderUsage();
    } catch (_) {}
  }
  function openUsage() {
    usageBox.hidden = false;
    renderUsage();
    loadCommentsUsage(true);
  }
  function closeUsage() { usageBox.hidden = true; }
  usagePill.addEventListener("click", openUsage);
  document.getElementById("usage-close").addEventListener("click", closeUsage);
  document.getElementById("usage-done").addEventListener("click", closeUsage);
  document.getElementById("usage-refresh").addEventListener("click", () => loadCommentsUsage(true));
  usageBox.addEventListener("click", (event) => { if (event.target === usageBox) closeUsage(); });

  function shortPath(url) {
    try { return new URL(url).pathname; } catch (_) { return url; }
  }

  function stat(value, label) {
    const box = document.createElement("div");
    box.className = "stat";
    const number = document.createElement("b");
    number.textContent = String(value);
    const caption = document.createElement("span");
    caption.textContent = label;
    box.append(number, caption);
    return box;
  }

  function pill(text, kind) {
    const node = document.createElement("span");
    node.className = "pill " + kind;
    node.textContent = text;
    return node;
  }

  // (every request has its time: none can leave a button waiting forever)
  async function postJson(path, payload, ms = 45000) {
    const response = await fetchWithTimeout(apiRoot + path, {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-CSRF-Token": csrf, "X-Client-Id": clientId()},
      cache: "no-store",
      body: JSON.stringify({...payload, csrf_token: csrf})
    }, ms);
    const data = await response.json();
    if (!response.ok && !data.message) throw new Error("تعذّر إكمال الطلب.");
    return data;
  }

  function renderProgress(data) {
    progressPanel.hidden = false;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    progressPanel.scrollIntoView({block: "nearest", behavior: reduceMotion ? "auto" : "smooth"});
    const phase = data.phase || "collect";
    const titles = {login: "فتح القروب", prepare: "تجهيز المهمة", collect: "جمع تغريدات القروب", act: "تنفيذ الإجراءات"};
    progressTitle.textContent = titles[phase] || "جارٍ العمل";
    progressMessage.textContent = data.message || "";
    const current = phase === "act" ? (data.done || 0) : (data.collected || 0);
    const total = data.requested || 0;
    progressCount.textContent = String(current);
    progressDenom.textContent = total ? " / " + total : "";
    const pct = total ? Math.max(0, Math.min(100, Math.round((current / total) * 100))) : 0;
    const indeterminate = phase === "login" || phase === "prepare" || !total;
    meter.classList.toggle("is-indeterminate", indeterminate);
    meterBar.style.width = indeterminate ? "" : pct + "%";
    meter.setAttribute("aria-valuenow", String(pct));
    const elapsed = Math.max(0, Math.round((performance.now() - progressStarted) / 1000));
    const mins = Math.floor(elapsed / 60);
    const secs = elapsed % 60;
    const clock = mins ? mins + " د " + secs + " ث" : secs + " ث";
    progressNote.textContent = phase === "act"
      ? "مضى " + clock + ". الحالات المفعّلة مسبقًا تُتجاوز."
      : "مضى " + clock + ". لا يُنفَّذ أي إجراء خلال هذه المرحلة.";
  }

  function finishTrackedJob(data) {
    if (!data || data.status === "running") return;
    showNotice(data.message || "", Boolean(data.success));
    renderProgress(data);
    if (data.status === "interrupted") {
      progressNote.textContent = "آخر حالة قبل توقف السكربت. لن تُستكمل العملية تلقائيًا.";
    }
    const hasResults = Array.isArray(data.results) && data.results.length > 0;
    if (data.kind === "execute" && hasResults) renderResults(data);
    loadSessions();
  }

  function renderResults(data) {
    const rows = data.results || [];
    let done = 0;
    let skip = 0;
    let fail = 0;
    repostList.replaceChildren();
    rows.forEach((row, index) => {
      const item = document.createElement("li");
      const top = document.createElement("div");
      top.className = "post-top";
      const idx = document.createElement("span");
      idx.className = "idx";
      idx.textContent = String(index + 1);
      const link = document.createElement("a");
      link.href = row.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = shortPath(row.url || "");
      top.append(idx, link);
      item.appendChild(top);
      const pills = document.createElement("div");
      pills.className = "pills";
      Object.entries(row.actions || {}).forEach(([key, value]) => {
        let kind = "is-fail";
        if (value === "تم التنفيذ") { kind = "is-will"; done += 1; }
        else if (String(value).includes("مفعّل") || String(value).includes("تخطي")) { kind = "is-skip"; skip += 1; }
        else fail += 1;
        pills.appendChild(pill((LABELS[key] || key) + " · " + value, kind));
      });
      item.appendChild(pills);
      if (row.comment) {
        const note = document.createElement("p");
        note.className = "excerpt";
        note.textContent = row.comment;
        item.appendChild(note);
      }
      repostList.appendChild(item);
    });
    resultStats.replaceChildren(stat(done, "نُفّذ"), stat(skip, "تُجاوز"), stat(fail, "لم يكتمل"));
    noReposts.hidden = rows.length > 0;
    repostResults.hidden = false;
    reveal(repostResults);
  }

  commentToggle.addEventListener("change", syncGemini);
  if (showGemini) showGemini.addEventListener("click", () => openGemini(geminiFields.hidden));
  if (claudeFields) {
    const claudeKey = document.getElementById("claude-key");
    const claudeModel = document.getElementById("claude-model");
    showClaude.addEventListener("click", () => {
      claudeFields.hidden = !claudeFields.hidden;
      showClaude.setAttribute("aria-expanded", claudeFields.hidden ? "false" : "true");
      if (!claudeFields.hidden) claudeKey.focus();
    });
    document.getElementById("save-claude").addEventListener("click", async () => {
      try {
        const data = await postJson("/claude", {api_key: claudeKey.value.trim(), model: claudeModel.value.trim()});
        showNotice(data.message || "تعذّر حفظ مفتاح Claude.", Boolean(data.success));
        if (data.success) {
          claudeKey.value = "";
          showOwnClaude(data);
          showCommentsEngine(data.comments_engine);
        }
      } catch (_) {
        showNotice("تعذّر حفظ مفتاح Claude.", false);
      }
    });
    document.getElementById("delete-claude").addEventListener("click", async () => {
      if (!window.confirm("حذف مفتاح Claude؟ تعود التعليقات إلى Gemini.")) return;
      try {
        const data = await postJson("/claude/delete", {});
        showNotice(data.message || "تعذّر حذف مفتاح Claude.", Boolean(data.success));
        if (data.success) {
          showOwnClaude(data);
          showCommentsEngine(data.comments_engine);
        }
      } catch (_) {
        showNotice("تعذّر حذف مفتاح Claude.", false);
      }
    });
  }
  // The reply's voice chosen last time, on this browser ("_v2": a choice made before «مذكر» became the
  // default is not restored).
  try {
    const voice = localStorage.getItem("x_reply_voice_v2");
    const box = document.querySelector('input[name="reply-voice"][value="' + voice + '"]');
    if (box) box.checked = true;
  } catch (_) {}
  document.querySelectorAll('input[name="reply-voice"]').forEach((box) => box.addEventListener("change", () => {
    try {
      localStorage.setItem("x_reply_voice_v2", selectedVoice());
    } catch (_) {}
  }));
  const savedModel = geminiByOwner ? "" : localStorage.getItem("x_gemini_model");
  const savedKey = geminiByOwner ? "" : localStorage.getItem("x_gemini_key");
  if (savedModel) geminiModel.value = savedModel;
  if (savedKey) geminiKey.value = savedKey;
  let geminiSaveTimer = 0;
  function rememberGeminiLocal() {
    if (geminiByOwner) return;
    const key = geminiKey.value.trim();
    const model = geminiModel.value.trim();
    if (key) localStorage.setItem("x_gemini_key", key);
    if (model) localStorage.setItem("x_gemini_model", model);
    clearTimeout(geminiSaveTimer);
    geminiSaveTimer = setTimeout(() => {
      if (!key && !model) return;
      postJson("/gemini", {gemini_api_key: key, gemini_model: model}).catch(() => {});
    }, 350);
  }
  geminiKey.addEventListener("change", rememberGeminiLocal);
  geminiModel.addEventListener("change", rememberGeminiLocal);
  geminiKey.addEventListener("blur", rememberGeminiLocal);
  geminiModel.addEventListener("blur", rememberGeminiLocal);
  // «اختبار قدرة الهاتف»: the phone's memory, processor, heat, battery and background permissions (from the
  // app), with a short speed test here; then how many accounts it can run at the same time. Shown as a system
  // console: each line is typed a letter at a time (a touch on the screen shows the rest at once).
  const phoneCheckBtn = document.getElementById("phone-check");
  const pcBox = document.getElementById("phone-check-box");
  const pcScreen = document.getElementById("pc-screen");
  const pcAgain = document.getElementById("pc-again");
  const pcCursor = document.createElement("span");
  pcCursor.className = "pc-cursor";
  const typeAtOnce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let pcRun = 0;
  let pcSkip = false;
  const pcSleep = (ms) => new Promise((done) => setTimeout(done, ms));
  function speedTest(ms) {
    // integer math, array and text work: the kind of work a page of X keeps doing
    const end = performance.now() + ms;
    let rounds = 0;
    let x = 1;
    const values = new Array(256).fill(0);
    while (performance.now() < end) {
      for (let i = 0; i < 4000; i++) { x = (x * 1103515245 + 12345) & 0x7fffffff; values[i & 255] = x; }
      values.sort((a, b) => a - b);
      let text = "";
      for (let i = 0; i < 40; i++) text += (values[i] % 36).toString(36);
      if (text.length < 0) x++;
      rounds++;
    }
    return Math.round(rounds * 1000 / ms);
  }
  // One line of the console, typed a letter at a time. kind: "" (a step), "is-head", "is-dim" (a detail).
  async function pcType(text, kind, run, pace) {
    const line = document.createElement("div");
    line.className = "pc-line" + (kind ? " " + kind : "");
    const body = document.createElement("span");
    if (kind !== "is-dim") {
      const prompt = document.createElement("span");
      prompt.className = "pc-p";
      prompt.textContent = "› ";
      line.append(prompt);
    }
    line.append(body, pcCursor);
    pcScreen.appendChild(line);
    for (const letter of Array.from(String(text))) {
      if (run !== pcRun) return line;
      body.textContent += letter;
      if (!pcSkip && !typeAtOnce && letter !== " ") await pcSleep(pace || 12);
      pcScreen.scrollTop = pcScreen.scrollHeight;
    }
    return line;
  }
  function pcTag(line, level) {
    const tag = document.createElement("span");
    tag.className = "pc-tag is-" + level;
    tag.textContent = level === "ok" ? "  [ سليم ]" : level === "warn" ? "  [ تنبيه ]" : "  [ خطأ ]";
    line.insertBefore(tag, pcCursor);
  }
  const gb = (mb) => (Math.round(mb / 102.4) / 10).toLocaleString("en-US");
  async function runPhoneCheck() {
    const run = ++pcRun;
    pcSkip = false;
    pcBox.hidden = false;
    pcAgain.hidden = true;
    pcScreen.replaceChildren();
    await pcType("بدء فحص قدرة الهاتف…", "is-head", run);
    await pcType("قراءة معلومات الجهاز…", "", run);
    let report = {};
    try {
      const response = await fetchWithTimeout(apiRoot + "/phone-check", {cache: "no-store"}, 20000, true);
      const data = await response.json();
      report = (data && data.report) || {};
    } catch (_) {}
    if (run !== pcRun) return;
    const inApp = Boolean(report.in_app);
    if (inApp) {
      await pcType([report.model, report.android ? "أندرويد " + report.android : "", report.webview ? "WebView " + report.webview : ""]
        .filter(Boolean).join(" · "), "is-dim", run, 5);
    }
    await pcType("اختبار سرعة المعالج…", "", run);
    await pcSleep(60);
    if (run !== pcRun) return;
    speedTest(150);
    const speed = Math.max(speedTest(700), speedTest(700));
    if (run !== pcRun) return;

    const most = report.max_accounts || MAX_ACCOUNTS;
    const per = 450, reserve = 1024;
    const totalMb = report.ram_total_mb || (navigator.deviceMemory ? navigator.deviceMemory * 1024 : 0);
    const availMb = report.ram_avail_mb || 0;
    let byRam = 2;
    if (inApp && availMb) byRam = Math.floor((availMb + (report.browsers_open || 0) * per - reserve) / per);
    else if (totalMb) byRam = totalMb >= 6144 ? 3 : totalMb >= 3072 ? 2 : 1;
    if (totalMb && totalMb < 3072) byRam = Math.min(byRam, 1);
    else if (totalMb && totalMb < 6144) byRam = Math.min(byRam, 2);
    if (report.low_ram_device) byRam = Math.min(byRam, 1);
    const cores = report.cores || navigator.hardwareConcurrency || 0;
    const ghz = (report.max_mhz || 0) / 1000;
    let byCpu = speed >= 9000 ? 3 : speed >= 4500 ? 2 : 1;
    if (cores && cores < 6) byCpu = Math.min(byCpu, 1);
    else if (ghz && ghz < 2.0) byCpu = Math.min(byCpu, 2);
    let count = Math.min(byRam, byCpu, most);
    if (inApp && report.profiles === false) count = Math.min(count, 1);
    if (typeof report.thermal === "number" && report.thermal >= 3) count -= 1;
    count = Math.max(1, Math.min(most, count));

    // What each check found: [level, what, detail]
    const rows = [];
    const ramText = totalMb ? gb(totalMb) + " جيجا" + (availMb ? " · المتاح الآن " + gb(availMb) + " جيجا" : "") : "غير معروفة";
    if (inApp && availMb && byRam < 1) rows.push(["bad", "الذاكرة: " + ramText, "المتاح قليل الآن: أغلق التطبيقات الأخرى ثم أعد الفحص."]);
    else rows.push([byRam >= 2 ? "ok" : "warn", "الذاكرة: " + ramText,
      byRam >= 3 ? "تكفي ٣ حسابات." : byRam === 2 ? "تكفي حسابين." : "تكفي حسابًا واحدًا في كل مرة."]);
    rows.push([byCpu >= 2 ? "ok" : "warn", "المعالج: " + (byCpu >= 3 ? "قوي" : byCpu === 2 ? "متوسط" : "ضعيف"),
      [cores ? cores + " أنوية" : "", ghz ? "أعلى سرعة " + ghz.toFixed(1) + " GHz" : "", "نتيجة الاختبار " + speed.toLocaleString("en-US")].filter(Boolean).join(" · ")]);
    if (inApp) {
      if (report.profiles === false) rows.push(["bad", "متصفح مستقل لكل حساب: غير مدعوم", "لا تعمل الحسابات معًا إلا بعد تحديث «Android System WebView» من المتجر."]);
      else rows.push(["ok", "متصفح مستقل لكل حساب: مدعوم", "كل حساب في متصفحه، وتعمل الحسابات معًا."]);
      const heat = typeof report.thermal === "number" ? report.thermal : -1;
      if (heat >= 3) rows.push(["bad", "الحرارة: الجوال حار الآن", "خُفّض العدد واحدًا. دع الجوال يبرد ثم أعد الفحص."]);
      else if (heat === 2) rows.push(["warn", "الحرارة: دافئ", "قد يبطئ الجوال نفسه إذا زادت الحرارة."]);
      else if (heat >= 0) rows.push(["ok", "الحرارة: طبيعية", ""]);
      const level = typeof report.battery === "number" && report.battery >= 0 ? report.battery + "%" : "";
      if (report.power_save) rows.push(["warn", "وضع توفير الطاقة: مفعّل", "يبطئ المعالج ويوقف العمل في الخلفية. أوقفه أثناء المهام."]);
      else if (!report.charging && typeof report.battery === "number" && report.battery >= 0 && report.battery < 30) rows.push(["warn", "البطارية: " + level, "منخفضة وغير موصولة بالشاحن. المهام الطويلة تحتاج الشاحن."]);
      else rows.push(["ok", "البطارية" + (level ? ": " + level : ""), report.charging ? "على الشاحن." : "يُفضّل الشاحن في المهام الطويلة."]);
      if (report.overlay === false) rows.push(["bad", "العمل في الخلفية: ينقص إذن", "امنح إذن «الظهور فوق التطبيقات»، وإلا تتوقف المهام حين تخرج من التطبيق."]);
      else if (report.battery_free === false) rows.push(["warn", "العمل في الخلفية: تحسين البطارية مفعّل", "من إعدادات الجوال استثنِ التطبيق من «تحسين البطارية» حتى لا يوقفه النظام."]);
      else rows.push(["ok", "العمل في الخلفية", "الأذونات مكتملة."]);
    } else {
      rows.push(["warn", "الفحص الكامل داخل التطبيق", "هنا تُقدَّر الذاكرة والمعالج من المتصفح فقط."]);
    }
    for (const [level, what, detail] of rows) {
      const line = await pcType(what, "", run);
      if (run !== pcRun) return;
      pcTag(line, level);
      if (detail) await pcType(detail, "is-dim", run, 5);
    }
    if (run !== pcRun) return;
    await pcType("اكتمل الفحص.", "is-head", run);
    const final = document.createElement("div");
    final.className = "pc-final" + (count >= 2 ? (count === 2 && most > 2 ? " is-mid" : "") : " is-low");
    const number = document.createElement("b");
    number.textContent = String(count);
    const verdict = document.createElement("span");
    final.append(number, verdict);
    pcScreen.appendChild(final);
    const verdictText = count >= 3 ? "يتحمّل جوالك ٣ حسابات تعمل في الوقت نفسه."
      : count === 2 ? "يتحمّل جوالك حسابين يعملان في الوقت نفسه."
      : "يتحمّل جوالك حسابًا واحدًا يعمل في كل مرة. شغّل مهام الحسابات الأخرى بعده.";
    for (const letter of Array.from(verdictText)) {
      if (run !== pcRun) return;
      verdict.textContent += letter;
      if (!pcSkip && !typeAtOnce && letter !== " ") await pcSleep(16);
    }
    await pcType("تقدير تقريبي من مواصفات الهاتف وحالته الآن واختبار سرعة قصير.", "is-dim", run, 4);
    pcScreen.scrollTop = pcScreen.scrollHeight;
    pcAgain.hidden = false;
  }
  function closePhoneCheck() {
    pcRun++;                                         // (stops any typing still going)
    pcBox.hidden = true;
  }
  if (phoneCheckBtn) phoneCheckBtn.addEventListener("click", () => { runPhoneCheck(); });
  pcAgain.addEventListener("click", () => { runPhoneCheck(); });
  pcScreen.addEventListener("click", () => { pcSkip = true; });
  document.getElementById("pc-close").addEventListener("click", closePhoneCheck);
  document.getElementById("pc-done").addEventListener("click", closePhoneCheck);
  pcBox.addEventListener("click", (event) => { if (event.target === pcBox) closePhoneCheck(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !pcBox.hidden) closePhoneCheck(); });
  editGemini.addEventListener("click", () => {
    if (geminiKey.readOnly) {
      lockGemini(false);
      geminiKey.focus();
      geminiKey.select();
      return;
    }
    lockGemini(true);
    rememberGeminiLocal();
  });
  syncGemini();
  loadCommentsUsage(false);
  setInterval(() => { if (!document.hidden) loadCommentsUsage(false); }, 60000);

  // تنبيهات المالك وتعليماته من لوحة التحكّم: داخل التطبيق تذهب إلى قائمة التنبيهات (تفتح وحدها)، وفي
  // المتصفح العادي تظهر في شريط التنبيه أعلى الصفحة.
  let noticesBusy = false;
  async function loadAdminNotices() {
    if (noticesBusy) return;
    noticesBusy = true;
    try {
      const response = await fetchWithTimeout(apiRoot + "/notices", {headers: {"X-CSRF-Token": csrf}, cache: "no-store"}, 20000);
      const data = await response.json();
      if (!response.ok || !data.success) return;
      const inApp = Boolean(window.GroupsNative && typeof window.GroupsNative.notify === "function");
      for (const item of data.notices || []) {
        if (inApp) pushNative(item.text, "admin-" + item.kind);
        else showNotice("📢 " + item.text, item.kind === "info");
      }
    } catch (_) {
    } finally {
      noticesBusy = false;
    }
  }
  loadAdminNotices();
  setInterval(loadAdminNotices, 45000);

  // «مساعدة»: وصف المشكلة مع صور أو فيديو قصير، يُرسل إلى صاحب البرنامج (يصل إلى «الرسائل» في لوحة التحكّم).
  const helpBox = document.getElementById("help-box");
  if (helpBox) {
    const helpText = document.getElementById("help-text");
    const helpInput = document.getElementById("help-files");
    const helpList = document.getElementById("help-list");
    const helpStatus = document.getElementById("help-status");
    const helpSend = document.getElementById("help-send");
    const helpAttach = document.getElementById("help-attach");
    const HELP_MAX_FILES = 5, HELP_IMAGE_MB = 8, HELP_VIDEO_MB = 25;
    let helpFiles = [];
    let helpBusy = false;
    const sizeText = (bytes) => bytes >= 1048576 ? (bytes / 1048576).toFixed(1) + " ميجابايت" : Math.max(1, Math.round(bytes / 1024)) + " كيلوبايت";
    function helpSay(text, kind) {
      helpStatus.textContent = text || "";
      helpStatus.className = "help-status" + (kind ? " " + kind : "");
      helpStatus.hidden = !text;
    }
    function renderHelpFiles() {
      helpList.replaceChildren();
      helpFiles.forEach((entry, index) => {
        const row = document.createElement("li");
        let thumb;
        if (entry.url) {
          thumb = document.createElement("img");
          thumb.src = entry.url;
          thumb.alt = "";
        } else {
          thumb = document.createElement("span");
          thumb.textContent = "🎬";
        }
        thumb.className = "thumb";
        const name = document.createElement("div");
        name.className = "name";
        name.textContent = entry.file.name || (entry.url ? "صورة" : "فيديو");
        const small = document.createElement("small");
        small.textContent = sizeText(entry.file.size);
        const bar = document.createElement("div");
        bar.className = "bar";
        entry.bar = document.createElement("i");
        bar.appendChild(entry.bar);
        name.append(small, bar);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "usage-x";
        remove.textContent = "×";
        remove.setAttribute("aria-label", "إزالة الملف");
        remove.disabled = helpBusy;
        remove.addEventListener("click", () => {
          if (entry.url) URL.revokeObjectURL(entry.url);
          helpFiles.splice(index, 1);
          renderHelpFiles();
        });
        row.append(thumb, name, remove);
        helpList.appendChild(row);
      });
      helpList.hidden = !helpFiles.length;
      helpAttach.disabled = helpBusy || helpFiles.length >= HELP_MAX_FILES;
    }
    function openHelp() {
      helpBox.hidden = false;
      if (!helpBusy) helpSay("");
      setTimeout(() => helpText.focus(), 50);
    }
    function closeHelp() { helpBox.hidden = true; }
    function resetHelp() {
      helpFiles.forEach((entry) => entry.url && URL.revokeObjectURL(entry.url));
      helpFiles = [];
      helpText.value = "";
      renderHelpFiles();
    }
    const helpOpen = document.getElementById("help-open");
    if (helpOpen) helpOpen.addEventListener("click", openHelp);
    // In the app: its own «؟» button (under ⋮, at the top) opens this.
    window.__groupsHelp = {open: openHelp};
    try {
      if (window.GroupsNative && typeof window.GroupsNative.helpReady === "function") window.GroupsNative.helpReady(true);
    } catch (_) {}
    document.getElementById("help-close").addEventListener("click", closeHelp);
    document.getElementById("help-cancel").addEventListener("click", closeHelp);
    helpBox.addEventListener("click", (event) => { if (event.target === helpBox) closeHelp(); });
    helpAttach.addEventListener("click", () => helpInput.click());
    helpInput.addEventListener("change", () => {
      const problems = [];
      for (const file of Array.from(helpInput.files || [])) {
        const video = (file.type || "").startsWith("video/");
        const image = (file.type || "").startsWith("image/");
        if (helpFiles.length >= HELP_MAX_FILES) { problems.push("الحد الأقصى " + HELP_MAX_FILES + " ملفات."); break; }
        if (!video && !image) { problems.push("«" + file.name + "» ليس صورة ولا فيديو."); continue; }
        if (file.size > (video ? HELP_VIDEO_MB : HELP_IMAGE_MB) * 1048576) {
          problems.push("«" + file.name + "» أكبر من " + (video ? HELP_VIDEO_MB + " ميجابايت. قصّ الفيديو أو صوّر مقطعًا أقصر." : HELP_IMAGE_MB + " ميجابايت."));
          continue;
        }
        helpFiles.push({file, url: image ? URL.createObjectURL(file) : ""});
      }
      helpInput.value = "";
      renderHelpFiles();
      helpSay(problems.join(" "), problems.length ? "is-bad" : "");
    });
    function uploadHelpFile(entry) {
      return new Promise((resolve, reject) => {
        const request = new XMLHttpRequest();
        request.open("POST", apiRoot + "/support/upload");
        request.setRequestHeader("X-CSRF-Token", csrf);
        request.setRequestHeader("X-File-Type", entry.file.type || "");
        request.setRequestHeader("X-File-Name", encodeURIComponent(entry.file.name || ""));
        request.upload.onprogress = (event) => {
          if (entry.bar && event.lengthComputable) entry.bar.style.width = Math.round((event.loaded / event.total) * 100) + "%";
        };
        request.onload = () => {
          let data = {};
          try { data = JSON.parse(request.responseText); } catch (_) {}
          if (request.status === 200 && data.success && data.id) resolve(data.id);
          else reject(new Error(data.message || "تعذّر تجهيز الملف «" + (entry.file.name || "") + "»."));
        };
        request.onerror = () => reject(new Error("تعذّر تجهيز الملف «" + (entry.file.name || "") + "»."));
        request.send(entry.file);
      });
    }
    async function waitForHelpSend(id) {
      for (;;) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
        let data;
        try {
          const response = await fetchWithTimeout(apiRoot + "/support/status", {headers: {"X-CSRF-Token": csrf}, cache: "no-store"});
          data = await response.json();
        } catch (_) { continue; }
        if (!data || data.id !== id) return {state: "failed", message: "انقطع الإرسال. أعد المحاولة."};
        if (data.state === "sending") { helpSay(data.message, ""); continue; }
        return data;
      }
    }
    helpSend.addEventListener("click", async () => {
      const text = helpText.value.trim();
      if (text.length < 5 && !helpFiles.length) { helpSay("اكتب وصفًا للمشكلة (كلمتان على الأقل).", "is-bad"); helpText.focus(); return; }
      helpBusy = true;
      helpSend.disabled = true;
      renderHelpFiles();
      try {
        const ids = [];
        for (let i = 0; i < helpFiles.length; i += 1) {
          helpSay("يجهّز الملف " + (i + 1) + " من " + helpFiles.length + "…", "");
          ids.push(await uploadHelpFile(helpFiles[i]));
        }
        helpSay("يرسل الرسالة…", "");
        const started = await postJson("/support/send", {text, files: ids}, 120000);
        if (!started.success) throw new Error(started.message || "تعذّر الإرسال.");
        const done = await waitForHelpSend(started.id);
        if (done.state !== "done") throw new Error(done.message || "تعذّر الإرسال.");
        resetHelp();
        closeHelp();
        showNotice(done.message, true);
      } catch (error) {
        helpSay(error.message || "تعذّر الإرسال. أعد المحاولة.", "is-bad");
      } finally {
        helpBusy = false;
        helpSend.disabled = false;
        renderHelpFiles();
      }
    });
  }
  loadActionCounts();
  setInterval(() => { if (!document.hidden) loadActionCounts(); }, 5000);
  // The invisible top-left button (the owner's copy only): with the password, the comment cost starts
  // again from 0 (the count stays). Users' costs are reset from «توزيع البرنامج».
  document.getElementById("cost-reset")?.addEventListener("click", async () => {
    const password = window.prompt("كلمة السر");
    if (password === null) return;
    try {
      const data = await postJson("/gemini-usage/reset", {password});
      showNotice(data.message || "تعذّرت إعادة التعيين.", Boolean(data.success));
      if (data.success) loadCommentsUsage(true);
    } catch (_) {
      showNotice("تعذّر الاتصال أثناء إعادة التعيين.", false);
    }
  });

  accountSettings.addEventListener("click", () => setAccountPanel(accountPanel.hidden));

  async function verifySession() {
    try {
      const pulled = await postJson("/browser-session", {});
      if (pulled.success && pulled.auth_token) tokenField.value = pulled.auth_token;
    } catch (_) {}
    const authToken = tokenField.value.trim();
    if (!authToken) { showNotice("اضغط تسجيل الدخول، ثم ارجع واضغط تحقق.", false); return; }
    if (loginButton) loginButton.disabled = true;
    quickVerify.disabled = true;
    showNotice("جارٍ التحقق من الجلسة…", true);
    try {
      const data = await postJson("/verify-login", {auth_token: authToken}, 120000);
      showNotice(data.message, data.success);
      if (data.success) {
        showAccount(data.username ? "تم التحقق: هذه الجلسة تخص @" + data.username : "تم التحقق من الدخول، دون قراءة الاسم.");
        await loadSessions();
      }
    } catch (_) {
      showNotice("تعذّر الاتصال لإكمال التحقق.", false);
    } finally {
      if (loginButton) loginButton.disabled = false;
      quickVerify.disabled = false;
    }
  }
  if (loginButton) loginButton.addEventListener("click", verifySession);
  quickVerify.addEventListener("click", verifySession);
  // «تسجيل الدخول»: first the steps (sign in, open the chat and enter its code, come back and press «تحقق»),
  // then the browser opens when the user says so.
  const loginGuide = document.getElementById("login-guide");
  async function openLoginBrowser() {
    const button = document.getElementById("browser-login");
    if (button) button.disabled = true;
    showNotice("يُفتح المتصفح لتسجيل الدخول…", true);
    try {
      const data = await postJson("/browser-login", {}, 120000);
      showNotice(data.message, Boolean(data.success));
    } catch (_) {
      showNotice("تعذّر فتح المتصفح.", false);
    } finally {
      if (button) button.disabled = false;
    }
  }
  function closeLoginGuide() { loginGuide.hidden = true; }
  document.getElementById("browser-login")?.addEventListener("click", () => { loginGuide.hidden = false; });
  document.getElementById("guide-go").addEventListener("click", () => { closeLoginGuide(); openLoginBrowser(); });
  document.getElementById("guide-cancel").addEventListener("click", closeLoginGuide);
  document.getElementById("guide-close").addEventListener("click", closeLoginGuide);
  loginGuide.addEventListener("click", (event) => { if (event.target === loginGuide) closeLoginGuide(); });

  function renderGroups() {
    groupBox.hidden = linksMode || groupNames.length === 0;
    // Three rows, or fewer when there are fewer groups (no empty rows under them).
    groupList.style.gridTemplateRows = "repeat(" + Math.max(1, Math.min(3, groupNames.length)) + ", auto)";
    groupList.replaceChildren();
    groupNames.forEach((name) => {
      const item = document.createElement("li");
      const pick = document.createElement("button");
      pick.type = "button";
      pick.className = "pick" + (name === selectedGroup ? " is-on" : "");
      const who = document.createElement("span");
      who.className = "who";
      who.textContent = name;
      pick.append(who);
      pick.addEventListener("click", () => {
        selectedGroup = name;
        renderGroups();
        snapshotActive();
        showNotice("تم اختيار: " + name, true);
        pushScreen();
      });
      item.append(pick);
      groupList.appendChild(item);
    });
  }

  groupsButton.addEventListener("click", async () => {
    if (linksMode) {
      // «القروبات»: back to the groups shown before, at once (no browser, no chat).
      setLinksMode(false);
      if (!groupNames.length) showNotice("لا توجد قروبات معروضة بعد. اضغط «عرض القروبات» لجلبها.", true);
      return;
    }
    const authToken = tokenField.value.trim();
    const pin = pinField.value.trim();
    if (!authToken) { showNotice("سجّل الدخول ثم اضغط تحقق أولًا.", false); return; }
    if (!/^\d{4,8}$/.test(pin)) { showNotice("رمز الدردشة ٤ إلى ٨ أرقام.", false); revealField(pinField); return; }
    groupsButton.disabled = true;
    const settle = !!waitGroups.checked;
    const settleSeconds = secondsFrom(waitGroupsSec, 1, 120, 30);
    showNotice(settle ? "جارٍ فتح الدردشة ثم الانتظار " + settleSeconds + " ث قبل التقاط القروبات…" : "جارٍ فتح الدردشة وعرض القروبات…", true);
    try {
      const data = await postJson("/groups", {auth_token: authToken, chat_pin: pin, wait: settle, wait_seconds: settleSeconds}, (settleSeconds + 240) * 1000);
      if (!data.success) {
        showNotice(data.message || "تعذّر عرض القروبات.", false);
        return;
      }
      groupNames = data.groups || [];
      if (selectedGroup && !groupNames.includes(selectedGroup)) selectedGroup = "";
      renderGroups();
      showNotice(groupNames.length ? "ظهر " + groupNames.length + " قروب. اختر واحدًا ثم اضغط تنفيذ." : "لم يظهر أي قروب.", groupNames.length > 0);
    } catch (_) {
      showNotice("تعذّر الاتصال أثناء جلب القروبات.", false);
    } finally {
      groupsButton.disabled = false;
    }
  });

  document.getElementById("repost-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const authToken = tokenField.value.trim();
    const pin = pinField.value.trim();
    const stopRaw = stopField.value.trim();
    const stopMatch = stopRaw.match(/status\/(\d{6,25})/);
    const stopId = stopMatch ? stopMatch[1] : (/^\d{15,25}$/.test(stopRaw) ? stopRaw : "");
    const actions = selectedActions();
    const byLinks = linksMode;
    const links = byLinks ? pastedTweets(linksField.value) : [];
    if (!authToken) { showNotice("سجّل الدخول ثم اضغط تحقق أولًا.", false); return; }
    if (byLinks) {
      // No chat and no group: only the tweets are needed (the chat PIN is not).
      if (!links.length) { showNotice("الصق رابط تغريدة واحدًا على الأقل.", false); linksField.focus(); return; }
      if (links.length > MAX_LINKS) { showNotice("الحد الأقصى " + MAX_LINKS + " رابط في المهمة الواحدة.", false); linksField.focus(); return; }
    } else {
      if (!/^\d{4,8}$/.test(pin)) { showNotice("أدخل رمز الدردشة.", false); revealField(pinField); return; }
      if (!selectedGroup) { showNotice("اعرض القروبات ثم اختر واحدًا.", false); return; }
      if (!stopId) { showNotice("الصق رابط التغريدة المحددة أو رقمها.", false); stopField.focus(); return; }
    }
    if (!actions.length) { showNotice("اختر إجراءً واحدًا على الأقل.", false); return; }
    if (actions.includes("comment") && (geminiByOwner || controlOn)) {
      // (Its keys come from the owner when it starts: the script waits for them, and says if they do not come.)
    } else if (actions.includes("comment")) {
      repostButton.disabled = true;          // (not sent twice while it asks)
      await loadCommentsEngine();
      repostButton.disabled = false;
      if (!commentsByOther) {
        if (!geminiKey.value.trim()) { openGemini(true); lockGemini(false); showNotice("أدخل مفتاح Gemini.", false); geminiKey.focus(); return; }
        if (!geminiModel.value.trim()) { openGemini(true); lockGemini(false); showNotice("أدخل اسم النموذج.", false); geminiModel.focus(); return; }
      }
      rememberGeminiLocal();
    }
    repostButton.disabled = true;
    try {
      const task = {
        auth_token: authToken,
        chat_pin: pin,
        actions,
        gemini_api_key: geminiKey.value.trim(),
        gemini_model: geminiModel.value.trim(),
        reply_voice: selectedVoice()
      };
      if (byLinks) task.links = links;
      else Object.assign(task, {group: selectedGroup, stop_tweet: stopRaw});
      const started = await postJson("/group-run", task, 90000);
      if (!started.success || !started.job_id || !started.job_key) {
        showNotice(started.message || "تعذّر بدء التنفيذ.", false);
        return;
      }
      const accountRow = sessionRows.find((item) => item.token === authToken);
      const account = accountRow && accountRow.username ? "@" + accountRow.username : "";
      const name = byLinks ? "روابط (" + links.length + ")" : selectedGroup;
      followTask({
        id: started.job_id,
        key: started.job_key,
        token: authToken,
        title: name + (account ? " · " + account : ""),
        startedAt: Date.now()
      });
      showNotice(started.queued
        ? "أُضيفت المهمة إلى الانتظار: " + (started.message || "تبدأ تلقائيًا بعد انتهاء ما قبلها على هذا الحساب.").replace(/^في الانتظار: /, "")
        : (byLinks ? "بدأت مهمة على " + links.length + " تغريدة من الروابط." : "بدأت مهمة «" + selectedGroup + "»."), true);
    } catch (_) {
      showNotice("تعذّر الاتصال أثناء التنفيذ.", false);
    } finally {
      repostButton.disabled = false;
    }
  });

  tokenField.addEventListener("input", () => {
    const token = tokenField.value.trim();
    const row = sessionRows.find((item) => item.token === token);
    if (row) {
      showAccount(row.username ? "الجلسة المحفوظة: @" + row.username : "تم اختيار جلسة محفوظة.");
      if (document.activeElement !== pinField) pinField.value = row.chat_pin || "";
    } else showAccount("");
    renderSessions();
  });

  let pinSaveTimer = 0;
  function saveAccountPin() {
    const token = tokenField.value.trim();
    const pin = pinField.value.trim();
    if (!token || !/^\d{4,8}$/.test(pin)) return;
    const row = sessionRows.find((item) => item.token === token);
    if (row) row.chat_pin = pin;
    postJson("/sessions/pin", {auth_token: token, chat_pin: pin}).catch(() => {});
  }

  let screenTimer = 0;
  function pushScreen() {
    clearTimeout(screenTimer);
    screenTimer = setTimeout(() => {
      const payload = {
        auth_token: tokenField.value.trim(),
        chat_pin: pinField.value.trim(),
        group: selectedGroup,
        stop_tweet: stopField.value.trim(),
        actions: selectedActions()
      };
      if (groupNames.length) payload.groups = groupNames;
      postJson("/screen", payload).catch(() => {});
    }, 350);
  }

  function applyScreen(data) {
    if (!data) return;
    if (data.auth_token) tokenField.value = data.auth_token;
    lockToken(true);
    if (data.chat_pin) pinField.value = data.chat_pin;
    if (typeof data.stop_tweet === "string") stopField.value = data.stop_tweet;
    if (Array.isArray(data.actions) && data.actions.length) {
      ["repost", "like", "bookmark", "comment"].forEach((key) => {
        const box = document.getElementById("action-" + key);
        if (box) box.checked = data.actions.includes(key);
      });
      syncGemini();
    }
    if (Array.isArray(data.groups) && data.groups.length) {
      groupNames = data.groups;
      if (data.group) selectedGroup = data.group;
      renderGroups();
    } else if (data.group) {
      selectedGroup = data.group;
    }
  }

  async function restoreScreen() {
    // The saved tasks start showing their progress at once, without waiting for the rest.
    readTasks().forEach((task) => followTask(task));
    let runningJobs = [];
    let screenJob = null;
    for (let attempt = 0; attempt < 2 && !screenJob; attempt += 1) {
      try {
        const response = await fetchWithTimeout(apiRoot + "/state", {cache: "no-store"});
        const data = await response.json();
        if (response.ok && data && data.success) {
          applyScreen(data);
          screenJob = data;
          runningJobs = Array.isArray(data.running_jobs) ? data.running_jobs : [];
        }
      } catch (_) {}
    }
    await loadSessions();
    runningJobs.slice().reverse().forEach((job) => {
      const same = screenJob && screenJob.job_id === job.id;
      followTask({
        id: job.id,
        key: same ? (screenJob.job_key || "") : "",
        token: (screenJob && screenJob.auth_token) || "",
        title: job.username || (screenJob && screenJob.group) || "مهمة"
      });
    });
    if (!runningJobs.length && screenJob && screenJob.job && screenJob.job.status && screenJob.job.status !== "running") {
      finishTrackedJob(screenJob.job);
    }
    // Now the account is known: show only its cards and its counters, and its own pasted links.
    activeToken = tokenField.value.trim();
    if (activeToken && accountState[activeToken]) {
      linksField.value = accountState[activeToken].linksText || "";
      setLinksMode(!!accountState[activeToken].links);
    }
    filterTaskCards();
    loadActionCounts();
    if (taskList.querySelector(".task-card:not([hidden])")) {
      taskBoard.hidden = false;
      taskBoard.scrollIntoView({block: "start"});
    } else {
      taskBoard.hidden = true;
    }
  }

  tokenField.addEventListener("change", pushScreen);
  tokenField.addEventListener("input", pushScreen);
  pinField.addEventListener("input", () => {
    clearTimeout(pinSaveTimer);
    pinSaveTimer = setTimeout(saveAccountPin, 400);
  });
  pinField.addEventListener("change", () => {
    saveAccountPin();
    pushScreen();
  });
  stopField.addEventListener("change", pushScreen);
  document.querySelectorAll('#repost-form input[type="checkbox"]').forEach((box) => {
    box.addEventListener("change", pushScreen);
  });

  restoreScreen();

  // Updates. A user's copy shows «تحديث» when the owner offers a newer version; the owner's
  // copy shows «توزيع البرنامج», which opens g.py's page.
  const updateBar = document.getElementById("update-bar");
  const updateText = document.getElementById("update-text");
  const updateButton = document.getElementById("update-button");
  const updateState = document.getElementById("update-state");
  const distLink = document.getElementById("dist-link");

  async function checkUpdate() {
    try {
      const response = await fetchWithTimeout(apiRoot + "/update/check", {cache: "no-store"}, 30000);
      const data = await response.json();
      if (data.owner) {
        // g.py's page: this host on its own port, unless CONTROL_URL says where.
        if (data.control_url || data.control_port) {
          distLink.href = data.control_url || location.protocol + "//" + location.hostname + ":" + data.control_port + "/";
          distLink.hidden = false;
        }
        return;
      }
      updateState.textContent = data.message || "";
      if (data.available && !updateButton.disabled) {
        updateText.textContent = "يتوفر إصدار جديد " + data.latest;
        updateButton.textContent = "تحديث إلى " + data.latest;
      }
      updateBar.hidden = !data.available;
    } catch (_) {}
  }

  updateButton.addEventListener("click", async () => {
    updateButton.disabled = true;
    updateText.textContent = "جارٍ تنزيل التحديث…";
    let data;
    try {
      data = await postJson("/update/apply", {}, 300000);
    } catch (_) {
      data = {message: "تعذّر الاتصال أثناء التحديث."};
    }
    if (!data.success) {
      updateText.textContent = data.message || "تعذّر التحديث.";
      updateButton.disabled = false;
      return;
    }
    updateText.textContent = data.message;
    // Wait until the program runs again with the new version, then open its page.
    const started = Date.now();
    while (Date.now() - started < 90000) {
      await new Promise((done) => setTimeout(done, 1500));
      try {
        const response = await fetchWithTimeout(apiRoot + "/update/check?light=1", {cache: "no-store"}, 4000);
        if ((await response.json()).version === data.version) {
          location.reload();
          return;
        }
      } catch (_) {}
    }
    updateText.textContent = "لم يعد البرنامج للعمل بعد. حدّث الصفحة بعد قليل.";
  });

  checkUpdate();
  setInterval(() => { if (!document.hidden) checkUpdate(); }, 2 * 60 * 1000);

  // ---------------------------------------------------------------- back from the background
  // When the phone comes back to the app, the page does not wait for its next round: it asks the program at once
  // for the counters, the account's tasks (one that started or ended meanwhile shows) and the notices, and wakes
  // the tasks it follows. Reads still out from before (the phone may have frozen the app mid-way) are dropped and
  // asked again. The app calls window.__ggResume() as well, and takes no answer as a sign the page is stuck.
  let hiddenSince = document.hidden ? Date.now() : 0;
  let lastResume = 0;
  async function resyncAccount() {
    const token = tokenField.value.trim();
    try {
      const response = await fetchWithTimeout(apiRoot + "/state", {headers: token ? {"X-Account-Token": token} : {}, cache: "no-store"});
      const data = await response.json();
      if (!response.ok || !data || !data.success || tokenField.value.trim() !== token) return;
      (data.running_jobs || []).forEach((job) => followTask({
        id: job.id,
        key: data.job_id === job.id ? (data.job_key || "") : "",
        token: token,
        title: job.username || data.group || "مهمة"
      }));
      filterTaskCards();
    } catch (_) {}
  }
  function resume(force) {
    const now = Date.now();
    const away = hiddenSince ? now - hiddenSince : 0;
    hiddenSince = 0;
    if (!force && now - lastResume < 1500) return;
    lastResume = now;
    inFlight.forEach((entry) => {
      if (entry.read && entry.at < now) { entry.dropped = true; entry.controller.abort(); }
    });
    wakeAll();
    setTimeout(wakeAll, 40);            // (and the ones that start waiting after a dropped read: they ask again at once)
    loadActionCounts();
    setTimeout(loadAdminNotices, 40);   // (after its dropped read has let go)
    resyncAccount();
    if (force || away > 60000) { checkUpdate(); loadCommentsUsage(false); }
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) hiddenSince = Date.now();
    else resume(false);
  });
  window.addEventListener("pageshow", (event) => { if (event.persisted) resume(true); });
  window.addEventListener("online", () => resume(true));
  window.addEventListener("focus", () => { if (hiddenSince) resume(false); });
  window.__ggResume = () => { resume(false); return "ok"; };

})();
</script>
</body>
</html>

'''

PAGE = load_page()

ACTION_CONTROLS = {
    "repost": ("unretweet", "retweet"),
    "like": ("unlike", "like"),
    "bookmark": ("removeBookmark", "bookmark"),
}

READ_GROUPS_JS = r"""
(wanted) => {
  const clean = (value) => (value || "").replace(/\s+/g, " ").trim();
  const timeLike = /^(now|الآن|\d{1,2}:\d{2}(?:\s*[ap]m)?|\d+\s*[smhdw]|\d+\s*(?:د|دقائق|دقيقة|س|ساعة|ساعات|ي|يوم|أيام|ث|أسبوع|أسابيع))\.?$/i;
  const chrome = /^(all|unread|direct|groups|group|messages|search|new chat|chat|requests|people|الكل|غير مقروء|المباشرة|قروبات|القروبات|مجموعات|المجموعات|رسائل|بحث|تم)$/i;
  const roots = [];
  const walk = (root) => {
    if (!root || roots.includes(root)) return;
    roots.push(root);
    const nodes = root.querySelectorAll ? root.querySelectorAll("*") : [];
    for (const node of nodes) if (node.shadowRoot) walk(node.shadowRoot);
  };
  walk(document);
  const queryAll = (selector) => {
    const out = [];
    for (const root of roots) if (root.querySelectorAll) out.push(...root.querySelectorAll(selector));
    return out;
  };
  const rows = queryAll('[data-testid^="dm-conversation-item-"], [data-testid^="dm-message-request-item-"]');
  const nameOf = (row) => {
    const titled = [...row.querySelectorAll(".line-clamp-1")].map((el) => clean(el.textContent || "")).find((text) => text.length >= 2 && text.length <= 80 && !timeLike.test(text) && !chrome.test(text));
    if (titled) return titled;
    const leaves = [...row.querySelectorAll("span, div")].filter((el) => {
      if (el.querySelector("span, div")) return false;
      const text = clean(el.textContent || "");
      return text.length >= 2 && text.length <= 80 && !timeLike.test(text) && !chrome.test(text);
    });
    if (leaves.length) return clean(leaves[0].textContent || "");
    return "";
  };
  if (wanted) {
    const target = clean(typeof wanted === "object" ? (wanted.name || "") : wanted);
    const wantedId = typeof wanted === "object" ? String(wanted.testid || "") : "";
    const open = (row, how) => {
      const link = row.querySelector('a[href*="/i/chat/"], a[href*="/messages/"]');
      const path = link ? (link.getAttribute("href") || "") : "";
      if (link) link.click();
      else row.click();
      return {clicked: true, how, matched: nameOf(row), path: path, groups: [], rows: rows.length, loading: false};
    };
    // 1) The group's own id: stays the same when the group is renamed.
    if (wantedId) {
      for (const row of rows) if ((row.getAttribute("data-testid") || "") === wantedId) return open(row, "id");
    }
    // 2) The exact name.
    for (const row of rows) if (nameOf(row) === target) return open(row, "name");
    // 3) A very similar name: only a few characters changed (usually near the end).
    const chars = (text) => Array.from(text || "");
    const distance = (a, b) => {
      let prev = Array.from({length: b.length + 1}, (_, j) => j);
      for (let i = 1; i <= a.length; i++) {
        const cur = [i];
        for (let j = 1; j <= b.length; j++) {
          cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        }
        prev = cur;
      }
      return prev[b.length];
    };
    const shared = (a, b) => { let n = 0; while (n < a.length && n < b.length && a[n] === b[n]) n++; return n; };
    const targetChars = chars(target);
    const allowed = Math.min(6, Math.max(2, Math.floor(targetChars.length * 0.35)));
    let best = null, bestDistance = Infinity, tie = false;
    for (const row of rows) {
      const id = row.getAttribute("data-testid") || "";
      const desc = row.getAttribute("aria-description") || "";
      if (!(/dm-conversation-item-g\d/.test(id) || /جماعية|group chat/i.test(desc))) continue;
      const nameChars = chars(nameOf(row));
      if (shared(targetChars, nameChars) < Math.min(4, targetChars.length)) continue;
      const d = distance(targetChars, nameChars);
      if (d > allowed) continue;
      if (d < bestDistance) { best = row; bestDistance = d; tie = false; }
      else if (d === bestDistance) tie = true;
    }
    if (best && !tie) return open(best, "similar");
    return {clicked: false, groups: [], rows: rows.length, loading: false};
  }
  const groups = [];
  const ids = [];
  const paths = [];
  const seen = new Set();
  for (const row of rows) {
    const id = row.getAttribute("data-testid") || "";
    const desc = row.getAttribute("aria-description") || "";
    const isGroup = /dm-conversation-item-g\d/.test(id) || /جماعية|group chat/i.test(desc);
    if (!isGroup) continue;
    const name = nameOf(row);
    if (!name || seen.has(name)) continue;
    seen.add(name);
    groups.push(name);
    ids.push(id);
    const link = row.querySelector('a[href*="/i/chat/"], a[href*="/messages/"]');
    paths.push(link ? (link.getAttribute("href") || "") : "");
  }
  const loading = queryAll('[data-testid="dm-conversation-list-loading-footer"]').some((el) => {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  });
  return {clicked: false, groups, ids, paths, rows: rows.length, loading};
}
"""

SCROLL_INBOX_JS = r"""
() => {
  const roots = [];
  const walk = (root) => {
    if (!root || roots.includes(root)) return;
    roots.push(root);
    const nodes = root.querySelectorAll ? root.querySelectorAll("*") : [];
    for (const node of nodes) if (node.shadowRoot) walk(node.shadowRoot);
  };
  walk(document);
  const query = (selector) => {
    for (const root of roots) {
      const found = root.querySelector && root.querySelector(selector);
      if (found) return found;
    }
    return null;
  };
  const panel = query('[data-testid="dm-inbox-panel"]');
  const row = query('[data-testid^="dm-conversation-item-"]');
  let node = panel || (row ? row.parentElement : null);
  while (node && node !== document.body) {
    const style = getComputedStyle(node);
    if (/(auto|scroll|overlay)/.test(style.overflowY) && node.scrollHeight > node.clientHeight + 40) {
      const before = node.scrollTop;
      node.scrollTop = before + Math.max(220, node.clientHeight * 0.75);
      return node.scrollTop > before;
    }
    node = node.parentElement;
  }
  return false;
}
"""

# Shared start of the group chat's scripts below: finds elements in the page and its shadow
# roots, and the element that really scrolls the chat.
CHAT_FIND_JS = r"""
  const roots = [];
  const walk = (root) => {
    if (!root || roots.includes(root)) return;
    roots.push(root);
    const nodes = root.querySelectorAll ? root.querySelectorAll("*") : [];
    for (const node of nodes) if (node.shadowRoot) walk(node.shadowRoot);
  };
  walk(document);
  const queryAll = (selector) => {
    const out = [];
    for (const root of roots) if (root.querySelectorAll) out.push(...root.querySelectorAll(selector));
    return out;
  };
  // How much of the element shows on the screen, in square pixels.
  const shownArea = (el) => {
    if (el.checkVisibility && !el.checkVisibility({opacityProperty: true, visibilityProperty: true, checkOpacity: true, checkVisibilityCSS: true})) return 0;
    const rect = el.getBoundingClientRect();
    const width = Math.min(rect.right, innerWidth) - Math.max(rect.left, 0);
    const height = Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0);
    return width > 0 && height > 0 ? width * height : 0;
  };
  // The match that shows most on the screen (the page can also hold a hidden copy of the
  // chat), else the first match.
  const query = (selector) => {
    const all = queryAll(selector);
    let best = null;
    let bestArea = 0;
    for (const el of all) {
      const area = shownArea(el);
      if (area > bestArea) {
        best = el;
        bestArea = area;
      }
    }
    return best || all[0] || null;
  };
  // The element that really scrolls the chat: X's scroller itself, one of its parents, or the
  // page (X's phone layout can scroll one of these instead of the scroller).
  const scrollerOf = (start) => {
    for (let node = start; node && node.nodeType === 1; node = node.parentElement || (node.parentNode && node.parentNode.host) || null) {
      if (/(auto|scroll|overlay)/.test(getComputedStyle(node).overflowY) && node.scrollHeight > node.clientHeight + 10) return node;
    }
    const page = document.scrollingElement;
    if (page && page.scrollHeight > page.clientHeight + 10) return page;
    return start;
  };
"""

GROUP_READ_TWEETS_JS = r"""
(arg) => {
  let stopId = "";
  let dir = 0;
  let factor = 1;
  if (arg && typeof arg === "object") {
    stopId = String(arg.stopId || "");
    dir = arg.dir === 1 || arg.dir === -1 ? arg.dir : 0;
    factor = Number(arg.factor) > 1 ? Number(arg.factor) : 1;
  } else {
    stopId = String(arg || "");
  }
  const clean = (value) => (value || "").replace(/\s+/g, " ").trim();
""" + CHAT_FIND_JS + r"""
  const collectDeep = (root, selector, out) => {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll(selector).forEach((node) => out.push(node));
    root.querySelectorAll("*").forEach((node) => {
      if (node.shadowRoot) collectDeep(node.shadowRoot, selector, out);
    });
  };
  const list = query('[data-testid="dm-message-list"]')
    || query('[data-testid="dm-conversation-content"]')
    || query('[data-testid="dm-message-scroller"]');
  if (!list) return {tweets: [], pending: 0};
  const bubbles = [];
  collectDeep(list, '[data-testid^="message-"]', bubbles);
  const isBubble = (el) => {
    const id = el.getAttribute("data-testid") || "";
    return id.startsWith("message-") && !id.startsWith("message-text-");
  };
  const messages = bubbles.filter((el) => {
    if (!isBubble(el)) return false;
    const nested = [];
    collectDeep(el, '[data-testid^="message-"]', nested);
    return !nested.some((node) => node !== el && isBubble(node));
  });
  const targets = messages.length ? messages : [list];
  const statusRe = /(?:https?:\/\/)?(?:www\.)?(?:x|twitter)\.com\/(?:i\/web\/status\/|i\/status\/)?([A-Za-z0-9_]{1,15}\/)?status\/(\d{6,25})/gi;
  const bareRe = /status\/(\d{6,25})/;
  const tweets = [];
  const seen = new Set();
  let pending = 0;
  const climb = (node) => {
    const chain = [];
    let el = node;
    while (el && chain.length < 50) {
      chain.push(el);
      if (el.parentElement) el = el.parentElement;
      else if (el.parentNode && el.parentNode.nodeType === 11) el = el.parentNode.host;
      else break;
    }
    return chain;
  };
  const statusOf = (href) => {
    const match = (href || "").match(/status\/(\d{6,25})/);
    return match ? match[1] : "";
  };
  const insideQuote = (node) => climb(node).some((el) => {
    const test = (el.getAttribute && el.getAttribute("data-testid")) || "";
    return /quote/i.test(test);
  });
  const pushId = (statusId, href, bubble, text, hit) => {
    if (!statusId) return;
    if (seen.has(statusId)) {
      if (hit) {
        const existing = tweets.find((row) => row.statusId === statusId);
        if (existing) existing.hit = true;
      }
      return;
    }
    seen.add(statusId);
    const rect = bubble.getBoundingClientRect();
    tweets.push({
      statusId,
      url: href || ("https://x.com/i/web/status/" + statusId),
      text: (text || "تغريدة").slice(0, 500),
      top: Math.round(rect.top || 0),
      hit: !!hit
    });
  };
  for (const bubble of targets) {
    const links = [];
    collectDeep(bubble, '[href*="status/"]', links);
    const candidates = [];
    for (const link of links) {
      const href = link.getAttribute("href") || "";
      const statusId = statusOf(href);
      if (!statusId || insideQuote(link)) continue;
      const nestedUnderOther = climb(link).some((el) => {
        if (el === link || !el.getAttribute) return false;
        const parentId = statusOf(el.getAttribute("href") || "");
        return parentId && parentId !== statusId;
      });
      if (nestedUnderOther) continue;
      candidates.push({statusId, href, link, depth: climb(link).length});
    }
    let foundHere = 0;
    if (candidates.length) {
      candidates.sort((a, b) => a.depth - b.depth);
      const outer = candidates[0];
      const textNodes = [];
      collectDeep(bubble, '[data-testid="tweetText"]', textNodes);
      const ownText = textNodes.find((node) => !insideQuote(node));
      const text = clean((ownText && ownText.innerText) || "");
      pushId(outer.statusId, outer.href, bubble, text, !!(stopId && outer.statusId === stopId));
      foundHere = 1;
    }
    const blob = clean(bubble.innerText || "");
    if (!foundHere) {
      statusRe.lastIndex = 0;
      const match = statusRe.exec(blob);
      if (match) {
        pushId(match[2], match[0], bubble, blob.slice(0, 280), !!(stopId && match[2] === stopId));
        foundHere = 1;
      }
    }
    if (!foundHere) {
      const match = bareRe.exec(blob);
      if (match) {
        pushId(match[1], "https://x.com/i/web/status/" + match[1], bubble, blob.slice(0, 280), !!(stopId && match[1] === stopId));
        foundHere = 1;
      }
    }
    const cardish = [];
    collectDeep(bubble, '[data-testid="tweetText"], article, [data-testid="card.wrapper"], [data-testid="tweetPhoto"]', cardish);
    if (!foundHere && cardish.length) pending += 1;
  }
  const scroller = scrollerOf(query('[data-testid="dm-message-scroller"]') || list);
  const ids = messages.map((el) => el.getAttribute("data-testid") || "");
  const fingerprint = ids.slice(0, 8).concat(ids.slice(-8)).join("|");
  let loading = false;
  const spinner = list.querySelector('[data-testid="dm-message-list-spinner-slot"], [data-testid="dm-message-list-spinner"], [data-testid*="spinner"], [role="progressbar"]');
  if (spinner) {
    const rect = spinner.getBoundingClientRect();
    loading = rect.width > 8 && rect.height > 8;
  }
  let moved = 0;
  let atOlderEdge = false;
  if (scroller) {
    const beforeTop = scroller.scrollTop || 0;
    atOlderEdge = beforeTop <= 48;
    const client = scroller.clientHeight || 800;
    const base = dir > 0
      ? Math.max(560, Math.min(1200, Math.round(client * 0.75)))
      : Math.max(400, Math.min(800, Math.round(client * 0.5)));
    // GROUP_SCROLL_FACTOR times the step, but never past what the chat shows at once.
    const step = Math.max(base, Math.min(base * factor, Math.round(client * 0.9)));
    if (dir === -1 || dir === 1) {
      if (dir < 0 && beforeTop <= 48) {
        scroller.scrollTop = 0;
        try { scroller.dispatchEvent(new WheelEvent("wheel", {deltaY: -640, bubbles: true, cancelable: true})); } catch (error) {}
      } else if (dir > 0 && beforeTop + client >= scroller.scrollHeight - 80) {
        scroller.scrollTop = scroller.scrollHeight;
      } else {
        const next = dir < 0 ? Math.max(0, beforeTop - step) : Math.min(scroller.scrollHeight, beforeTop + step);
        scroller.scrollTop = next;
      }
      try { scroller.dispatchEvent(new Event("scroll", {bubbles: true})); } catch (error) {}
      moved = Math.abs((scroller.scrollTop || 0) - beforeTop);
    }
  }
  return {
    tweets,
    pending,
    messages: messages.length,
    fingerprint,
    loading,
    atOlderEdge,
    moved: Math.round(moved),
    scrollHeight: scroller ? Math.round(scroller.scrollHeight) : 0,
    scrollTop: scroller ? Math.round(scroller.scrollTop) : 0,
    clientHeight: scroller ? Math.round(scroller.clientHeight) : 0
  };
}
"""

GROUP_CHAT_SCROLL_JS = r"""
(action) => {
""" + CHAT_FIND_JS + r"""
  const list = query('[data-testid="dm-message-list"]') || query('[data-testid="dm-conversation-content"]');
  const start = query('[data-testid="dm-message-scroller"]') || list;
  const scroller = start ? scrollerOf(start) : null;
  const spinner = list && (list.querySelector('[data-testid="dm-message-list-spinner-slot"], [data-testid="dm-message-list-spinner"], [data-testid*="spinner"]') || list.querySelector('[role="progressbar"]'));
  let spinnerVisible = false;
  if (spinner) {
    const rect = spinner.getBoundingClientRect();
    spinnerVisible = rect.width > 8 && rect.height > 8;
  }
  const messageNodes = list
    ? [...list.querySelectorAll('[data-testid^="message-"]')].filter((el) => {
        const id = el.getAttribute("data-testid") || "";
        return id.startsWith("message-") && !id.startsWith("message-text-");
      })
    : [];
  const messages = messageNodes.length;
  const ids = messageNodes.map((el) => el.getAttribute("data-testid") || "");
  const fingerprint = ids.slice(0, 8).concat(ids.slice(-8)).join("|");
  let moved = 0;
  let atOlderEdge = false;
  if (scroller) {
    atOlderEdge = scroller.scrollTop <= 48;
    if (action === "latest") {
      const before = scroller.scrollTop;
      scroller.scrollTop = scroller.scrollHeight;
      moved = Math.abs(scroller.scrollTop - before);
    }
    if (action === "older") {
      const before = scroller.scrollTop;
      const step = Math.max(420, Math.round(scroller.clientHeight * 0.75));
      scroller.scrollTop = Math.max(0, before - step);
      moved = Math.abs(scroller.scrollTop - before);
    }
  }
  return {
    hasList: !!list,
    messages,
    fingerprint,
    loading: spinnerVisible,
    atOlderEdge,
    reversed: false,
    olderSign: -1,
    moved: Math.round(moved),
    scrollHeight: scroller ? Math.round(scroller.scrollHeight) : 0,
    scrollTop: scroller ? Math.round(scroller.scrollTop) : 0,
    clientHeight: scroller ? Math.round(scroller.clientHeight) : 0
  };
}
"""

CHAT_URLS = ("https://x.com/i/chat", "https://x.com/messages")

ALLOWED_ACTIONS = {"repost", "like", "bookmark", "comment"}


def parse_requested_count(value) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    return None


def normalize_status_path(href: str) -> str | None:
    raw = href or ""
    for match in re.finditer(r"(?:https?://(?:www\.)?(?:x|twitter)\.com)?/([A-Za-z0-9_]{1,15})/status/(\d{6,25})", raw):
        owner, status_id = match.group(1), match.group(2)
        if owner.lower() in {"i", "web", "intent", "share"}:
            continue
        return f"/{owner}/status/{status_id}"
    status_id = re.search(r"status/(\d{6,25})", raw)
    if status_id:
        return f"/i/web/status/{status_id.group(1)}"
    return None


_mouse_at: dict[int, tuple[float, float]] = {}


def _mouse_start(page, target_x: float, target_y: float) -> tuple[float, float]:
    remembered = _mouse_at.get(id(page))
    if remembered:
        return remembered
    size = page.viewport_size or {"width": VIEWPORT_WIDTH, "height": 900}
    angle = random.uniform(0, math.tau)
    distance = random.uniform(140, 420)
    return (
        min(max(target_x + math.cos(angle) * distance, 8), size["width"] - 8),
        min(max(target_y + math.sin(angle) * distance, 8), size["height"] - 8),
    )


def _human_path(start: tuple[float, float], end: tuple[float, float], viewport: dict) -> list[tuple[float, float]]:
    sx, sy = start
    ex, ey = end
    dx, dy = ex - sx, ey - sy
    dist = math.hypot(dx, dy)
    if dist < 6:
        return [(ex, ey)]
    side_x, side_y = -dy / dist, dx / dist
    bend = max(-220.0, min(220.0, dist * random.uniform(0.18, 0.62))) * random.choice((-1.0, 1.0))
    c1 = (
        sx + dx * random.uniform(0.18, 0.42) + side_x * bend * random.uniform(0.35, 1.05),
        sy + dy * random.uniform(0.18, 0.42) + side_y * bend * random.uniform(0.35, 1.05),
    )
    c2 = (
        sx + dx * random.uniform(0.58, 0.86) + side_x * bend * random.uniform(-0.25, 0.85),
        sy + dy * random.uniform(0.58, 0.86) + side_y * bend * random.uniform(-0.25, 0.85),
    )
    width = float(viewport.get("width") or VIEWPORT_WIDTH)
    height = float(viewport.get("height") or 900)
    sway = random.uniform(2, 6)
    phase = random.uniform(0, math.tau)
    waves = random.uniform(1.0, 1.6)
    ease = random.uniform(1.2, 1.6)
    points: list[tuple[float, float]] = []
    steps = 2
    for index in range(1, steps + 1):
        raw = index / steps
        progress = 1 - (1 - raw) ** ease
        inverse = 1 - progress
        x = (inverse ** 3) * sx + 3 * (inverse ** 2) * progress * c1[0] + 3 * inverse * (progress ** 2) * c2[0] + (progress ** 3) * ex
        y = (inverse ** 3) * sy + 3 * (inverse ** 2) * progress * c1[1] + 3 * inverse * (progress ** 2) * c2[1] + (progress ** 3) * ey
        wobble = math.sin(progress * waves * math.tau + phase) * sway * (1 - progress)
        x += side_x * wobble
        y += side_y * wobble
        if index < steps:
            x = min(max(x, 1), width - 1)
            y = min(max(y, 1), height - 1)
        points.append((x, y))
    points[-1] = (ex, ey)
    return points


# Inside the Android app («قروبات») the page is not scrolled for the script's own sake: a button is clicked where
# it is, once the page has stopped moving, and the aim is checked again just before the press (on a phone X loads
# slower, and scrolling it while it loaded moved the buttons from under the mouse).
IN_APP = os.environ.get("GG_IN_APP") == "1"


def _same_box(a: dict | None, b: dict | None) -> bool:
    return bool(a and b) and all(abs(float(a[key]) - float(b[key])) < 1 for key in ("x", "y", "width", "height"))


def _in_view(page, box: dict | None) -> bool:
    if not box:
        return False
    viewport = page.viewport_size or {"width": VIEWPORT_WIDTH, "height": 900}
    middle_y = float(box["y"]) + float(box["height"]) / 2
    middle_x = float(box["x"]) + float(box["width"]) / 2
    return 0 < middle_y < viewport["height"] and 0 < middle_x < viewport["width"]


def _still_box(page, read_box, seconds: float = 5.0, scroll=None):
    """The box once it reads the same twice in a row (the page stopped moving). scroll(): asked once, only when
    the box is outside the page's view."""
    last = None
    scrolled = scroll is None
    deadline = time.monotonic() + seconds
    while True:
        box = read_box()
        if box and _same_box(box, last):
            if _in_view(page, box) or scrolled:
                return box
            try:
                scroll()
            except Exception:
                pass
            scrolled = True
            box = None
        if time.monotonic() >= deadline:
            return box
        last = box
        page.wait_for_timeout(150)


def _press_at(page, read_box, box: dict, local_x: float, local_y: float) -> None:
    """Move to the spot like a hand; if the button moved meanwhile, move again to where it is now; then press."""
    x, y = box["x"] + local_x, box["y"] + local_y
    _move_like_a_hand(page, x, y)
    for _ in range(4):
        try:
            now = read_box()
        except Exception:
            now = None
        if not now:
            break
        nx = now["x"] + min(local_x, max(1.0, now["width"] - 1))
        ny = now["y"] + min(local_y, max(1.0, now["height"] - 1))
        if abs(nx - x) < 1 and abs(ny - y) < 1:
            break
        page.mouse.move(nx, ny, steps=4)
        x, y = nx, ny
        _mouse_at[id(page)] = (x, y)
        page.wait_for_timeout(120)
    page.mouse.down()
    page.wait_for_timeout(100)
    page.mouse.up()


def _move_like_a_hand(page, x: float, y: float) -> None:
    viewport = page.viewport_size or {"width": VIEWPORT_WIDTH, "height": 900}
    start = _mouse_start(page, x, y)
    for px, py in _human_path(start, (x, y), viewport):
        page.mouse.move(px, py)
    _mouse_at[id(page)] = (x, y)


def real_click(locator) -> None:
    """Use the selector only to read the button box, then send a real mouse click."""
    locator.wait_for(state="visible", timeout=8000)
    if IN_APP:
        box = _still_box(locator.page, locator.bounding_box, scroll=lambda: locator.scroll_into_view_if_needed(timeout=4000))
    else:
        try:
            locator.scroll_into_view_if_needed(timeout=4000)
        except Exception:
            pass
        box = locator.bounding_box()
    if not box or box["width"] < 2 or box["height"] < 2:
        raise PlaywrightTimeoutError("button box missing")
    width = box["width"]
    height = box["height"]
    inset_x = min(2.0, width * 0.12)
    inset_y = min(2.0, height * 0.12)
    zone = random.choice(("center", "left", "right", "top", "bottom"))
    if zone == "center":
        local_x = width * random.uniform(0.42, 0.58)
        local_y = height * random.uniform(0.42, 0.58)
    elif zone == "left":
        local_x = random.uniform(inset_x, max(inset_x + 0.5, width * 0.22))
        local_y = height * random.uniform(0.28, 0.72)
    elif zone == "right":
        local_x = random.uniform(min(width * 0.78, width - inset_x), width - inset_x)
        local_y = height * random.uniform(0.28, 0.72)
    elif zone == "top":
        local_x = width * random.uniform(0.28, 0.72)
        local_y = random.uniform(inset_y, max(inset_y + 0.5, height * 0.22))
    else:
        local_x = width * random.uniform(0.28, 0.72)
        local_y = random.uniform(min(height * 0.78, height - inset_y), height - inset_y)
    local_x = min(max(local_x, inset_x), width - inset_x)
    local_y = min(max(local_y, inset_y), height - inset_y)
    page = locator.page
    if IN_APP:
        _press_at(page, locator.bounding_box, box, local_x, local_y)
        return
    x = box["x"] + local_x
    y = box["y"] + local_y
    _move_like_a_hand(page, x, y)
    page.mouse.down()
    page.wait_for_timeout(100)
    page.mouse.up()


def article_locator(page, path: str):
    status_id = ""
    match = re.search(r"status/(\d{6,25})", path or "")
    if match:
        status_id = match.group(1)
    articles = page.locator('article[data-testid="tweet"]')
    if not status_id:
        return articles
    return articles.filter(has=page.locator(f'a[href*="/status/{status_id}"]'))


def click_box(page, box: dict) -> None:
    width = float(box.get("width") or 0)
    height = float(box.get("height") or 0)
    if width < 2 or height < 2:
        raise PlaywrightTimeoutError("button box missing")
    x = float(box["x"]) + width * random.uniform(0.4, 0.6)
    y = float(box["y"]) + height * random.uniform(0.4, 0.6)
    box_text = {key: round(float(box[key]), 1) for key in ("x", "y", "width", "height")}
    trace_click(f"ضغط على ({x:.0f},{y:.0f}) صندوق {box_text}")
    _move_like_a_hand(page, x, y)
    page.mouse.down()
    page.wait_for_timeout(100)
    page.mouse.up()


def read_action_state(page, status_id: str, actions: list[str]) -> dict | None:
    payload = page.evaluate(
        """({statusId, names, scroll}) => {
          const articles = [...document.querySelectorAll('article[data-testid="tweet"]')];
          const boxOf = (el) => {
            if (!el) return null;
            const rect = el.getBoundingClientRect();
            if (rect.width < 2 || rect.height < 2) return null;
            return {x: rect.x, y: rect.y, width: rect.width, height: rect.height};
          };
          let card = null;
          if (statusId) {
            card = articles.find((article) => [...article.querySelectorAll('a[href*="/status/"]')].some((node) => (node.getAttribute("href") || "").includes("/status/" + statusId)));
          }
          if (!card) card = articles[0] || null;
          if (!card) return null;
          if (scroll) { try { card.scrollIntoView({block: "center"}); } catch (error) {} }
          const map = {repost: ["unretweet", "retweet"], like: ["unlike", "like"], bookmark: ["removeBookmark", "bookmark"]};
          const labelOf = {
            reply: /reply|رد/i, retweet: /repost|retweet|إعادة النشر|اعادة النشر/i,
            unretweet: /undo repost|unretweet|تم إعادة|إلغاء إعادة/i,
            like: /like|إعجاب|اعجاب/i, unlike: /unlike|liked|أعجبني|معجب/i,
            bookmark: /bookmark|إشارة مرجعية/i, removeBookmark: /remove bookmark|إزالة الإشارة/i
          };
          const scopeOf = (article) => (article && article.closest("[data-testid='cellInnerDiv']")) || article;
          const findBtn = (root, testid) => {
            if (!root) return null;
            const re = labelOf[testid];
            const nodes = [];
            const tagged = root.querySelector('[data-testid="' + testid + '"]');
            if (tagged) nodes.push(tagged);
            if (re) {
              for (const node of root.querySelectorAll("button, [role='button']")) {
                const label = node.getAttribute("aria-label") || "";
                if (!re.test(label)) continue;
                if (testid === "like" && /unlike|liked|أعجبني|معجب/i.test(label)) continue;
                nodes.push(node);
              }
            }
            for (const node of nodes) {
              const btn = node.closest("button, [role='button']") || node;
              if (btn.closest("[data-testid='tweetTextarea_0'], [data-testid='toolBar']")) continue;
              const rect = btn.getBoundingClientRect();
              if (rect.width >= 2 && rect.height >= 2) return btn;
            }
            return null;
          };
          const out = {};
          const root = scopeOf(card);
          for (const name of names) {
            const pair = map[name];
            if (!pair) continue;
            const on = findBtn(root, pair[0]);
            const off = findBtn(root, pair[1]);
            out[name] = {on: !!on, box: on ? null : boxOf(off)};
          }
          return out;
        }""",
        {"statusId": status_id, "names": actions, "scroll": not IN_APP},
    )
    return payload if isinstance(payload, dict) else None


ACTION_BUTTON_PROBE_JS = r"""
({statusId, testid, scroll}) => {
  const labelOf = {
    reply: /reply|رد/i, retweet: /repost|retweet|إعادة النشر|اعادة النشر/i,
    unretweet: /undo repost|unretweet|تم إعادة|إلغاء إعادة/i,
    like: /like|إعجاب|اعجاب/i, unlike: /unlike|liked|أعجبني|معجب/i,
    bookmark: /bookmark|إشارة مرجعية/i, removeBookmark: /remove bookmark|إزالة الإشارة/i
  };
  const articles = [...document.querySelectorAll('article[data-testid="tweet"], [data-testid="tweet"]')];
  let card = null;
  if (statusId) {
    card = articles.find((article) => [...article.querySelectorAll('a[href*="/status/"]')]
      .some((node) => (node.getAttribute("href") || "").includes("/status/" + statusId)));
  }
  if (!card) card = articles[0] || null;
  if (!card) return null;
  const root = card.closest('[data-testid="cellInnerDiv"]') || card;
  const re = labelOf[testid];
  const nodes = [];
  const tagged = root.querySelector('[data-testid="' + testid + '"]');
  if (tagged) nodes.push(tagged);
  if (re) {
    for (const node of root.querySelectorAll("button, [role='button']")) {
      const label = node.getAttribute("aria-label") || "";
      if (!re.test(label)) continue;
      if (testid === "like" && /unlike|liked|أعجبني|معجب/i.test(label)) continue;
      nodes.push(node);
    }
  }
  let button = null;
  for (const node of nodes) {
    const btn = node.closest("button, [role='button']") || node;
    if (btn.closest("[data-testid='tweetTextarea_0'], [data-testid='toolBar']")) continue;
    const rect = btn.getBoundingClientRect();
    if (rect.width >= 2 && rect.height >= 2) { button = btn; break; }
  }
  if (!button) return {box: null};
  const aboveBar = () => {
    const bar = document.querySelector('[data-testid="BottomBar"]');
    const top = bar ? bar.getBoundingClientRect().top : window.innerHeight;
    return top > 80 ? top - 12 : window.innerHeight - 12;
  };
  const bringIntoView = () => {
    const placed = () => {
      const r = button.getBoundingClientRect();
      return r.width >= 2 && r.top > 24 && r.bottom < aboveBar();
    };
    if (placed()) return true;
    let node = button.parentElement;
    while (node) {
      const style = getComputedStyle(node);
      if (/(auto|scroll|overlay)/.test(style.overflowY) && node.scrollHeight > node.clientHeight + 8) {
        const r = button.getBoundingClientRect();
        const host = node.getBoundingClientRect();
        node.scrollTop += (r.top + r.height / 2) - Math.min(host.top + host.height / 2, aboveBar() * 0.55);
      }
      node = node.parentElement;
    }
    const r = button.getBoundingClientRect();
    const delta = (r.top + r.height / 2) - (aboveBar() * 0.55);
    try { window.scrollBy(0, delta); } catch (error) {}
    if (document.scrollingElement) document.scrollingElement.scrollTop += delta;
    try { button.scrollIntoView({block: "center", inline: "nearest"}); } catch (error) {}
    return placed();
  };
  if (scroll) {
    const seen = bringIntoView();
    return {scrolled: true, inView: seen};
  }
  const rect = button.getBoundingClientRect();
  if (rect.width < 2 || rect.height < 2) return {box: null};
  const x = rect.x + rect.width / 2;
  const y = rect.y + rect.height / 2;
  const hit = document.elementFromPoint(x, y);
  const ok = !!hit && (button === hit || button.contains(hit) || hit.closest("button, [role='button']") === button);
  let blocker = "";
  if (!ok && hit) {
    const tag = hit.closest("[data-testid]");
    blocker = (tag && tag.getAttribute("data-testid")) || hit.tagName.toLowerCase();
  }
  const limit = aboveBar();
  return {box: {x: rect.x, y: rect.y, width: rect.width, height: rect.height}, ok, blocker,
          inView: rect.top > 8 && rect.bottom < limit};
}
"""

TAP_ACTION_JS = r"""
({statusId, testid}) => {
  const labelOf = {
    reply: /reply|رد/i, retweet: /repost|retweet|إعادة النشر|اعادة النشر/i,
    unretweet: /undo repost|unretweet|تم إعادة|إلغاء إعادة/i,
    like: /like|إعجاب|اعجاب/i, unlike: /unlike|liked|أعجبني|معجب/i,
    bookmark: /bookmark|إشارة مرجعية/i, removeBookmark: /remove bookmark|إزالة الإشارة/i
  };
  const articles = [...document.querySelectorAll('article[data-testid="tweet"], [data-testid="tweet"]')];
  let card = null;
  if (statusId) {
    card = articles.find((article) => [...article.querySelectorAll('a[href*="/status/"]')]
      .some((node) => (node.getAttribute("href") || "").includes("/status/" + statusId)));
  }
  if (!card) card = articles[0] || null;
  if (!card) return "missing";
  const root = card.closest('[data-testid="cellInnerDiv"]') || card;
  const re = labelOf[testid];
  const nodes = [];
  const tagged = root.querySelector('[data-testid="' + testid + '"]');
  if (tagged) nodes.push(tagged);
  if (re) {
    for (const node of root.querySelectorAll("button, [role='button']")) {
      const label = node.getAttribute("aria-label") || "";
      if (!re.test(label)) continue;
      if (testid === "like" && /unlike|liked|أعجبني|معجب/i.test(label)) continue;
      nodes.push(node);
    }
  }
  let button = null;
  for (const node of nodes) {
    const btn = node.closest("button, [role='button']") || node;
    if (btn.closest("[data-testid='tweetTextarea_0'], [data-testid='toolBar']")) continue;
    if (btn.tagName === "A" && /\/status\//.test(btn.getAttribute("href") || "")) continue;
    const rect = btn.getBoundingClientRect();
    if (rect.width >= 2 && rect.height >= 2) { button = btn; break; }
  }
  if (!button) return "missing";
  const rect = button.getBoundingClientRect();
  if (rect.bottom < 0 || rect.top > window.innerHeight) {
    try { button.scrollIntoView({block: "center", inline: "nearest", behavior: "instant"}); } catch (error) {}
  }
  button.addEventListener("click", (event) => event.stopPropagation(), {capture: true, once: true});
  button.click();
  return "clicked";
}
"""


CLOSE_POPUPS_JS = r"""
() => {
  const words = /^(close|dismiss|not now|maybe later|got it|skip|no thanks|cancel|إغلاق|اغلاق|ليس الآن|لاحقًا|لاحقا|فهمت|تخطي|تخطّي|لا شكرًا|لا شكرا|إلغاء)$/i;
  const chat = '[data-testid="dm-message-list"], [data-testid="dm-message-scroller"], [data-testid="dm-conversation-content"], [data-testid="dm-inbox-panel"]';
  const layers = [...document.querySelectorAll('[role="dialog"], [role="alertdialog"], [aria-modal="true"], [data-testid="sheetDialog"], [data-testid="confirmationSheetDialog"]')]
    .filter((el) => el.getClientRects().length && !el.closest(chat) && !el.querySelector(chat));
  const closed = [];
  for (const layer of layers) {
    const buttons = [...layer.querySelectorAll('button, [role="button"]')].filter((node) => node.getClientRects().length);
    const hit = buttons.find((node) => {
      const label = (node.getAttribute("aria-label") || "").trim();
      const text = (node.innerText || "").replace(/\s+/g, " ").trim();
      const testid = node.getAttribute("data-testid") || "";
      return words.test(label) || words.test(text) || testid === "app-bar-close" || testid === "confirmationSheetCancel";
    });
    if (hit) {
      hit.click();
      closed.push(layer.getAttribute("data-testid") || layer.getAttribute("aria-label") || "dialog");
    }
  }
  return closed;
}
"""


ACCEPT_COOKIES_JS = r"""
() => {
  const accept = /^(accept all cookies|قبول جميع ملفات الكوكيز)$/i;
  for (const node of document.querySelectorAll('button, [role="button"]')) {
    if (accept.test((node.textContent || "").replace(/\s+/g, " ").trim()) && node.getClientRects().length) {
      node.click();
      return true;
    }
  }
  return false;
}
"""


def accept_cookies(page) -> bool:
    """Press "قبول جميع ملفات الكوكيز" on X's cookie notice when it shows: it covers the bottom of the page."""
    try:
        clicked = bool(page.evaluate(ACCEPT_COOKIES_JS))
    except Exception:
        return False
    if clicked:
        page.wait_for_timeout(400)
    return clicked


def close_popups(page) -> int:
    """Close pop-up dialogs that cover the page, and accept the cookie notice. The chat itself is never touched."""
    cookies = accept_cookies(page)
    try:
        closed = page.evaluate(CLOSE_POPUPS_JS) or []
    except Exception:
        return int(cookies)
    if closed:
        if os.environ.get("COLLECT_DEBUG"):
            print(f"closed popups: {closed}", flush=True)
        page.wait_for_timeout(400)
    return len(closed) + int(cookies)


# Official mobile actions from X's docs (docs.x.com Web Intents). On a phone the timeline
# button is not the desktop control: a tap opens the post and its reply box. Like, repost and
# reply are documented as these pages, which work in a mobile WebView.
OFFICIAL_INTENTS = {
    "like": "https://x.com/intent/like?tweet_id={id}",
    "repost": "https://x.com/intent/retweet?tweet_id={id}",
}

CONFIRM_INTENT_JS = r"""
() => {
  const body = ((document.body && document.body.innerText) || "").replace(/\s+/g, " ").slice(0, 2500);
  if (/you liked|liked this tweet|تم الإعجاب|أعجبك هذا/i.test(body)) return "done";
  if (/reposted|you reposted|تم إعادة النشر|أعدت نشر/i.test(body)) return "done";
  const words = /^(like|إعجاب|اعجاب|repost|retweet|إعادة النشر|اعادة النشر)$/i;
  const nodes = [...document.querySelectorAll('button, [role="button"], input[type="submit"], [data-testid="confirmationSheetConfirm"]')];
  const hit = nodes.find((node) => {
    if (node.closest("[data-testid='tweetTextarea_0']")) return false;
    const test = node.getAttribute("data-testid") || "";
    const text = (node.innerText || node.value || node.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
    return test === "confirmationSheetConfirm" || words.test(text);
  });
  if (!hit) return "";
  hit.click();
  return "clicked";
}
"""


def _tweet_back_url(path: str, status_id: str) -> str:
    raw = (path or "").strip()
    if raw.startswith("http"):
        return raw
    if raw.startswith("/"):
        return "https://x.com" + raw
    if status_id:
        return f"https://x.com/i/web/status/{status_id}"
    return "https://x.com" + ("/" + raw if raw else "")


def press_official_intent(page, path: str, status_id: str, action: str) -> str:
    """Like or repost through the official mobile intent page, then return to the post."""
    if not status_id or action not in OFFICIAL_INTENTS:
        return "missing"
    back = _tweet_back_url(path, status_id)
    goto_x(page, OFFICIAL_INTENTS[action].format(id=status_id))
    outcome = ""
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        try:
            outcome = str(page.evaluate(CONFIRM_INTENT_JS) or "")
        except Exception:
            outcome = ""
        if outcome:
            break
        page.wait_for_timeout(400)
    page.wait_for_timeout(900)
    try:
        goto_x(page, back)
        page.wait_for_timeout(800)
    except Exception:
        pass
    return "" if outcome else "missing"


# The phone page does not use the desktop buttons. A click on the card opens the tweet and
# stops there. These are the calls that page itself makes when a button works (the same web
# session, read from the open page). Query ids are the ones documented from X's own client
# and are replaced by whatever that page already loaded when it differs.
WEB_MUTATION_JS = r"""
async ({action, tweetId, text}) => {
  const bearer = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
  const fallback = {
    FavoriteTweet: "lI07N6Otwv1PhnEgXILM7A",
    UnfavoriteTweet: "ZYKSe-w7KEslx3JhSIk5LA",
    CreateRetweet: "mbRO74GrOvSfRcJnlMapnQ",
    DeleteRetweet: "ZyZigVsNiFO6v1dEks1eWg",
    CreateBookmark: "aoDbu3RHznuiSkQ9aNM67Q",
    DeleteBookmark: "Wlmlj2-xzyS1GN3a6cj-mQ",
    CreateTweet: "l4hk8uVGvR-a8kzQ4nOhPA"
  };
  const tweetFeatures = {
    premium_content_api_read_enabled: false,
    communities_web_enable_tweet_community_results_fetch: true,
    c9s_tweet_anatomy_moderator_badge_enabled: true,
    responsive_web_grok_analyze_button_fetch_trends_enabled: false,
    responsive_web_grok_analyze_post_followups_enabled: true,
    rweb_cashtags_composer_attachment_enabled: true,
    responsive_web_jetfuel_frame: true,
    rweb_sports_post_context_enabled: true,
    x_elections_post_context_enabled: true,
    responsive_web_grok_share_attachment_enabled: true,
    responsive_web_grok_annotations_enabled: true,
    responsive_web_edit_tweet_api_enabled: true,
    graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
    view_counts_everywhere_api_enabled: true,
    longform_notetweets_consumption_enabled: true,
    responsive_web_twitter_article_tweet_consumption_enabled: true,
    content_disclosure_indicator_enabled: true,
    content_disclosure_ai_generated_indicator_enabled: true,
    responsive_web_grok_show_grok_translated_post: true,
    responsive_web_grok_analysis_button_from_backend: true,
    post_ctas_fetch_enabled: true,
    longform_notetweets_rich_text_read_enabled: true,
    longform_notetweets_inline_media_enabled: false,
    profile_label_improvements_pcf_label_in_post_enabled: true,
    responsive_web_profile_redirect_enabled: true,
    rweb_tipjar_consumption_enabled: false,
    verified_phone_label_enabled: false,
    responsive_web_nested_quote_preview_enabled: true,
    articles_preview_enabled: true,
    rweb_cashtags_enabled: true,
    responsive_web_grok_community_note_auto_translation_is_enabled: true,
    freedom_of_speech_not_reach_fetch_enabled: true,
    standardized_nudges_misinfo: true,
    tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
    responsive_web_grok_image_annotation_enabled: true,
    responsive_web_grok_imagine_annotation_enabled: true,
    responsive_web_graphql_timeline_navigation_enabled: true
  };
  const ct0 = decodeURIComponent((document.cookie.match(/(?:^|; )ct0=([^;]+)/) || [])[1] || "");
  if (!ct0) return {ok: false, error: "لا توجد جلسة دخول في الصفحة"};
  const learn = () => {
    if (window.__ggQLearned) return;
    window.__ggQLearned = true;
    window.__ggQ = Object.assign({}, fallback, window.__ggQ || {});
    const grab = (source) => {
      if (!source) return;
      const first = /queryId:"([A-Za-z0-9_-]{8,80})",operationName:"([A-Za-z0-9_]+)"/g;
      const second = /operationName:"([A-Za-z0-9_]+)",queryId:"([A-Za-z0-9_-]{8,80})"/g;
      let match;
      while ((match = first.exec(source))) window.__ggQ[match[2]] = match[1];
      while ((match = second.exec(source))) window.__ggQ[match[1]] = match[2];
    };
    try {
      const chunks = self.webpackChunk_twitter_responsive_web || [];
      let budget = 0;
      for (const chunk of chunks) {
        const mods = chunk && chunk[1];
        if (!mods) continue;
        for (const fn of Object.values(mods)) {
          let source = "";
          try { source = Function.prototype.toString.call(fn); } catch (error) { continue; }
          if (source.indexOf("queryId") < 0 && source.indexOf("FavoriteTweet") < 0 && source.indexOf("CreateTweet") < 0) continue;
          grab(source);
          budget += source.length;
          if (budget > 2500000) return;
        }
      }
    } catch (error) {}
  };
  const send = async (name, variables, features) => {
    const queryId = (window.__ggQ && window.__ggQ[name]) || fallback[name];
    const response = await fetch("https://x.com/i/api/graphql/" + queryId + "/" + name, {
      method: "POST",
      credentials: "include",
      headers: {
        authorization: "Bearer " + bearer,
        "x-csrf-token": ct0,
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-active-user": "yes",
        "content-type": "application/json"
      },
      body: JSON.stringify({variables, features: features || {}, queryId})
    });
    const raw = await response.text();
    let data = {};
    try { data = JSON.parse(raw); } catch (error) {}
    const errors = data.errors || [];
    const message = (errors[0] && (errors[0].message || "")) || "";
    const already = /already|duplicate|has already|been already|327|139/i.test(message + " " + raw.slice(0, 300));
    return {status: response.status, ok: (response.status === 200 && errors.length === 0) || already, error: message || ("HTTP " + response.status), raw: raw.slice(0, 180)};
  };
  learn();
  const ops = {like: "FavoriteTweet", repost: "CreateRetweet", bookmark: "CreateBookmark", comment: "CreateTweet"};
  const name = ops[action];
  if (!name) return {ok: false, error: "إجراء غير معروف"};
  let variables = {tweet_id: String(tweetId)};
  let features = {};
  if (action === "repost") variables = {tweet_id: String(tweetId), dark_request: false};
  if (action === "comment") {
    variables = {
      tweet_text: text || "",
      dark_request: false,
      media: {media_entities: [], possibly_sensitive: false},
      semantic_annotation_ids: [],
      reply: {in_reply_to_tweet_id: String(tweetId), exclude_reply_user_ids: []}
    };
    features = tweetFeatures;
  }
  let result = await send(name, variables, features);
  if (!result.ok && result.status === 404) {
    window.__ggQLearned = false;
    learn();
    result = await send(name, variables, features);
  }
  if (!result.ok && action === "like") {
    const response = await fetch("https://x.com/i/api/1.1/favorites/create.json", {
      method: "POST",
      credentials: "include",
      headers: {
        authorization: "Bearer " + bearer,
        "x-csrf-token": ct0,
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-active-user": "yes",
        "content-type": "application/json"
      },
      body: JSON.stringify({id: String(tweetId)})
    });
    const raw = await response.text();
    if (response.status === 200 || /already|139/i.test(raw)) return {ok: true, via: "rest"};
    result = {ok: false, error: result.error || ("HTTP " + response.status)};
  }
  if (!result.ok && action === "repost") {
    const response = await fetch("https://x.com/i/api/1.1/statuses/retweet/" + encodeURIComponent(tweetId) + ".json", {
      method: "POST",
      credentials: "include",
      headers: {
        authorization: "Bearer " + bearer,
        "x-csrf-token": ct0,
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-active-user": "yes",
        "content-type": "application/x-www-form-urlencoded"
      },
      body: "id=" + encodeURIComponent(tweetId)
    });
    const raw = await response.text();
    if (response.status === 200 || /already|327/i.test(raw)) return {ok: true, via: "rest"};
  }
  return result.ok ? {ok: true} : {ok: false, error: (result.error || "فشل الطلب").slice(0, 140)};
}
"""


def web_mutate(page, status_id: str, action: str, text: str = "") -> dict:
    """Like, repost, bookmark, or reply through the call the logged-in page already uses."""
    try:
        result = page.evaluate(WEB_MUTATION_JS, {"action": action, "tweetId": status_id, "text": text or ""})
    except Exception as exc:
        return {"ok": False, "error": str(exc).splitlines()[0][:140]}
    return result if isinstance(result, dict) else {"ok": False, "error": "رد غير مفهوم من الصفحة"}


PRESS_PAGE_JS = r"""
async ({statusId, testid}) => {
  const labelOf = {
    reply: /reply|رد/i, retweet: /repost|retweet|إعادة النشر|اعادة النشر/i,
    unretweet: /undo repost|unretweet|تم إعادة|إلغاء إعادة/i,
    like: /like|إعجاب|اعجاب/i, unlike: /unlike|liked|أعجبني|معجب/i,
    bookmark: /bookmark|إشارة مرجعية/i, removeBookmark: /remove bookmark|إزالة الإشارة/i
  };
  const articles = [...document.querySelectorAll('article[data-testid="tweet"], [data-testid="tweet"]')];
  let card = articles.find((article) => statusId && [...article.querySelectorAll('a[href*="/status/"]')]
    .some((node) => (node.getAttribute("href") || "").includes("/status/" + statusId))) || articles[0] || null;
  if (!card) return {how: "missing"};
  const root = card.closest('[data-testid="cellInnerDiv"]') || card;
  const re = labelOf[testid];
  const nodes = [];
  const tagged = root.querySelector('[data-testid="' + testid + '"]');
  if (tagged) nodes.push(tagged);
  if (re) {
    for (const node of root.querySelectorAll("button, [role='button']")) {
      const label = node.getAttribute("aria-label") || "";
      if (!re.test(label)) continue;
      if (testid === "like" && /unlike|liked|أعجبني|معجب/i.test(label)) continue;
      nodes.push(node);
    }
  }
  let button = null;
  for (const node of nodes) {
    const btn = node.closest("button, [role='button']") || node;
    if (btn.closest("[data-testid='tweetTextarea_0'], [data-testid='toolBar']")) continue;
    const rect = btn.getBoundingClientRect();
    if (rect.width >= 2 && rect.height >= 2) { button = btn; break; }
  }
  if (!button) return {how: "missing"};
  const aboveBar = () => {
    const bar = document.querySelector('[data-testid="BottomBar"]');
    const top = bar ? bar.getBoundingClientRect().top : window.innerHeight;
    return top > 80 ? top - 12 : window.innerHeight - 12;
  };
  const placed = () => {
    const r = button.getBoundingClientRect();
    return r.width >= 2 && r.top > 24 && r.bottom < aboveBar();
  };
  if (!placed()) {
    let node = button.parentElement;
    while (node) {
      const style = getComputedStyle(node);
      if (/(auto|scroll|overlay)/.test(style.overflowY) && node.scrollHeight > node.clientHeight + 8) {
        const r = button.getBoundingClientRect();
        const host = node.getBoundingClientRect();
        node.scrollTop += (r.top + r.height / 2) - Math.min(host.top + host.height / 2, aboveBar() * 0.55);
      }
      node = node.parentElement;
    }
    const r = button.getBoundingClientRect();
    const delta = (r.top + r.height / 2) - (aboveBar() * 0.55);
    try { window.scrollBy(0, delta); } catch (error) {}
    if (document.scrollingElement) document.scrollingElement.scrollTop += delta;
    try { button.scrollIntoView({block: "center", inline: "nearest"}); } catch (error) {}
  }
  if (!placed()) return {how: "offscreen"};
  const before = button.getAttribute("aria-label") || "";
  const event = (node) => ({
    preventDefault() {}, stopPropagation() {}, persist() {},
    nativeEvent: {isTrusted: true, button: 0},
    isTrusted: true, button: 0, type: "click",
    target: node, currentTarget: node
  });
  const fire = (node) => {
    if (!node) return "";
    const keys = Object.keys(node);
    for (const key of keys) {
      if (!key.startsWith("__reactProps$")) continue;
      const props = node[key];
      if (props && typeof props.onClick === "function") {
        props.onClick(event(node));
        return "react";
      }
    }
    return "";
  };
  let how = fire(button);
  if (!how) {
    for (const child of button.querySelectorAll("*")) {
      how = fire(child);
      if (how) break;
    }
  }
  await new Promise((done) => setTimeout(done, 400));
  const sheet = document.querySelector('[data-testid="confirmationSheetConfirm"], [data-testid="retweetConfirm"]');
  if (sheet) {
    fire(sheet) || sheet.click();
    how = (how || "sheet") + "+تأكيد";
  }
  return {how: how || "no-handler", before, after: button.isConnected ? (button.getAttribute("aria-label") || "") : "gone"};
}
"""


def press_action_button(page, path: str, status_id: str, action: str) -> str:
    """Scroll the button into view, make sure nothing covers it, then click it.

    Returns "" after a click reached the button, "missing" when the button is
    not on the page, or the name of whatever was covering the button.
    """
    testid = ACTION_CONTROLS[action][1]
    blocker = ""

    def probe(scroll: bool = False):
        try:
            return page.evaluate(ACTION_BUTTON_PROBE_JS, {"statusId": status_id, "testid": testid, "scroll": scroll})
        except Exception:
            return None

    for _ in range(3):
        close_popups(page)
        info = probe(False)
        trace_click(f"{action} {status_id} فحص {info}")
        if not info or not info.get("box"):
            trace_page(page, f"{action} الزر غير موجود")
            return "missing"
        if not info.get("inView") or str((info or {}).get("blocker") or "") == "BottomBar":
            probe(True)
            page.wait_for_timeout(450)
            info = probe(False)
        if info and info.get("ok") and info.get("inView") and info.get("box"):
            if IN_APP:
                try:
                    pressed = page.evaluate(PRESS_PAGE_JS, {"statusId": status_id, "testid": testid})
                except Exception as exc:
                    pressed = {"how": "error", "error": str(exc)[:160]}
                trace_click(f"{action} معالج الصفحة {pressed}")
                how = str((pressed or {}).get("how") or "")
                if how == "offscreen" or how == "missing" or how == "no-handler":
                    blocker = "خارج الشاشة" if how == "offscreen" else (blocker or "لم يُقبل النقر")
                    page.wait_for_timeout(400)
                    continue
                return ""
            click_box(page, info["box"])
            trace_click(f"{action} أُرسلت النقرة")
            return ""
        blocker = str((info or {}).get("blocker") or "خارج الشاشة")
        trace_click(f"{action} لم تُصب النقرة: {blocker}")
        try:
            page.keyboard.press("Escape")
        except Exception:
            pass
        page.wait_for_timeout(600)
    return blocker or "خارج الشاشة"


def apply_actions_on_path(page, path: str, actions: list[str]) -> dict[str, str]:
    """Click only inactive controls. Already-on actions are left untouched."""
    status_id = ""
    match = re.search(r"status/(\d{6,25})", path or "")
    if match:
        status_id = match.group(1)
    try:
        state = read_action_state(page, status_id, actions)
    except Exception as exc:
        if browser_closed_error(exc):
            raise BrowserClosed() from exc
        state = None
    if not state:
        return {key: "تعذر العثور على المنشور" for key in actions}
    outcome: dict[str, str] = {}
    pressed = 0
    for action in actions:
        row = state.get(action) if isinstance(state.get(action), dict) else {}
        if row.get("on"):
            outcome[action] = "مفعّل مسبقًا — تم التجاوز"
            continue
        if pressed:
            page.wait_for_timeout(random.randint(80, 200))
        pressed += 1
        try:
            blocker = press_action_button(page, path, status_id, action)
            if blocker == "missing":
                outcome[action] = "زر الإجراء غير متاح — تم التجاوز"
                continue
            if blocker:
                outcome[action] = f"تعذر النقر: الزر مغطى بـ {blocker}"
                continue
            if action == "repost":
                confirm = page.locator('[data-testid="retweetConfirm"]')
                try:
                    confirm.wait_for(state="visible", timeout=1200)
                    real_click(confirm.first)
                except PlaywrightTimeoutError:
                    pass
            confirmed = False
            deadline = time.monotonic() + 2.5
            while time.monotonic() < deadline:
                again = read_action_state(page, status_id, [action]) or {}
                if (again.get(action) or {}).get("on"):
                    confirmed = True
                    break
                page.wait_for_timeout(60)
            outcome[action] = "تم التنفيذ" if confirmed else "أُرسل الطلب لكن تعذر تأكيد الحالة"
            trace_click(f"{action} النتيجة: {outcome[action]}")
        except Exception as exc:
            if browser_closed_error(exc):
                raise BrowserClosed() from exc
            outcome[action] = "تعذر التنفيذ"
            trace_click(action + " استثناء " + traceback.format_exc().replace("\n", " | ")[-400:])
    return outcome


def normalize_gemini_model(value: str) -> str | None:
    model = (value or "").strip()
    if model.lower().startswith("models/"):
        model = model.split("/", 1)[1].strip()
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,80}", model):
        return model
    return None


def valid_gemini_key(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_\-]{20,256}", value or ""))


def clean_comment(raw: str) -> str:
    text = re.sub(r"\s+", " ", raw or "").strip()
    text = text.replace("**", "")
    text = re.sub(r"^(?:reply|comment|التعليق|الرد|الدعاء)\s*[:：\-]\s*", "", text, flags=re.I)
    text = re.sub(r"^[\w؀-ۿ]{2,24}\s*[:：]\s*", "", text)
    text = text.strip("\"'«»“” ")
    if len(text) > 280:
        cut = text[:280]
        end = max(cut.rfind("؟"), cut.rfind("?"), cut.rfind("!"), cut.rfind("."), cut.rfind("…"))
        text = cut[: end + 1] if end >= 40 else cut.rsplit(" ", 1)[0]
    return text.strip()


def comment_is_complete(text: str) -> bool:
    # An emoji or two at the end are fine: the words before them are what is checked.
    text = re.sub(r"[\s\u200d\ufe0f\u2600-\u27bf\U0001f000-\U0001faff]+$", "", text or "")
    words = [word for word in text.split() if word]
    if len(words) < 6:
        return False
    if re.search(r"[،,؛;:：\-–—/\\*]$", text.strip()):
        return False
    last = re.sub(r"[.!?؟…\"'«»“”]+$", "", words[-1])
    return len(last) > 2


def gemini_thinking_config(model: str) -> dict | None:
    if re.search(r"2\.5", model):
        return {"thinkingBudget": 0}
    if re.search(r"gemini-3|3\.\d", model):
        return {"thinkingLevel": "low"}
    return None


def gemini_is_busy(status: int, detail: str) -> bool:
    if status in (429, 500, 502, 503, 504):
        return True
    return bool(re.search(
        r"high demand|try again later|unavailable|overloaded|resource exhausted|rate limit|quota",
        detail or "",
        re.I,
    ))


GEMINI_USAGE_PATH = DATA_DIR / "gemini_usage.json"
# Price counted for each comment the model writes (shown on the page as the running total).
GEMINI_PRICE_PER_COMMENT = 0.01
# Password asked by the page's hidden button that resets the cost (the comment count is kept). Only in
# the owner's copy: users' costs are reset from «توزيع البرنامج».
COST_RESET_PASSWORD = "a1@"
gemini_usage_lock = threading.Lock()
gemini_usage: dict = {}


def load_gemini_usage() -> None:
    loaded = read_private_json(GEMINI_USAGE_PATH) or {}
    try:
        comments = max(0, int(loaded.get("comments") or 0))
        since = float(loaded.get("since") or 0)
        # Comments counted in the cost since it was last reset (all of them if it never was).
        cost_comments = max(0, int(loaded.get("cost_comments", comments) or 0))
    except (TypeError, ValueError):
        comments, since, cost_comments = 0, 0.0, 0
    with gemini_usage_lock:
        gemini_usage.clear()
        # reset_id: the owner's last cost reset this copy made («توزيع البرنامج»).
        gemini_usage.update({"comments": comments, "since": since, "cost_comments": cost_comments, "reset_id": str(loaded.get("reset_id") or "")})


def record_comment_generated() -> None:
    """Count one comment written by the model."""
    try:
        with gemini_usage_lock:
            if not gemini_usage.get("since"):
                gemini_usage["since"] = time.time()
            gemini_usage["comments"] = int(gemini_usage.get("comments") or 0) + 1
            gemini_usage["cost_comments"] = int(gemini_usage.get("cost_comments") or 0) + 1
            write_private_json(GEMINI_USAGE_PATH, dict(gemini_usage))
    except Exception:
        pass


def reset_gemini_cost(reset_id: str = "") -> None:
    """Start the cost again from 0; the comment count is kept. reset_id: the owner's reset it answers."""
    with gemini_usage_lock:
        gemini_usage["cost_comments"] = 0
        if reset_id:
            gemini_usage["reset_id"] = reset_id
        write_private_json(GEMINI_USAGE_PATH, dict(gemini_usage))


# «صيغة الرد» on the page: how the comment speaks of the one writing it (the account's owner).
REPLY_VOICES = {
    "male": "You write as a man: when you speak of yourself, use masculine forms (in Arabic: مبسوط، متأكد).",
    "female": "You write as a woman: when you speak of yourself, use feminine forms (in Arabic: مبسوطة، متأكدة).",
    "neutral": "The reply must suit a man or a woman: never use words that show the writer's gender "
               "(in Arabic, no forms like مبسوط or مبسوطة, متأكد or متأكدة).",
}
# The voice when none (or an unknown one) is given.
DEFAULT_REPLY_VOICE = "male"
# How a reply takes the tweet: one is drawn at random for each reply, so the group's accounts do not all answer
# one tweet the same way (and one account does not answer every tweet the same way).
REPLY_ANGLES = (
    "a frank remark on its point, the way people talk among friends",
    "you disagree with one point in it, and say why",
    "a detail in it that most people will miss",
    "a light, dry joke about the situation",
    "you doubt one part of it, and say what does not add up",
    "a comparison with something from everyday life",
    "what it will lead to, or what comes next",
    "a short question about one point in it",
)
# How long, in words: drawn at random too, all within REPLY_MAX_CHARS.
REPLY_LENGTHS = ((6, 10), (8, 13), (10, 16))
# The most a posted reply may be, in characters (spaces included).
REPLY_MAX_CHARS = 100
# How much of the tweet's text goes with the screenshot: enough for a long post to be read to its end (a story
# cut at its start was answered wrongly).
REPLY_TWEET_TEXT = 1200
# How an account writes: one manner for each account (drawn from it, so it stays the same), as a real person
# keeps their own.
REPLY_MANNERS = (
    "short and direct, no emojis",
    "calm and down-to-earth",
    "sarcastic and witty",
    "blunt and critical, but not rude",
    "easygoing; now and then one emoji at the end",
    "curious; sometimes ends with a short question",
    "matter-of-fact; sticks to what the tweet says",
    "playful, with everyday slang",
)
# The last replies written on this copy, by account and by tweet: the next reply is told not to look like them.
REPLIES_REMEMBERED = 8
replies_by_account: dict[str, list[str]] = {}
replies_by_tweet: dict[str, list[str]] = {}
account_names: dict[str, str] = {}   # معرّف الحساب (profile_key) -> اسم X المقروء، لعرض التكلفة لكل حساب
replies_memory_lock = threading.Lock()


def reply_manner(account: str) -> str:
    """The account's own manner of writing (always the same one for an account)."""
    if not account:
        return random.choice(REPLY_MANNERS)
    drawn = int(hashlib.sha256(("reply-manner:" + account).encode("utf-8")).hexdigest()[:8], 16)
    return REPLY_MANNERS[drawn % len(REPLY_MANNERS)]


def remember_reply(account: str, tweet_id: str, text: str) -> None:
    with replies_memory_lock:
        for book, key in ((replies_by_account, account), (replies_by_tweet, tweet_id)):
            if key:
                kept = book.setdefault(key, [])
                kept.append(text)
                del kept[:-REPLIES_REMEMBERED]
        while len(replies_by_tweet) > 500:
            replies_by_tweet.pop(next(iter(replies_by_tweet)))


def reply_prompt(voice: str, account: str = "", tweet_id: str = "") -> str:
    """What the model is asked for one reply: a remark on the tweet's topic, not about the writer (no stories or
    experiences of theirs) and not a compliment, in the account's manner, with an angle and a length drawn for
    this reply, and the replies it must not look like."""
    low, high = random.choice(REPLY_LENGTHS)
    prompt = (
        "Write one public reply to this tweet, as an ordinary person scrolling X who comments on what it says. "
        "Read the whole tweet first and answer what it really says (its point, and its ending when it tells a story); "
        "do not guess beyond it. "
        "Not personal: the reply is about the tweet's topic, not about you. No stories or experiences of yours, "
        "nothing that happened to you, your family or your friends, and nothing about your own life (nothing like: "
        "صار معي، جربت، شفت بنفسي، أخوي، عندنا في البيت، أتذكر لما، لو كنت مكانه). "
        "Speak about its topic, not to please its author: do not compliment, thank or flatter the author, do not "
        "praise the tweet (nothing like: well said, you're right, great post, صدقت، كفو، أبدعت، كلامك ذهب), and do "
        "not just agree. Honest, never rude: no insults, and do not mock the author. "
        f"This time: {random.choice(REPLY_ANGLES)}. Your manner (always the same): {reply_manner(account)}. "
        "If the tweet is a prayer (دعاء), about religion, a death, an illness or other sad news, leave the angle and "
        "the manner: reply sincerely and respectfully, with no joke and no disagreement. "
        f"At most {REPLY_MAX_CHARS} characters, spaces included (about {low} to {high} words). Finish the sentence. "
        "Never stop mid-word or mid-phrase. "
        "Write in the tweet's own language. An Arabic tweet gets everyday spoken Saudi Arabic (عامية سعودية بيضاء), "
        "the way people really type on X, never formal Arabic (فصحى): no words like الأولى، ينبغي، لا تثبت، ما زال، "
        "إذ، لذا، حيث، كما أن. A tweet in another language (English, Turkish…) gets its reply in that language. "
        "Plain letters only: no diacritics (no تشكيل: no fatha, damma, kasra, tanween, shadda or sukun), and no "
        "commas (، or ,). " + REPLY_VOICES.get(voice, REPLY_VOICES[DEFAULT_REPLY_VOICE]) + " "
        "Sound like a real person, specific and casual, not a teacher, a preacher, a brand or an assistant: no "
        "advice or lessons to the author or to people (nothing like: الأولى أن، يجب، الأفضل أن، تذكّر، نصيحتي), no "
        "general wisdom or sayings, no neat conclusion; just make your point about the topic itself. "
        "The image, when one comes, is only there to understand the tweet: never mention it, the picture, the post "
        "or the tweet (no الصورة، المنشور، التغريدة); react to what is in them. Lines in square brackets under the "
        "tweet's text (the post it quotes, its picture) say what the tweet shows; they are not its words. "
        "Do not open with filler (like صراحة، فعلاً، والله) or by repeating the tweet. "
        "No hashtags, no links, no quotes, no labels, no introduction. Return only the finished reply."
    )
    with replies_memory_lock:
        own = list(replies_by_account.get(account) or []) if account else []
        others = [text for text in (replies_by_tweet.get(tweet_id) or []) if text not in own] if tweet_id else []
    if others:
        prompt += ("\n\nReplies other people already wrote to this same tweet. Yours must say something else, "
                   "in another way:\n" + "\n".join("- " + text for text in others))
    if own:
        prompt += ("\n\nYour own last replies to other tweets. This one must not look like them (another opening, "
                   "another shape, other words):\n" + "\n".join("- " + text for text in own))
    return prompt


def gemini_comment(api_key: str, model: str, image: bytes | None, tweet_text: str, voice: str = DEFAULT_REPLY_VOICE,
                   account: str = "", tweet_id: str = "") -> str:
    """One reply to a tweet, from the account (its profile key) to the tweet (its id)."""
    prompt = reply_prompt(voice, account, tweet_id)
    if image:
        prompt = "Look at the image sent with the tweet. " + prompt
    if tweet_text:
        prompt += "\n\nTweet text:\n" + tweet_text[:REPLY_TWEET_TEXT]
    parts: list[dict] = [{"text": prompt}]
    if image:
        parts.append({"inlineData": {"mimeType": "image/jpeg", "data": base64.b64encode(image).decode("ascii")}})
    attempts: list[tuple[dict | None, int]] = [(gemini_thinking_config(model), 2048), (None, 4096)]
    busy_waits = (5, 12, 20, 30)
    best = ""
    saw_busy = False
    for thinking, max_tokens in attempts:
        # The model's own temperature (1.0): Google advises it for Gemini 3, and it keeps the replies varied.
        config: dict = {"temperature": 1.0, "maxOutputTokens": max_tokens}
        if thinking:
            config["thinkingConfig"] = thinking
        body = {"contents": [{"parts": parts}], "generationConfig": config}
        payload = None
        thinking_rejected = False
        for try_index in range(len(busy_waits) + 1):
            request = urllib.request.Request(
                "https://generativelanguage.googleapis.com/v1beta/models/"
                + quote(model, safe="")
                + ":generateContent",
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
                method="POST",
            )
            try:
                with urllib.request.urlopen(request, timeout=45) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    parsed = json.loads(exc.read().decode("utf-8", "replace")[:800])
                    detail = str(((parsed.get("error") or {}).get("message") or ""))[:160]
                except Exception:
                    detail = ""
                if api_key and api_key in detail:
                    detail = ""
                if thinking and re.search(r"thinking", detail, re.I):
                    thinking_rejected = True
                    break
                if gemini_is_busy(getattr(exc, "code", 0) or 0, detail):
                    saw_busy = True
                    if try_index < len(busy_waits):
                        time.sleep(busy_waits[try_index])
                        continue
                    break
                raise RuntimeError(detail or "رفض Gemini الطلب") from None
            except Exception as exc:
                if try_index < 2:
                    time.sleep(busy_waits[try_index])
                    continue
                raise RuntimeError("تعذر الاتصال بـ Gemini") from exc
        if thinking_rejected:
            continue
        if not payload:
            break
        candidate = (payload.get("candidates") or [{}])[0]
        reply_parts = ((candidate.get("content") or {}).get("parts") or [])
        texts = []
        for part in reply_parts:
            if not isinstance(part, dict) or part.get("thought"):
                continue
            if part.get("text"):
                texts.append(str(part["text"]))
        text = clean_comment(" ".join(texts))
        if comment_is_complete(text):
            record_comment_generated()
            remember_reply(account, tweet_id, text)
            return text
        if len(text) > len(best):
            best = text
    if comment_is_complete(best):
        record_comment_generated()
        remember_reply(account, tweet_id, best)
        return best
    if saw_busy:
        raise RuntimeError("النموذج مشغول مؤقتًا بعد عدة محاولات. غيّر النموذج أو أعد التنفيذ بعد قليل.")
    return ""


# Comments by Grok (xAI), when the owner chooses it in «توزيع البرنامج»: for users' copies, its key and model
# come with each check-in (kept in memory only); the owner's own copy follows the same choice, with the key
# and model saved there. (A copy of the script with no «توزيع البرنامج» has its own «مفتاح Claude» in its
# panel instead: see Claude's part below.) Each comment is asked with the same prompt as Gemini's, through
# xAI's Responses API, with the tweet's picture.
GROK_URL = "https://api.x.ai/v1/responses"
GROK_DEFAULT_MODEL = "grok-4.3"             # (as in g.py: the model when none is set there)
GROK_PATH = DATA_DIR / "grok.json"         # (a Grok key kept from before: removed when the program starts)
# Comments are asked with no reasoning: much faster (and cheaper) than thinking first, and enough for a reply
# this short. A model that does not take the setting is asked again without it (with its own default), and
# is not sent it again.
GROK_REASONING = {"effort": "none"}
grok_reasoning_refused: set[str] = set()
grok_lock = threading.Lock()
saved_grok: dict = {"engine": "gemini", "api_key": "", "model": ""}


def valid_grok_key(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_\-]{20,256}", value or ""))


def valid_grok_model(value: str) -> bool:
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9.\-]{1,60}", value or ""))


def apply_owner_comments(engine: str, key: str, model: str) -> None:
    """Who the owner chose to write this copy's comments (from its check-in): Grok or Claude, with its key and
    model, or Gemini (the other key is then dropped here)."""
    valid = (engine == "grok" and valid_grok_key(key) and valid_grok_model(model)) or \
        (engine == "claude" and valid_claude_key(key) and valid_claude_model(model))
    wanted = {"engine": engine if valid else "gemini", "api_key": key if valid else "", "model": model if valid else ""}
    with grok_lock:
        saved_grok.update(wanted)              # (in memory only)


def distribution_saved() -> dict:
    """What «توزيع البرنامج» saved beside this script (g.py's data/distribution.json), only read here."""
    try:
        loaded = json.loads((CONTROL_FILE.with_name("data") / "distribution.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return loaded if isinstance(loaded, dict) else {}


def owner_comments_choice() -> dict:
    """The owner's copy: who writes the comments, as chosen in «توزيع البرنامج» for users' copies (the same for
    this one) {"engine", "api_key", "model"}: from g.py's page when this program serves it, else from what
    that page saved beside this script."""
    page = distribution_page
    names = ("comments_engine", "grok_key", "grok_model", "claude_key", "claude_model")
    if page is not None:
        with page.store_lock:
            saved = {name: page.store.get(name) for name in names}
        grok_default = str(getattr(page, "GROK_DEFAULT_MODEL", "") or GROK_DEFAULT_MODEL)
        claude_default = str(getattr(page, "CLAUDE_DEFAULT_MODEL", "") or CLAUDE_DEFAULT_MODEL)
    else:
        saved, grok_default, claude_default = distribution_saved(), GROK_DEFAULT_MODEL, CLAUDE_DEFAULT_MODEL
    engine = str(saved.get("comments_engine") or "")
    if engine == "claude":
        return {"engine": engine, "api_key": str(saved.get("claude_key") or "").strip(),
                "model": str(saved.get("claude_model") or "").strip().lower() or claude_default}
    return {"engine": engine, "api_key": str(saved.get("grok_key") or "").strip(),
            "model": str(saved.get("grok_model") or "").strip().lower() or grok_default}


def comments_writer() -> tuple[str, str, str]:
    """Who writes this copy's comments: ("grok" | "claude", key, model), or ("gemini", "", "") — the owner's
    choice in «توزيع البرنامج», for users' copies (from their check-ins) and for the owner's own copy alike."""
    if is_owner_copy() and not key_typed_here():
        choice = owner_comments_choice()
    else:
        # A user's copy (from its check-ins), or a copy with no «توزيع البرنامج» (the key typed in its panel).
        with grok_lock:
            choice = dict(saved_grok)
    engine, key, model = choice.get("engine"), str(choice.get("api_key") or ""), str(choice.get("model") or "")
    if engine == "grok" and valid_grok_key(key) and valid_grok_model(model):
        return "grok", key, model
    if engine == "claude" and valid_claude_key(key) and valid_claude_model(model):
        return "claude", key, model
    return "gemini", "", ""


def grok_settings() -> tuple[str, str]:
    """(key, model) when Grok writes this copy's comments, else ("", "")."""
    engine, key, model = comments_writer()
    return (key, model) if engine == "grok" else ("", "")


def grok_comments_on() -> bool:
    """Whether Grok writes this copy's comments (see comments_writer)."""
    return bool(grok_settings()[0])


def gemini_writes_comments() -> bool:
    """Whether Gemini writes this copy's comments (no Grok or Claude chosen)."""
    return comments_writer()[0] == "gemini"


def grok_answer_text(answer: dict) -> str:
    """The text of a Responses API answer: output[] → message → content[] → output_text."""
    parts = []
    for item in answer.get("output") or []:
        if isinstance(item, dict) and item.get("type") == "message":
            for content in item.get("content") or []:
                if isinstance(content, dict) and content.get("type") == "output_text":
                    parts.append(str(content.get("text") or ""))
    return "\n".join(parts) or str(answer.get("output_text") or "")


def grok_comment(api_key: str, model: str, image: bytes | None, tweet_text: str, voice: str = DEFAULT_REPLY_VOICE,
                 account: str = "", tweet_id: str = "") -> str:
    """One reply to a tweet by Grok: the same prompt as Gemini's, the tweet's picture with it, no reasoning. A
    model that does not take the reasoning setting is asked again without it; a busy Grok is asked again a
    few times."""
    prompt = reply_prompt(voice, account, tweet_id)
    if image:
        prompt = "Look at the image sent with the tweet. " + prompt
    if tweet_text:
        prompt += "\n\nTweet text:\n" + tweet_text[:REPLY_TWEET_TEXT]
    content: list[dict] = [{"type": "input_text", "text": prompt}]
    if image:
        content.append({"type": "input_image", "image_url": "data:image/jpeg;base64," + base64.b64encode(image).decode("ascii")})
    reasoning = model not in grok_reasoning_refused
    busy_waits = (5, 12, 20, 30)
    best = ""
    saw_busy = False
    for _ in range(2):               # a reply that comes back cut off is asked for once more
        payload = None
        for try_index in range(len(busy_waits) + 1):
            body: dict = {"model": model, "input": [{"role": "user", "content": content}]}
            if reasoning:
                body["reasoning"] = dict(GROK_REASONING)
            request = urllib.request.Request(GROK_URL, data=json.dumps(body).encode("utf-8"), method="POST",
                                             headers={"Content-Type": "application/json", "Authorization": "Bearer " + api_key})
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    data = json.loads(exc.read(4096).decode("utf-8", "replace"))
                    error = data.get("error") if isinstance(data, dict) else None
                    detail = str((error.get("message") if isinstance(error, dict) else error) or data.get("message") or "")
                except Exception:
                    detail = ""
                detail = re.sub(r"\s+", " ", detail.replace(api_key, "…") if api_key else detail).strip()[:160]
                if reasoning and exc.code == 400 and re.search(r"reasoning", detail, re.I):
                    reasoning = False    # this model takes no reasoning setting: asked again without it,
                    grok_reasoning_refused.add(model)    # and not sent it again
                    continue
                if exc.code in (401, 403):
                    raise RuntimeError("مفتاح Grok غير صالح أو بلا صلاحية. أخبر صاحب البرنامج.") from None
                if re.search(r"credit|spending limit|billing", detail, re.I):
                    raise RuntimeError("نفد رصيد Grok أو بلغ حد الإنفاق. أخبر صاحب البرنامج.") from None
                if exc.code in (429, 500, 502, 503, 504):
                    saw_busy = True
                    if try_index < len(busy_waits):
                        time.sleep(busy_waits[try_index])
                        continue
                    break
                raise RuntimeError(("رفض Grok الطلب: " + detail) if detail else f"تعذر الاتصال بـ Grok (رمز {exc.code}).") from None
            except (urllib.error.URLError, OSError, ValueError) as exc:
                if try_index < 2:
                    time.sleep(busy_waits[try_index])
                    continue
                raise RuntimeError("تعذر الاتصال بـ Grok") from exc
        if not isinstance(payload, dict):
            break
        text = clean_comment(grok_answer_text(payload))
        if comment_is_complete(text):
            record_comment_generated()
            remember_reply(account, tweet_id, text)
            return text
        if len(text) > len(best):
            best = text
    if comment_is_complete(best):
        record_comment_generated()
        remember_reply(account, tweet_id, best)
        return best
    if saw_busy:
        raise RuntimeError("Grok مشغول مؤقتًا بعد عدة محاولات. أعد التنفيذ بعد قليل.")
    return ""


# Comments by Claude (Anthropic), when the owner chooses it in «توزيع البرنامج»: the same as Grok's (its key and
# model come with each check-in, in memory only), asked through the Messages API with the same prompt and the
# tweet's picture, at medium effort (it thinks a little before it writes).
CLAUDE_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_API_VERSION = "2026-10-21"
CLAUDE_DEFAULT_MODEL = "claude-haiku-5-5"   # (as in g.py: the model when none is set there)
CLAUDE_EFFORT = "medium"
# Models that take no effort setting (older ones), asked again without it and not sent it again.
claude_effort_refused: set[str] = set()


def valid_claude_key(value: str) -> bool:
    return bool(re.fullmatch(r"sk-ant-[A-Za-z0-9_\-]{20,250}", value or ""))


def valid_claude_model(value: str) -> bool:
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9.\-]{1,60}", value or ""))


# A copy of the script with no «توزيع البرنامج» (no g.py beside it) has its own «مفتاح Claude» in its panel: the
# key typed there, kept sealed in data/claude.json, writes its comments with Claude, at the same effort and with
# the same prompt, and it needs nothing else. (Its panel had «مفتاح Grok» before: a Grok key kept from then is
# removed, and the comments are Gemini's until a Claude key is saved.)
CLAUDE_PATH = DATA_DIR / "claude.json"


def key_typed_here() -> bool:
    """A copy on its own (see on_its_own): its comments are written with the Claude key typed in its own panel,
    when one is saved, and it needs nothing else."""
    return on_its_own()


def load_panel_key() -> None:
    """A user's copy keeps the comments key in memory only, from its check-ins, never on its disk: files from
    before (data/grok.json, which held one) are removed, and the copy starts with Gemini until its first
    check-in. The owner's copy reads back the Claude key typed in its own panel («مفتاح Claude»), kept there
    sealed; a Grok key typed there before («مفتاح Grok», no longer in the panel) is removed, as is any file it
    cannot use."""
    key = model = ""
    if is_owner_copy():
        loaded = read_private_json(CLAUDE_PATH) or {}
        key = open_key(loaded.get("api_key_sealed")).strip() if loaded.get("source") == "panel" else ""
        model = str(loaded.get("model") or "").strip().lower() or CLAUDE_DEFAULT_MODEL
    if not (valid_claude_key(key) and valid_claude_model(model)):
        key = model = ""
    for path in (GROK_PATH,) if key else (GROK_PATH, CLAUDE_PATH):
        try:
            path.unlink()
        except OSError:
            pass
    with grok_lock:
        saved_grok.update(engine="claude" if key else "gemini", api_key=key, model=model)


def remember_own_claude(key: str, model: str) -> None:
    """The Claude key and model typed in this copy's panel (none: back to Gemini), kept sealed."""
    with grok_lock:
        saved_grok.update(engine="claude" if key else "gemini", api_key=key, model=model if key else "")
        if key:
            write_private_json(CLAUDE_PATH, {"version": 1, "source": "panel", "api_key_sealed": seal_key(key), "model": model})
        else:
            try:
                CLAUDE_PATH.unlink()
            except OSError:
                pass


def own_claude_shown() -> dict:
    """What the panel shows of its own Claude key: only its first and last letters."""
    with grok_lock:
        key, model = (saved_grok["api_key"], saved_grok["model"]) if saved_grok["engine"] == "claude" else ("", "")
    return {"claude_key": f"{key[:7]}…{key[-4:]}" if key else "", "claude_model": model or CLAUDE_DEFAULT_MODEL}


def claude_answer_text(answer: dict) -> str:
    """The text of a Messages API answer: its text blocks (it may begin with thinking blocks)."""
    parts = [str(block.get("text") or "") for block in answer.get("content") or []
             if isinstance(block, dict) and block.get("type") == "text"]
    return "\n".join(parts)


def claude_comment(api_key: str, model: str, image: bytes | None, tweet_text: str, voice: str = DEFAULT_REPLY_VOICE,
                   account: str = "", tweet_id: str = "") -> str:
    """One reply to a tweet by Claude: the same prompt as Gemini's and Grok's, the tweet's picture with it, at
    medium effort. A model that takes no effort setting is asked again without it; a busy Claude is asked again
    a few times."""
    prompt = reply_prompt(voice, account, tweet_id)
    if image:
        prompt = "Look at the image sent with the tweet. " + prompt
    if tweet_text:
        prompt += "\n\nTweet text:\n" + tweet_text[:REPLY_TWEET_TEXT]
    content: list[dict] = []
    if image:
        content.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                                    "data": base64.b64encode(image).decode("ascii")}})
    content.append({"type": "text", "text": prompt})
    effort = model not in claude_effort_refused
    busy_waits = (5, 12, 20, 30)
    best = ""
    saw_busy = False
    for _ in range(2):               # a reply that comes back cut off is asked for once more
        payload = None
        for try_index in range(len(busy_waits) + 1):
            # (Its thinking counts toward max_tokens: room for it, and for the short reply after it.)
            body: dict = {"model": model, "max_tokens": 2048, "messages": [{"role": "user", "content": content}]}
            if effort:
                body["output_config"] = {"effort": CLAUDE_EFFORT}
            request = urllib.request.Request(CLAUDE_URL, data=json.dumps(body).encode("utf-8"), method="POST",
                                             headers={"Content-Type": "application/json", "x-api-key": api_key,
                                                      "anthropic-version": CLAUDE_API_VERSION})
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as exc:
                detail, code = "", ""
                try:
                    data = json.loads(exc.read(4096).decode("utf-8", "replace"))
                    error = data.get("error") if isinstance(data, dict) else None
                    if isinstance(error, dict):
                        detail = str(error.get("message") or "")
                        code = str((error.get("details") or {}).get("error_code") or "") if isinstance(error.get("details"), dict) else ""
                except Exception:
                    detail = ""
                detail = re.sub(r"\s+", " ", detail.replace(api_key, "…") if api_key else detail).strip()[:160]
                if effort and exc.code == 400 and re.search(r"effort|output_config", detail, re.I):
                    effort = False       # this model takes no effort setting: asked again without it,
                    claude_effort_refused.add(model)    # and not sent it again
                    continue
                if exc.code in (401, 403):
                    raise RuntimeError("مفتاح Claude غير صالح أو بلا صلاحية. أخبر صاحب البرنامج.") from None
                if code == "enforced_spend_limit_reached" or re.search(r"usage limits|credit balance|billing", detail, re.I):
                    raise RuntimeError("بلغ حساب Claude حد الصرف أو نفد رصيده. أخبر صاحب البرنامج.") from None
                if exc.code in (429, 500, 502, 503, 504, 529):
                    saw_busy = True
                    if try_index < len(busy_waits):
                        time.sleep(busy_waits[try_index])
                        continue
                    break
                raise RuntimeError(("رفض Claude الطلب: " + detail) if detail else f"تعذر الاتصال بـ Claude (رمز {exc.code}).") from None
            except (urllib.error.URLError, OSError, ValueError) as exc:
                if try_index < 2:
                    time.sleep(busy_waits[try_index])
                    continue
                raise RuntimeError("تعذر الاتصال بـ Claude") from exc
        if not isinstance(payload, dict):
            break
        if payload.get("stop_reason") == "refusal":
            raise RuntimeError("امتنع Claude عن التعليق على هذه التغريدة.")
        text = clean_comment(claude_answer_text(payload))
        if comment_is_complete(text):
            record_comment_generated()
            remember_reply(account, tweet_id, text)
            return text
        if len(text) > len(best):
            best = text
    if comment_is_complete(best):
        record_comment_generated()
        remember_reply(account, tweet_id, best)
        return best
    if saw_busy:
        raise RuntimeError("Claude مشغول مؤقتًا بعد عدة محاولات. أعد التنفيذ بعد قليل.")
    return ""


# Arabic diacritics (تشكيل): tanween, fatha, damma, kasra, shadda, sukun, and the other marks over or under letters.
ARABIC_DIACRITICS = re.compile(r"[\u064B-\u0652\u0656-\u065F\u0670]")
# Words a reply cannot end on, when one that is too long is shortened.
HANGING_WORDS = {"و", "او", "أو", "بس", "لكن", "لان", "لأن", "عشان", "اللي", "الي", "في", "من", "على", "عن", "مع", "الى",
                 "إلى", "يعني", "ثم", "حتى", "اذا", "إذا", "لو", "ما", "لا", "كان", "and", "or", "but", "the", "to", "of",
                 "in", "a", "an", "with", "for", "that", "ve", "ama", "ile", "için", "bir", "de", "da"}


def polish_comment(text: str) -> str:
    """The reply as it is posted: no Arabic diacritics and no commas (a number's thousands keep their digits)."""
    text = ARABIC_DIACRITICS.sub("", text or "")
    text = re.sub(r"(?<=\d),(?=\d{3})", "", text)
    text = re.sub(r"\s*[،,؛;]\s*", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def fit_comment(text: str, limit: int = REPLY_MAX_CHARS) -> str:
    """A reply cut to at most limit characters, at a word, and not on a word that leaves it hanging."""
    words = text.split()
    while words and len(" ".join(words)) > limit:
        words.pop()
    while words and words[-1].lower() in HANGING_WORDS:
        words.pop()
    return " ".join(words)


def write_comment(api_key: str, model: str, image: bytes | None, tweet_text: str, voice: str = DEFAULT_REPLY_VOICE,
                  account: str = "", tweet_id: str = "") -> str:
    """One reply, by whoever writes this copy's comments: Grok or Claude when the owner chose one of them in
    «توزيع البرنامج» (for users' copies and the owner's alike), else Gemini (with the task's key and model, or
    this copy's saved ones). It is posted with no diacritics and no commas, in at most REPLY_MAX_CHARS
    characters: one that comes back longer is asked for once more, then shortened at a word."""
    if control_configured():
        return control_comment(tweet_text, image, voice, account, tweet_id)
    if not is_owner_copy() and not wait_for_owner_keys():
        raise RuntimeError(no_keys_message())
    engine, key, engine_model = comments_writer()
    if engine == "gemini" and not api_key:
        with gemini_lock:
            api_key = str(saved_gemini.get("api_key") or "")
            model = model or normalize_gemini_model(str(saved_gemini.get("model") or ""))

    def ask() -> str:
        if engine == "grok":
            return grok_comment(key, engine_model, image, tweet_text, voice, account, tweet_id)
        if engine == "claude":
            return claude_comment(key, engine_model, image, tweet_text, voice, account, tweet_id)
        return gemini_comment(api_key, model, image, tweet_text, voice, account, tweet_id)

    first = polish_comment(ask())
    if len(first) <= REPLY_MAX_CHARS:
        return first
    second = polish_comment(ask())               # too long: asked for once more
    if second and len(second) <= REPLY_MAX_CHARS:
        return second
    return fit_comment(min((text for text in (first, second) if text), key=len))


def reply_for(api_key: str, model: str, image: bytes | None, tweet_text: str, voice: str = DEFAULT_REPLY_VOICE,
              account: str = "", tweet_id: str = "") -> str:
    """One reply (see write_comment), asked once more when the first is under four words."""
    comment = write_comment(api_key, model, image, tweet_text, voice, account, tweet_id)
    if len(comment.split()) < 4:
        comment = write_comment(api_key, model, image, tweet_text, voice, account, tweet_id)
    return comment


# A reply is written from the tweet's content, asked of FxTwitter (api.fxtwitter.com/status/<id>, see
# fx_tweet_views), not from a picture of the opened page: its text, the post it quotes, and its picture
# only when its own text is too short to say what it is about (under COMMENT_PICTURE_LETTERS letters).
# So it can be written before the tweet is opened: a comments task asks for the next tweet's reply while
# it is still on the one before (CommentsAhead), and when the tweet opens its reply is ready.
COMMENT_PICTURE_LETTERS = 60
COMMENT_PICTURE_MAX_BYTES = 3_000_000


def comment_material(content: dict) -> tuple[str, str]:
    """What a reply is written from, out of a tweet's content (see fx_content): its text (with the post it
    quotes), and the address of the picture to send with it ("" when its text says enough, or it has none)."""
    body = re.sub(r"[ \t ]+", " ", str(content.get("body") or "")).strip()
    quoted = content.get("quote") if isinstance(content.get("quote"), dict) else {}
    lines = [body] if body else []
    quote_body = re.sub(r"\s+", " ", str(quoted.get("body") or "")).strip()
    if quote_body:
        by = str(quoted.get("by") or "")
        lines.append(f"[The post it quotes{' (by @' + by + ')' if by else ''}: {quote_body[:600]}]")
    picture = ""
    if len(re.sub(r"[\W_]+", "", re.sub(r"https?://\S+", "", body))) < COMMENT_PICTURE_LETTERS:
        for kind, address in list(content.get("pictures") or []) + list(quoted.get("pictures") or []):
            picture = address
            break
    if picture:
        lines.append("[The picture sent with it is the tweet's own picture]")
    return "\n".join(lines).strip(), picture


def fetch_picture(address: str) -> bytes | None:
    """A tweet's picture, small (X's picture server only, as JPEG); None when it cannot be had."""
    if not address or not TWEET_PICTURE.fullmatch(address):
        return None
    base = address.split("?", 1)[0]
    stem = re.sub(r"\.(?:jpe?g|png|webp|gif)$", "", base, flags=re.I)
    for url in (stem + "?format=jpg&name=small", base):
        try:
            asking = urllib.request.Request(url, headers={"User-Agent": "x-group-tool/1.0", "Accept": "image/jpeg"})
            with urllib.request.urlopen(asking, timeout=12) as response:
                data = response.read(COMMENT_PICTURE_MAX_BYTES + 1)
        except Exception:
            continue
        if len(data) <= COMMENT_PICTURE_MAX_BYTES and data[:3] == b"\xff\xd8\xff":
            return data
    return None


class CommentsAhead:
    """The replies of one comments task, written before their tweets are opened. ask(item): the tweet's
    content is asked of FxTwitter and its reply written, in the background; take(id): that reply (waiting
    for it while it is still being written) and the content it came from. A task asks for the tweet it is
    about to open and for the one after it, so the next reply is being written while the task is still
    on the tweet before."""

    def __init__(self, write, account: str, actions: list[str], should_stop=None):
        self.write = write                  # (tweet_text, image, tweet_id) -> reply
        self.account = account
        self.actions = list(actions)
        self.should_stop = should_stop
        self.lock = threading.Lock()
        self.asked: dict[str, dict] = {}
        self.closed = False

    def ask(self, item: dict | None) -> None:
        url = str((item or {}).get("url") or "")
        status_id = tweet_status_id(url)
        if not status_id or self.closed or (self.should_stop and self.should_stop()):
            return
        if "comment" not in item_actions(item or {}, self.actions):
            return                          # (a retry of the failed: this tweet's comment is not asked again)
        if (already_done_recently(self.account, status_id, self.actions)
                or already_done_recently(self.account, status_id, ["comment"]) or tweet_is_ignored(url)):
            return                          # it is skipped: no reply is needed
        with self.lock:
            if status_id in self.asked:
                return
            entry = {"done": threading.Event(), "reply": "", "content": None, "error": ""}
            self.asked[status_id] = entry
        threading.Thread(target=self._write, args=(status_id, entry), name="comment-ahead", daemon=True).start()

    def _write(self, status_id: str, entry: dict) -> None:
        with as_account(self.account):
            try:
                outcome, _views, link, content = fx_tweet_views(status_id)
                if outcome != "ok" or content is None:
                    entry["error"] = outcome
                    return
                entry["content"] = content
                if self.closed or (link and tweet_is_ignored(link)):
                    return
                text, picture = comment_material(content)
                image = fetch_picture(picture) if picture else None
                if (text or image) and not self.closed:
                    entry["reply"] = self.write(text, image, status_id)
            except Exception as exc:        # (the reply is then written when the tweet opens)
                entry["error"] = (str(exc).splitlines() or [type(exc).__name__])[0][:160]
            finally:
                entry["done"].set()

    def take(self, status_id: str) -> tuple[str, dict | None]:
        """The reply written ahead for this tweet, and the content it was written from: ("", content or None)
        when there is none (FxTwitter had no answer, or writing it failed)."""
        with self.lock:
            entry = self.asked.pop(status_id, None)
        if entry is None:
            return "", None
        while not entry["done"].wait(0.25):
            if self.closed or (self.should_stop and self.should_stop()):
                return "", None
        return entry["reply"], entry["content"]

    def keep_only(self, status_ids: set[str]) -> None:
        """Forget the tweets the task has gone past (a reply still being written for one is not used)."""
        with self.lock:
            for status_id in [key for key in self.asked if key not in status_ids]:
                del self.asked[status_id]

    def close(self) -> None:
        self.closed = True
        with self.lock:
            self.asked.clear()


PAGE_PICTURE_JS = r"""
(statusId) => {
  const articles = [...document.querySelectorAll('article[data-testid="tweet"]')];
  const article = articles.find((node) => statusId && node.querySelector('a[href*="/status/' + statusId + '"]')) || articles[0];
  if (!article) return "";
  const photo = article.querySelector('[data-testid="tweetPhoto"] img');
  if (photo && photo.getAttribute("src")) return photo.getAttribute("src");
  const video = article.querySelector("video[poster]");
  return video ? (video.getAttribute("poster") || "") : "";
}
"""


def reply_from_page(page, card, item: dict, content: dict | None, api_key: str, model: str, voice: str,
                    account: str, tweet_id: str) -> str:
    """The reply, written once the tweet is open, when none was ready: from its content when FxTwitter gave
    it, else from what the opened page shows (its text, and its picture when the text is short)."""
    if content is not None:
        text, picture = comment_material(content)
        image = fetch_picture(picture) if picture else None
        if text or image:
            return reply_for(api_key, model, image, text, voice, account, tweet_id)
    text = article_text(card)
    collected = str(item.get("text") or "").strip()
    if not text and collected != "تغريدة":
        text = collected
    image = None
    if len(re.sub(r"[\W_]+", "", re.sub(r"https?://\S+", "", text))) < COMMENT_PICTURE_LETTERS:
        try:
            address = str(page.evaluate(PAGE_PICTURE_JS, tweet_id) or "")
        except Exception:
            address = ""
        image = fetch_picture(address) if address else None
        if image is not None:
            text = (text + "\n[The picture sent with it is the tweet's own picture]").strip()
        elif not text:
            image = screenshot_article(card)    # nothing else to go by: a picture of the tweet as shown
    return reply_for(api_key, model, image, text, voice, account, tweet_id)


def screenshot_article(card) -> bytes | None:
    try:
        if not IN_APP:
            try:
                card.scroll_into_view_if_needed(timeout=4000)
            except Exception:
                pass
        return card.screenshot(type="jpeg", quality=70, timeout=12000)
    except Exception:
        return None


def reply_block_reason(page) -> str | None:
    try:
        text = page.evaluate("() => (document.body && document.body.innerText || '').slice(0, 5000)")
    except Exception:
        return None
    if re.search(r"can.?t reply|cannot reply|aren.?t allowed to reply|replies are limited|who can reply|Reply limited", text or "", re.I):
        return "الرد غير مسموح على هذه التغريدة"
    if re.search(r"daily limit|rate limit|Try again later", text or "", re.I):
        return "الحساب وصل حد الردود مؤقتًا"
    if re.search(r"لا يمكنك الرد|غير مسموح بالرد|الردود محدودة", text or ""):
        return "الرد غير مسموح على هذه التغريدة"
    return None


def reply_button_ready(page) -> bool:
    try:
        return bool(page.evaluate(
            """() => {
              const nodes = [...document.querySelectorAll('[data-testid="tweetButtonInline"], [data-testid="tweetButton"]')];
              return nodes.some((button) => button.getAttribute("aria-disabled") !== "true" && !button.disabled);
            }"""
        ))
    except Exception:
        return False


def composer_visible(page) -> bool:
    try:
        box = page.locator('[data-testid="tweetTextarea_0"]')
        return box.count() > 0 and box.first.is_visible()
    except Exception:
        return False


def open_reply_composer(page, path: str) -> None:
    """Wait for the tweet to settle, then open the reply box. On the phone, call the reply
    button's own handler. A coordinate press was landing on the account name."""
    match = re.search(r"status/(\d{6,25})", path or "")
    status_id = match.group(1) if match else ""
    if IN_APP:
        for _ in range(3):
            if composer_visible(page):
                trace_click("reply مربع الكتابة ظاهر")
                return
            try:
                pressed = page.evaluate(PRESS_PAGE_JS, {"statusId": status_id, "testid": "reply"})
            except Exception as exc:
                pressed = {"how": "error", "error": str(exc).splitlines()[0][:160]}
            trace_click(f"reply فتح {pressed}")
            try:
                page.locator('[data-testid="tweetTextarea_0"]').last.wait_for(state="visible", timeout=8000)
                trace_click("reply ظهر مربع الكتابة")
                return
            except PlaywrightTimeoutError:
                page.wait_for_timeout(500)
        raise PlaywrightTimeoutError("tweetTextarea_0 not visible after retries")
    for attempt in range(3):
        page.wait_for_timeout(800 if attempt == 0 else 1400)
        if composer_visible(page):
            real_click(page.locator('[data-testid="tweetTextarea_0"]').first)
            page.wait_for_timeout(400)
            return
        card = article_locator(page, path)
        try:
            if card.count() and not IN_APP:
                card.first.scroll_into_view_if_needed(timeout=3000)
                page.wait_for_timeout(500)
        except Exception:
            pass
        button = card.locator('[data-testid="reply"]') if card.count() else page.locator('[data-testid="reply"]')
        if button.count() == 0:
            button = page.locator('[data-testid="reply"]')
        if button.count() == 0:
            continue
        try:
            if not IN_APP:
                button.first.scroll_into_view_if_needed(timeout=2000)
                page.wait_for_timeout(400)
            real_click(button.first)
        except Exception:
            continue
        try:
            page.locator('[data-testid="tweetTextarea_0"]').last.wait_for(state="visible", timeout=8000)
            page.wait_for_timeout(500)
            return
        except PlaywrightTimeoutError:
            continue
    raise PlaywrightTimeoutError("tweetTextarea_0 not visible after retries")


# A reply is typed into the box a letter at a time at an uneven pace, not pasted whole. The whole comment takes
# TYPING_TOTAL_MS (between the two, at random), whatever its length. (It was 5 to 10 seconds: the slowest part of a
# comment.)
TYPING_TOTAL_MS = (1500, 3000)
TYPE_STEPS_PER_CALL = 20        # (in the app the typing is done by the page itself, this many letters a call)


def typing_plan(text: str) -> list[list]:
    """[letter, milliseconds to wait after it] in order, paced so the whole comment is typed
    over TYPING_TOTAL_MS whatever its length (the letters still appear one after another)."""
    steps: list[list] = [[ch, 0] for ch in text]
    if not steps:
        return steps
    total = random.randint(*TYPING_TOTAL_MS)    # total time to type the whole comment, in ms
    share = total / len(steps)
    for step in steps:
        step[1] = max(4, int(share * random.uniform(0.6, 1.4)))
    return steps


def typed_text(steps: list[list]) -> str:
    """The text a typing plan leaves in the box."""
    out: list[str] = []
    for ch, _wait in steps:
        if ch == "\b":
            if out:
                out.pop()
        else:
            out.append(ch)
    return "".join(out)


def same_text(seen, wanted: str) -> bool:
    clean = lambda value: re.sub(r"\s+", " ", re.sub(r"[​‌‍﻿]", "", str(value or ""))).strip()
    return clean(seen) == clean(wanted)


# The page types the letters itself (the reply box is X's editor): each letter put in as typed text, with the
# waits between them, in the box of the reply dialog.
TYPING_JS = r"""
async ({steps, clear}) => {
  const box = document.querySelector('[role="dialog"] [data-testid="tweetTextarea_0"]')
    || document.querySelector('[data-testid="tweetTextarea_0"]');
  if (!box) return {ok: false, why: "no box"};
  const editable = box.querySelector('[contenteditable="true"]') || box;
  editable.focus();
  if (clear) {
    document.execCommand("selectAll", false);
    document.execCommand("delete", false);
  }
  const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
  for (const [letter, wait] of steps) {
    if (letter === "\b") document.execCommand("delete", false);
    else document.execCommand("insertText", false, letter);
    if (wait) await sleep(wait);
  }
  return {ok: true, text: (editable.innerText || "").replace(/\s+/g, " ").trim()};
}
"""

COMPOSER_TEXT_JS = r"""
() => {
  const box = document.querySelector('[role="dialog"] [data-testid="tweetTextarea_0"]')
    || document.querySelector('[data-testid="tweetTextarea_0"]');
  return box ? (box.innerText || "") : "";
}
"""


def type_like_a_person(page, text: str) -> bool:
    """Type the reply a letter at a time (see typing_plan). True when the box then holds the text and the reply
    button is live; False when it did not work out (the box is then written in one go by the caller)."""
    steps = typing_plan(text)
    if IN_APP:
        typed: object = None
        for start in range(0, len(steps), TYPE_STEPS_PER_CALL):
            try:
                typed = page.evaluate(TYPING_JS, {"steps": steps[start:start + TYPE_STEPS_PER_CALL], "clear": start == 0})
            except Exception as exc:
                typed = {"ok": False, "why": str(exc).splitlines()[0][:80]}
            if not (isinstance(typed, dict) and typed.get("ok")):
                trace_click(f"reply الكتابة حرفًا حرفًا توقفت: {typed}")
                return False
        page.wait_for_timeout(200)
        seen = typed.get("text") if isinstance(typed, dict) else ""
    else:
        for letter, wait in steps:
            if letter == "\b":
                page.keyboard.press("Backspace")
            else:
                page.keyboard.type(letter)
            page.wait_for_timeout(wait)
        page.wait_for_timeout(350)
        try:
            seen = page.evaluate(COMPOSER_TEXT_JS)
        except Exception:
            seen = ""
    if same_text(seen, text) and reply_button_ready(page):
        trace_click(f"reply كُتب النص حرفًا حرفًا ({len(steps)} ضغطة)")
        return True
    trace_click("reply الكتابة حرفًا حرفًا لم تترك النص كما هو: يُكتب دفعة واحدة")
    return False


def insert_reply_text(page, text: str) -> None:
    if IN_APP:
        if type_like_a_person(page, text):
            return
        page.evaluate(
            """(value) => {
              const box = document.querySelector('[role="dialog"] [data-testid="tweetTextarea_0"]')
                || document.querySelector('[data-testid="tweetTextarea_0"]');
              if (!box) return false;
              const editable = box.querySelector('[contenteditable="true"]') || box;
              editable.focus();
              document.execCommand("selectAll", false);
              document.execCommand("delete", false);
              document.execCommand("insertText", false, value);
              editable.dispatchEvent(new InputEvent("input", {bubbles: true, inputType: "insertText", data: value}));
              return true;
            }""",
            text,
        )
        page.wait_for_timeout(400)
        if reply_button_ready(page):
            trace_click("reply كُتب النص")
            return
        page.keyboard.insert_text(text)
        page.wait_for_timeout(400)
        if not reply_button_ready(page):
            raise PlaywrightTimeoutError("reply button stayed disabled")
        trace_click("reply كُتب النص من لوحة المفاتيح")
        return
    box = page.locator('[role="dialog"] [data-testid="tweetTextarea_0"]')
    if box.count() == 0:
        box = page.locator('[data-testid="tweetTextarea_0"]')
    box.last.wait_for(state="visible", timeout=10000)
    real_click(box.last)
    page.keyboard.press("Control+A")
    page.keyboard.press("Backspace")
    if type_like_a_person(page, text):
        return
    page.keyboard.press("Control+A")
    page.keyboard.press("Backspace")
    page.keyboard.insert_text(text)
    page.wait_for_timeout(350)
    if reply_button_ready(page):
        return
    page.keyboard.press("Control+A")
    page.keyboard.press("Backspace")
    page.keyboard.type(text, delay=8)
    page.wait_for_timeout(250)
    if reply_button_ready(page):
        return
    page.evaluate(
        """(value) => {
          const box = document.querySelector('[role="dialog"] [data-testid="tweetTextarea_0"]')
            || document.querySelector('[data-testid="tweetTextarea_0"]');
          if (!box) return;
          const editable = box.querySelector('[contenteditable="true"]') || box;
          editable.focus();
          document.execCommand("selectAll", false);
          document.execCommand("delete", false);
          document.execCommand("insertText", false, value);
          editable.dispatchEvent(new InputEvent("input", {bubbles: true, inputType: "insertText", data: value}));
        }""",
        text,
    )
    page.wait_for_function(
        """() => {
          const nodes = [...document.querySelectorAll('[data-testid="tweetButtonInline"], [data-testid="tweetButton"]')];
          return nodes.some((button) => button.getAttribute("aria-disabled") !== "true" && !button.disabled);
        }""",
        timeout=8000,
    )


PRESS_SEND_JS = r"""
() => {
  const nodes = [...document.querySelectorAll('[data-testid="tweetButtonInline"], [data-testid="tweetButton"]')];
  const button = [...nodes].reverse().find((node) => node.getAttribute("aria-disabled") !== "true" && !node.disabled);
  if (!button) return {how: "missing"};
  const before = (button.innerText || button.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
  const event = {
    preventDefault() {}, stopPropagation() {}, persist() {},
    nativeEvent: {isTrusted: true, button: 0},
    isTrusted: true, button: 0, type: "click",
    target: button, currentTarget: button
  };
  const keys = Object.keys(button);
  for (const key of keys) {
    if (!key.startsWith("__reactProps$")) continue;
    const props = button[key];
    if (props && typeof props.onClick === "function") {
      props.onClick(event);
      return {how: "react", before};
    }
  }
  for (const child of button.querySelectorAll("*")) {
    for (const key of Object.keys(child)) {
      if (!key.startsWith("__reactProps$")) continue;
      const props = child[key];
      if (props && typeof props.onClick === "function") {
        props.onClick(event);
        return {how: "react", before};
      }
    }
  }
  return {how: "no-handler", before};
}
"""


def click_reply_send(page) -> None:
    enabled = page.locator(
        '[data-testid="tweetButtonInline"]:not([aria-disabled="true"]), '
        '[data-testid="tweetButton"]:not([aria-disabled="true"])'
    )
    if enabled.count() == 0:
        raise PlaywrightTimeoutError("reply button stayed disabled")
    if IN_APP:
        sent = page.evaluate(PRESS_SEND_JS)
        trace_click(f"reply نشر {sent}")
        if not isinstance(sent, dict) or sent.get("how") not in ("react", "fiber"):
            raise PlaywrightTimeoutError("reply button stayed disabled")
        return
    real_click(enabled.last)


def publish_reply(page, text: str, path: str) -> tuple[bool, str]:
    blocked = reply_block_reason(page)
    if blocked:
        return False, blocked
    open_reply_composer(page, path)
    page.wait_for_timeout(250)
    blocked = reply_block_reason(page)
    if blocked:
        return False, blocked
    insert_reply_text(page, text)
    page.wait_for_timeout(250)
    click_reply_send(page)
    snippet = text[:24]
    try:
        page.wait_for_function(
            """(snippet) => [...document.querySelectorAll('article[data-testid="tweet"]')]
              .some((article) => (article.innerText || "").includes(snippet))""",
            arg=snippet,
            timeout=12000,
        )
        return True, ""
    except PlaywrightTimeoutError:
        blocked = reply_block_reason(page)
        return False, blocked or "أُرسل الطلب لكن الرد لم يظهر في الصفحة"


def comment_failure_text(exc: Exception) -> str:
    message = str(exc)
    if isinstance(exc, PlaywrightTimeoutError):
        if "tweetTextarea" in message:
            return "لم يظهر مربع كتابة الرد"
        if "reply button" in message or "aria-disabled" in message or "disabled" in message:
            return "زر النشر بقي معطّلًا"
        if "article" in message:
            return "لم تُفتح التغريدة في الوقت المناسب"
        return "انتهت المهلة أثناء تجهيز الرد"
    line = message.splitlines()[0][:110] if message else type(exc).__name__
    return line or "خطأ غير متوقع"


RESOLVE_PARENT_JS = r"""
(replyPath) => {
  const statusPath = (href) => {
    const match = (href || "").match(/^(?:https?:\/\/(?:www\.)?(?:x|twitter)\.com)?(\/[A-Za-z0-9_]+\/status\/\d+)/);
    return match ? match[1] : "";
  };
  const articles = [...document.querySelectorAll('article[data-testid="tweet"]')];
  const paths = articles.map((article) => {
    const time = article.querySelector("time");
    const link = time && time.closest('a[href*="/status/"]');
    return statusPath(link ? link.getAttribute("href") : "");
  });
  const index = paths.findIndex((path) => path && (replyPath.endsWith(path) || path.endsWith(replyPath)));
  if (index > 0) return paths[index - 1];
  return "";
}
"""


def article_text(card) -> str:
    """The tweet's own text as its opened page shows it (a long post whole, where the collected text stops
    at 280 letters); "" when it has none (a picture alone)."""
    try:
        found = card.locator('[data-testid="tweetText"]')
        if not found.count():
            return ""
        text = found.first.inner_text(timeout=2000)
    except Exception:
        return ""
    return re.sub(r"\s+", " ", text or "").strip()


def resolve_comment_target(page, path: str, needs_parent: bool) -> tuple[str, object]:
    if needs_parent:
        try:
            parent = page.evaluate(RESOLVE_PARENT_JS, path) or ""
        except Exception:
            parent = ""
        parent_path = normalize_status_path(str(parent))
        if parent_path and parent_path != path:
            matches = article_locator(page, parent_path)
            if matches.count() > 0:
                return parent_path, matches.first
    matches = article_locator(page, path)
    if matches.count() > 0:
        return path, matches.first
    return path, page.locator('article[data-testid="tweet"]').first


def execute_comment_actions(page, items: list[dict], actions: list[str], api_key: str, model: str, on_progress=None, should_stop=None, on_snapshot=None, account: str = "", voice: str = DEFAULT_REPLY_VOICE) -> list[dict]:
    """The task's actions on its tweets, with a reply on each. Each reply is written from the tweet's content
    (FxTwitter), asked before the tweet is opened (CommentsAhead): the page's pictures are not needed, so
    this browser keeps not loading them."""
    ahead = None
    if "comment" in actions:
        ahead = CommentsAhead(
            lambda text, image, tweet_id: reply_for(api_key, model, image, text, voice, account, tweet_id),
            account, actions, should_stop,
        )
    try:
        return _execute_comment_actions(page, items, actions, api_key, model, on_progress, should_stop, on_snapshot,
                                        account, voice, ahead)
    finally:
        if ahead is not None:
            ahead.close()


def _execute_comment_actions(page, items: list[dict], task_actions: list[str], api_key: str, model: str, on_progress,
                             should_stop, on_snapshot, account: str, voice: str, ahead) -> list[dict]:
    results: list[dict] = []
    total = len(items)
    failures = FailedTweets()
    # Where each tweet's result starts in results: going back after a pause drops them from there on.
    starts: dict[int, int] = {}
    if on_progress:
        on_progress(0, total, "act")
    index = -1
    acted = False
    while index + 1 < total:
        index += 1
        item = items[index]
        actions = item_actions(item, task_actions)      # (all the task's, or only those that failed on it before)
        plain = [action for action in actions if action != "comment"]
        if should_stop and should_stop():
            break
        starts[index] = len(results)
        result = {"url": item.get("url", ""), "text": item.get("text", ""), "actions": {}, "comment": ""}
        path = normalize_status_path(str(item.get("url") or ""))
        if not path:
            result["actions"] = {key: "تعذر العثور على المنشور" for key in actions}
            results.append(result)
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        status_id = tweet_status_id(str(item.get("url") or ""))
        if already_done_recently(account, status_id, actions):
            # Everything asked was done on this tweet by this account in the last 8 hours: skip without opening it.
            result["actions"] = {key: "سبق التفاعل خلال ٨ ساعات — تم التخطي" for key in actions}
            results.append(result)
            if on_snapshot:
                on_snapshot(list(results))
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        if acted:
            pause_span(0.15, 0.4, should_stop)
            if should_stop and should_stop():
                break
        acted = True
        # This account already replied to this tweet in the last 8 hours: never reply to it again.
        replied_before = "comment" in actions and already_done_recently(account, status_id, ["comment"])
        if ahead is not None:
            # Its reply (if not asked already, while on the tweet before) and the next tweet's are asked now.
            following = items[index + 1] if index + 1 < total else None
            ahead.keep_only({status_id, tweet_status_id(str((following or {}).get("url") or ""))})
            ahead.ask(item)
            ahead.ask(following)
        left = list(plain)
        try:
            opened, reason = open_task_tweet(page, str(item.get("url") or ""), None)
        except Exception as exc:
            if browser_closed_error(exc):
                if on_snapshot and results:
                    on_snapshot(list(results))
                raise BrowserClosed() from exc
            raise
        if opened or reason == "gone":
            failures.opened()
        else:
            back = failures.failed(index)
            new_page = None
            if back is not None:
                seconds = failures.next_pause()
                if seconds is None:
                    # A third time: the task stops here, with what it did (these two would not open).
                    result["actions"] = {key: "تعذر فتح التغريدة" for key in actions}
                    results.append(result)
                    if on_snapshot:
                        on_snapshot(list(results))
                    raise TweetsKeptFailing(results, index + 1)
                new_page = pause_after_failures(should_stop, on_progress, total, None, seconds,
                                                "pause" if failures.pauses == 1 else "pause_again")
            if new_page is not None:
                # Back to the first of the two that would not open; what was recorded from it on goes.
                page = new_page
                del results[starts[back]:]
                if on_snapshot:
                    on_snapshot(list(results))
                if on_progress:
                    on_progress(back, total, "act")
                index = back - 1
                continue
        if not opened:
            note = "محذوفة — تم التخطي" if reason == "gone" else "تعذر فتح التغريدة"
            result["actions"] = {key: note for key in actions}
            results.append(result)
            if on_snapshot:
                on_snapshot(list(results))
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        if tweet_is_ignored("https://x.com" + opened):
            # The opened tweet's author is an ignored account: take no action and leave no trace.
            forget_collected("https://x.com" + opened)
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        path = opened
        result["url"] = "https://x.com" + path
        try:
            page.wait_for_timeout(400)
            target_path, card = resolve_comment_target(page, path, bool(item.get("needs_parent")))
            result["url"] = "https://x.com" + target_path
            if not IN_APP:
                try:
                    card.scroll_into_view_if_needed(timeout=4000)
                except Exception:
                    pass
            page.wait_for_timeout(300)
            if left:
                result["actions"].update(apply_actions_on_path(page, target_path, left))
            if replied_before or ("comment" in actions and already_done_recently(account, tweet_status_id(target_path), ["comment"])):
                result["actions"]["comment"] = "سبق الرد خلال ٨ ساعات — تم التخطي"
            elif "comment" in actions:
                reply_to = tweet_status_id(target_path)
                comment, content = ahead.take(reply_to) if ahead is not None else ("", None)
                if comment:
                    print(f"تعليق التغريدة {reply_to} كان جاهزًا قبل فتحها", flush=True)
                else:
                    comment = reply_from_page(page, card, item, content, api_key, model, voice, account, reply_to)
                if len(comment.split()) < 4:
                    result["actions"]["comment"] = "لم يُرجع النموذج تعليقًا صالحًا"
                else:
                    result["comment"] = comment
                    page.wait_for_timeout(300)
                    posted, detail = publish_reply(page, comment, target_path)
                    result["actions"]["comment"] = "تم التنفيذ" if posted else (detail or "أُرسل الطلب لكن تعذر تأكيد الحالة")
        except RuntimeError as exc:
            result["actions"]["comment"] = "تعذر توليد التعليق: " + str(exc)[:120]
        except Exception as exc:
            if browser_closed_error(exc):
                if on_snapshot and results:
                    on_snapshot(list(results))
                raise BrowserClosed() from exc
            print(f"X reply failed on {path}: {type(exc).__name__}: {str(exc).splitlines()[0][:180]}", flush=True)
            if "comment" in actions and "comment" not in result["actions"]:
                result["actions"]["comment"] = "تعذر نشر التعليق: " + comment_failure_text(exc)
            for action in left:
                result["actions"].setdefault(action, "تعذر التنفيذ")
        # Save what was done, for the tweet in the group and for the tweet actually replied to.
        for done_id in {status_id, tweet_status_id(result["url"])}:
            remember_done(account, done_id, result["actions"])
        count_successes(result["actions"], account)
        results.append(result)
        if on_snapshot:
            on_snapshot(list(results))
        if on_progress:
            on_progress(index + 1, total, "act")
        page.wait_for_timeout(600)
    return results


# Do not download images, videos or audio in the automation browser.
BLOCK_MEDIA = True
BLOCKED_RESOURCE_TYPES = {"image", "media"}


def block_media(context) -> None:
    if not BLOCK_MEDIA:
        return
    state = {"allow": False}
    context._media_state = state

    def handle(route):
        request = route.request
        try:
            if not state["allow"] and (request.resource_type in BLOCKED_RESOURCE_TYPES or "video.twimg.com" in request.url):
                route.abort()
            else:
                route.continue_()
        except Exception:
            pass

    try:
        context.route("**/*", handle)
    except Exception:
        pass


def allow_media(page) -> None:
    """Let this browser load images and videos again (used for comments)."""
    state = getattr(page.context, "_media_state", None)
    if state is not None:
        state["allow"] = True


# Up to three accounts, each with its own task: the tasks run at the same time, one per account
# (a new task on an account that is already working waits in that account's line, see account_lines).
MAX_ACCOUNTS = 3
MAX_PARALLEL_JOBS = 3


PROFILES_DIR = DATA_DIR / "profiles"
# The size asked of a new browser. In the app the browser keeps the phone's own screen (its real
# width and height): a size asked of it is not applied.
NORMAL_VIEWPORT_HEIGHT = 1800
# Width of the script's browser page (the height stays as set above). Narrower means less
# to draw; 600 keeps X's normal layout (below 500 X switches to its phone layout).
VIEWPORT_WIDTH = 600
profile_locks: dict[str, threading.Lock] = {}
profile_locks_guard = threading.Lock()


def profile_key(auth_token: str) -> str:
    """Folder name for an account's browser profile. Derived from the token, never the token itself."""
    return hashlib.sha256((auth_token or "").encode("utf-8")).hexdigest()[:24]


def profile_lock(key: str) -> threading.Lock:
    with profile_locks_guard:
        lock = profile_locks.get(key)
        if lock is None:
            lock = threading.Lock()
            profile_locks[key] = lock
        return lock


# On Android, in Termux: the browser is Termux's own Chromium, and Playwright's driver runs on Termux's
# Node (the Node that comes with Playwright is built for desktop Linux and does not run on Android).
# The driver also works out where browsers would be downloaded as soon as it starts, and it does not
# know Android ("Unsupported platform: android"): it is given that folder, so it never asks.
TERMUX_PREFIX = os.getenv("PREFIX", "") if "/com.termux/" in os.getenv("PREFIX", "") else ""
if TERMUX_PREFIX:
    if not os.getenv("PLAYWRIGHT_NODEJS_PATH") and Path(TERMUX_PREFIX, "bin", "node").is_file():
        os.environ["PLAYWRIGHT_NODEJS_PATH"] = str(Path(TERMUX_PREFIX, "bin", "node"))
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(Path.home() / ".cache" / "ms-playwright"))


# A copy on its own (see on_its_own) opens the full Chromium in its new headless mode (the "chromium" channel),
# not Playwright's lighter headless browser; the owner's main copy and users' copies keep the light one. It needs
# Playwright 1.49 or newer and the browser installed with what it needs from the system (python -m playwright
# install --with-deps chromium). Where it cannot be opened, the light browser is used as before, with one message on
# how to install it, and it is not asked again.
OWN_COPY_CHANNEL = "chromium"
channel_unavailable: list[str] = []


def browser_launch_options() -> dict:
    """The browser's switches, on Termux where its Chromium is, and on a copy on its own the full Chromium
    (OWN_COPY_CHANNEL). GG_CHROMIUM_ARGS adds switches (e.g. "--single-process" if Android keeps stopping the
    browser's helper processes)."""
    options: dict = {}
    args = ["--disable-blink-features=AutomationControlled", "--disable-dev-shm-usage", "--no-sandbox"]
    if TERMUX_PREFIX:
        for candidate in (Path(TERMUX_PREFIX, "lib", "chromium", "chrome"), Path(TERMUX_PREFIX, "bin", "chromium-browser")):
            if candidate.is_file():
                options["executable_path"] = str(candidate)
                break
        args.append("--disable-gpu")
    elif OWN_COPY_CHANNEL and on_its_own() and not channel_unavailable:
        options["channel"] = OWN_COPY_CHANNEL
    options["args"] = args + os.getenv("GG_CHROMIUM_ARGS", "").split()
    return options


def channel_not_installed(exc: Exception) -> bool:
    """Whether the full Chromium could not be opened only because it is not ready here: not installed, missing
    something it needs from the system, or a Playwright too old for the channel."""
    text = str(exc).lower()
    return any(part in text for part in ("executable doesn't exist", "unsupported chromium channel", "is not found at",
                                         "distribution 'chromium'", "missing dependencies",
                                         "error while loading shared libraries"))


def open_x_profile(playwright, auth_token: str, profile_dir: Path, user_agent: str = "", viewport: dict | None = None):
    """Open the account's permanent browser profile (created on first use)."""
    profile_dir.mkdir(parents=True, exist_ok=True)
    options = browser_launch_options()
    settings = dict(
        headless=True,
        viewport=viewport or screen_size(NORMAL_VIEWPORT_HEIGHT),
        user_agent=user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        ),
        locale="en-US",
    )
    try:
        context = playwright.chromium.launch_persistent_context(str(profile_dir), **options, **settings)
    except Exception as exc:
        if "channel" not in options or not channel_not_installed(exc):
            raise
        first = not channel_unavailable
        channel_unavailable.append((str(exc).strip().splitlines() or [type(exc).__name__])[0][:200])
        if first:
            print("⚠️ متصفح Chromium الكامل لا يعمل هنا (غير مثبّت، أو تنقصه مكتبات من النظام، أو Playwright أقدم من 1.49)، "
                  "فيُفتح المتصفح الخفيف كما كان. للتثبيت: python -m pip install -U playwright "
                  "ثم python -m playwright install --with-deps chromium", flush=True)
            print(f"   ({channel_unavailable[0]})", flush=True)
        options.pop("channel", None)
        context = playwright.chromium.launch_persistent_context(str(profile_dir), **options, **settings)
    context.add_init_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    block_media(context)
    if auth_token:
        context.add_cookies([{
            "name": "auth_token",
            "value": auth_token,
            "domain": ".x.com",
            "path": "/",
            "httpOnly": True,
            "secure": True,
            "sameSite": "Lax",
        }])
    page = context.pages[0] if context.pages else context.new_page()
    for extra in context.pages[1:]:
        try:
            extra.close()
        except Exception:
            pass
    page.set_default_timeout(20_000)
    page.set_default_navigation_timeout(60_000)
    return context, page


_login_jobs: queue.Queue = queue.Queue()
_login_state: dict = {}
_login_worker_started = False
_login_worker_guard = threading.Lock()
_MANUAL_LOGIN_AGENT = (
    "Mozilla/5.0 (Linux; Android 14; SM-G998U) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
)


def _login_worker() -> None:
    while True:
        fn, box = _login_jobs.get()
        try:
            box["result"] = fn()
        except Exception as exc:
            box["error"] = exc
        finally:
            box["done"].set()


def _ensure_login_worker() -> None:
    global _login_worker_started
    with _login_worker_guard:
        if _login_worker_started:
            return
        threading.Thread(target=_login_worker, name="manual-login", daemon=True).start()
        _login_worker_started = True


def _on_login_thread(fn, timeout: float = 90):
    _ensure_login_worker()
    box: dict = {"done": threading.Event()}
    _login_jobs.put((fn, box))
    if not box["done"].wait(timeout):
        raise TimeoutError("manual login")
    if box.get("error") is not None:
        raise box["error"]
    return box.get("result")


def _show_manual_browser() -> None:
    if not IN_APP:
        return
    show_account_browser(str(_login_state.get("folder") or MANUAL_BROWSER))
    _prepare_manual_browser()


def _prepare_manual_browser() -> None:
    """The app shows «المتصفح», and lets the user type in it."""
    from java import jclass
    jclass("app.tg.groups.BrowserHost").prepareManualLogin()


# «المتصفح» in the app shows one browser: the one of the account the panel shows (the other accounts' browsers
# keep working behind it), or the sign-in browser while an account signs in.
_shown_browser: dict = {"folder": None}


def show_account_browser(folder: str) -> None:
    """«المتصفح» shows this browser (a profile folder; "" when the panel shows no account)."""
    if not IN_APP or _shown_browser["folder"] == folder:
        return
    _shown_browser["folder"] = folder
    try:
        from java import jclass
        jclass("app.tg.groups.BrowserHost").showAccount(folder or "")
    except Exception:
        pass


def show_active_browser() -> None:
    """«المتصفح» follows the panel: the browser of the account it shows; while a new account is added (no account
    shown), the sign-in browser; else none."""
    token = active_token
    if valid_auth_token(token):
        show_account_browser(manual_profile_folder(token))
    elif _login_page_open():
        show_account_browser(str(_login_state.get("folder") or MANUAL_BROWSER))
    else:
        show_account_browser("")


def _login_page_open() -> bool:
    page = _login_state.get("page")
    if page is None:
        return False
    try:
        return not page.is_closed()
    except Exception:
        return False


def _page_open(page) -> bool:
    if page is None:
        return False
    try:
        return not page.is_closed()
    except Exception:
        return False


# The manual browser stays open between tasks, so the unlocked chat and its keys are not thrown away.
# Each account signed in by hand keeps its own browser open between its tasks (one per profile folder, never
# shared): its next task goes on in the same page, with its chat already unlocked.
_task_browsers: dict[str, dict] = {}
_task_browsers_lock = threading.Lock()


def _kept_browser(folder: str) -> dict | None:
    with _task_browsers_lock:
        kept = _task_browsers.get(folder)
    return kept if kept and _page_open(kept.get("page")) else None


def _close_browser_parts(context, playwright) -> None:
    if context is not None:
        try:
            context.close()
        except Exception:
            pass
    if playwright is not None:
        try:
            playwright.stop()
        except Exception:
            pass


def _drop_task_browser(folder: str | None = None) -> None:
    """Close the browser kept open for this profile folder (every kept one when None). Its profile stays."""
    with _task_browsers_lock:
        if folder is None:
            dropped = list(_task_browsers.values())
            _task_browsers.clear()
        else:
            one = _task_browsers.pop(folder, None)
            dropped = [one] if one else []
    for kept in dropped:
        _close_browser_parts(kept.get("context"), kept.get("playwright"))


# In the app, an account's browser kept open with nothing to do is closed after this long (its session stays,
# and its next task opens it again in a few seconds): an idle page of X still uses the processor and battery.
KEPT_BROWSER_IDLE_SECONDS = 600


def close_idle_browsers_once(now: float | None = None) -> list[str]:
    """Close the kept browsers idle for KEPT_BROWSER_IDLE_SECONDS or more. Returns their profile folders."""
    now = time.monotonic() if now is None else now
    with _task_browsers_lock:
        idle = [folder for folder, kept in _task_browsers.items()
                if kept.get("idle_since") is not None and now - kept["idle_since"] >= KEPT_BROWSER_IDLE_SECONDS]
    closed = []
    for folder in idle:
        lock = profile_lock(folder)
        if not lock.acquire(blocking=False):          # (a task of the account has it now)
            continue
        try:
            with _task_browsers_lock:
                kept = _task_browsers.get(folder)
                due = bool(kept) and kept.get("idle_since") is not None and now - kept["idle_since"] >= KEPT_BROWSER_IDLE_SECONDS
                account = str((kept or {}).get("account") or "")
            if due:
                _drop_task_browser(folder)
                closed.append(folder)
                with as_account(account):
                    trace_click(f"أُغلق متصفح هذا الحساب بعد {KEPT_BROWSER_IDLE_SECONDS // 60} دقائق بلا مهمة (جلسته محفوظة).")
        finally:
            lock.release()
    return closed


def close_idle_browsers_in_background() -> None:
    while True:
        time.sleep(30)
        try:
            close_idle_browsers_once()
        except Exception:
            pass


def _drop_idle_task_browsers() -> None:
    """Close the kept browsers no task is using now (so a new sign-in has room for its own browser)."""
    with _task_browsers_lock:
        folders = list(_task_browsers)
    for folder in folders:
        lock = profile_lock(folder)
        if lock.acquire(blocking=False):
            try:
                _drop_task_browser(folder)
            finally:
                lock.release()


def _open_login_browser() -> str:
    """«تسجيل الدخول». With no account shown (a new account is being added): a new browser with a profile of its
    own (data/profiles/login-…), kept open so «تحقق» can read its session; then it is that account's own
    browser, for its tasks and everything else. With an account shown: that account's own browser, not a new
    sign-in (shown as it is when it is open or in a task; opened on X otherwise, where it is signed in, or
    signs in again if its session ended). Returns what the panel says."""
    token = active_token
    shown = valid_auth_token(token)
    if shown:
        folder = manual_profile_folder(token)
        if _kept_browser(folder) is not None or profile_lock(folder).locked():
            show_account_browser(folder)
            _prepare_manual_browser()
            return "متصفح هذا الحساب مفتوح في تبويب «المتصفح»."
        if _login_page_open() and str(_login_state.get("folder") or MANUAL_BROWSER) != folder:
            _close_login_browser()           # (a sign-in begun for a new account is left for this one)
    else:
        folder = "login-" + secrets.token_hex(6)
    if not _login_page_open():
        with _task_browsers_lock:
            crowded = len(_task_browsers) >= MAX_ACCOUNTS
        if crowded:
            _drop_idle_task_browsers()
        playwright = sync_playwright().start()
        context, page = open_x_profile(
            playwright, token if shown else "", PROFILES_DIR / folder,
            user_agent=_MANUAL_LOGIN_AGENT, viewport={"width": 412, "height": 820},
        )
        allow_media(page)
        _login_state.update(playwright=playwright, context=context, page=page, folder=folder)
    page = _login_state["page"]
    _show_manual_browser()
    page.goto("https://x.com/i/flow/login", wait_until="domcontentloaded", timeout=60_000)
    _show_manual_browser()
    if shown:
        return "فُتح متصفح هذا الحساب في تبويب «المتصفح». إن ظهرت صفحة تسجيل الدخول فجلسته انتهت: سجّل الدخول ثم اضغط تحقق."
    return "سجّل الدخول في تبويب المتصفح، ثم ارجع إلى اللوحة واضغط تحقق."


def start_manual_login() -> str:
    return str(_on_login_thread(_open_login_browser) or "")


def _read_login_token() -> tuple[str, str]:
    """The session the sign-in browser holds, and that browser's profile folder."""
    if not _login_page_open():
        return "", ""
    folder = str(_login_state.get("folder") or MANUAL_BROWSER)
    try:
        cookies = _login_state["page"].context.cookies(["https://x.com", "https://twitter.com"])
    except Exception:
        return "", folder
    for cookie in cookies:
        if cookie.get("name") == "auth_token" and cookie.get("value"):
            return str(cookie["value"]), folder
    return "", folder


def manual_login_token() -> str:
    if not _login_worker_started:
        return ""
    try:
        token, folder = _on_login_thread(_read_login_token, timeout=20) or ("", "")
        token = str(token or "")
    except Exception:
        return ""
    if valid_auth_token(token):
        remember_manual_profile(token, folder or MANUAL_BROWSER)
    return token


def _close_login_browser() -> None:
    """Close the login window without deleting its profile, so a task can open that same browser."""
    context = _login_state.pop("context", None)
    playwright = _login_state.pop("playwright", None)
    _login_state.pop("page", None)
    _login_state.pop("folder", None)
    if context is not None:
        try:
            context.close()
        except Exception:
            pass
    if playwright is not None:
        try:
            playwright.stop()
        except Exception:
            pass


def release_manual_browser() -> None:
    if not _login_worker_started:
        return
    try:
        _on_login_thread(_close_login_browser, timeout=20)
    except Exception:
        pass
    show_active_browser()


MANUAL_BROWSER = "manual-login"
MANUAL_PROFILES_PATH = DATA_DIR / "manual_profiles.json"
_manual_profiles_lock = threading.Lock()


def _load_manual_profiles() -> dict:
    try:
        data = json.loads(MANUAL_PROFILES_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def remember_manual_profile(auth_token: str, folder: str = MANUAL_BROWSER) -> None:
    """This account signed in by hand in this browser (profile folder): from now on it is the account's own
    browser for everything. A browser belongs to one account only; the account's browser from before (an
    earlier sign-in, or the one its token alone opened) is no one's any more, so it goes."""
    key = profile_key(auth_token)
    with _manual_profiles_lock:
        saved = _load_manual_profiles()
        before = str(saved.get(key) or key)
        saved = {name: owned for name, owned in saved.items() if owned != folder}
        saved[key] = folder
        MANUAL_PROFILES_PATH.parent.mkdir(parents=True, exist_ok=True)
        MANUAL_PROFILES_PATH.write_text(json.dumps(saved), encoding="utf-8")
        still_used = set(saved.values())
    if before != folder and before not in still_used:
        discard_profile_folder(before)


def discard_profile_folder(folder: str) -> None:
    """Remove a browser profile no account uses any more (its folder, and in the app its WebView profile)."""
    if not folder or "/" in folder or folder in (".", ".."):
        return
    lock = profile_lock(folder)
    if not lock.acquire(timeout=5):
        return
    try:
        _drop_task_browser(folder)
        shutil.rmtree(PROFILES_DIR / folder, ignore_errors=True)
        if IN_APP:
            try:
                from java import jclass
                jclass("app.tg.groups.BrowserHost").deleteProfile(folder)
            except Exception:
                pass
    finally:
        lock.release()


def manual_profile_folder(auth_token: str) -> str:
    key = profile_key(auth_token)
    with _manual_profiles_lock:
        saved = _load_manual_profiles()
    return str(saved.get(key) or key)


def forget_manual_profile(auth_token: str) -> None:
    key = profile_key(auth_token)
    with _manual_profiles_lock:
        saved = _load_manual_profiles()
        if key not in saved:
            return
        del saved[key]
        MANUAL_PROFILES_PATH.write_text(json.dumps(saved), encoding="utf-8")


# The running task's "close and reopen the browser" function (one per worker thread).
browser_restart = threading.local()

# Live view of a task's browser (its card no longer offers it; kept for the view endpoint). Pictures are taken in the task's own
# thread during its waits, and only while someone is watching.
LIVE_VIEW_EVERY = 0.25
live_task = threading.local()
live_views: dict[str, dict] = {}
live_views_lock = threading.Lock()
_page_wait_for_timeout = Page.wait_for_timeout


def capture_live_view(page, job_id: str) -> bool:
    """Take the task's next picture when one is due. Returns whether someone is watching."""
    now = time.monotonic()
    with live_views_lock:
        view = live_views.get(job_id)
        if not view or view["wanted_until"] < now:
            return False
        if now - view["taken_at"] < LIVE_VIEW_EVERY:
            return True
        view["taken_at"] = now
    try:
        size = page.viewport_size or {"width": VIEWPORT_WIDTH, "height": NORMAL_VIEWPORT_HEIGHT}
        image = page.screenshot(type="jpeg", quality=40, timeout=3000,
                                clip={"x": 0, "y": 0, "width": size["width"], "height": min(size["height"], 1000)})
    except Exception:
        return True
    with live_views_lock:
        # An unchanged page gives the same picture: keep the old one so nothing is sent again.
        if image != view["image"]:
            view["image"] = image
            view["seq"] += 1
    return True


def wait_and_watch(page, timeout: float) -> None:
    """page.wait_for_timeout for every page: in a task's thread it also feeds that task's live view."""
    job_id = getattr(live_task, "job_id", "")
    if not job_id:
        return _page_wait_for_timeout(page, timeout)
    end = time.monotonic() + max(0.0, timeout) / 1000
    while True:
        watched = capture_live_view(page, job_id)
        left = end - time.monotonic()
        if left <= 0:
            return
        # Watched: wake up for every picture. Otherwise once a second, to notice a new viewer.
        _page_wait_for_timeout(page, min(left, LIVE_VIEW_EVERY if watched else 1.0) * 1000)


Page.wait_for_timeout = wait_and_watch


def restart_browser(while_closed=None):
    fn = getattr(browser_restart, "fn", None)
    return fn(while_closed) if fn else None




def acquire_profile_slot(key: str) -> str:
    """Take the account's browser profile (data/profiles/<key>), waiting while a task is using it."""
    profile_lock(key).acquire()
    return key


def app_task_running(on: bool) -> None:
    """In the app: tell it a task is working (or has ended). While one works, the app keeps working in the
    background even when the task's browser is closed for a moment (the pause after tweets would not open),
    so the browser opened after the pause goes on without waiting for the app to come back to the screen."""
    if not IN_APP:
        return
    try:
        from java import jclass
        jclass("app.tg.groups.BrowserHost").taskRunning(bool(on))
    except Exception:
        pass


def run_on_fresh_browser(auth_token: str, work):
    """Do one piece of work in the account's own browser, as that account's work (its log, its groups…).
    While it works the app keeps working in the background; a browser left open with nothing to do does not."""
    with as_account(profile_key(auth_token)):
        app_task_running(True)
        try:
            return _run_on_account_browser(auth_token, work)
        finally:
            app_task_running(False)


def _run_on_account_browser(auth_token: str, work):
    """Open the account's own browser profile for one piece of work.

    An account signed in by hand has its own browser, the one it signed in with: it stays open after the
    work, and its next task goes on in that same page. An account given by its token alone has a browser of
    its own too (data/profiles/<its key>), closed when its work ends. No two accounts share a browser.
    """
    folder = manual_profile_folder(auth_token)
    signed_by_hand = folder == MANUAL_BROWSER or folder.startswith("login-")
    if _login_state.get("page") is not None and str(_login_state.get("folder") or MANUAL_BROWSER) == folder:
        release_manual_browser()            # (its sign-in window closes: the same browser opens for the work)
    slot_name = acquire_profile_slot(folder)
    same_browser = signed_by_hand
    try:
        state = {"context": None, "playwright": None}

        def keep(page) -> None:
            with _task_browsers_lock:
                _task_browsers[slot_name] = {"playwright": state["playwright"], "context": state["context"], "page": page,
                                             "account": profile_key(auth_token), "idle_since": None}

        def open_saved(target):
            if same_browser:
                trace_click("التنفيذ على متصفح هذا الحساب الذي سُجّل الدخول إليه")
                return open_x_profile(
                    target, auth_token, PROFILES_DIR / slot_name,
                    user_agent=_MANUAL_LOGIN_AGENT, viewport={"width": 412, "height": 820},
                )
            return open_x_profile(target, auth_token, PROFILES_DIR / slot_name)

        def restart(while_closed=None):
            """Close the profile's browser, reopen it on Google, then go to X. Returns the new page.
            while_closed runs with the browser closed; when it returns False the browser stays
            closed and None is returned."""
            try:
                if state["context"] is not None:
                    state["context"].close()
            except Exception:
                pass
            state["context"] = None
            with _task_browsers_lock:
                _task_browsers.pop(slot_name, None)
            if while_closed is not None and while_closed() is False:
                return None
            if state["playwright"] is None:
                state["playwright"] = sync_playwright().start()
            state["context"], new_page = open_saved(state["playwright"])
            try:
                new_page.goto("https://www.google.com/", wait_until="domcontentloaded", timeout=60_000)
                new_page.wait_for_timeout(2000)
            except Exception:
                pass
            try:
                goto_x(new_page, "https://x.com/home")
                session_is_logged_in(new_page)
            except Exception:
                pass
            if same_browser:
                keep(new_page)
            return new_page

        browser_restart.fn = restart
        try:
            kept = _kept_browser(slot_name) if same_browser else None
            if kept:
                with _task_browsers_lock:
                    kept["idle_since"] = None             # (working again)
                trace_click("المهمة على صفحة متصفح هذا الحساب المفتوحة")
                state["context"] = kept.get("context")
                state["playwright"] = kept.get("playwright")
                return work(kept["page"])
            state["playwright"] = sync_playwright().start()
            state["context"], page = open_saved(state["playwright"])
            if same_browser:
                keep(page)
            return work(page)
        finally:
            browser_restart.fn = None
            still_open = _kept_browser(slot_name) if same_browser else None
            if still_open:
                with _task_browsers_lock:
                    still_open["idle_since"] = time.monotonic()
                trace_click(f"بقيت صفحة هذا الحساب مفتوحة لمهمته التالية (تُغلق بعد {KEPT_BROWSER_IDLE_SECONDS // 60} دقائق بلا مهمة)")
            elif same_browser:
                _drop_task_browser(slot_name)
            else:
                _close_browser_parts(state["context"], state["playwright"])
    finally:
        profile_lock(slot_name).release()


def screen_size(height: int) -> dict:
    """The size asked of a new browser (in the app the browser keeps the phone's own screen)."""
    return {"width": VIEWPORT_WIDTH, "height": int(height)}


def delete_profile(auth_token: str) -> None:
    """The account is removed: its browsers (profiles) go with it."""
    key = profile_key(auth_token)
    folder = manual_profile_folder(auth_token)
    forget_manual_profile(auth_token)
    for name in {key, folder}:
        discard_profile_folder(name)
        for extra in PROFILES_DIR.glob(f"{name}-*"):
            shutil.rmtree(extra, ignore_errors=True)



def run_on_browser(auth_token: str, work):
    """Every action gets its own browser, closed as soon as the action ends."""
    return run_on_fresh_browser(auth_token, work)


def goto_x(page, url: str) -> None:
    """page.goto for X pages. X sometimes answers with a file instead of the page (Playwright:
    "Download is starting"): ask again, and after two such answers ask past the browser's cache
    and X's service worker for that one load (nothing is deleted)."""
    for attempt in range(4):
        cdp = None
        try:
            if attempt >= 2:
                cdp = page.context.new_cdp_session(page)
                cdp.send("Network.enable")
                cdp.send("Network.setBypassServiceWorker", {"bypass": True})
                cdp.send("Network.setCacheDisabled", {"cacheDisabled": True})
            page.goto(url, wait_until="domcontentloaded", timeout=60_000)
            return
        except Exception as exc:
            if "Download is starting" not in str(exc):
                raise
            if attempt == 3:
                raise RuntimeError("أرسل X ملفًا بدل الصفحة أكثر من مرة. أعد المحاولة بعد قليل.") from exc
        finally:
            if cdp is not None:
                try:
                    cdp.send("Network.setBypassServiceWorker", {"bypass": False})
                    cdp.send("Network.setCacheDisabled", {"cacheDisabled": False})
                    cdp.detach()
                except Exception:
                    pass
        page.wait_for_timeout(1500)


# The session, checked on X's settings list (a light page: no timeline). X sends a signed-out session to its
# sign-in page at once; a signed-in one gets the list, with its @name within a few seconds. A few seconds,
# against 5 to 15 for x.com/home and the wait for its account button. (X's internal API is not asked: it
# refuses requests that do not come from its own web app.)
SESSION_PROBE_SECONDS = 6
SIGN_IN_URL = re.compile(r"/i/flow/(?:login|signup)|/i/jf/onboarding|/login(?:[/?#]|$)")
SIGNED_OUT_JS = """() => !!document.querySelector('a[href*="/i/flow/login"], a[href*="/i/flow/signup"], [data-testid="loginButton"], [data-testid="signupButton"]')"""


def probe_session(page) -> tuple[str, str]:
    """("in", @name) signed in · ("out", "") X sent the session to sign in · ("unknown", "") neither showed in
    SESSION_PROBE_SECONDS (the session is then checked the usual way)."""
    try:
        goto_x(page, SETTINGS_URL)
    except Exception:
        return "unknown", ""
    deadline = time.monotonic() + SESSION_PROBE_SECONDS
    while True:
        url = page.url or ""
        if SIGN_IN_URL.search(url):
            trace_click("الجلسة: X أحالها إلى تسجيل الدخول")
            return "out", ""
        try:
            if page.evaluate(SIGNED_OUT_JS):
                trace_click("الجلسة: صفحة X تعرض تسجيل الدخول")
                return "out", ""
        except Exception:
            pass
        try:
            name = str(page.evaluate(SETTINGS_NAME_JS) or "").strip().lstrip("@")
        except Exception:
            name = ""
        if re.fullmatch(r"[A-Za-z0-9_]{1,15}", name):
            trace_click(f"الجلسة من قائمة الإعدادات: @{name}")
            return "in", name
        if time.monotonic() >= deadline:
            trace_click("الجلسة: لم تتبيّن من قائمة الإعدادات في الوقت؛ تُفحص بالطريقة المعتادة")
            return "unknown", ""
        page.wait_for_timeout(300)


def ensure_logged_in(page) -> bool:
    """Whether the browser's session is signed in: from the page it is on when it shows the account, else asked
    of X directly (probe_session), and only when that gives no answer by opening x.com/home."""
    probe = page.locator(
        'button[aria-label="Account menu"], '
        '[data-testid="SideNav_AccountSwitcher_Button"], '
        'a[data-testid="AppTabBar_Profile_Link"], '
        # X's phone layout (narrow screens) has no side menu: its avatar button and the Home tab.
        '[data-testid="DashButton_ProfileIcon_Link"], '
        'a[data-testid="AppTabBar_Home_Link"]'
    )
    try:
        if "x.com" in (page.url or "") and probe.first.is_visible(timeout=1500):
            return True
    except Exception:
        pass
    status, name = probe_session(page)
    if status == "in":
        page._session_name = name          # (read_session_username gives it back without a page to read it from)
        return True
    if status == "out":
        return False
    goto_x(page, "https://x.com/home")
    return session_is_logged_in(page)


def session_is_logged_in(page) -> bool:
    try:
        page.locator(
            'button[aria-label="Account menu"], '
            '[data-testid="SideNav_AccountSwitcher_Button"], '
            'a[data-testid="AppTabBar_Profile_Link"], '
            # X's phone layout (narrow screens) has no side menu: its avatar button and the Home tab.
            '[data-testid="DashButton_ProfileIcon_Link"], '
            'a[data-testid="AppTabBar_Home_Link"]'
        ).first.wait_for(state="visible", timeout=20_000)
        return True
    except PlaywrightTimeoutError:
        return False


def read_session_username(page) -> str:
    """The logged-in handle. The phone has no side menu, so the desktop profile link is
    often missing; the avatar button and the session itself still carry the name."""
    try:
        handle = page.evaluate(
            """async () => {
              const reserved = new Set(["home","explore","search","settings","messages","notifications","i","compose","unknown","undefined","null","none","user","profile","guest"]);
              const clean = (value) => {
                const name = String(value || "").trim().replace(/^@/, "");
                if (!/^[A-Za-z0-9_]{1,15}$/.test(name) || reserved.has(name.toLowerCase())) return "";
                return name;
              };
              const fromHref = (node) => {
                if (!node) return "";
                const match = (node.getAttribute("href") || "").match(/^\\/([A-Za-z0-9_]{1,15})\\/?$/);
                return match ? clean(match[1]) : "";
              };
              const fromAvatar = (node) => {
                if (!node) return "";
                const tagged = node.getAttribute && (node.getAttribute("data-testid") || "").startsWith("UserAvatar-Container-")
                  ? node
                  : node.querySelector('[data-testid^="UserAvatar-Container-"]');
                if (!tagged) return "";
                return clean((tagged.getAttribute("data-testid") || "").slice("UserAvatar-Container-".length));
              };
              const profile = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
              const dash = document.querySelector('[data-testid="DashButton_ProfileIcon_Link"]');
              const visible = fromHref(profile) || fromAvatar(profile) || fromHref(dash) || fromAvatar(dash);
              if (visible) return {name: visible, source: "page"};
              const nodes = document.querySelectorAll('[data-testid="SideNav_AccountSwitcher_Button"], [data-testid="UserName"], [data-testid="DashButton_ProfileIcon_Link"]');
              for (const node of nodes) {
                const match = ((node.innerText || node.textContent || "")).match(/@([A-Za-z0-9_]{1,15})/);
                if (match && clean(match[1])) return {name: match[1], source: "text"};
              }
              const dig = (value, depth, seen) => {
                if (!value || depth > 8 || typeof value !== "object") return "";
                if (seen.has(value)) return "";
                seen.add(value);
                const direct = clean(value.screen_name || value.screenName || "");
                if (direct) return direct;
                for (const key of ["legacy", "core", "user", "viewer", "result", "data", "next", "memoizedState"]) {
                  if (value[key]) {
                    const found = dig(value[key], depth + 1, seen);
                    if (found) return found;
                  }
                }
                return "";
              };
              const root = dash || profile;
              if (root) {
                const fiberKey = Object.keys(root).find((key) => key.startsWith("__reactFiber$"));
                let fiber = fiberKey ? root[fiberKey] : null;
                for (let step = 0; fiber && step < 40; step++, fiber = fiber.return) {
                  const found = dig(fiber.memoizedProps, 0, new Set()) || dig(fiber.memoizedState, 0, new Set());
                  if (found) return {name: found, source: "account"};
                }
              }
              return {name: "", source: "empty"};
            }"""
        ) or {}
    except Exception as exc:
        handle = ""
        trace_click("قراءة الاسم فشلت: " + type(exc).__name__)
    else:
        if isinstance(handle, dict):
            trace_click(f"قراءة الاسم {handle}")
            handle = str(handle.get("name") or "")
        else:
            handle = str(handle or "")
    handle = handle.strip().lstrip("@")
    if handle.lower() in {"unknown", "undefined", "null", "none", "user"}:
        handle = ""
    if re.fullmatch(r"[A-Za-z0-9_]{1,15}", handle):
        return handle
    try:
        if "settings" not in (page.url or ""):
            goto_x(page, SETTINGS_URL)
        found = read_settings_username(page, 6)
        trace_click(f"قراءة الاسم من الإعدادات: {found or 'فارغ'}")
        if found:
            return found
    except Exception as exc:
        trace_click("قراءة الاسم من الإعدادات فشلت: " + type(exc).__name__)
    return str(getattr(page, "_session_name", "") or "")


SETTINGS_URL = "https://x.com/settings/account"


SETTINGS_NAME_JS = """() => {
      const reserved = new Set(["home","explore","search","settings","messages","notifications","i","compose","unknown","undefined","null","none","user","profile","guest","account","premium"]);
      const clean = (value) => {
        const name = String(value || "").trim().replace(/^@/, "");
        if (!/^[A-Za-z0-9_]{1,15}$/.test(name) || reserved.has(name.toLowerCase())) return "";
        return name;
      };
      const text = (document.body && document.body.innerText) || "";
      const match = text.match(/@([A-Za-z0-9_]{1,15})/);
      return match ? clean(match[1]) : "";
    }"""


def read_settings_username(page, wait_s: float = 6.0) -> str:
    """The @handle shown under «الإعدادات». Empty when the page is not the settings list."""
    script = SETTINGS_NAME_JS
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        url = page.url or ""
        if "/login" in url or "/i/flow" in url:
            return ""
        try:
            found = str(page.evaluate(script) or "").strip().lstrip("@")
        except Exception:
            found = ""
        if re.fullmatch(r"[A-Za-z0-9_]{1,15}", found):
            return found
        page.wait_for_timeout(300)
    return ""


def verify_x_login(auth_token: str) -> tuple[bool, str]:
    """«تحقق»: the session from X's settings list (probe_session, given more time when it is slow). The handle
    under «الإعدادات» is the session."""
    def work(page):
        status, name = probe_session(page)
        if status == "in":
            return True, name
        if status == "out":
            return False, ""
        username = read_settings_username(page)      # (the page is the settings list already: given more time)
        url = page.url or ""
        logged_in = bool(username) and "/login" not in url and "/i/flow" not in url
        trace_click(f"التحقق من الإعدادات: {username or 'غير معروف'}")
        return logged_in, username
    return run_on_browser(auth_token, work)


def valid_chat_pin(value: str) -> bool:
    return bool(re.fullmatch(r"\d{4,8}", (value or "").strip()))


def chat_body_text(page) -> str:
    try:
        return page.evaluate("() => (document.body && document.body.innerText || '').slice(0, 4000)") or ""
    except Exception:
        return ""


def pin_error_message(page) -> str | None:
    text = chat_body_text(page)
    if re.search(r"too many attempts|attempt limit|permanently", text, re.I):
        return "توقفت المحاولات عند X. لا تُعد إدخال الرمز."
    if re.search(r"incorrect pin|wrong pin|invalid pin|رمز.{0,16}غير صحيح", text, re.I):
        return "رمز الدردشة غير صحيح."
    return None


def pin_fields(page):
    locator = page.locator("input[type='password']:visible, input[type='tel']:visible, input[inputmode='numeric']:visible")
    boxes = []
    for index in range(min(locator.count(), 8)):
        box = locator.nth(index)
        try:
            if box.is_visible():
                boxes.append(box)
        except Exception:
            continue
    return boxes


def type_pin_once(page, pin: str) -> None:
    boxes = pin_fields(page)
    if not boxes:
        raise RuntimeError("ظهرت شاشة الرمز دون حقل يمكن الكتابة فيه.")
    if len(boxes) >= len(pin):
        for box, digit in zip(boxes, pin):
            box.click(timeout=4000)
            page.keyboard.type(digit, delay=70)
    else:
        boxes[0].click(timeout=4000)
        page.keyboard.type(pin, delay=70)
    page.wait_for_timeout(1200)


def chat_inbox_open(page) -> bool:
    if "pin" in (page.url or ""):
        return False
    try:
        return page.locator('[data-testid^="dm-conversation-item-"]').count() > 0
    except Exception:
        return False


def open_chat(page, pin: str) -> str | None:
    if chat_inbox_open(page):
        return None
    goto_x(page, CHAT_URLS[0])
    typed = False
    deadline = time.monotonic() + 55
    while time.monotonic() < deadline:
        accept_cookies(page)
        if page.locator('[data-testid^="dm-conversation-item-"]').count():
            return None
        if not typed and "pin" in (page.url or ""):
            if pin_fields(page):
                type_pin_once(page, pin)
                typed = True
                error = pin_error_message(page)
                if error:
                    return error
        page.wait_for_timeout(700)
    if page.locator('[data-testid="dm-inbox-panel"]').count():
        return None
    return pin_error_message(page) or "تعذّر فتح الدردشة بعد إدخال الرمز."


def choose_inbox_filter(page, testid: str, label: str) -> None:
    trigger = page.locator('[data-testid="dm-inbox-dropdown-trigger"]')
    try:
        trigger.first.wait_for(state="visible", timeout=8_000)
        trigger.first.click(timeout=5000)
        page.wait_for_timeout(400)
    except Exception:
        return
    item = page.locator(f'[data-testid="{testid}"]')
    if item.count() == 0:
        item = page.get_by_role("menuitem", name=re.compile(label, re.I))
    if item.count() == 0:
        try:
            page.keyboard.press("Escape")
        except Exception:
            pass
        return
    try:
        item.first.click(timeout=5000)
    except Exception:
        return
    page.wait_for_timeout(500)
    try:
        page.keyboard.press("Escape")
    except Exception:
        pass


def show_groups_only(page) -> None:
    choose_inbox_filter(page, "dm-inbox-dropdown-groups", r"groups|قروب|مجموع")


GROUP_IDS_PATH = DATA_DIR / "group_ids.json"     # (the program's own work only; each account has its own file)
group_ids_lock = threading.RLock()
# Each account's groups, in its own file (data/accounts/<key>/group_ids.json): the id of each group, and its
# conversation link (…/messages/<id> or …/i/chat/<id>), so a task can open the group by going straight to
# it. Two accounts never see each other's groups, even ones with the same name.
_group_stores: dict[str, dict] = {}


def _group_ids_path(key: str) -> Path:
    return account_dir(key) / "group_ids.json" if key else GROUP_IDS_PATH


def _group_store(key: str) -> dict:
    with group_ids_lock:
        store = _group_stores.get(key)
        if store is None:
            loaded = read_private_json(_group_ids_path(key)) or {}
            rows, paths = loaded.get("groups"), loaded.get("paths")
            store = {
                "groups": {str(k): str(v) for k, v in rows.items() if k and v} if isinstance(rows, dict) else {},
                "paths": {str(k): str(v) for k, v in paths.items() if k and v} if isinstance(paths, dict) else {},
            }
            _group_stores[key] = store
        return store


class _AccountGroupMap:
    """group_ids / group_paths: name -> value, the running account's own (see account_context)."""

    def __init__(self, field: str):
        self.field = field

    def _map(self) -> dict:
        return _group_store(current_account())[self.field]

    def get(self, name, default=None):
        return self._map().get(name, default)

    def __getitem__(self, name):
        return self._map()[name]

    def __setitem__(self, name, value):
        self._map()[name] = value

    def __contains__(self, name):
        return name in self._map()

    def __iter__(self):
        return iter(dict(self._map()))

    def __len__(self):
        return len(self._map())

    def items(self):
        return dict(self._map()).items()

    def update(self, other) -> None:
        self._map().update(other)


group_ids = _AccountGroupMap("groups")
group_paths = _AccountGroupMap("paths")


def load_group_ids() -> None:
    """(each account's groups are read from its own file the first time they are needed)"""


def save_group_ids_unlocked() -> None:
    key = current_account()
    store = _group_store(key)
    try:
        write_private_json(_group_ids_path(key), {"version": 2, "groups": dict(store["groups"]), "paths": dict(store["paths"])})
    except Exception:
        pass


def remember_group_id(name: str, testid: str) -> None:
    """Remember each group's id (it does not change when the group is renamed)."""
    with group_ids_lock:
        if group_ids.get(name) == testid:
            return
        group_ids[name] = testid
        save_group_ids_unlocked()


def remember_group_path(name: str, path: str) -> None:
    """Remember a group's conversation link, so it can be opened directly next time."""
    cleaned = (path or "").strip()
    if not cleaned or "/status/" in cleaned:
        return
    with group_ids_lock:
        if group_paths.get(name) == cleaned:
            return
        group_paths[name] = cleaned
        save_group_ids_unlocked()


GROUPS_SCROLL_PASSES_MIN = 3     # the inbox is scrolled at least this many times, whatever the first pass shows
GROUPS_SCROLL_PASSES_MAX = 24
GROUPS_SETTLE_MS = 3000          # after a scroll: how long more conversations are waited for (they come sooner, usually)
INBOX_ITEMS = '[data-testid^="dm-conversation-item-"]'


def inbox_item_count(page) -> int:
    try:
        return int(page.locator(INBOX_ITEMS).count() or 0)
    except Exception:
        return 0


def inbox_loading(page) -> bool:
    try:
        return page.locator('[data-testid="dm-inbox-panel"] [role="progressbar"]').first.is_visible(timeout=200)
    except Exception:
        return False


def wait_for_more_conversations(page, before: int, settle_ms: int = GROUPS_SETTLE_MS) -> int:
    """After a scroll of the inbox: wait for more conversations to show (up to settle_ms, longer while X is
    still loading them), then a moment for their names to be drawn. Returns how many show now."""
    deadline = time.monotonic() + settle_ms / 1000
    longest = time.monotonic() + 2 * settle_ms / 1000
    while True:
        count = inbox_item_count(page)
        if count > before:
            page.wait_for_timeout(500)
            return inbox_item_count(page)
        now = time.monotonic()
        if now >= deadline and not (inbox_loading(page) and now < longest):
            return count
        page.wait_for_timeout(300)


def collect_groups(page) -> list[str]:
    """The names of the groups in the inbox, scrolled through to its end: every pass reads what shows, scrolls,
    and waits for more to come (wait_for_more_conversations); the inbox is scrolled at least
    GROUPS_SCROLL_PASSES_MIN times, and the reading stops after three scrolls that brought nothing new."""
    found: list[str] = []
    seen: set[str] = set()
    idle = 0
    passes = 0
    for _ in range(GROUPS_SCROLL_PASSES_MAX):
        passes += 1
        try:
            payload = page.evaluate(READ_GROUPS_JS, "") or {}
        except Exception:
            payload = {}
        added = 0
        ids = payload.get("ids") or []
        paths = payload.get("paths") or []
        for index, name in enumerate(payload.get("groups") or []):
            clean = re.sub(r"\s+", " ", str(name)).strip()
            if not clean or clean in seen:
                continue
            seen.add(clean)
            found.append(clean)
            if index < len(ids) and ids[index]:
                remember_group_id(clean, str(ids[index]))
            if index < len(paths) and paths[index]:
                remember_group_path(clean, str(paths[index]))
            added += 1
        before = inbox_item_count(page)
        try:
            page.evaluate(SCROLL_INBOX_JS)
        except Exception:
            pass
        try:
            panel = page.locator('[data-testid="dm-inbox-panel"]').first
            box = panel.bounding_box()
            if box:
                page.mouse.move(box["x"] + min(box["width"] / 2, 280), box["y"] + min(box["height"] * 0.55, 420))
                page.mouse.wheel(0, 700)
        except Exception:
            pass
        after = wait_for_more_conversations(page, before)
        trace_click(f"القروبات: تمرير {passes}، ظهر {after} محادثة (كانت {before})، أسماء جديدة {added}")
        if added or after > before:
            idle = 0
            continue
        idle += 1
        if passes >= GROUPS_SCROLL_PASSES_MIN and ((found and idle >= 3) or idle >= 8):
            break
    return found


# A group's conversation view, once its page has loaded.
GROUP_VIEW_SELECTOR = '[data-testid="dm-message-list"], [data-testid="dm-message-scroller"], [data-testid="dm-conversation-content"]'


def conversation_key(url: str) -> str:
    """The conversation id in a chat link (…/i/chat/<id> or …/messages/<id>): its digits when it has
    any (so "g123" and "123" are the same group), else the id itself. "" for any other page."""
    match = re.search(r"/(?:i/chat|messages)/([^/?#\s]+)", url or "")
    if not match:
        return ""
    raw = match.group(1)
    if raw.lower() in ("pin", "compose", "requests", "settings"):
        return ""
    return re.sub(r"\D", "", raw) or raw.lower()


def conversation_link(path: str) -> str:
    """The full address of a saved group link, or "" when it is not a chat conversation link."""
    cleaned = (path or "").strip()
    if not conversation_key(cleaned):
        return ""
    if cleaned.startswith("/"):
        return "https://x.com" + cleaned
    if re.match(r"https://(?:www\.)?(?:x|twitter)\.com/", cleaned):
        return cleaned
    return ""


def land_in_group(page, target: str, pin: str, wait_s: float) -> bool:
    """After a group's page was loaded, wait until that group shows: its conversation view, at its own
    link. Types the chat PIN if X asks for it; if X then shows the chat list instead of the group,
    goes to the group's link once more. Only the view is waited for, not the messages: after a full
    page load X can take a while to show them. True once the group shows."""
    want = conversation_key(target)
    plain_target = (target or "").split("?")[0].rstrip("/")
    typed = False
    again = False
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        accept_cookies(page)
        url = page.url or ""
        at_group = bool(want and conversation_key(url) == want) or url.split("?")[0].rstrip("/") == plain_target
        if at_group and "pin" not in url:
            return True
        if "pin" in url:
            if not typed and pin_fields(page):
                type_pin_once(page, pin)
                typed = True
                error = pin_error_message(page)
                if error:
                    raise RuntimeError(error)
        elif typed and not at_group and not again and (target or "").startswith("http"):
            again = True
            try:
                goto_x(page, target)
            except Exception as exc:
                if browser_closed_error(exc):
                    raise
        page.wait_for_timeout(500)
    return False


def open_group_direct(page, path: str, pin: str, wait_s: float = 40.0) -> bool:
    """Open the group by going straight to its saved link (the chat is already unlocked), instead of
    waiting for it to show up in the chat list. True once the group shows; False to find it in the
    chat list instead."""
    target = conversation_link(path)
    if not target:
        return False
    try:
        goto_x(page, target)
    except Exception as exc:
        if browser_closed_error(exc):
            raise
        return False
    opened = land_in_group(page, target, pin, wait_s)
    if os.environ.get("COLLECT_DEBUG"):
        print(f"group opened directly by its link {target}: {opened}", flush=True)
    return opened


def wait_group_messages(page, wait_s: float) -> bool:
    """Wait up to wait_s for the open group's messages to show. True when they did."""
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        try:
            state = page.evaluate(GROUP_CHAT_SCROLL_JS, "state") or {}
        except Exception as exc:
            if browser_closed_error(exc):
                raise
            state = {}
        if state.get("hasList") and state.get("messages"):
            page.wait_for_timeout(800)
            return True
        page.wait_for_timeout(400)
    return False


def open_named_group(page, name: str) -> str:
    """Find the group in the inbox (waiting up to 10 seconds for it), click it once,
    then wait for its messages. No retries: on failure the task stops with a message.

    The group is matched by its saved id first (renaming does not change it), then by
    exact name, then by a name that starts the same and differs only in the last few
    characters. Returns the name the group has now."""
    wanted = re.sub(r"\s+", " ", name).strip()
    with group_ids_lock:
        saved_id = group_ids.get(wanted, "")
    started = time.monotonic()
    clicked = False
    current_name = wanted
    while time.monotonic() - started < 10:
        try:
            payload = page.evaluate(READ_GROUPS_JS, {"name": wanted, "testid": saved_id}) or {}
        except Exception:
            payload = {}
        if payload.get("clicked"):
            clicked = True
            current_name = re.sub(r"\s+", " ", str(payload.get("matched") or wanted)).strip() or wanted
            # Remember the group's link, so the next task opens it straight away.
            if payload.get("path"):
                remember_group_path(wanted, str(payload.get("path")))
            if os.environ.get("COLLECT_DEBUG"):
                print(f"group opened by {payload.get('how')}: wanted={wanted!r} now={current_name!r}", flush=True)
            break
        if time.monotonic() - started > 3:
            try:
                page.evaluate(SCROLL_INBOX_JS)
            except Exception:
                pass
        page.wait_for_timeout(700)
    if not clicked:
        raise RuntimeError(f"لم يظهر القروب «{wanted}» في الدردشة خلال ١٠ ثوانٍ. توقفت المهمة.")
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        try:
            state = page.evaluate(GROUP_CHAT_SCROLL_JS, "state") or {}
        except Exception:
            state = {}
        if state.get("hasList") and state.get("messages"):
            page.wait_for_timeout(800)
            return current_name
        page.wait_for_timeout(300)
    raise RuntimeError("فُتح القروب لكن رسائله لم تظهر. توقفت المهمة.")


def peek_named_group(page, name: str, wait_s: float = 10.0) -> bool:
    """Open the group once (found the same way as open_named_group) and wait until its
    messages show, at most wait_s. True when the group was opened, whether or not the
    messages showed in time. Used before the real open, because X first opens a group at
    the place this account last read up to, not at the newest messages."""
    wanted = re.sub(r"\s+", " ", name).strip()
    with group_ids_lock:
        saved_id = group_ids.get(wanted, "")
    started = time.monotonic()
    clicked = False
    while time.monotonic() - started < 10:
        try:
            payload = page.evaluate(READ_GROUPS_JS, {"name": wanted, "testid": saved_id}) or {}
        except Exception:
            payload = {}
        if payload.get("clicked"):
            clicked = True
            if payload.get("path"):
                remember_group_path(wanted, str(payload.get("path")))
            break
        if time.monotonic() - started > 3:
            try:
                page.evaluate(SCROLL_INBOX_JS)
            except Exception:
                pass
        page.wait_for_timeout(700)
    if not clicked:
        return False
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        try:
            state = page.evaluate(GROUP_CHAT_SCROLL_JS, "state") or {}
        except Exception:
            state = {}
        if state.get("hasList") and state.get("messages"):
            page.wait_for_timeout(1000)
            return True
        page.wait_for_timeout(300)
    return True


def sway_group_while_waiting(page, seconds: int, should_stop=None) -> None:
    """During the wait inside the group, move the chat up and down. The last ten seconds
    stay at the bottom, where the newest messages are."""
    seconds = int(seconds)
    if seconds <= 0:
        return
    step = """(dir) => {
      const start = document.querySelector('[data-testid="dm-message-scroller"]')
        || document.querySelector('[data-testid="dm-message-list"]');
      const scrollerOf = (node) => {
        for (let el = node; el && el.nodeType === 1; el = el.parentElement) {
          if (/(auto|scroll|overlay)/.test(getComputedStyle(el).overflowY) && el.scrollHeight > el.clientHeight + 10) return el;
        }
        const page = document.scrollingElement;
        if (page && page.scrollHeight > page.clientHeight + 10) return page;
        return node;
      };
      const scroller = start ? scrollerOf(start) : document.scrollingElement;
      if (!scroller) return false;
      if (dir === 0) scroller.scrollTop = scroller.scrollHeight;
      else {
        const client = scroller.clientHeight || 800;
        const base = dir > 0
          ? Math.max(560, Math.min(1200, Math.round(client * 0.75)))
          : Math.max(400, Math.min(800, Math.round(client * 0.5)));
        const jump = Math.max(base, Math.min(base * 2, Math.round(client * 0.9)));
        scroller.scrollTop = dir < 0
          ? Math.max(0, scroller.scrollTop - jump)
          : Math.min(scroller.scrollHeight, scroller.scrollTop + jump);
      }
      try { scroller.dispatchEvent(new Event("scroll", {bubbles: true})); } catch (error) {}
      return true;
    }"""
    end = time.monotonic() + seconds
    bottom_at = end - 10 if seconds > 10 else time.monotonic()
    direction = -1
    while True:
        if should_stop and should_stop():
            return
        now = time.monotonic()
        if now >= end:
            return
        if now >= bottom_at:
            try:
                page.evaluate(step, 0)
            except Exception:
                pass
            page.wait_for_timeout(int(max(0, end - time.monotonic()) * 1000))
            return
        try:
            page.evaluate(step, direction)
        except Exception:
            pass
        direction = 1 if direction < 0 else -1
        page.wait_for_timeout(800)


def leave_group(page, pin: str) -> None:
    """Go back from the open group to the chat list, like pressing back."""
    try:
        page.go_back(wait_until="domcontentloaded", timeout=15_000)
    except Exception:
        pass
    page.wait_for_timeout(800)
    still_inside = re.search(r"/(?:i/chat|messages)/[^/?#]+", page.url or "")
    if still_inside or not chat_inbox_open(page):
        # Back did not land on the chat list: open it directly (types the chat PIN if X asks).
        goto_x(page, CHAT_URLS[0])
        error = open_chat(page, pin)
        if error:
            raise RuntimeError(error)


def saved_group_url(name: str) -> str:
    """The group's own address from what was saved earlier, without opening the chat list."""
    wanted = re.sub(r"\s+", " ", name).strip()
    with group_ids_lock:
        path = group_paths.get(wanted, "")
        gid = group_ids.get(wanted, "")
    link = conversation_link(path)
    if link:
        return link
    raw = re.sub(r"^dm-conversation-item-", "", (gid or path)).strip()
    digits = re.sub(r"\D", "", raw)
    if digits:
        return "https://x.com/i/chat/g" + digits
    return ""


def open_group_for_task(page, pin: str, group_name: str, group_wait_s: int, say) -> str:
    """Open the group by its address. The chat list is not opened and is not waited on.
    If X asks for the chat PIN on the way, it is typed, then the group address is opened again."""
    target = saved_group_url(group_name)
    if not target:
        raise RuntimeError(f"لا يوجد رابط محفوظ للقروب «{group_name}».")
    say(f"فتح القروب مباشرة: {group_name}")
    if not open_group_direct(page, target, pin, 25):
        raise RuntimeError(f"تعذّر فتح القروب «{group_name}» مباشرة.")
    remember_group_path(group_name, target)
    return group_name


def group_chat_state(page) -> dict:
    try:
        return page.evaluate(GROUP_CHAT_SCROLL_JS, "state") or {}
    except Exception:
        return {}


CHAT_SPOT_JS = r"""
() => {
""" + CHAT_FIND_JS + r"""
  const start = query('[data-testid="dm-message-scroller"]') || query('[data-testid="dm-message-list"]');
  if (!start) return null;
  // The chat's part of the screen: its scroller, else its list, else what really scrolls it.
  const area = [start, query('[data-testid="dm-message-list"]'), scrollerOf(start)].find((el) => el && shownArea(el) >= 1600);
  if (!area) return null;
  const rect = area.getBoundingClientRect();
  const left = Math.max(rect.left, 0);
  const top = Math.max(rect.top, 0);
  const width = Math.min(rect.right, innerWidth) - left;
  const height = Math.min(rect.bottom, innerHeight) - top;
  const inside = (node) => {
    for (let el = node; el; el = el.parentElement || (el.parentNode && el.parentNode.host) || null) {
      if (el === area) return true;
    }
    return false;
  };
  const spots = [[0.45, Math.min(0.42, 640 / height)], [0.5, 0.5], [0.5, 0.25], [0.5, 0.75], [0.25, 0.5], [0.75, 0.5]]
    .map(([fx, fy]) => ({x: Math.round(left + width * fx), y: Math.round(top + height * fy)}));
  for (const spot of spots) {
    let hit = document.elementFromPoint(spot.x, spot.y);
    while (hit && hit.shadowRoot) {
      const deeper = hit.shadowRoot.elementFromPoint(spot.x, spot.y);
      if (!deeper || deeper === hit) break;
      hit = deeper;
    }
    if (hit && inside(hit)) return spot;
  }
  return spots[0];
}
"""


def focus_group_scroller(page) -> None:
    """Put the mouse over the part of the chat that shows on the screen, on a spot nothing covers."""
    try:
        spot = page.evaluate(CHAT_SPOT_JS)
    except Exception:
        spot = None
    if spot:
        page.mouse.move(spot["x"], spot["y"])


CHAT_UNSTICK_JS = r"""
(pixels) => {
""" + CHAT_FIND_JS + r"""
  const start = query('[data-testid="dm-message-scroller"]') || query('[data-testid="dm-message-list"]');
  if (!start) return false;
  const scroller = scrollerOf(start);
  const room = scroller.scrollHeight - scroller.clientHeight;
  // Step down from the top; the mouse wheel then takes the chat back up to it.
  if (room > 10) scroller.scrollTop = Math.min(room, Math.max(120, pixels));
  if (start.scrollHeight - start.clientHeight > 10) return false;
  // The chat's own scroller cannot scroll (the loaded messages fit it): tell it it was scrolled up anyway.
  for (const target of new Set([start, scroller])) {
    try { target.dispatchEvent(new WheelEvent("wheel", {deltaY: -Math.max(120, pixels), bubbles: true, cancelable: true})); } catch (error) {}
    try { target.dispatchEvent(new Event("scroll", {bubbles: true})); } catch (error) {}
  }
  // Whether the loaded messages fit a chat made to scroll by itself: only a shorter screen lets it scroll.
  return /(auto|scroll|overlay)/.test(getComputedStyle(start).overflowY);
}
"""

# A screen taller than this is made this short for a moment when the chat's messages fit it.
SHORT_SCREEN_HEIGHT = 900


def unstick_group_chat(page, pixels: int) -> None:
    """For a climb that stopped at the oldest loaded messages while X loads no older ones: step
    down a little and wheel back up to the top, so X sees its chat being scrolled up. When the
    loaded messages fit the chat (on the tall phone screen nothing in it can scroll), this is done
    on a short screen, and the screen gets its height back after."""
    try:
        fits = bool(page.evaluate(CHAT_UNSTICK_JS, pixels))
    except Exception:
        return
    size = page.viewport_size or {}
    short = fits and int(size.get("height") or 0) > SHORT_SCREEN_HEIGHT
    try:
        if short:
            page.set_viewport_size({"width": int(size["width"]), "height": SHORT_SCREEN_HEIGHT})
            page.wait_for_timeout(600)
            page.evaluate(CHAT_UNSTICK_JS, pixels)
        page.wait_for_timeout(300)
        focus_group_scroller(page)
        page.mouse.wheel(0, -2 * pixels)
        page.wait_for_timeout(1500 if short else 300)
    except Exception as exc:
        if browser_closed_error(exc):
            raise
    finally:
        if short:
            try:
                page.set_viewport_size({"width": int(size["width"]), "height": int(size["height"])})
                page.wait_for_timeout(500)
            except Exception:
                pass


def tweet_url(raw_url: str, status_id: str) -> str:
    raw = (raw_url or "").strip()
    for match in re.finditer(rf"(?<![A-Za-z0-9_])/([A-Za-z0-9_]{{1,15}})/status/{status_id}(?!\d)", raw):
        owner = match.group(1)
        if owner.lower() in {"i", "web", "intent", "share"}:
            continue
        return f"https://x.com/{owner}/status/{status_id}"
    return f"https://x.com/i/web/status/{status_id}"


def extract_status_id(value: str) -> str:
    raw = (value or "").strip()
    match = re.search(r"status/(\d{6,25})", raw)
    if match:
        return match.group(1)
    if re.fullmatch(r"\d{15,25}", raw):
        return raw
    return ""


SCAN_STOP_JS = r"""
(arg) => {
  let wanted = "";
  let dir = 0;
  if (arg && typeof arg === "object") {
    wanted = String(arg.stopId || "");
    dir = arg.dir === 1 || arg.dir === -1 ? arg.dir : 0;
  } else {
    wanted = String(arg || "");
  }
""" + CHAT_FIND_JS + r"""
  const list = query('[data-testid="dm-message-list"]') || query('[data-testid="dm-conversation-content"]') || query('[data-testid="dm-message-scroller"]');
  if (!list) return {hit: false, pending: 0, oldest: "", count: 0, hitTop: 0};
  const all = [...list.querySelectorAll('[data-testid^="message-"]')].filter((el) => {
    const id = el.getAttribute("data-testid") || "";
    return id.startsWith("message-") && !id.startsWith("message-text-");
  });
  const messages = all.filter((el) => ![...el.querySelectorAll('[data-testid^="message-"]')].some((node) => {
    const id = node.getAttribute("data-testid") || "";
    return node !== el && id.startsWith("message-") && !id.startsWith("message-text-");
  }));
  let hit = false;
  let hitTop = 0;
  let pending = 0;
  for (const bubble of messages) {
    const links = [...bubble.querySelectorAll('a[href*="status/"]')].map((node) => node.getAttribute("href") || "");
    const blob = (bubble.innerText || "") + "\n" + links.join("\n");
    if (wanted && blob.includes(wanted)) {
      hit = true;
      hitTop = Math.round(bubble.getBoundingClientRect().top || 0);
      break;
    }
    const card = bubble.querySelector('[data-testid="tweetText"], article, [data-testid="card.wrapper"], [data-testid="tweetPhoto"]');
    if (card && !/status\/\d{6,25}/.test(blob)) pending += 1;
  }
  const oldest = messages.length ? (messages[0].getAttribute("data-testid") || "") : "";
  const scroller = scrollerOf(query('[data-testid="dm-message-scroller"]') || list);
  let loading = false;
  const spinner = list.querySelector('[data-testid="dm-message-list-spinner-slot"], [data-testid="dm-message-list-spinner"], [data-testid*="spinner"], [role="progressbar"]');
  if (spinner) {
    const rect = spinner.getBoundingClientRect();
    loading = rect.width > 8 && rect.height > 8;
  }
  let moved = 0;
  if (scroller && !hit && (dir === -1 || dir === 1)) {
    const beforeTop = scroller.scrollTop || 0;
    const client = scroller.clientHeight || 800;
    const step = Math.max(400, Math.min(800, Math.round(client * 0.5)));
    if (dir < 0 && beforeTop <= 48) {
      scroller.scrollTop = 0;
      try { scroller.dispatchEvent(new WheelEvent("wheel", {deltaY: -640, bubbles: true, cancelable: true})); } catch (error) {}
    } else if (dir > 0 && beforeTop + client >= scroller.scrollHeight - 80) {
      scroller.scrollTop = scroller.scrollHeight;
    } else {
      const next = dir < 0 ? Math.max(0, beforeTop - step) : Math.min(scroller.scrollHeight, beforeTop + step);
      scroller.scrollTop = next;
    }
    try { scroller.dispatchEvent(new Event("scroll", {bubbles: true})); } catch (error) {}
    moved = Math.abs((scroller.scrollTop || 0) - beforeTop);
  }
  return {
    hit,
    pending,
    oldest,
    count: messages.length,
    hitTop,
    loading,
    moved: Math.round(moved),
    scrollHeight: scroller ? Math.round(scroller.scrollHeight) : 0,
    scrollTop: scroller ? Math.round(scroller.scrollTop) : 0,
    clientHeight: scroller ? Math.round(scroller.clientHeight) : 0
  };
}
"""

STEP_OLDER_JS = r"""
(pixels) => {
""" + CHAT_FIND_JS + r"""
  const start = query('[data-testid="dm-message-scroller"]') || query('[data-testid="dm-message-list"]');
  if (!start) return {ok: false};
  const scroller = scrollerOf(start);
  const before = scroller.scrollTop;
  const atTop = before <= 48;
  if (!atTop) scroller.scrollTop = Math.max(0, before - Math.max(80, pixels));
  else scroller.scrollTop = 0;
  scroller.dispatchEvent(new Event("scroll", {bubbles: true}));
  return {ok: true, before: Math.round(before), after: Math.round(scroller.scrollTop), atTop, height: Math.round(scroller.scrollHeight)};
}
"""


# Inside the group, each scroll step is this many times the base step (never past what the
# chat shows at once).
GROUP_SCROLL_FACTOR = 2


FETCH_GROUP_PAGE_JS = r"""
async ({conversationId, maxId}) => {
  const bearer = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
  const ct0 = decodeURIComponent((document.cookie.match(/(?:^|; )ct0=([^;]+)/) || [])[1] || "");
  if (!ct0) return {ok: false, error: "لا يوجد ct0 في هذه الصفحة"};
  const params = new URLSearchParams({
    context: maxId ? "FETCH_DM_CONVERSATION_HISTORY" : "FETCH_DM_CONVERSATION",
    include_conversation_info: "true",
    include_cards: "1",
    tweet_mode: "extended",
    include_groups: "true",
    supports_reactions: "true",
    supports_edit: "true",
    dm_users: "false"
  });
  if (maxId) params.set("max_id", String(maxId));
  const url = "https://x.com/i/api/1.1/dm/conversation/" + encodeURIComponent(conversationId) + ".json?" + params.toString();
  let response;
  try {
    response = await fetch(url, {
      method: "GET",
      credentials: "include",
      headers: {
        authorization: "Bearer " + bearer,
        "x-csrf-token": ct0,
        "x-twitter-auth-type": "OAuth2Session",
        "x-twitter-active-user": "yes"
      }
    });
  } catch (error) {
    return {ok: false, error: String(error && error.message || error)};
  }
  const raw = await response.text();
  let data = null;
  try { data = JSON.parse(raw); } catch (error) { data = null; }
  const ids = [];
  const texts = [];
  const messageIds = [];
  const seen = new Set();
  const walk = (node) => {
    if (node == null) return;
    if (typeof node === "string") {
      const re = /status\/(\d{6,25})/g;
      let match;
      while ((match = re.exec(node))) {
        if (!seen.has(match[1])) { seen.add(match[1]); ids.push(match[1]); }
      }
      if (node.length > 1 && node.length < 400 && texts.length < 4) texts.push(node.slice(0, 140));
      return;
    }
    if (Array.isArray(node)) { node.forEach(walk); return; }
    if (typeof node === "object") {
      if (node.id && /^\d{10,25}$/.test(String(node.id))) messageIds.push(String(node.id));
      Object.keys(node).forEach((key) => walk(node[key]));
    }
  };
  if (data) walk(data);
  messageIds.sort();
  const sample = texts.join(" | ").slice(0, 180);
  const readable = /[\u0600-\u06FFa-zA-Z]{2,}/.test(sample);
  let error = "";
  if (response.status !== 200) error = "HTTP " + response.status + " " + raw.replace(/\s+/g, " ").slice(0, 160);
  else if (!ids.length && !readable && sample.length > 40) error = "النص غير مقروء ويبدو مشفراً";
  else if (!ids.length) error = "لا روابط تغريدات في الدفعة";
  return {
    ok: response.status === 200,
    status: response.status,
    keys: data && typeof data === "object" ? Object.keys(data).slice(0, 8).join(",") : "",
    tweets: ids,
    messages: messageIds.length,
    minId: messageIds.length ? messageIds[0] : "",
    sample,
    error
  };
}
"""


def group_conversation_ids(page, group_name: str) -> list[str]:
    """Ids worth asking for, without opening the group: the saved link, then the inbox row."""
    wanted = re.sub(r"\s+", " ", group_name).strip()
    found: list[str] = []

    def add(value: str) -> None:
        raw = (value or "").strip()
        match = re.search(r"/(?:i/chat|messages)/([^/?#\s]+)", raw)
        if match:
            raw = match.group(1)
        raw = re.sub(r"^dm-conversation-item-", "", raw)
        if raw and raw not in found:
            found.append(raw)
        digits = re.sub(r"\D", "", raw)
        if digits and digits not in found:
            found.append(digits)

    with group_ids_lock:
        add(group_paths.get(wanted, ""))
        add(group_ids.get(wanted, ""))
    try:
        payload = page.evaluate(READ_GROUPS_JS, "") or {}
    except Exception as exc:
        trace_click("جمع الجلسة: تعذرت قراءة قائمة الدردشة " + type(exc).__name__)
        payload = {}
    names = payload.get("groups") if isinstance(payload, dict) else None
    paths = payload.get("paths") if isinstance(payload, dict) else None
    ids = payload.get("ids") if isinstance(payload, dict) else None
    if isinstance(names, list):
        for index, name in enumerate(names):
            if re.sub(r"\s+", " ", str(name)).strip() != wanted:
                continue
            if isinstance(paths, list) and index < len(paths):
                add(str(paths[index]))
            if isinstance(ids, list) and index < len(ids):
                add(str(ids[index]))
    trace_click(f"جمع الجلسة: معرفات «{wanted}» = {found or 'لا يوجد'}")
    return found


def collect_group_by_session(page, group_name: str, limit: int, stop_id: str = "", should_stop=None) -> tuple[list[dict], bool, str]:
    """Read the group's tweets from the open chat session, without opening or scrolling the group.

    Returns (tweets, reached the stop tweet, error). An error means the caller should collect
    by scrolling; the reason is already in the click log."""
    ids = group_conversation_ids(page, group_name)
    if not ids:
        reason = "لا يوجد معرف للقروب في الدردشة"
        trace_click("جمع الجلسة: " + reason)
        return [], False, reason
    conversation_id = ""
    cursor = ""
    seen_cursors: set[str] = set()
    seen: set[str] = set()
    found: list[dict] = []
    reached = False
    last_error = ""
    for page_no in range(1, 31):
        if should_stop and should_stop():
            raise JobStopped
        if not conversation_id:
            conversation_id = ids.pop(0)
        try:
            payload = page.evaluate(FETCH_GROUP_PAGE_JS, {"conversationId": conversation_id, "maxId": cursor}) or {}
        except Exception as exc:
            last_error = type(exc).__name__ + ": " + str(exc).splitlines()[0][:160]
            trace_click(f"جمع الجلسة صفحة {page_no}: فشل الطلب {last_error}")
            break
        if not isinstance(payload, dict):
            last_error = "رد غير مفهوم"
            trace_click(f"جمع الجلسة صفحة {page_no}: {last_error}")
            break
        status = payload.get("status")
        trace_click(
            f"جمع الجلسة صفحة {page_no} id={conversation_id} HTTP={status} مفاتيح={payload.get('keys') or '-'} "
            f"رسائل={payload.get('messages') or 0} تغريدات={len(payload.get('tweets') or [])} "
            f"سبب={payload.get('error') or '-'} عينة={payload.get('sample') or '-'}"
        )
        if status == 404 and ids:
            last_error = f"المعرف {conversation_id} غير موجود"
            conversation_id = ""
            cursor = ""
            continue
        if payload.get("ok") and not (payload.get("tweets") or []) and "مشفر" in str(payload.get("error") or ""):
            last_error = str(payload.get("error") or "النص مشفر")
            break
        if not payload.get("ok"):
            last_error = str(payload.get("error") or "فشل الطلب")
            break
        for status_id in payload.get("tweets") or []:
            status_id = re.sub(r"\D", "", str(status_id))
            if not status_id or status_id in seen:
                if stop_id and status_id == stop_id:
                    reached = True
                continue
            seen.add(status_id)
            found.append({"url": f"https://x.com/i/web/status/{status_id}", "text": "تغريدة"})
            if stop_id and status_id == stop_id:
                reached = True
                break
            if not stop_id and len(found) >= limit:
                break
        if reached or (not stop_id and len(found) >= limit):
            last_error = ""
            break
        older = str(payload.get("minId") or "")
        if not older or older in seen_cursors or older == cursor:
            last_error = "" if found else str(payload.get("error") or "انتهى السجل بلا تغريدات")
            break
        seen_cursors.add(older)
        cursor = older
        last_error = ""
    if found and (not stop_id or reached or not last_error):
        trace_click(f"جمع الجلسة نجح: {len(found)} تغريدة")
        return found, reached or not stop_id, ""
    reason = last_error or "لم تُستخرج تغريدات من الجلسة"
    trace_click("جمع الجلسة لم يكتمل: " + reason)
    return [], False, reason


def _status_ids_and_cursor(payload) -> tuple[list[str], str]:
    """Tweet ids in a chat response, and the cursor that asks for the older page."""
    ids: list[str] = []
    seen: set[str] = set()
    cursors: list[str] = []

    def add_id(value: str) -> None:
        for status_id in re.findall(r"status/(\d{6,25})", value or ""):
            if status_id not in seen:
                seen.add(status_id)
                ids.append(status_id)

    def walk(node, key: str = "") -> None:
        if isinstance(node, str):
            add_id(node)
            if key in ("min_entry_id", "cursor", "next_cursor", "pagination_token", "bottom_cursor") and re.fullmatch(r"[A-Za-z0-9_=+/-]{6,}", node):
                cursors.append(node)
            return
        if isinstance(node, list):
            for item in node:
                walk(item)
            return
        if isinstance(node, dict):
            for item_key, item in node.items():
                walk(item, str(item_key))

    walk(payload)
    return ids, (cursors[0] if cursors else "")


def collect_from_page_requests(page, pin: str, group_name: str, limit: int, stop_id: str = "", should_stop=None, say=None) -> tuple[list[dict], bool, str]:
    """Open the group once and read the requests the page itself is allowed to make.

    Older pages are requested from those same addresses. The chat is not scrolled and the
    wait inside the group is not used."""
    caught: list[tuple[str, int, str]] = []

    def on_finished(request) -> None:
        url = str(getattr(request, "url", "") or "")
        if not re.search(r"dm/|conversation|xchat|graphql|/chat/", url, re.I):
            return
        response = request.response()
        if response is None:
            return
        try:
            text = response.text()
        except Exception as exc:
            trace_click(f"طلب الصفحة بلا جسم HTTP={getattr(response, 'status', 0)} {url[:160]} {type(exc).__name__}")
            return
        caught.append((url, int(getattr(response, "status", 0) or 0), text[:200000]))
        trace_click(f"طلب الصفحة HTTP={getattr(response, 'status', 0)} طول={len(text)} {url[:180]}")

    page.on("requestfinished", on_finished)
    try:
        if say:
            say(f"فتح القروب مرة واحدة لأخذ طلب الصفحة: {group_name}")
        open_group_for_task(page, pin, group_name, 0, say or (lambda _text: None))
        page.wait_for_timeout(1500)
    finally:
        page.remove_listener("requestfinished", on_finished)
    if should_stop and should_stop():
        raise JobStopped
    if not caught:
        reason = "الصفحة لم ترسل طلب سجل عند فتح القروب"
        trace_click("جمع الطلبات: " + reason)
        return [], False, reason
    found: list[dict] = []
    seen: set[str] = set()
    reached = False

    def take(status_ids: list[str]) -> bool:
        nonlocal reached
        for status_id in status_ids:
            if status_id in seen:
                if stop_id and status_id == stop_id:
                    reached = True
                    return True
                continue
            seen.add(status_id)
            found.append({"url": f"https://x.com/i/web/status/{status_id}", "text": "تغريدة"})
            if stop_id and status_id == stop_id:
                reached = True
                return True
            if not stop_id and len(found) >= limit:
                return True
        return False

    replay_url = ""
    cursor = ""
    for url, status, text in caught:
        parsed = None
        try:
            parsed = json.loads(text)
        except Exception:
            parsed = text
        status_ids, found_cursor = _status_ids_and_cursor(parsed)
        trace_click(f"جمع الطلبات: من الرد {status} تغريدات={len(status_ids)} مؤشر={found_cursor or '-'}")
        if status_ids or found_cursor:
            replay_url = url
            cursor = found_cursor
        if take(status_ids):
            trace_click(f"جمع الطلبات اكتفى من أول رد: {len(found)}")
            return found, reached or not stop_id, ""
    if not replay_url or not cursor:
        visible = []
        try:
            visible = page.evaluate(r"""() => {
              const seen = new Set();
              const ids = [];
              const take = (value) => {
                const re = /status\/(\d{6,25})/g;
                let match;
                while ((match = re.exec(value || ""))) if (!seen.has(match[1])) { seen.add(match[1]); ids.push(match[1]); }
              };
              take(document.body ? document.body.innerText : "");
              document.querySelectorAll('a[href*="status/"]').forEach((link) => take(link.getAttribute("href") || ""));
              return ids;
            }""") or []
        except Exception:
            visible = []
        trace_click(f"جمع الطلبات: الظاهر على الشاشة {len(visible)} بلا مؤشر صفحة أقدم")
        if take([str(item) for item in visible]):
            return found, reached or not stop_id, ""
        reason = "الطلبات لا تحمل روابط ولا مؤشر صفحة أقدم"
        trace_click("جمع الطلبات: " + reason)
        return found, False, reason
    seen_cursors = {cursor}
    for page_no in range(2, 26):
        if should_stop and should_stop():
            raise JobStopped
        next_url = replay_url
        if re.search(r"[?&]max_id=", next_url):
            next_url = re.sub(r"([?&]max_id=)[^&]*", r"\g<1>" + cursor, next_url)
        elif re.search(r"[?&]cursor=", next_url):
            next_url = re.sub(r"([?&]cursor=)[^&]*", r"\g<1>" + cursor, next_url)
        elif "?" in next_url:
            next_url += "&max_id=" + cursor
        else:
            next_url += "?max_id=" + cursor
        try:
            payload = page.evaluate(r"""
async ({url}) => {
  const bearer = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
  const ct0 = decodeURIComponent((document.cookie.match(/(?:^|; )ct0=([^;]+)/) || [])[1] || "");
  const response = await fetch(url, {
    method: "GET",
    credentials: "include",
    headers: {
      authorization: "Bearer " + bearer,
      "x-csrf-token": ct0,
      "x-twitter-auth-type": "OAuth2Session",
      "x-twitter-active-user": "yes"
    }
  });
  const raw = await response.text();
  return {status: response.status, raw: raw.slice(0, 200000)};
}
""", {"url": next_url}) or {}
        except Exception as exc:
            trace_click(f"جمع الطلبات صفحة {page_no}: فشل {type(exc).__name__}")
            break
        status = int(payload.get("status") or 0)
        raw = str(payload.get("raw") or "")
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = raw
        status_ids, found_cursor = _status_ids_and_cursor(parsed)
        trace_click(f"جمع الطلبات صفحة {page_no} HTTP={status} تغريدات={len(status_ids)} مؤشر={found_cursor or '-'}")
        done = take(status_ids)
        if done or not found_cursor or found_cursor in seen_cursors or status != 200:
            break
        seen_cursors.add(found_cursor)
        cursor = found_cursor
    if found:
        trace_click(f"جمع الطلبات نجح: {len(found)} بدون تمرير")
        return found, reached or not stop_id, ""
    reason = "صفحات الطلب لم تحمل تغريدات"
    trace_click("جمع الطلبات: " + reason)
    return [], False, reason


PROBE_CHAT_JS = r"""
async ({conversationId}) => {
  const bearer = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
  const ct0 = decodeURIComponent((document.cookie.match(/(?:^|; )ct0=([^;]+)/) || [])[1] || "");
  const headers = {
    authorization: "Bearer " + bearer,
    "x-csrf-token": ct0,
    "x-twitter-auth-type": "OAuth2Session",
    "x-twitter-active-user": "yes"
  };
  const id = String(conversationId || "");
  const urls = [
    "https://x.com/i/api/2/chat/conversations/" + id + "/events?max_results=50&chat_message_event.fields=conversation_id,created_at,encoded_event,id,sender_id",
    "https://api.x.com/2/chat/conversations/" + id + "/events?max_results=50&chat_message_event.fields=conversation_id,created_at,encoded_event,id,sender_id",
    "https://x.com/i/api/2/chat/conversations/" + id,
    "https://x.com/i/api/1.1/dm/inbox_initial_state.json?include_groups=true&supports_reactions=true"
  ];
  const seen = new Set(urls);
  try {
    const chunks = self.webpackChunk_twitter_responsive_web || [];
    let budget = 0;
    const re = /\/(?:2\/chat\/conversations|i\/api\/[^"'\\\s]{0,80}(?:dm|chat)[^"'\\\s]{0,80})/g;
    for (const chunk of chunks) {
      const mods = chunk && chunk[1];
      if (!mods) continue;
      for (const fn of Object.values(mods)) {
        let source = "";
        try { source = Function.prototype.toString.call(fn); } catch (error) { continue; }
        if (source.indexOf("chat") < 0 && source.indexOf("/dm/") < 0) continue;
        let match;
        while ((match = re.exec(source))) {
          const path = match[0];
          if (!seen.has(path) && urls.length < 10) { seen.add(path); urls.push(path); }
        }
        budget += source.length;
        if (budget > 1500000) break;
      }
    }
  } catch (error) {}
  const results = [];
  for (const url of urls) {
    const full = url.startsWith("http") ? url : ("https://x.com" + url);
    try {
      const response = await fetch(full, {method: "GET", credentials: "include", headers});
      const raw = await response.text();
      const ids = raw.match(/status\/\d{6,25}/g) || [];
      results.push({
        url: full.slice(0, 180),
        status: response.status,
        tweets: ids.length,
        encoded: raw.indexOf("encoded_event") >= 0,
        sample: raw.replace(/\s+/g, " ").slice(0, 180)
      });
    } catch (error) {
      results.push({url: full.slice(0, 180), status: 0, tweets: 0, encoded: false, sample: String(error && error.message || error).slice(0, 180)});
    }
  }
  return results;
}
"""


def probe_chat_without_group(page, group_name: str) -> None:
    """Ask the chat history from the inbox only. Never opens the group. Logs every answer."""
    ids = group_conversation_ids(page, group_name)
    group_id = next((item for item in ids if item.startswith("g")), ids[0] if ids else "")
    trace_click(f"تجربة بدون فتح: المعرف المستخدم {group_id or 'لا يوجد'}")
    if not group_id:
        trace_click("تجربة بدون فتح: توقف، لا معرف")
        return
    try:
        rows = page.evaluate(PROBE_CHAT_JS, {"conversationId": group_id}) or []
    except Exception as exc:
        trace_click("تجربة بدون فتح: فشل التشغيل " + type(exc).__name__ + " " + str(exc).splitlines()[0][:160])
        return
    if not isinstance(rows, list):
        trace_click("تجربة بدون فتح: رد غير مفهوم")
        return
    for row in rows:
        if not isinstance(row, dict):
            continue
        trace_click(
            f"تجربة HTTP={row.get('status')} تغريدات={row.get('tweets')} مشفر={row.get('encoded')} "
            f"{row.get('url')} | {row.get('sample')}"
        )
    readable = [row for row in rows if isinstance(row, dict) and int(row.get("tweets") or 0) > 0]
    encoded = [row for row in rows if isinstance(row, dict) and row.get("encoded")]
    if readable:
        trace_click(f"تجربة بدون فتح: وُجدت روابط في {len(readable)} طلب")
    elif encoded:
        trace_click("تجربة بدون فتح: السجل رجع مشفراً (encoded_event) بلا روابط مقروءة")
    else:
        trace_click("تجربة بدون فتح: لا طلب أعاد روابط تغريدات")


def collect_group_tweets(page, limit: int, on_progress=None, stop_id: str = "", should_stop=None) -> tuple[list[dict], bool]:
    found: list[dict] = []
    seen: set[str] = set()
    reached = False

    def pull() -> tuple[int, int, list[str]]:
        nonlocal reached
        try:
            payload = page.evaluate(GROUP_READ_TWEETS_JS, "") or {}
        except Exception:
            payload = {}
        if isinstance(payload, list):
            rows, pending = payload, 0
        else:
            rows, pending = payload.get("tweets") or [], int(payload.get("pending") or 0)
        rows = [row for row in rows if isinstance(row, dict)]
        rows.sort(key=lambda row: float(row.get("top") or 0), reverse=True)
        added = 0
        visible: list[str] = []
        for row in rows:
            if reached or (not stop_id and len(found) >= limit):
                break
            status_id = re.sub(r"\D", "", str(row.get("statusId") or ""))
            if not status_id:
                continue
            visible.append(status_id)
            if status_id in seen:
                if stop_id and status_id == stop_id:
                    reached = True
                    break
                continue
            seen.add(status_id)
            found.append({
                "url": tweet_url(str(row.get("url") or ""), status_id),
                "text": re.sub(r"\s+", " ", str(row.get("text") or "")).strip()[:280] or "تغريدة",
            })
            added += 1
            if stop_id and status_id == stop_id:
                reached = True
                break
        return added, pending, visible

    def settle(tries: int = 7) -> tuple[int, list[str]]:
        added_total = 0
        pending = 0
        visible: list[str] = []
        for _ in range(tries):
            added, pending, visible = pull()
            added_total += added
            if on_progress:
                on_progress(len(found), 0 if stop_id else limit, "collect")
            if reached or (not stop_id and len(found) >= limit):
                return added_total, visible
            if pending:
                page.wait_for_timeout(100)
                continue
            page.wait_for_timeout(40)
            added, pending, visible = pull()
            added_total += added
            if reached or (not stop_id and len(found) >= limit):
                return added_total, visible
            if not pending:
                return added_total, visible
        return added_total, visible

    def read_rows() -> tuple[list[dict], int]:
        try:
            payload = page.evaluate(GROUP_READ_TWEETS_JS, "") or {}
        except Exception:
            payload = {}
        if isinstance(payload, list):
            return [row for row in payload if isinstance(row, dict)], 0
        rows = payload.get("tweets") or []
        return [row for row in rows if isinstance(row, dict)], int(payload.get("pending") or 0)

    def row_id(row: dict) -> str:
        return re.sub(r"\D", "", str(row.get("statusId") or ""))

    def add_tweet(status_id: str, row: dict) -> bool:
        if not status_id or status_id in seen:
            return False
        seen.add(status_id)
        found.append({
            "url": tweet_url(str(row.get("url") or ""), status_id),
            "text": re.sub(r"\s+", " ", str(row.get("text") or "")).strip()[:280] or "تغريدة",
        })
        return True

    def at_latest(state: dict) -> bool:
        top = int(state.get("scrollTop") or 0)
        height = int(state.get("scrollHeight") or 0)
        client = int(state.get("clientHeight") or 0) or 700
        return height > 0 and top + client >= height - 80

    if stop_id:
        spotted = False
        quiet = 0
        rounds = 0
        hit_top = None
        last_oldest = ""
        last_height = 0
        max_seek = 8000

        def scan_stop(direction: int) -> dict:
            try:
                payload = page.evaluate(SCAN_STOP_JS, {"stopId": stop_id, "dir": direction}) or {}
            except Exception:
                payload = {}
            return payload if isinstance(payload, dict) else {}

        # Climb with real mouse-wheel input (what X's chat listens to for loading
        # older messages). Progress = the oldest mounted message changes, the
        # scroll position moves, or the list grows. Unfinished tweet cards no
        # longer keep the loop alive forever, and the climb has a time limit.
        last_top = -1
        deadline = time.monotonic() + 360
        while not spotted and rounds < max_seek and quiet < 8 and time.monotonic() < deadline:
            if should_stop and should_stop():
                raise JobStopped
            close_popups(page)
            scan = scan_stop(0)
            if scan.get("hit"):
                spotted = True
                hit_top = float(scan.get("hitTop") or 0)
                break
            client = int(scan.get("clientHeight") or 0) or 800
            step = max(250, min(500, int(client * 0.2)))
            step = max(step, min(step * GROUP_SCROLL_FACTOR, int(client * 0.9)))
            before_top = int(scan.get("scrollTop") or 0)
            focus_group_scroller(page)
            try:
                page.mouse.wheel(0, -step)
            except Exception:
                pass
            page.wait_for_timeout(2000)
            state = scan_stop(0)
            if state.get("hit"):
                spotted = True
                hit_top = float(state.get("hitTop") or 0)
                break
            top_now = int(state.get("scrollTop") or 0)
            if abs(top_now - before_top) <= 8 and top_now > 48:
                try:
                    page.evaluate(STEP_OLDER_JS, step)
                except Exception:
                    pass
                page.wait_for_timeout(300)
                state = scan_stop(0)
                top_now = int(state.get("scrollTop") or 0)
            oldest = str(state.get("oldest") or "")
            height = int(state.get("scrollHeight") or 0)
            moved = last_top >= 0 and abs(top_now - last_top) > 8
            grew = height > last_height + 24 or bool(oldest and last_oldest and oldest != last_oldest)
            if not moved and not grew and top_now <= 48:
                # At the oldest loaded messages and X has not loaded older ones.
                unstick_group_chat(page, step)
                state = scan_stop(0)
                if state.get("hit"):
                    spotted = True
                    hit_top = float(state.get("hitTop") or 0)
                    break
                top_now = int(state.get("scrollTop") or 0)
                oldest = str(state.get("oldest") or "")
                height = int(state.get("scrollHeight") or 0)
                grew = height > last_height + 24 or bool(oldest and last_oldest and oldest != last_oldest)
            if moved or grew:
                quiet = 0
            else:
                quiet += 1
            if oldest:
                last_oldest = oldest
            last_height = max(last_height, height)
            last_top = top_now
            rounds += 1
            if on_progress and rounds % 3 == 0:
                on_progress(rounds, 0, "seek")
            if os.environ.get("COLLECT_DEBUG"):
                print(
                    f"seek round={rounds} quiet={quiet} top={top_now} h={height} oldest={oldest} msgs={state.get('count')} pending={state.get('pending')}",
                    flush=True,
                )
        if not spotted:
            return [], False
        rows, _pending = read_rows()
        target_top = hit_top
        for row in rows:
            if row_id(row) == stop_id:
                target_top = float(row.get("top") or 0)
                break
        older: set[str] = set()
        for row in rows:
            status_id = row_id(row)
            top = float(row.get("top") or 0)
            if target_top is not None and top < target_top - 12:
                if status_id and status_id != stop_id:
                    older.add(status_id)
                continue
            add_tweet(status_id, row)
        if stop_id not in {row_id(row) for row in rows}:
            add_tweet(stop_id, {"url": f"https://x.com/i/web/status/{stop_id}", "text": "تغريدة"})
        if on_progress:
            on_progress(len(found), 0, "collect")
        stall = 0
        rounds = 0
        last_fp = ""
        while rounds < max_seek and stall < 5:
            if should_stop and should_stop():
                raise JobStopped
            close_popups(page)
            try:
                payload = page.evaluate(GROUP_READ_TWEETS_JS, {"dir": 1, "stopId": stop_id, "factor": GROUP_SCROLL_FACTOR}) or {}
            except Exception:
                payload = {}
            if not isinstance(payload, dict):
                payload = {}
            down_rows = [row for row in payload.get("tweets") or [] if isinstance(row, dict)]
            stop_row = next((row for row in down_rows if row_id(row) == stop_id), None)
            stop_top = float(stop_row.get("top") or 0) if stop_row else None
            for row in down_rows:
                status_id = row_id(row)
                if not status_id or status_id in older:
                    continue
                if stop_top is not None and status_id != stop_id and float(row.get("top") or 0) < stop_top - 12:
                    older.add(status_id)
                    continue
                add_tweet(status_id, row)
            if on_progress and found:
                on_progress(len(found), 0, "collect")
            fp = str(payload.get("fingerprint") or "")
            height = int(payload.get("scrollHeight") or 0)
            top = int(payload.get("scrollTop") or 0)
            client = int(payload.get("clientHeight") or 0) or 700
            latest = height > 0 and top + client >= height - 80
            pending = int(payload.get("pending") or 0)
            moved = bool(fp and last_fp and fp != last_fp) or int(payload.get("moved") or 0) > 8
            if pending or moved:
                stall = 0
                page.wait_for_timeout(1000)
            else:
                stall += 1
                page.wait_for_timeout(1000)
            last_fp = fp or last_fp
            rounds += 1
            if os.environ.get("COLLECT_DEBUG"):
                print(f"down round={rounds} found={len(found)} stall={stall} top={top} h={height} latest={latest}", flush=True)
        return found, True

    for _ in range(8):
        state = group_chat_state(page)
        if state.get("messages"):
            break
        page.wait_for_timeout(100)
    settle(1)
    stall = 0
    rounds = 0
    stall_limit = 12
    max_rounds = min(5000, max(400, (limit or 400) * 8))
    last_fp = ""
    last_h = 0

    while not reached and len(found) < limit and rounds < max_rounds and stall < stall_limit:
        if should_stop and should_stop():
            raise JobStopped
        before_count = len(found)
        close_popups(page)
        try:
            payload = page.evaluate(GROUP_READ_TWEETS_JS, {"dir": -1, "stopId": "", "factor": GROUP_SCROLL_FACTOR}) or {}
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        rows = payload.get("tweets") or []
        rows = [row for row in rows if isinstance(row, dict)]
        rows.sort(key=lambda row: float(row.get("top") or 0), reverse=True)
        for row in rows:
            if len(found) >= limit:
                break
            status_id = row_id(row)
            if not status_id or status_id in seen:
                continue
            add_tweet(status_id, row)
        if on_progress and len(found) != before_count:
            on_progress(len(found), limit, "collect")
        fp = str(payload.get("fingerprint") or "")
        height = int(payload.get("scrollHeight") or 0)
        at_edge = int(payload.get("scrollTop") or 0) <= 48 or bool(payload.get("atOlderEdge"))
        loading = bool(payload.get("loading")) or int(payload.get("pending") or 0) > 0
        grew = height > last_h + 24
        new_tweets = len(found) > before_count
        moved = bool(fp and last_fp and fp != last_fp) or int(payload.get("moved") or 0) > 8 or grew
        if new_tweets or loading or moved:
            stall = 0
        else:
            stall += 1
        if len(found) >= limit:
            break
        if loading:
            page.wait_for_timeout(2000)
        elif at_edge and not moved:
            client = int(payload.get("clientHeight") or 0) or 800
            unstick_group_chat(page, max(250, min(500, int(client * 0.2))))
            page.wait_for_timeout(2000)
        else:
            page.wait_for_timeout(2000)
        last_fp = fp or last_fp
        last_h = max(last_h, height)
        rounds += 1
        if os.environ.get("COLLECT_DEBUG"):
            print(
                f"round={rounds} found={len(found)} stall={stall} top={payload.get('scrollTop')} h={height} load={loading} edge={at_edge}",
                flush=True,
            )
    return found[:limit], reached


def reveal_status(page) -> None:
    try:
        clicked = page.evaluate(
            """() => {
              const words = /^(view|show|see post|yes,? view|عرض|عرض المنشور|نعم، عرض|عرض الوسائط|متابعة المشاهدة)$/i;
              const nodes = [...document.querySelectorAll('button, [role="button"], a')];
              const hit = nodes.find((node) => words.test((node.innerText || "").replace(/\\s+/g, " ").trim()) && node.getClientRects().length);
              if (!hit) return false;
              hit.click();
              return true;
            }"""
        )
        if clicked:
            page.wait_for_timeout(900)
    except Exception:
        pass


def read_status_gate(page) -> str:
    try:
        state = page.evaluate(
            """() => {
              const articles = [...document.querySelectorAll('article[data-testid="tweet"]')];
              const live = articles.find((article) => !/was deleted|deleted by the post author|تم حذف|غير متاح/i.test(article.innerText || ""));
              if (live) return "tweet";
              const chunks = [];
              for (const node of document.querySelectorAll('[data-testid="primaryColumn"], [data-testid="empty_state_header_text"], [data-testid="error-detail"], [role="status"]')) {
                chunks.push(node.innerText || "");
              }
              if (!chunks.length && document.body) chunks.push((document.body.innerText || "").slice(0, 1800));
              const text = chunks.join(" ").replace(/\\s+/g, " ");
              if (/was deleted|deleted by the post author|this post is unavailable|this post was deleted|doesn.?t exist|account is suspended|unable to view this post|هذه الصفحة غير موجودة|هذا المنشور غير متاح|تم حذف|حذف صاحب|الحساب موقوف/i.test(text)) return "gone";
              if (document.querySelector('[data-testid="empty_state_header_text"], [data-testid="error-detail"]')) return "gone";
              return "wait";
            }"""
        )
    except Exception:
        return "wait"
    return state if state in {"tweet", "gone", "wait"} else "wait"


QUICK_ACTIONS_ON_JS = r"""
({statusId, names}) => {
  if (!statusId) return false;
  const card = [...document.querySelectorAll('article[data-testid="tweet"], [data-testid="tweet"]')].find((article) =>
    [...article.querySelectorAll('a[href*="/status/"]')].some((node) => (node.getAttribute("href") || "").includes("/status/" + statusId)));
  if (!card) return false;
  const root = card.closest('[data-testid="cellInnerDiv"]') || card;
  const on = {repost: "unretweet", like: "unlike", bookmark: "removeBookmark"};
  const labels = {unretweet: /undo repost|unretweet|تم إعادة|إلغاء إعادة/i, unlike: /unlike|liked|أعجبني|معجب/i, removeBookmark: /remove bookmark|إزالة الإشارة/i};
  const has = (testid) => {
    if (root.querySelector('[data-testid="' + testid + '"]')) return true;
    const re = labels[testid];
    if (!re) return false;
    return [...root.querySelectorAll("button, [role='button']")].some((node) => re.test(node.getAttribute("aria-label") || ""));
  };
  return names.length > 0 && names.every((name) => on[name] && has(on[name]));
}
"""


BUTTONS_READY_JS = r"""
({statusId, names}) => {
  const want = {
    like: ["like", "unlike"],
    repost: ["retweet", "unretweet"],
    bookmark: ["bookmark", "removeBookmark"]
  };
  const roots = [...document.querySelectorAll('article, [data-testid="tweet"], [data-testid="cellInnerDiv"]')];
  const card = roots.find((node) => [...node.querySelectorAll('a[href*="/status/"]')].some((link) => (link.getAttribute("href") || "").includes("/status/" + statusId)));
  if (!card) return false;
  return names.length > 0 && names.every((name) => (want[name] || []).some((id) => card.querySelector('[data-testid="' + id + '"]')));
}
"""


def tweet_flags_from_api(data, status_id: str) -> dict | None:
    """Find the tweet in X's own API reply and read its like / repost / bookmark state."""
    stack = [data]
    seen = 0
    while stack and seen < 20000:
        node = stack.pop()
        seen += 1
        if isinstance(node, dict):
            legacy = node.get("legacy")
            if str(node.get("rest_id") or "") == status_id and isinstance(legacy, dict):
                return {
                    "like": bool(legacy.get("favorited")),
                    "repost": bool(legacy.get("retweeted")),
                    "bookmark": bool(legacy.get("bookmarked")),
                }
            stack.extend(node.values())
        elif isinstance(node, list):
            stack.extend(node)
    return None


def open_status_page(page, url: str, skip_if_on: list[str] | None = None) -> tuple[str | None, str]:
    """Open a tweet. With skip_if_on, return (path, "already_on") the moment the
    tweet's buttons show every listed action already on, without waiting for the
    rest of the page to load."""
    match = re.search(r"status/(\d{6,25})", url or "")
    status_id = match.group(1) if match else ""
    canonical = normalize_status_path(url) or ""
    if status_id:
        target = f"https://x.com/i/web/status/{status_id}"
    elif canonical:
        target = "https://x.com" + canonical
    else:
        return None, "fail"
    quick = [name for name in (skip_if_on or []) if name in ACTION_CONTROLS]
    if skip_if_on and len(quick) != len(skip_if_on):
        quick = []
    # X's page asks its API for the tweet before drawing it. Listening to that reply
    # gives the button states before they appear on screen. Only replies that have
    # finished downloading are read: reading one that is still arriving waits with no
    # time limit, so a reply that stalls halfway would freeze the task on this tweet.
    replies: list = []
    api_flags: dict | None = None

    def on_finished(request):
        address = request.url
        if "/graphql/" in address and ("TweetDetail" in address or "TweetResultByRestId" in address):
            replies.append(request)

    if quick and status_id:
        page.on("requestfinished", on_finished)
    try:
        try:
            page.goto(target, wait_until="commit" if quick else "domcontentloaded", timeout=20_000)
        except Exception:
            return None, "fail"
        revealed = False
        deadline = time.monotonic() + (12 if quick else 8)
        while time.monotonic() < deadline:
            if quick and status_id:
                while replies and api_flags is None:
                    request = replies.pop(0)
                    try:
                        response = request.response()
                        api_flags = tweet_flags_from_api(response.json(), status_id) if response else None
                    except Exception:
                        api_flags = None
                    if api_flags is not None and os.environ.get("COLLECT_DEBUG"):
                        print(f"tweet {status_id} api state: {api_flags}", flush=True)
                if api_flags is not None and all(api_flags.get(name) for name in quick):
                    return canonical or f"/i/web/status/{status_id}", "already_on"
                try:
                    if page.evaluate(QUICK_ACTIONS_ON_JS, {"statusId": status_id, "names": quick}):
                        return canonical or f"/i/web/status/{status_id}", "already_on"
                    if page.evaluate(BUTTONS_READY_JS, {"statusId": status_id, "names": quick}):
                        return canonical or f"/i/web/status/{status_id}", ""
                except Exception:
                    pass
            state = read_status_gate(page)
            if state == "gone":
                return None, "gone"
            if state == "tweet":
                href = ""
                if status_id:
                    try:
                        href = page.evaluate(
                            """(id) => {
                              const link = [...document.querySelectorAll('a[href*="/status/"]')]
                                .find((node) => (node.getAttribute("href") || "").includes("/status/" + id));
                              return link ? (link.getAttribute("href") || "") : "";
                            }""",
                            status_id,
                        ) or ""
                    except Exception:
                        href = ""
                return normalize_status_path(str(href)) or canonical or f"/i/web/status/{status_id}", ""
            if not revealed and time.monotonic() + 5 < deadline:
                pass
            elif not revealed:
                reveal_status(page)
                revealed = True
                if read_status_gate(page) == "gone":
                    return None, "gone"
            page.wait_for_timeout(120)
        if read_status_gate(page) == "gone":
            return None, "gone"
        return None, "fail"
    finally:
        if quick and status_id:
            try:
                page.remove_listener("requestfinished", on_finished)
            except Exception:
                pass


def all_actions_already_on(page, path: str, actions: list[str], timeout_s: float = 1.5) -> bool:
    """Read the tweet's buttons as soon as they appear. True only when every
    requested action is already on, so the tweet can be skipped without waiting
    for the rest of the page to load."""
    if not actions or any(action not in ACTION_CONTROLS for action in actions):
        return False
    match = re.search(r"status/(\d{6,25})", path or "")
    status_id = match.group(1) if match else ""
    deadline = time.monotonic() + timeout_s
    while True:
        state = read_action_state(page, status_id, actions) or {}
        rows = [state.get(action) if isinstance(state.get(action), dict) else {} for action in actions]
        if rows and all(row.get("on") for row in rows):
            return True
        if rows and all(row.get("on") or row.get("box") for row in rows):
            return False
        if time.monotonic() >= deadline:
            return False
        page.wait_for_timeout(150)


DONE_HISTORY_PATH = DATA_DIR / "done_history.json"
DONE_HISTORY_HOURS = 8
done_history_lock = threading.Lock()
done_history: dict[str, dict[str, dict[str, float]]] = {}


def prune_done_history_unlocked() -> None:
    cutoff = time.time() - DONE_HISTORY_HOURS * 3600
    for account in list(done_history):
        tweets = done_history[account]
        for status_id in list(tweets):
            kept = {action: stamp for action, stamp in tweets[status_id].items() if stamp >= cutoff}
            if kept:
                tweets[status_id] = kept
            else:
                del tweets[status_id]
        if not tweets:
            del done_history[account]


def load_done_history() -> None:
    loaded = read_private_json(DONE_HISTORY_PATH) or {}
    rows = loaded.get("accounts")
    if not isinstance(rows, dict):
        return
    with done_history_lock:
        for account, tweets in rows.items():
            if not isinstance(tweets, dict):
                continue
            clean: dict[str, dict[str, float]] = {}
            for status_id, done in tweets.items():
                if isinstance(done, dict):
                    clean[str(status_id)] = {str(a): float(t) for a, t in done.items() if isinstance(t, (int, float))}
            done_history[str(account)] = clean
        prune_done_history_unlocked()


def tweet_status_id(url: str) -> str:
    match = re.search(r"status/(\d{6,25})", url or "")
    return match.group(1) if match else ""


def same_x_account(account: str) -> set[str]:
    """The added accounts that are this one X account (the same @name signed in more than once, in two or three
    of the app's accounts), by their profile keys, this one among them. Their 8-hour memory is one: a tweet one
    of them acted on, the others skip, so the X account never acts twice on it."""
    twins = {account}
    if not account:
        return twins
    with sessions_lock:
        rows = [(profile_key(row["token"]), str(row.get("username") or "").lower()) for row in saved_sessions]
    name = next((found for key, found in rows if key == account and found), "") or str(account_names.get(account) or "").lower()
    if name:
        twins.update(key for key, found in rows if found == name)
    return twins


def already_done_recently(account: str, status_id: str, actions: list[str]) -> bool:
    """True when every requested action was done on this tweet in the last 8 hours by this account, or by
    another of the app's accounts that is the same X account (see same_x_account)."""
    if not account or not status_id or not actions:
        return False
    cutoff = time.time() - DONE_HISTORY_HOURS * 3600
    twins = same_x_account(account)
    with done_history_lock:
        done: dict[str, float] = {}
        for twin in twins:
            for action, stamp in ((done_history.get(twin) or {}).get(status_id) or {}).items():
                done[action] = max(done.get(action, 0.0), float(stamp))
        return all(done.get(action, 0) >= cutoff for action in actions)


ACTION_COUNTS_PATH = DATA_DIR / "action_counts.json"
action_counts_lock = threading.Lock()
ACTION_NAMES = ("repost", "like", "bookmark", "comment")
# The totals shown at the top of the page, kept for each account on its own (keyed by profile_key).
action_counts: dict[str, dict[str, int]] = {}


def zero_counts() -> dict[str, int]:
    return {action: 0 for action in ACTION_NAMES}


def account_counts(account: str) -> dict[str, int]:
    """A copy of one account's totals (zeros when it has none yet)."""
    with action_counts_lock:
        row = action_counts.get(account) or {}
    return {action: int(row.get(action) or 0) for action in ACTION_NAMES}


def load_action_counts() -> None:
    loaded = read_private_json(ACTION_COUNTS_PATH) or {}
    by_account = loaded.get("by_account") if isinstance(loaded, dict) else None
    with action_counts_lock:
        action_counts.clear()
        if isinstance(by_account, dict):
            for key, row in by_account.items():
                if not isinstance(row, dict):
                    continue
                action_counts[str(key)] = {action: max(0, int(row.get(action) or 0)) for action in ACTION_NAMES}


def count_successes(outcome: dict[str, str], account: str = "") -> None:
    """Add this tweet's successful actions to this account's totals shown at the top of the page."""
    done = [action for action, note in (outcome or {}).items() if note == "تم التنفيذ" and action in ACTION_NAMES]
    if not done or not account:
        return
    with action_counts_lock:
        row = action_counts.get(account)
        if row is None:
            row = action_counts[account] = zero_counts()
        for action in done:
            row[action] += 1
        try:
            write_private_json(ACTION_COUNTS_PATH, {"by_account": action_counts})
        except Exception:
            pass
    stats_changed()


def remember_done(account: str, status_id: str, outcome: dict[str, str]) -> None:
    """Save the actions that are now on for this tweet (done now or already on)."""
    if not account or not status_id:
        return
    now = time.time()
    finished = [
        action for action, note in (outcome or {}).items()
        if (action in ACTION_CONTROLS and (note == "تم التنفيذ" or "مفعّل مسبقًا" in str(note)))
        or (action == "comment" and (note == "تم التنفيذ" or str(note).startswith("أُرسل الطلب")))
    ]
    if not finished:
        return
    with done_history_lock:
        tweets = done_history.setdefault(account, {})
        record = tweets.setdefault(status_id, {})
        for action in finished:
            record[action] = now
        prune_done_history_unlocked()
        try:
            write_private_json(DONE_HISTORY_PATH, {"version": 1, "accounts": done_history})
        except Exception:
            pass


# Two tweets in a row that would not open: the browser is closed for a while, then the task goes back
# to the first of them. The first time for 3.5 minutes, the second time for 1 minute; the third time
# the task stops (X is likely not letting this account open tweets now).
TWEET_FAIL_PAUSES = (210, 60)


def open_task_tweet(page, url: str, skip_if_on):
    """Open a task's tweet with two tries. Returns (opened path or None, reason)."""
    opened, reason = open_status_page(page, url, skip_if_on)
    if not opened and reason != "gone":
        opened, reason = open_status_page(page, url, skip_if_on)
    return opened, reason


class TweetsKeptFailing(Exception):
    """Two tweets in a row would not open a third time in one task, so it stops. results: what it did
    before (with the two that would not open); at: the number of the tweet it stopped at (from 1)."""

    def __init__(self, results: list[dict], at: int):
        super().__init__("تعذّر فتح التغريدات ثلاث مرات")
        self.results = results
        self.at = at


class FailedTweets:
    """The tweets of a task that would not open (a deleted one does not count). Two in a row that would
    not open close the browser for a pause, then the task goes back to the first of them: the first
    pause is TWEET_FAIL_PAUSES[0] seconds, the second TWEET_FAIL_PAUSES[1]; the third time, the task
    stops."""

    def __init__(self):
        self.last: int | None = None   # the tweet tried before, when it would not open
        self.pauses = 0                # the pauses this task has had

    def opened(self) -> None:
        self.last = None

    def failed(self, index: int) -> int | None:
        """This tweet would not open. Returns the first of the two in a row that would not (to go back to
        after a pause), or None to go on."""
        before, self.last = self.last, index
        if before is None:
            return None
        self.last = None
        return before

    def next_pause(self) -> int | None:
        """How many seconds the next pause lasts; None when the task has had them all and stops."""
        if self.pauses >= len(TWEET_FAIL_PAUSES):
            return None
        self.pauses += 1
        return TWEET_FAIL_PAUSES[self.pauses - 1]


def pause_after_failures(should_stop=None, on_progress=None, total: int = 0, after_reopen=None,
                         seconds: int = TWEET_FAIL_PAUSES[0], phase: str = "pause"):
    """Close the browser for seconds, then reopen it. Returns the new page, or None when the task was
    stopped during the wait (the browser then stays closed) or the browser cannot be reopened here.
    phase: "pause" for the first pause, "pause_again" for the next one (said on the page)."""

    def wait_closed() -> bool:
        end = time.monotonic() + seconds
        shown = None
        while (left := math.ceil(end - time.monotonic())) > 0:
            if should_stop and should_stop():
                return False
            if on_progress and (shown is None or shown - left >= 5):
                on_progress(left, total, phase)
                shown = left
            time.sleep(min(1.0, max(0.0, end - time.monotonic())))
        if on_progress:
            on_progress(0, total, phase)
        return True

    new_page = restart_browser(wait_closed)
    if new_page is not None and after_reopen:
        after_reopen(new_page)
    return new_page


FAST_ACTION_JS = r"""
async ({tweetId, actions}) => {
  if (!document.querySelector(".r-4ny6nl")) {
    document.body.insertAdjacentHTML("beforeend", '<svg viewBox="0 0 24 24" class="r-4ny6nl" aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden"><g><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path><path d="M 10,30 C 122,187 104,187 103,126 h 138 s 227,202 174,135 C 152,101 34,196 34,87 h 6 s 226,188 106,153 C 231,147 29,174 201,196 h 204 s 228,148 25,98 C 50,176 119,37 179,166 h 238 s 165,79 149,248 C 174,109 209,150 145,241 h 147 s 232,158 29,130 C 93,223 109,131 25,248 h 32 s 0,188 126,131 C 60,243 17,86 23,33 h 192 s 126,253 172,188 C 126,73 139,14 3,216 h 30 s 90,215 111,153 C 155,162 193,46 245,226 h 92 s 191,137 89,230 C 248,58 105,73 70,150 h 125 s 16,137 172,157 C 95,36 92,165 130,133 h 40 s 77,193 26,205 C 178,240 72,243 224,186 h 119 s 90,85 129,109 C 105,22 118,126 102,5 h 150 s 31,50 184,95 C 25,0 253,76 191,143 h 46 s 237,163 152,173 C 188,70 200,28 131,107 h 173 s 154,236 38,62 C 108,128 158,54 218,65 h 200 s 231,231 210,236" fill="#1d9bf008"></path></g></svg>');
  }
  const bearer = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
  const ops = {
    like: ["FavoriteTweet", "lI07N6Otwv1PhnEgXILM7A"],
    repost: ["CreateRetweet", "mbRO74GrOvSfRcJnlMapnQ"],
    bookmark: ["CreateBookmark", "aoDbu3RHznuiSkQ9aNM67Q"]
  };
  const OPEN_TEMPLATES = {"TweetDetail":{"id":"dQDdKtt882nl-Km98FJGSQ","variables":"{\"focalTweetId\":\"2120842815139623164\",\"with_rux_injections\":false,\"rankingMode\":\"Relevance\",\"includePromotedContent\":true,\"withCommunity\":true,\"withQuickPromoteEligibilityTweetFields\":true,\"withBirdwatchNotes\":true,\"withVoice\":true}","features":"{\"rweb_video_screen_enabled\":false,\"rweb_cashtags_enabled\":true,\"profile_label_improvements_pcf_label_in_post_enabled\":true,\"responsive_web_profile_redirect_enabled\":true,\"rweb_tipjar_consumption_enabled\":false,\"verified_phone_label_enabled\":false,\"creator_subscriptions_tweet_preview_api_enabled\":true,\"responsive_web_graphql_timeline_navigation_enabled\":true,\"premium_content_api_read_enabled\":false,\"communities_web_enable_tweet_community_results_fetch\":true,\"c9s_tweet_anatomy_moderator_badge_enabled\":true,\"responsive_web_grok_analyze_button_fetch_trends_enabled\":false,\"responsive_web_grok_analyze_post_followups_enabled\":true,\"rweb_cashtags_composer_attachment_enabled\":true,\"responsive_web_jetfuel_frame\":true,\"rweb_sports_post_context_enabled\":true,\"x_elections_post_context_enabled\":true,\"responsive_web_grok_share_attachment_enabled\":true,\"responsive_web_grok_annotations_enabled\":true,\"articles_preview_enabled\":true,\"responsive_web_edit_tweet_api_enabled\":true,\"rweb_conversational_replies_downvote_enabled\":false,\"graphql_is_translatable_rweb_tweet_is_translatable_enabled\":true,\"view_counts_everywhere_api_enabled\":true,\"longform_notetweets_consumption_enabled\":true,\"responsive_web_twitter_article_tweet_consumption_enabled\":true,\"content_disclosure_indicator_enabled\":true,\"content_disclosure_ai_generated_indicator_enabled\":true,\"responsive_web_grok_show_grok_translated_post\":true,\"responsive_web_grok_analysis_button_from_backend\":true,\"post_ctas_fetch_enabled\":false,\"freedom_of_speech_not_reach_fetch_enabled\":true,\"standardized_nudges_misinfo\":true,\"tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled\":true,\"longform_notetweets_rich_text_read_enabled\":true,\"longform_notetweets_inline_media_enabled\":false,\"responsive_web_nested_quote_preview_enabled\":true,\"responsive_web_grok_image_annotation_enabled\":true,\"responsive_web_grok_imagine_annotation_enabled\":true,\"responsive_web_made_on_x_label_enabled\":false,\"responsive_web_grok_community_note_auto_translation_is_enabled\":true,\"responsive_web_enhance_cards_enabled\":false}","fieldToggles":"{\"withPayments\":false,\"withDmBlocks\":false,\"withArticleRichContentState\":true,\"withArticlePlainText\":false,\"withArticleSummaryText\":true,\"withArticleVoiceOver\":true,\"withGrokAnalyze\":false,\"withDisallowedReplyControls\":false}"},"TweetResultByRestId":{"id":"U8lc5aomF5krJzZ9vJ9wxg","variables":"{\"tweetId\":\"2120842815139623164\",\"includePromotedContent\":true,\"withBirdwatchNotes\":true,\"withVoice\":true,\"withCommunity\":true}","features":"{\"creator_subscriptions_tweet_preview_api_enabled\":true,\"premium_content_api_read_enabled\":false,\"communities_web_enable_tweet_community_results_fetch\":true,\"c9s_tweet_anatomy_moderator_badge_enabled\":true,\"responsive_web_grok_analyze_button_fetch_trends_enabled\":false,\"responsive_web_grok_analyze_post_followups_enabled\":true,\"rweb_cashtags_composer_attachment_enabled\":true,\"responsive_web_jetfuel_frame\":true,\"rweb_sports_post_context_enabled\":true,\"x_elections_post_context_enabled\":true,\"responsive_web_grok_share_attachment_enabled\":true,\"responsive_web_grok_annotations_enabled\":true,\"articles_preview_enabled\":true,\"responsive_web_edit_tweet_api_enabled\":true,\"rweb_conversational_replies_downvote_enabled\":false,\"graphql_is_translatable_rweb_tweet_is_translatable_enabled\":true,\"view_counts_everywhere_api_enabled\":true,\"longform_notetweets_consumption_enabled\":true,\"responsive_web_twitter_article_tweet_consumption_enabled\":true,\"content_disclosure_indicator_enabled\":true,\"content_disclosure_ai_generated_indicator_enabled\":true,\"responsive_web_grok_show_grok_translated_post\":true,\"responsive_web_grok_analysis_button_from_backend\":true,\"post_ctas_fetch_enabled\":false,\"rweb_cashtags_enabled\":true,\"freedom_of_speech_not_reach_fetch_enabled\":true,\"standardized_nudges_misinfo\":true,\"tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled\":true,\"longform_notetweets_rich_text_read_enabled\":true,\"longform_notetweets_inline_media_enabled\":false,\"profile_label_improvements_pcf_label_in_post_enabled\":true,\"responsive_web_profile_redirect_enabled\":true,\"rweb_tipjar_consumption_enabled\":false,\"verified_phone_label_enabled\":false,\"responsive_web_nested_quote_preview_enabled\":true,\"responsive_web_grok_image_annotation_enabled\":true,\"responsive_web_grok_imagine_annotation_enabled\":true,\"responsive_web_made_on_x_label_enabled\":false,\"responsive_web_grok_community_note_auto_translation_is_enabled\":true,\"responsive_web_graphql_timeline_navigation_enabled\":true}","fieldToggles":"{\"withArticleRichContentState\":true,\"withArticlePlainText\":false,\"withArticleSummaryText\":true,\"withArticleVoiceOver\":true,\"withPayments\":false}"}};
  const started = Date.now();
  while (!self.webpackChunk_twitter_responsive_web && Date.now() - started < 8000) {
    await new Promise((done) => setTimeout(done, 40));
  }
  const chunks = self.webpackChunk_twitter_responsive_web;
  if (!chunks) return {};
  const req = await new Promise((resolve) => {
    chunks.push([["ggfast"], {}, (got) => resolve(got)]);
  });
  let sign = null;
  try {
    let chunkId = 59924;
    let modId = 564498;
    for (const chunk of chunks) {
      const mods = chunk && chunk[1];
      if (!mods) continue;
      for (const fn of Object.values(mods)) {
        let source = "";
        try { source = Function.prototype.toString.call(fn); } catch (error) { continue; }
        if (source.indexOf("x-client-transaction-id") < 0) continue;
        const match = source.match(/\.e\((\d+)\)\.then\(\(\)=>[A-Za-z]\((\d+)\)\)\.then\([A-Za-z]=>[A-Za-z]\([A-Za-z]\.default\(\)\)\)/);
        if (match) { chunkId = Number(match[1]); modId = Number(match[2]); }
      }
    }
    const factory = await req.e(chunkId).then(() => req(modId));
    sign = await factory.default();
  } catch (error) {}
  const ct0 = decodeURIComponent((document.cookie.match(/(?:^|; )ct0=([^;]+)/) || [])[1] || "");
  if (!ct0) return {};
  const lang = ((document.documentElement && document.documentElement.lang) || navigator.language || "en").slice(0, 2);
  const signedHeaders = async (path, method) => {
    let tx = "";
    if (sign) {
      for (let attempt = 0; attempt < 12 && !tx; attempt++) {
        try { tx = await sign(path, method); }
        catch (error) { await new Promise((done) => setTimeout(done, 60)); }
      }
    }
    const headers = {
      authorization: "Bearer " + bearer,
      "x-csrf-token": ct0,
      "x-twitter-auth-type": "OAuth2Session",
      "x-twitter-active-user": "yes",
      "x-twitter-client-language": lang
    };
    if (tx) headers["x-client-transaction-id"] = tx;
    return headers;
  };
  const startOpen = async (name) => {
    const spec = OPEN_TEMPLATES[name];
    if (!spec) return null;
    const variables = JSON.parse(spec.variables);
    if (variables.focalTweetId) variables.focalTweetId = String(tweetId);
    if (variables.tweetId) variables.tweetId = String(tweetId);
    const path = "/i/api/graphql/" + spec.id + "/" + name;
    const url = new URL("https://x.com" + path);
    url.searchParams.set("variables", JSON.stringify(variables));
    url.searchParams.set("features", spec.features);
    if (spec.fieldToggles) url.searchParams.set("fieldToggles", spec.fieldToggles);
    const headers = await signedHeaders(path, "GET");
    fetch(url, {method: "GET", credentials: "include", headers}).catch(() => null);
  };
  await Promise.all(["TweetDetail", "TweetResultByRestId"].map((name) => startOpen(name).catch(() => null)));
  const out = {};
  let sent = false;
  for (const action of actions) {
    const pair = ops[action];
    if (!pair) continue;
    if (sent) await new Promise((done) => setTimeout(done, 300 + Math.floor(Math.random() * 501)));
    sent = true;
    const name = pair[0];
    const queryId = pair[1];
    const path = "/i/api/graphql/" + queryId + "/" + name;
    const variables = action === "repost" ? {tweet_id: String(tweetId), dark_request: false} : {tweet_id: String(tweetId)};
    const headers = await signedHeaders(path, "POST");
    headers["content-type"] = "application/json";
    try {
      const response = await fetch("https://x.com" + path, {
        method: "POST",
        credentials: "include",
        headers,
        body: JSON.stringify({variables, queryId})
      });
      const raw = await response.text();
      const already = /already|duplicate|327|139/i.test(raw);
      let errors = [];
      try { errors = (JSON.parse(raw).errors) || []; } catch (error) {}
      const ok = (response.status === 200 && errors.length === 0) || already;
      out[action] = {ok, already, error: (errors[0] && errors[0].message) || ("HTTP " + response.status)};
    } catch (error) {
      out[action] = {ok: false, error: String(error).slice(0, 120)};
    }
  }
  return out;
}
"""


def pause_span(low: float, high: float, should_stop=None) -> None:
    """Wait a random gap. Returns early when the task is stopped."""
    end = time.monotonic() + random.uniform(low, high)
    while time.monotonic() < end:
        if should_stop and should_stop():
            return
        time.sleep(min(0.1, max(0.0, end - time.monotonic())))


def apply_actions_immediately(page, url: str, actions: list[str]) -> dict[str, str]:
    """Go to the tweet address only, then send the open requests and the buttons.
    The tweet card is not waited for."""
    match = re.search(r"status/(\d{6,25})", url or "")
    if not match:
        return {}
    status_id = match.group(1)
    wanted = [action for action in actions if action in {"repost", "like", "bookmark"}]
    if not wanted:
        return {}
    trace_click("تنفيذ مباشر: طلب الفتح ثم الزر دون انتظار ظهور التغريدة")
    try:
        page.goto(f"https://x.com/i/web/status/{status_id}", wait_until="commit", timeout=20_000)
    except Exception as exc:
        if browser_closed_error(exc):
            raise
        trace_click("تنفيذ مباشر: تعذّر فتح العنوان " + type(exc).__name__)
        return {}
    try:
        payload = page.evaluate(FAST_ACTION_JS, {"tweetId": status_id, "actions": wanted}) or {}
    except Exception as exc:
        if browser_closed_error(exc):
            raise
        trace_click("تنفيذ مباشر فشل: " + type(exc).__name__)
        return {}
    outcome: dict[str, str] = {}
    for action in wanted:
        row = payload.get(action) if isinstance(payload, dict) else None
        if not isinstance(row, dict) or not row.get("ok"):
            trace_click(f"تنفيذ مباشر {action} لم يقبل: {(row or {}).get('error') or 'بلا رد'}")
            continue
        outcome[action] = "مفعّل مسبقًا — تم التجاوز" if row.get("already") else "تم التنفيذ"
    if outcome:
        trace_click("تنفيذ مباشر: " + "، ".join(f"{key}={value}" for key, value in outcome.items()))
    return outcome


# ---------------------------------------------------------------------------- إعادة المحاولة للفاشلة
# مهمة اكتملت وفيها إجراءات فشلت على بعض التغريدات: «إعادة المحاولة للفاشلة» تبدأ مهمة جديدة على نفس الحساب
# بتلك التغريدات وحدها، ولكل تغريدة الإجراءات التي فشلت عليها فقط (item["only"]).
# الرتويت والإعجاب والمرجعية آمنة الإعادة دائمًا: تُقرأ حالة الزر قبل النقر فلا يُلغى ما نجح. أما التعليق فلا
# يُعاد إلا إن فشل قبل إرساله، حتى لا يُنشر ردّان على التغريدة نفسها.
COMMENT_RETRY_SAFE = (
    "تعذر فتح التغريدة", "تعذر العثور على المنشور", "لم يُرجع النموذج تعليقًا صالحًا", "لم يظهر مربع كتابة الرد",
    "زر النشر بقي معطّلًا", "لم تُفتح التغريدة في الوقت المناسب", "الحساب وصل حد الردود مؤقتًا",
)


def item_actions(item: dict, actions: list[str]) -> list[str]:
    """The actions to take on this tweet: all of the task's, or in a retry of the failed only those that failed."""
    only = item.get("only") if isinstance(item, dict) else None
    if isinstance(only, list):
        return [action for action in actions if action in only]
    return list(actions)


def action_failed(note: str) -> bool:
    """As the page counts it: not done, and not skipped (on already, done before, deleted, not available)."""
    note = str(note or "")
    return note != "تم التنفيذ" and not any(word in note for word in ("مفعّل", "تخطي", "تجاوز"))


def action_retryable(action: str, note: str) -> bool:
    if not action_failed(note):
        return False
    if action != "comment":
        return True
    note = str(note or "")
    if note.startswith("تعذر نشر التعليق: "):
        note = note[len("تعذر نشر التعليق: "):]
    return note in COMMENT_RETRY_SAFE or note.startswith("تعذر توليد التعليق") or note.startswith("تعذر الاتصال")


def failed_retry_items(job: dict) -> list[dict]:
    """The finished task's tweets with an action to retry, each with only those actions."""
    out: list[dict] = []
    seen: set[str] = set()
    for row in job.get("results") or []:
        if not isinstance(row, dict):
            continue
        url = str(row.get("url") or "")
        only = [action for action, note in (row.get("actions") or {}).items()
                if action in ALLOWED_ACTIONS and action_retryable(action, note)]
        if not only or not url or url in seen or tweet_is_ignored(url):
            continue
        seen.add(url)
        out.append({"url": url, "text": str(row.get("text") or ""), "only": only})
    return out


def failed_retry_count(job: dict) -> int:
    if job.get("status") != "done" or job.get("retried_by") or (job.get("kind") or "") != "execute":
        return 0
    return len(failed_retry_items(job))


def visit_and_apply(page, items: list[dict], task_actions: list[str], on_progress=None, on_snapshot=None, should_stop=None, account: str = "") -> list[dict]:
    results: list[dict] = []
    total = len(items)
    failures = FailedTweets()
    # Where each tweet's result starts in results: going back after a pause drops them from there on.
    starts: dict[int, int] = {}
    if on_progress:
        on_progress(0, total, "act")
    index = -1
    acted = False
    while index + 1 < total:
        index += 1
        item = items[index]
        actions = item_actions(item, task_actions)      # (all the task's, or only those that failed on it before)
        if should_stop and should_stop():
            break
        starts[index] = len(results)
        result = {"url": item.get("url", ""), "text": item.get("text", ""), "actions": {}}
        status_id = tweet_status_id(str(item.get("url") or ""))
        if already_done_recently(account, status_id, actions):
            # Done by this account in the last 8 hours: skip without opening the tweet.
            result["actions"] = {key: "سبق التفاعل خلال ٨ ساعات — تم التخطي" for key in actions}
            results.append(result)
            if on_snapshot:
                on_snapshot(list(results))
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        if acted:
            pause_span(0.15, 0.4, should_stop)
            if should_stop and should_stop():
                break
        acted = True
        try:
            opened, reason = open_task_tweet(page, str(item.get("url") or ""), actions)
        except Exception as exc:
            if browser_closed_error(exc):
                if on_snapshot and results:
                    on_snapshot(list(results))
                raise BrowserClosed() from exc
            raise
        if opened or reason == "gone":
            failures.opened()
        else:
            back = failures.failed(index)
            new_page = None
            if back is not None:
                seconds = failures.next_pause()
                if seconds is None:
                    # A third time: the task stops here, with what it did (these two would not open).
                    result["actions"] = {key: "تعذر فتح التغريدة" for key in actions}
                    results.append(result)
                    if on_snapshot:
                        on_snapshot(list(results))
                    raise TweetsKeptFailing(results, index + 1)
                new_page = pause_after_failures(should_stop, on_progress, total, None, seconds,
                                                "pause" if failures.pauses == 1 else "pause_again")
            if new_page is not None:
                # Back to the first of the two that would not open; what was recorded from it on goes.
                page = new_page
                del results[starts[back]:]
                if on_snapshot:
                    on_snapshot(list(results))
                if on_progress:
                    on_progress(back, total, "act")
                index = back - 1
                continue
        if not opened:
            note = "محذوفة — تم التخطي" if reason == "gone" else "تعذر فتح التغريدة"
            result["actions"] = {key: note for key in actions}
            results.append(result)
            if on_snapshot:
                on_snapshot(list(results))
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        if tweet_is_ignored("https://x.com" + opened):
            # The opened tweet's author is an ignored account: take no action and leave no trace.
            forget_collected("https://x.com" + opened)
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        result["url"] = "https://x.com" + opened
        try:
            already_on = reason == "already_on" or all_actions_already_on(page, opened, actions)
        except Exception as exc:
            if browser_closed_error(exc):
                raise BrowserClosed() from exc
            already_on = False
        if already_on:
            result["actions"] = {key: "مفعّل مسبقًا — تم التجاوز" for key in actions}
            remember_done(account, status_id or tweet_status_id(opened), result["actions"])
            results.append(result)
            if on_snapshot:
                on_snapshot(list(results))
            if on_progress:
                on_progress(index + 1, total, "act")
            continue
        close_popups(page)
        try:
            result["actions"] = apply_actions_on_path(page, opened, actions)
        except Exception as exc:
            if browser_closed_error(exc):
                raise BrowserClosed() from exc
            result["actions"] = {key: "تعذر تنفيذ الإجراء بعد فتح التغريدة" for key in actions}
        remember_done(account, status_id or tweet_status_id(opened), result["actions"])
        count_successes(result["actions"], account)
        results.append(result)
        if on_snapshot:
            on_snapshot(list(results))
        if on_progress:
            on_progress(index + 1, total, "act")
    return results


def fetch_group_names(auth_token: str, pin: str, settle: bool = False, settle_seconds: int = 10) -> tuple[list[str], str | None]:
    def work(page):
        if not ensure_logged_in(page):
            return [], "الجلسة غير مسجّلة الدخول."
        handle = read_session_username(page)
        if handle:
            remember_session(auth_token, handle, pin)
        error = open_chat(page, pin)
        if error:
            return [], error
        show_groups_only(page)
        if settle:
            page.wait_for_timeout(max(1, min(120, int(settle_seconds))) * 1000)
        names = collect_groups(page)
        if not names:
            return [], "فُتحت الدردشة لكن لم تظهر قروبات."
        return names, None
    try:
        return run_on_browser(auth_token, work)
    except Exception:
        return [], "تعذّر فتح المتصفح."


class JobStopped(Exception):
    pass


# Arguments of each group task, kept in memory so the retry button can continue it.
job_run_args: dict[str, tuple] = {}


class BrowserClosed(Exception):
    """Chromium died or the tab was closed. The job can reopen and continue."""


def browser_closed_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    return (
        "has been closed" in text
        or "target closed" in text
        or "connection closed" in text
        or "browser closed" in text
    )


def job_cancelled(job_id: str) -> bool:
    with jobs_lock:
        job = jobs.get(job_id) or {}
        return bool(job.get("cancel"))


# Each account's line of tasks. A task added while its account is working waits («في الانتظار») and starts
# by itself when the ones before it end, first come first served. Accounts do not wait for one another.
MAX_TASKS_PER_ACCOUNT = 10          # in one account's line: the working one and those waiting
account_turns = threading.Condition()
account_lines: dict[str, deque] = {}


def account_line_join(auth_digest: str, job_id: str) -> int:
    """Put a task at the end of its account's line. Returns how many tasks are before it (0: its turn now)."""
    with account_turns:
        line = account_lines.setdefault(auth_digest, deque())
        if job_id not in line:
            line.append(job_id)
        return list(line).index(job_id)


def account_line_size(auth_digest: str) -> int:
    with account_turns:
        return len(account_lines.get(auth_digest) or ())


def account_line_leave(auth_digest: str, job_id: str) -> None:
    with account_turns:
        line = account_lines.get(auth_digest)
        if line is not None:
            try:
                line.remove(job_id)
            except ValueError:
                pass
        account_turns.notify_all()


def waiting_message(ahead: int) -> str:
    if ahead <= 1:
        return "في الانتظار: تبدأ تلقائيًا بعد انتهاء المهمة السابقة على هذا الحساب."
    if ahead == 2:
        return "في الانتظار: تبدأ تلقائيًا بعد انتهاء مهمتين قبلها على هذا الحساب."
    return f"في الانتظار: تبدأ تلقائيًا بعد انتهاء {ahead} مهام قبلها على هذا الحساب."


def wait_account_turn(auth_digest: str, job_id: str) -> bool:
    """Wait until the task is first in its account's line. False when it was stopped while it waited."""
    shown = None
    while True:
        with account_turns:
            line = account_lines.setdefault(auth_digest, deque())
            if job_id not in line:
                line.append(job_id)
            ahead = list(line).index(job_id)
        if ahead == 0:
            return True
        if job_cancelled(job_id):
            account_line_leave(auth_digest, job_id)
            return False
        if ahead != shown:
            publish_job(job_id, phase="queue", message=waiting_message(ahead))
            shown = ahead
        with account_turns:
            account_turns.wait(1.0)


def run_group_job_in_turn(job_id: str, auth_digest: str, start_phase: str, start_message: str, args: tuple) -> None:
    """A group task in its account's line: it waits for its turn, runs, then lets the next one start."""
    with as_account(profile_key(str(args[0]) if args else "")):      # (all it prints is its account's)
        _run_group_job_in_turn(job_id, auth_digest, start_phase, start_message, args)


def _run_group_job_in_turn(job_id: str, auth_digest: str, start_phase: str, start_message: str, args: tuple) -> None:
    # (a waiting task counts as work for the app too, so it stays working in the background between two tasks)
    app_task_running(True)
    try:
        if not wait_account_turn(auth_digest, job_id):
            publish_job(job_id, status="done", success=False, message="أُلغيت المهمة قبل أن يأتي دورها.")
            return
        with jobs_lock:
            waited = (jobs.get(job_id) or {}).get("phase") == "queue"
        if waited:
            publish_job(job_id, phase=start_phase, message=start_message)
        run_group_job(job_id, *args)
    finally:
        account_line_leave(auth_digest, job_id)
        app_task_running(False)


def account_busy(auth_digest: str) -> bool:
    """Whether the account has a task working or waiting now."""
    with jobs_lock:
        return any(job.get("status") == "running" and job.get("kind") == "execute" and job.get("auth_digest") == auth_digest
                   for job in jobs.values())


DEFAULT_GROUP_WAIT_SECONDS = 8
# «روابط التغريدات»: a task on tweets pasted on the page, instead of opening a group and collecting.
# The page sends each tweet as "handle/id", or "id" when its link has no author's name.
MAX_TWEET_LINKS = MAX_REPOSTS_REQUEST
LINKS_TASK_NAME = "روابط التغريدات"


def tweet_links_from(entries) -> list[dict]:
    """The pasted tweets as the same {"url", "text"} rows a group's collecting gives: each tweet
    once, in the order pasted."""
    items: list[dict] = []
    seen: set[str] = set()
    for entry in entries if isinstance(entries, list) else []:
        match = re.fullmatch(r"(?:([A-Za-z0-9_]{1,15})/)?(\d{6,25})", str(entry or "").strip())
        if not match or match.group(2) in seen:
            continue
        handle, status_id = match.group(1) or "", match.group(2)
        seen.add(status_id)
        if handle.lower() in _HANDLE_NOT_A_USER:
            handle = ""
        url = f"https://x.com/{handle}/status/{status_id}" if handle else f"https://x.com/i/web/status/{status_id}"
        items.append({"url": url, "text": ""})
    return items


def run_group_job(job_id: str, auth_token: str, pin: str, group_name: str, requested_count: int, actions: list[str], gemini_api_key: str = "", gemini_model: str = "", stop_id: str = "", group_wait_s: int = DEFAULT_GROUP_WAIT_SECONDS, reply_voice: str = DEFAULT_REPLY_VOICE, tweet_links: list[dict] | None = None) -> None:
    def on_progress(done: int, requested: int, phase: str) -> None:
        if job_cancelled(job_id):
            raise JobStopped
        if phase == "collect":
            if stop_id:
                publish_job(job_id, phase="collect", collected=done, requested=0, message=f"جُمعت {done}. التمرير مستمر حتى التغريدة المحددة.")
            else:
                publish_job(job_id, phase="collect", collected=done, requested=requested, message=f"جُمعت {done} من {requested}.")
        elif phase == "seek":
            publish_job(job_id, phase="collect", collected=0, requested=0, message=f"يبحث عن التغريدة المحددة. الخطوة {done}، وما زال يحمّل الأقدم.")
        elif phase == "act":
            publish_job(job_id, phase="act", done=done, collected=done, requested=requested, message=f"تنفيذ {done} من {requested}.")
        elif phase in ("pause", "pause_again"):
            # Two tweets in a row would not open: the browser is closed, done = seconds left. The second
            # time ("pause_again") is the last: a third time stops the task.
            again = phase == "pause_again"
            if done > 0:
                publish_job(job_id, phase="act", message=(
                    f"تعذّر فتح تغريدتين متتاليتين{' مرة أخرى' if again else ''}، فأُغلق المتصفح. المتابعة منهما بعد {done // 60}:{done % 60:02d}."
                    + (" إن تعذّر مرة ثالثة تتوقف المهمة." if again else "")))
            else:
                publish_job(job_id, phase="act", message="انتهى الانتظار. إعادة فتح المتصفح والمتابعة من التغريدتين…")
        else:
            publish_job(job_id, phase=phase, message="فتح الدردشة والقروب…")

    job_run_args[job_id] = (auth_token, pin, group_name, requested_count, actions, gemini_api_key, gemini_model, stop_id, group_wait_s, reply_voice, tweet_links)

    def work(page):
        try:
            # Pick up any change to the ignored-accounts list (the owner sets it in «توزيع البرنامج»,
            # which shares this folder; a user's copy keeps it current from its check-in).
            load_skip_users()
            with jobs_lock:
                saved = jobs.get(job_id) or {}
                items = list(saved["items"]) if isinstance(saved.get("items"), list) else []
                prefix = list(saved["results"]) if isinstance(saved.get("results"), list) else []
            if items and len(prefix) > len(items):
                prefix = prefix[: len(items)]
            if not items and tweet_links:
                # «روابط التغريدات»: the tweets were pasted on the page, so no chat, no group and no
                # collecting: check the session, then straight to the actions.
                publish_job(job_id, phase="prepare", message="التحقق من الجلسة…")
                if not ensure_logged_in(page):
                    publish_job(job_id, status="done", success=False, message="فشل التحقق: الجلسة غير مسجّلة الدخول.")
                    return
                accept_cookies(page)
                handle = read_session_username(page)
                if handle:
                    remember_session(auth_token, handle, pin)
                # A tweet by an ignored account leaves no trace here either (one whose link has no
                # author's name is caught once it is open, as for a group).
                items = [dict(item) for item in tweet_links if not tweet_is_ignored(str(item.get("url") or ""))]
                if not items:
                    publish_job(job_id, status="done", success=False, message="لا توجد تغريدات للتنفيذ.")
                    return
                prefix = []
                publish_job(job_id, phase="act", collected=len(items), requested=len(items), items=items,
                            message=f"بدأ تنفيذ الإجراءات على {len(items)} تغريدة من الروابط.")
            elif not items:
                publish_job(job_id, phase="login", message="التحقق من الجلسة ثم فتح القروب مباشرة…")
                if not ensure_logged_in(page):
                    publish_job(job_id, status="done", success=False, message="فشل التحقق: الجلسة غير مسجّلة الدخول.")
                    return
                accept_cookies(page)
                handle = read_session_username(page)
                if handle:
                    remember_session(auth_token, handle, pin)
                publish_job(job_id, status="done", success=False, message="التجميع غير موجود في هذه النسخة.")
                return
            elif not ensure_logged_in(page):
                publish_job(job_id, status="done", success=False, message="فشل التحقق: الجلسة غير مسجّلة الدخول.")
                return
            else:
                publish_job(job_id, phase="act", requested=len(items), collected=len(items), done=len(prefix), message=f"استئناف التنفيذ من {len(prefix)} من {len(items)}.")
            stopped_at = 0   # the tweet the task stopped at when two kept failing to open
            if len(prefix) >= len(items):
                results = prefix
            else:
                pending = items[len(prefix) :]

                def snapshot(rows: list[dict]) -> None:
                    merged = prefix + list(rows)
                    publish_job(
                        job_id, phase="act", done=len(merged), requested=len(items), collected=len(items),
                        results=merged, items=items, message=f"تنفيذ {len(merged)} من {len(items)}.",
                    )

                def on_act(done: int, requested: int, phase: str) -> None:
                    if phase in ("pause", "pause_again"):
                        on_progress(done, requested, phase)
                    else:
                        on_progress(len(prefix) + done, len(items), "act")

                try:
                    if "comment" in actions:
                        fresh = execute_comment_actions(
                            page, pending, actions, gemini_api_key, gemini_model, on_act,
                            lambda: job_cancelled(job_id), snapshot, profile_key(auth_token), reply_voice,
                        )
                    else:
                        fresh = visit_and_apply(page, pending, actions, on_act, snapshot, lambda: job_cancelled(job_id), profile_key(auth_token))
                except TweetsKeptFailing as stop:
                    fresh, stopped_at = stop.results, len(prefix) + stop.at
                results = prefix + fresh
                refine_collected_links(fresh)
            if stopped_at:
                publish_job(
                    job_id, status="done", success=False, phase="act", done=len(results), requested=len(items),
                    collected=len(items), results=results, items=items, actions=actions, username=group_name,
                    message=(f"توقفت المهمة عند التغريدة {stopped_at} من {len(items)}: تعذّر فتح تغريدتين متتاليتين ثلاث مرات "
                             f"(بعد انتظار ثلاث دقائق ونصف ثم دقيقة)، والأرجح أن X يمنع هذا الحساب من فتح التغريدات الآن."),
                )
                return
            if job_cancelled(job_id):
                publish_job(
                    job_id, status="done", success=False, phase="act", done=len(results), requested=len(items),
                    collected=len(items), message="تم إيقاف التنفيذ.",
                    results=results, items=items, actions=actions, username=group_name,
                )
                return
            publish_job(
                job_id, status="done", success=True, phase="act", done=len(results), requested=len(items),
                collected=len(items), message=f"اكتمل التنفيذ على {len(results)} تغريدة من {group_name}.",
                results=results, items=items, actions=actions, username=group_name,
            )
        except JobStopped:
            publish_job(job_id, status="done", success=False, message="تم إيقاف التنفيذ.")
            return
        except BrowserClosed:
            raise
        except Exception as exc:
            if browser_closed_error(exc):
                raise BrowserClosed() from exc
            app.logger.warning("group run failed")
            publish_job(job_id, status="done", success=False, message=str(exc) or "تعذّر تنفيذ إجراءات القروب.")
            raise
    # One attempt only. If anything fails, the task stops with a message and is not retried.
    live_task.job_id = job_id
    app_task_running(True)
    try:
        run_on_fresh_browser(auth_token, work)
    except BrowserClosed:
        with jobs_lock:
            job = jobs.get(job_id) or {}
            already_done = job.get("status") == "done"
        if not already_done:
            publish_job(
                job_id, status="done", success=False,
                message="توقف التنفيذ لأن المتصفح أُغلق. ما اكتمل قبل الإغلاق ما زال ظاهرًا.",
            )
    except Exception as exc:
        with jobs_lock:
            job = jobs.get(job_id) or {}
            already_done = job.get("status") == "done"
        if not already_done:
            app.logger.warning("group run failed")
            message = "أُغلق المتصفح أثناء العمل." if browser_closed_error(exc) else (str(exc) or "تعذّر تنفيذ إجراءات القروب.")
            publish_job(job_id, status="done", success=False, message=message)
    finally:
        live_task.job_id = ""
        app_task_running(False)
        with live_views_lock:
            live_views.pop(job_id, None)


def allow_attempt(client: str) -> bool:
    now = time.monotonic()
    with attempts_lock:
        q = attempts[client]
        while q and now - q[0] > ATTEMPT_WINDOW_SECONDS:
            q.popleft()
        if len(q) >= MAX_ATTEMPTS_PER_CLIENT:
            return False
        q.append(now)
        return True


def csrf_matches(submitted: str) -> bool:
    expected = session.get("csrf_token", "")
    return bool(expected) and hmac.compare_digest(str(submitted), expected)


def csrf_ok(data: dict) -> bool:
    return csrf_matches(str(data.get("csrf_token", "")))


def valid_auth_token(value: str) -> bool:
    return 20 <= len(value) <= 512


@app.before_request
def limit_request_size():
    if (request.content_length or 0) > SMALL_REQUEST_BYTES and request.endpoint not in ("group_run_endpoint", "support_upload_endpoint"):
        abort(413)


@app.after_request
def secure_response(response):
    if request.endpoint == "page_font" and response.status_code == 200:
        response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
    else:
        response.headers["Cache-Control"] = "no-store, max-age=0"
        response.headers["Pragma"] = "no-cache"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' blob: data: https://pbs.twimg.com; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self'; form-action 'self'; base-uri 'none'"
    return response


@app.after_request
def compress_response(response):
    """Big answers (a finished task's list, the page itself) go gzipped: a phone loads them in a
    fraction of the time."""
    if (
        response.status_code != 200
        or response.direct_passthrough
        or "Content-Encoding" in response.headers
        or "gzip" not in (request.headers.get("Accept-Encoding") or "").lower()
        or response.mimetype not in ("application/json", "text/html")
    ):
        return response
    body = response.get_data()
    if len(body) < 2048:
        return response
    response.set_data(gzip.compress(body, compresslevel=5))
    response.headers["Content-Encoding"] = "gzip"
    response.vary.add("Accept-Encoding")
    return response


@app.get("/healthz")
def health():
    return "ok", 200, {"Content-Type": "text/plain; charset=utf-8"}


@app.get("/")
def root():
    return redirect("/" + ACCESS_PATH, code=302)


@app.get("/<access_path>")
def login_page(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    csrf_token = session.get("csrf_token")
    if not csrf_token:
        csrf_token = secrets.token_urlsafe(32)
        session["csrf_token"] = csrf_token
    response = make_response(render_template_string(
        PAGE, csrf_token=csrf_token, api_root="/" + ACCESS_PATH, app_version=shown_version(), owner_copy=is_owner_copy(), max_links=MAX_TWEET_LINKS,
        claude_here=key_typed_here(), claude_default=CLAUDE_DEFAULT_MODEL, control_on=control_configured(),
        content_ready=content_ready.is_set() or (CONTENT_FILE.is_file() if is_owner_copy() else bool(CONTENT_EMBEDDED)),
        tweets_in_content=content_shows_tweets, in_app=IN_APP, max_accounts=MAX_ACCOUNTS,
    ))
    return response


@app.post("/<access_path>/browser-login")
def browser_login_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    if not IN_APP:
        return jsonify(success=False, message="تسجيل الدخول من المتصفح متاح داخل التطبيق."), 400
    try:
        message = start_manual_login()
    except Exception:
        app.logger.warning("manual login browser failed", exc_info=True)
        return jsonify(success=False, message="تعذّر فتح المتصفح. أعد المحاولة."), 502
    return jsonify(success=True, message=message or "سجّل الدخول في تبويب المتصفح، ثم ارجع إلى اللوحة واضغط تحقق.")


@app.post("/<access_path>/browser-session")
def browser_session_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    token = manual_login_token()
    if not valid_auth_token(token):
        return jsonify(success=False, message="لم تكتمل جلسة المتصفح بعد.")
    return jsonify(success=True, auth_token=token)


@app.post("/<access_path>/verify-login")
def verify_login_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    if not allow_attempt(request.remote_addr or "unknown"):
        return jsonify(success=False, message="تجاوزت عدد المحاولات المسموح به مؤقتًا. انتظر قليلًا ثم أعد المحاولة."), 429
    auth_token = str(data.get("auth_token", "")).strip()
    if not valid_auth_token(auth_token):
        return jsonify(success=False, message="أدخل auth_token صالحًا."), 400
    try:
        success, handle = verify_x_login(auth_token)
        if success:
            remember_session(auth_token, handle)
        if success and handle:
            message = f"تم التحقق بنجاح: هذه الجلسة تخص @{handle}."
        elif success:
            message = "تم التحقق من تسجيل الدخول، لكن تعذّر قراءة اسم الحساب. حُفظ الرمز ويمكن اختياره لاحقًا."
        else:
            message = "فشل التحقق: لم يظهر الحساب مسجّل الدخول. قد يكون الرمز غير صالح أو منتهيًا."
        return jsonify(success=success, message=message, username=handle)
    except Exception:
        app.logger.warning("X login verification failed (details suppressed)")
        return jsonify(success=False, message="تعذّر إكمال التحقق بسبب مشكلة في الاتصال أو تشغيل المتصفح."), 502
    finally:
        auth_token = ""


def write_private_json(path: Path, payload: dict, compact: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    text = json.dumps(payload, ensure_ascii=False, separators=(",", ":")) if compact else json.dumps(payload, ensure_ascii=False, indent=2)
    temporary.write_text(text, encoding="utf-8")
    try:
        os.chmod(temporary, 0o600)
    except OSError:
        pass
    temporary.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def read_private_json(path: Path) -> dict | None:
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except (OSError, json.JSONDecodeError):
        if path.exists():
            broken = path.with_suffix(path.suffix + ".corrupt")
            path.replace(broken)
        return None
    return loaded if isinstance(loaded, dict) else None


# Ignored accounts. The owner sets a list of handles in «توزيع البرنامج» (stored beside g.py in
# data/skip_users.json); every user's copy takes the list on its check-in and caches it in the same
# file on its own server. A collected tweet whose author is on the list is dropped right after it is
# gathered — before it is opened — so it is never acted on and never appears anywhere in the result.
SKIP_USERS_PATH = DATA_DIR / "skip_users.json"
skip_users_lock = threading.Lock()
skip_users_cache: set[str] = set()
_HANDLE_NOT_A_USER = {"i", "web", "intent", "share", "home", "search", "messages", "notifications", "explore"}


def normalize_handle(value: str) -> str:
    """An X handle, lowercased, no leading @; "" when it is not a valid handle."""
    handle = (value or "").strip().lstrip("@").lower()
    return handle if re.fullmatch(r"[a-z0-9_]{1,15}", handle) else ""


def _clean_handles(handles) -> list[str]:
    seen = {h for h in (normalize_handle(x) for x in (handles or [])) if h}
    return sorted(seen)


def load_skip_users() -> None:
    data = read_private_json(SKIP_USERS_PATH) or {}
    users = data.get("users") if isinstance(data, dict) else []
    cleaned = _clean_handles(users if isinstance(users, list) else [])
    with skip_users_lock:
        skip_users_cache.clear()
        skip_users_cache.update(cleaned)


def store_skip_users(handles) -> list[str]:
    """Replace the ignored-accounts list, persist it only when it changed, and return it cleaned."""
    cleaned = _clean_handles(handles)
    with skip_users_lock:
        changed = set(cleaned) != skip_users_cache
        if changed:
            skip_users_cache.clear()
            skip_users_cache.update(cleaned)
    if changed:
        try:
            write_private_json(SKIP_USERS_PATH, {"users": cleaned})
        except OSError:
            pass
    return cleaned


def skip_users_list() -> list[str]:
    with skip_users_lock:
        return sorted(skip_users_cache)


def tweet_author_handle(url: str) -> str:
    """The author handle inside an x.com/<handle>/status/<id> link, or "" for a handle-less link."""
    match = re.search(r"(?:^|[^A-Za-z0-9_])([A-Za-z0-9_]{1,15})/status/\d", url or "")
    if match:
        handle = match.group(1).lower()
        if handle not in _HANDLE_NOT_A_USER:
            return handle
    return ""


def tweet_is_ignored(url: str) -> bool:
    """True when this tweet's author is an ignored account, so it must be skipped silently."""
    handle = tweet_author_handle(url)
    if not handle:
        return False
    with skip_users_lock:
        return handle in skip_users_cache


# «عرض التغريدات»: the tweets the tasks collected in the last 7 days. Each tweet is saved once, when it
# is first collected (its time and group); collecting it again does not add it again. It is kept 7
# days from then. The page sorts the tweets into days in the viewer's own time zone.
COLLECTED_PATH = DATA_DIR / "collected_tweets.json"
COLLECTED_KEEP_SECONDS = 7 * 24 * 3600
collected_lock = threading.Lock()
collected_tweets: dict[str, dict] = {}


def prune_collected_unlocked(now: float) -> bool:
    """Drop the tweets saved more than 7 days ago. True when any was dropped."""
    oldest = now - COLLECTED_KEEP_SECONDS
    gone = [status_id for status_id, row in collected_tweets.items() if row["at"] < oldest]
    for status_id in gone:
        del collected_tweets[status_id]
    return bool(gone)


def persist_collected_unlocked() -> None:
    try:
        write_private_json(COLLECTED_PATH, {"version": 2, "tweets": collected_tweets}, compact=True)
    except OSError:
        pass


def load_collected() -> None:
    data = read_private_json(COLLECTED_PATH) or {}
    rows = data.get("tweets") if isinstance(data.get("tweets"), dict) else {}
    loaded: dict[str, dict] = {}
    for status_id, row in rows.items():
        if not isinstance(row, dict) or not re.fullmatch(r"\d{6,25}", str(status_id)):
            continue
        try:
            if row.get("at") is not None:
                at = int(row["at"])
            else:
                # Saved by the first version, which kept every collection: the first one is the time.
                at = min(int(entry[0]) for entry in row.get("seen") or [])
        except (TypeError, ValueError, IndexError):
            continue
        group = row.get("group")
        if not group and isinstance(row.get("groups"), list) and row["groups"]:
            group = row["groups"][0]
        record = {
            "url": str(row.get("url") or "")[:300],
            "text": str(row.get("text") or "")[:300],
            "group": str(group or "")[:80],
            "at": at,
        }
        # «عرض الأكثر مشاهدة»: the view count from the last check, and when (views None: no count then).
        try:
            if row.get("views_at") is not None:
                record["views_at"] = int(row["views_at"])
                record["views"] = None if row.get("views") is None else max(0, int(row["views"]))
        except (TypeError, ValueError):
            record.pop("views_at", None)
        record.update(tweet_content(row))
        loaded[str(status_id)] = record
    with collected_lock:
        collected_tweets.clear()
        collected_tweets.update(loaded)
        if prune_collected_unlocked(time.time()) or any(isinstance(r, dict) and "seen" in r for r in rows.values()):
            persist_collected_unlocked()


def remember_collected(items: list[dict], group_name: str) -> None:
    """Save the tweets a task has just collected from a group, each only the first time (for
    «عرض التغريدات»). A tweet already saved is not saved again; only a missing text, or a link
    without the author's name, is filled in."""
    now = int(time.time())
    group = re.sub(r"\s+", " ", group_name or "").strip()[:80]
    changed = False
    with collected_lock:
        if prune_collected_unlocked(now):
            changed = True
        for item in items or []:
            url = str(item.get("url") or "")
            status_id = tweet_status_id(url)
            if not status_id:
                continue
            text = re.sub(r"\s+", " ", str(item.get("text") or "")).strip()
            text = "" if text == "تغريدة" else text[:300]
            row = collected_tweets.get(status_id)
            if row is None:
                collected_tweets[status_id] = {"url": url[:300], "text": text, "group": group, "at": now}
                changed = True
                continue
            if text and not row["text"]:
                row["text"] = text
                changed = True
            if tweet_author_handle(url) and not tweet_author_handle(row["url"]):
                row["url"] = url[:300]
                changed = True
        if changed:
            persist_collected_unlocked()


def forget_collected(url: str) -> None:
    """Remove a saved tweet: it turned out to be by an ignored account, which leaves no trace."""
    status_id = tweet_status_id(url)
    if not status_id:
        return
    with collected_lock:
        if collected_tweets.pop(status_id, None) is not None:
            persist_collected_unlocked()


def refine_collected_links(results: list[dict]) -> None:
    """After a task, give each saved tweet the link it really opened at (it has the author's name)."""
    changed = False
    with collected_lock:
        for result in results or []:
            url = str(result.get("url") or "")
            status_id = tweet_status_id(url)
            row = collected_tweets.get(status_id) if status_id else None
            if row and tweet_author_handle(url) and not tweet_author_handle(row["url"]):
                row["url"] = url[:300]
                changed = True
        if changed:
            persist_collected_unlocked()


# Once per copy, when it starts: the tweets it worked on lately put in «التغريدات المجموعة» as if they had
# been collected then, so a copy that has not collected any yet (it was updated since) has them on its page.
# From its tasks of the last day: each tweet a group task collected, with its text and group, at the
# task's time; then from the tweets its accounts acted on in the last 8 hours (kept to skip them), the
# ones not found there, at their first action. Their views and content are then asked for.
COLLECTED_FILLED_PATH = DATA_DIR / "collected_filled.json"


def fill_collected_from_history() -> int:
    """Add those tweets (the ones not saved yet) and ask for their views; how many were added."""
    if COLLECTED_FILLED_PATH.exists():
        return 0
    found: dict[str, dict] = {}
    with jobs_lock:
        tasks = [dict(job) for job in jobs.values()]
    for job in tasks:
        group = re.sub(r"\s+", " ", str(job.get("username") or "")).strip()[:80]
        if job.get("kind") != "execute" or group == LINKS_TASK_NAME or not isinstance(job.get("items"), list):
            continue
        try:
            at = int(float(job.get("created_at") or 0))
        except (TypeError, ValueError):
            continue
        for item in job["items"]:
            url = str(item.get("url") or "") if isinstance(item, dict) else ""
            status_id = tweet_status_id(url)
            if not status_id or not at:
                continue
            text = re.sub(r"\s+", " ", str(item.get("text") or "")).strip()
            text = "" if text == "تغريدة" else text[:300]
            row = found.get(status_id)
            if row is None or at < row["at"]:
                found[status_id] = {"url": url[:300], "text": text or (row or {}).get("text", ""), "group": group, "at": at}
            elif text and not row["text"]:
                row["text"] = text
    with done_history_lock:
        acted: dict[str, float] = {}
        for tweets in done_history.values():
            for status_id, done in tweets.items():
                if done and re.fullmatch(r"\d{6,25}", status_id):
                    acted[status_id] = min(min(done.values()), acted.get(status_id, float("inf")))
    for status_id, at in acted.items():
        if status_id not in found:
            found[status_id] = {"url": f"https://x.com/i/web/status/{status_id}", "text": "", "group": "", "at": int(at)}
    now = time.time()
    added = []
    with collected_lock:
        for status_id, row in found.items():
            if status_id not in collected_tweets and now - row["at"] < COLLECTED_KEEP_SECONDS and not tweet_is_ignored(row["url"]):
                collected_tweets[status_id] = row
                added.append(status_id)
        if added:
            persist_collected_unlocked()
    try:
        write_private_json(COLLECTED_FILLED_PATH, {"at": now, "added": len(added)})
    except OSError:
        pass
    if added:
        queue_views(sorted(added, key=lambda status_id: -found[status_id]["at"]))
    return len(added)


def collected_payload() -> list[dict]:
    """The saved tweets for the page, newest first; ignored accounts left out."""
    with collected_lock:
        if prune_collected_unlocked(time.time()):
            persist_collected_unlocked()
        rows = [{"id": status_id, **row} for status_id, row in collected_tweets.items()]
    rows = [row for row in rows if not tweet_is_ignored(row["url"])]
    rows.sort(key=lambda row: row["at"], reverse=True)
    return rows


# «عرض الأكثر مشاهدة» in «عرض التغريدات»: the current view count of a day's tweets, from FxTwitter's free
# API (api.fxtwitter.com/status/<id>). It is asked FX_AT_ONCE tweets at a time, with no wait between
# them (a test asked 140 at once, then 140 one after another, and none was refused). If the service
# refuses (too many requests), or several tweets get no answer while none is answered, the fetching
# waits a few minutes (longer each time), then goes on where it stopped, one tweet at a time, slowly.
# The counts are kept with the saved tweets. Every day of the last 7 can be checked (today's too); once a
# day is asked for, its button waits VIEWS_AGAIN_SECONDS, then it can be asked for again (all its tweets).
FX_STATUS_URL = "https://api.fxtwitter.com/status/{}"
FX_AT_ONCE = 10                      # tweets asked at the same time
FX_SLOW_GAP_SECONDS = (5.0, 8.0)     # once the service has refused: one tweet at a time, this far apart
FX_PAUSE_SECONDS = 180               # the first wait; the next ones wait 6, 9, 12 then 15 minutes
FX_PAUSE_MAX_SECONDS = 900
FX_MAX_PAUSES = 6                    # waits in a row with no answer between them: then it stops
VIEWS_DAYS = (0, 6)                  # the days that can be checked: today to 6 days ago
VIEWS_AGAIN_SECONDS = 600            # a day asked for can be asked for again after 10 minutes
# With its views, a tweet's content is kept: its text, its pictures (a photo, or the still of a video or
# a GIF; from X's picture server only, at most 4) and the tweet it quotes, if any.
TWEET_PICTURE = re.compile(r"https://pbs\.twimg\.com/[A-Za-z0-9_./-]{1,200}(?:\?[A-Za-z0-9_=&.-]{1,80})?")
TWEET_HANDLE = re.compile(r"[A-Za-z0-9_]{1,30}")
TWEET_BODY_MAX = 2000
QUOTE_BODY_MAX = 1000
views_lock = threading.Lock()
views_queue: deque = deque()
views_state: dict = {"running": False, "paused_until": 0.0, "error": "", "removed": [], "slow": False}
# The days asked for in the last VIEWS_AGAIN_SECONDS: the start of the day (in the asker's time zone) → when.
views_asked: dict[int, float] = {}


def recent_views_asks(now: float) -> dict[int, float]:
    """The days still waiting after being asked for (the older ones are dropped). Call with views_lock held."""
    for start in [start for start, at in views_asked.items() if now - at >= VIEWS_AGAIN_SECONDS]:
        del views_asked[start]
    return dict(views_asked)


def minutes_text(seconds: float) -> str:
    """«دقيقة»، «دقيقتين»، «3 دقائق»، «11 دقيقة»: the minutes, rounded up."""
    minutes = max(1, math.ceil(seconds / 60))
    if minutes <= 2:
        return ("دقيقة", "دقيقتين")[minutes - 1]
    return f"{minutes} {'دقائق' if 3 <= minutes % 100 <= 10 else 'دقيقة'}"


def tweet_pictures(value) -> list[list[str]]:
    """Pictures as kept, [kind, address] with kind "photo" or "video" (its still): only X's picture
    server, at most 4."""
    found = []
    for pair in value if isinstance(value, list) else []:
        if (isinstance(pair, list) and len(pair) == 2 and pair[0] in ("photo", "video")
                and isinstance(pair[1], str) and TWEET_PICTURE.fullmatch(pair[1])):
            found.append([pair[0], pair[1]])
    return found[:4]


def tweet_content(row: dict) -> dict:
    """A saved tweet's content ("body", "pictures", and "quote": "by", "body", "pictures"), checked
    again; {} when it has none (its views were not fetched since this was added)."""
    if not isinstance(row.get("body"), str):
        return {}
    content = {"body": row["body"][:TWEET_BODY_MAX], "pictures": tweet_pictures(row.get("pictures"))}
    quoted = row.get("quote")
    if isinstance(quoted, dict):
        by = str(quoted.get("by") or "")
        content["quote"] = {"by": by if TWEET_HANDLE.fullmatch(by) else "", "body": str(quoted.get("body") or "")[:QUOTE_BODY_MAX],
                            "pictures": tweet_pictures(quoted.get("pictures"))}
    return content


def fx_content(tweet: dict) -> dict:
    """The content kept from FxTwitter's answer about a tweet (see tweet_content)."""
    def pictures(of: dict) -> list[list[str]]:
        media = of.get("media")
        found = []
        for item in (media.get("all") or []) if isinstance(media, dict) else []:
            if isinstance(item, dict) and item.get("type") in ("photo", "video", "gif"):
                found.append(["photo", item.get("url")] if item["type"] == "photo" else ["video", item.get("thumbnail_url")])
        return tweet_pictures(found)
    content = {"body": str(tweet.get("text") or "")[:TWEET_BODY_MAX], "pictures": pictures(tweet)}
    quoted = tweet.get("quote")
    if isinstance(quoted, dict):
        author = quoted.get("author") if isinstance(quoted.get("author"), dict) else {}
        by = str(author.get("screen_name") or "")
        content["quote"] = {"by": by if TWEET_HANDLE.fullmatch(by) else "", "body": str(quoted.get("text") or "")[:QUOTE_BODY_MAX],
                            "pictures": pictures(quoted)}
    return content


def fx_tweet_views(status_id: str) -> tuple[str, int | None, str, dict | None]:
    """Ask FxTwitter about one tweet. Returns (outcome, views, detail, content): ("ok", views or None,
    the tweet's link, its content) · ("gone", None, "", None) deleted, private or not found ·
    ("blocked", None, seconds to wait or "", None) too many requests · ("error", None, why, None) no
    usable answer."""
    asking = urllib.request.Request(FX_STATUS_URL.format(status_id), headers={
        "User-Agent": "x-group-tool/1.0", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(asking, timeout=20) as response:
            data = json.loads(response.read(4 * 1024 * 1024).decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            body = json.loads(exc.read(4096).decode("utf-8"))
        except Exception:
            body = None
        if exc.code == 429:
            return "blocked", None, str(exc.headers.get("Retry-After") or ""), None
        if isinstance(body, dict) and body.get("code") in (401, 403, 404, 410):
            return "gone", None, "", None    # FxTwitter's own answer about this tweet
        if exc.code in (403, 503):
            return "blocked", None, str(exc.headers.get("Retry-After") or ""), None
        if exc.code in (404, 410):
            return "gone", None, "", None
        return "error", None, f"HTTP {exc.code}", None
    except Exception as exc:                 # no answer, a cut connection, or not JSON
        return "error", None, type(exc).__name__, None
    tweet = data.get("tweet") if isinstance(data, dict) else None
    if not isinstance(tweet, dict):
        return "gone", None, "", None
    views = tweet.get("views")
    if isinstance(views, bool) or not isinstance(views, (int, float)) or views < 0:
        views = None
    return "ok", None if views is None else int(views), str(tweet.get("url") or ""), fx_content(tweet)


def views_to_end_of_line(status_ids: list[str]) -> None:
    """These tweets are asked again after the others."""
    with views_lock:
        for status_id in status_ids:
            try:
                views_queue.remove(status_id)
            except ValueError:
                continue
            views_queue.append(status_id)


def views_worker() -> None:
    """The fetching thread. It marks itself finished under the lock when the line is empty, so a new
    request starts a new thread; if something unexpected breaks it, it stops cleanly the same way."""
    try:
        fetch_queued_views()
    except Exception:
        app.logger.warning("views fetching failed")
        with views_lock:
            views_queue.clear()
            views_state.update(running=False, paused_until=0.0, slow=False,
                               error="توقف جلب المشاهدات بسبب خطأ. اضغط «عرض الأكثر مشاهدة» ليكمل.")


def keep_views(answers: list[tuple[str, str, int | None, str, dict | None]]) -> None:
    """Keep what FxTwitter said of these tweets ((id, outcome, views, link, content)): the count, or
    «لا يوجد رقم» (deleted, private, no count, or no answer three times), and the tweet's content,
    then take them out of the line. A tweet whose author turns out to be an ignored account is
    removed, and the page is told."""
    ignored = {status_id for status_id, outcome, _, link, _ in answers if outcome == "ok" and link and tweet_is_ignored(link)}
    with collected_lock:
        for status_id, outcome, views, link, content in answers:
            row = collected_tweets.get(status_id)
            if row is None:
                continue
            if status_id in ignored:
                del collected_tweets[status_id]
                continue
            row["views"] = views if outcome == "ok" else None
            row["views_at"] = int(time.time())
            if outcome == "ok" and link and tweet_author_handle(link) and not tweet_author_handle(row["url"]):
                row["url"] = link[:300]
            if outcome == "ok" and content:
                for key in ("body", "pictures", "quote"):
                    row.pop(key, None)
                row.update(content)
            elif outcome == "gone":
                for key in ("body", "pictures", "quote"):
                    row.pop(key, None)       # deleted or private: nothing of it to show
        persist_collected_unlocked()
    with views_lock:
        for status_id, *_ in answers:
            try:
                views_queue.remove(status_id)
            except ValueError:
                pass
        if ignored:
            views_state["removed"] = (views_state["removed"] + [status_id for status_id, *_ in answers if status_id in ignored])[-500:]


def fetch_queued_views() -> None:
    """Fetch the queued tweets' view counts, FX_AT_ONCE at a time with no wait between them. A refusal
    (or no answer at all) makes it wait out the block, then go on one tweet at a time, slowly."""
    pauses = 0                       # waits in a row, with no answer between them
    failed: dict[str, int] = {}      # failed asks of each tweet
    failing: set[str] = set()        # the tweets that failed since the last answer
    slow = False
    with concurrent.futures.ThreadPoolExecutor(max_workers=FX_AT_ONCE, thread_name_prefix="tweet-views") as pool:
        while True:
            with views_lock:
                if not views_queue:
                    views_state.update(running=False, paused_until=0.0, slow=False)
                    return
                asking = list(itertools.islice(views_queue, 1 if slow else FX_AT_ONCE))
            done, again, refused = [], [], []
            for status_id, (outcome, views, detail, content) in zip(asking, pool.map(fx_tweet_views, asking)):
                if outcome == "blocked":
                    refused.append(detail)           # stays where it is: asked again after the wait
                    continue
                if outcome == "error":
                    failed[status_id] = failed.get(status_id, 0) + 1
                    failing.add(status_id)
                    if failed[status_id] < 3:
                        again.append(status_id)      # asked again after the others
                        continue
                    # It keeps failing while others are answered: no count for it.
                done.append((status_id, outcome, views, detail if outcome == "ok" else "", content if outcome == "ok" else None))
            answered = any(outcome in ("ok", "gone") for _, outcome, *_ in done)
            if answered:
                pauses = 0
                failing.clear()
            if done:
                keep_views(done)
            views_to_end_of_line(again)
            if not refused and not answered and len(failing) >= 3:
                refused.append("")                   # three tweets and no answer: the service or the connection is down
            if refused:
                pauses += 1
                if pauses > FX_MAX_PAUSES:
                    with views_lock:
                        views_queue.clear()
                        views_state.update(running=False, paused_until=0.0, slow=False,
                                           error="توقف جلب المشاهدات لأن الخدمة لم تعد تجيب. اضغط «عرض الأكثر مشاهدة» لاحقًا ليكمل.")
                    return
                asked = 0
                for detail in refused:
                    try:
                        asked = max(asked, int(float(detail)))
                    except (ValueError, OverflowError):
                        pass                         # no number of seconds (empty, a date, "inf")
                wait = min(max(asked, FX_PAUSE_SECONDS * pauses), FX_PAUSE_MAX_SECONDS)
                slow = True
                with views_lock:
                    views_state.update(paused_until=time.time() + wait, slow=True)
                time.sleep(wait)
                with views_lock:
                    views_state["paused_until"] = 0.0
                continue
            if again and not answered:
                time.sleep(10)                       # a moment's trouble: try them again shortly
            elif slow:
                time.sleep(random.uniform(*FX_SLOW_GAP_SECONDS))


def queue_views(ids: list[str]) -> int:
    """Add tweets to the ones waiting for their view count; start fetching if it is not running."""
    with views_lock:
        waiting = set(views_queue)
        added = [status_id for status_id in dict.fromkeys(ids) if status_id not in waiting]
        views_queue.extend(added)
        views_state["error"] = ""
        if views_queue and not views_state["running"]:
            views_state.update(running=True, slow=False)
            threading.Thread(target=views_worker, name="tweet-views", daemon=True).start()
        return len(added)


def views_status_payload(since: float) -> dict:
    """How the fetching is going, and the counts fetched since `since` (a time this server gave)."""
    now = time.time()
    with views_lock:
        state = {"running": views_state["running"], "waiting": list(views_queue), "error": views_state["error"],
                 "paused": max(0, int(views_state["paused_until"] - now)), "removed": list(views_state["removed"]),
                 "slow": views_state["slow"]}
    with collected_lock:
        state["views"] = {status_id: [row.get("views"), row["views_at"], tweet_content(row) or None] for status_id, row in collected_tweets.items()
                          if row.get("views_at") and row["views_at"] >= since - 2}
    state["now"] = now
    return state


def local_day_number(seconds: float, offset_minutes: int) -> int:
    """The calendar day (days since 1970) a moment falls on, at the viewer's UTC offset."""
    return math.floor((seconds + offset_minutes * 60) / 86400)


def day_spans(data: dict) -> list[tuple[int, int]]:
    """The days the page asks about, as [start, end) in seconds (in the viewer's own time zone)."""
    spans = []
    for pair in (data.get("ranges") or [])[:10]:
        try:
            start, end = int(pair[0]), int(pair[1])
        except (TypeError, ValueError, IndexError):
            continue
        if 0 < end - start <= 26 * 3600:
            spans.append((start, end))
    return spans


# Updates. Users and their keys live in g.py beside the owner's script ("توزيع البرنامج"),
# which this script starts on its own port; a user's copy takes updates from it with its key.
CONTROL_FILE = Path(__file__).resolve().with_name("g.py")
CONTROL_PORT = int(os.getenv("CONTROL_PORT", "5050"))
# Where «توزيع البرنامج» opens, when not this host on CONTROL_PORT (e.g. behind a domain).
CONTROL_URL = os.getenv("CONTROL_URL", "")
BACKUPS_DIR = DATA_DIR / "backups"
MAX_PROGRAM_BYTES = 8 * 1024 * 1024
# Set once g.py's page is up.
distribution_started = threading.Event()
# g.py's page, once this program serves it.
distribution_page = None
# Set while a user's copy installs an update: no new task starts.
updating = threading.Event()
update_check_cache: dict = {"at": 0.0, "answer": None}


def is_owner_copy() -> bool:
    """The owner's own copy has «توزيع البرنامج»; a copy given to a user takes updates."""
    return not UPDATE_SOURCE


def on_its_own() -> bool:
    """A copy on its own: the owner's kind of copy with no «توزيع البرنامج» (no g.py beside it, nor what that
    page saved), such as the script downloaded alone into a folder of its own."""
    return (is_owner_copy() and distribution_page is None and not CONTROL_FILE.is_file()
            and not (CONTROL_FILE.with_name("data") / "distribution.json").is_file())


def shown_version() -> str:
    """The version on the page: in the owner's copy, the one last published from «توزيع البرنامج»."""
    if is_owner_copy():
        published = (read_private_json(DATA_DIR / "distribution.json") or {}).get("published_version")
        if published:
            return str(published)
    return APP_VERSION


def start_distribution(bind_host: str) -> None:
    """Serve g.py's page («توزيع البرنامج») from this same program, on CONTROL_PORT, when g.py
    sits beside the owner's script. It hands out this script."""
    if not is_owner_copy() or not CONTROL_FILE.is_file():
        return
    try:
        spec = importlib.util.spec_from_file_location("distribution_page", CONTROL_FILE)
        control = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(control)
        control.PROGRAM_PATH = Path(__file__).resolve()
        server = make_server(bind_host, CONTROL_PORT, control.app, threaded=True)
    except (Exception, SystemExit) as exc:
        # Werkzeug exits the program when the port is taken; the script keeps running without the page.
        reason = "المنفذ مستخدم من برنامج آخر" if isinstance(exc, SystemExit) else str(exc)
        print(f"لم تبدأ صفحة التوزيع ({CONTROL_FILE.name}) على المنفذ {CONTROL_PORT}: {reason}", flush=True)
        return
    threading.Thread(target=server.serve_forever, name="distribution", daemon=True).start()
    global distribution_page
    distribution_page = control             # (its choice of who writes the comments is this copy's too)
    distribution_started.set()
    print(f"صفحة التوزيع ({CONTROL_FILE.name}) على المنفذ {CONTROL_PORT}", flush=True)


def version_of(text: str) -> str:
    match = re.search(r'^APP_VERSION = "([0-9][0-9.]*)"', text, re.M)
    return match.group(1) if match else ""


def version_tuple(version: str) -> tuple[int, ...]:
    return tuple(int(part) for part in re.findall(r"\d+", version or "")) or (0,)


def ask_update_source(path: str, timeout: float, report: dict | None = None) -> tuple[int, bytes]:
    """A user's copy asks the owner's g.py (posting report when given). Returns (HTTP status, body);
    status 0 when unreachable."""
    headers = {"X-Update-Key": UPDATE_KEY, "User-Agent": "x-group-update"}
    body = None
    if report is not None:
        body = json.dumps(report).encode("utf-8")
        headers["Content-Type"] = "application/json"
    asking = urllib.request.Request(UPDATE_SOURCE.rstrip("/") + path, data=body, headers=headers)
    try:
        with urllib.request.urlopen(asking, timeout=timeout) as answer:
            return answer.status, answer.read(MAX_PROGRAM_BYTES + 1)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(4096)
    except (urllib.error.URLError, OSError, ValueError):
        return 0, b""


# A user's copy checks in with the owner this often, and when its page opens.
OWNER_SYNC_EVERY = 120
owner_sync_lock = threading.Lock()
owner_sync_state = {"at": 0.0, "ok": False}


def apply_owner_gemini(key: str, model: str = "") -> None:
    """Use the Gemini key and model the owner set for this copy; when the owner deleted the key, drop
    it here too. With no model from the owner, the copy keeps its own."""
    model = normalize_gemini_model(model) or ""
    with gemini_lock:
        current, managed = saved_gemini.get("api_key") or "", bool(saved_gemini.get("managed"))
        changed = False
        if key and valid_gemini_key(key):
            if key != current or not managed:
                saved_gemini.update(api_key=key, managed=True)
                changed = True
        elif managed and current:
            saved_gemini.update(api_key="", managed=False)
            changed = True
        if model and model != saved_gemini.get("model"):
            saved_gemini["model"] = model
            changed = True
        if changed:
            persist_gemini_unlocked()


def sync_with_owner() -> None:
    """A user's copy checks in with the owner's g.py: it reports its Gemini comments and cost, takes
    the Gemini key the owner set for it (or drops the one deleted), and resets its cost when asked."""
    if is_owner_copy() or not owner_sync_lock.acquire(blocking=False):
        return
    try:
        for _ in range(2):  # after a reset, report the new cost straight away
            with gemini_usage_lock:
                done = str(gemini_usage.get("reset_id") or "")
                report = {
                    # Since the cost was last reset, like the cost beside it in «إدارة».
                    "comments": int(gemini_usage.get("cost_comments") or 0),
                    "cost": round(int(gemini_usage.get("cost_comments") or 0) * GEMINI_PRICE_PER_COMMENT, 6),
                    "reset_id": done,
                    # Since this copy began (never reset): its total cost from the beginning.
                    "total_comments": int(gemini_usage.get("comments") or 0),
                    "total_cost": round(int(gemini_usage.get("comments") or 0) * GEMINI_PRICE_PER_COMMENT, 6),
                }
            status, body = ask_update_source("/user/sync", 15, report)
            try:
                answer = json.loads(body.decode("utf-8")) if status == 200 else {}
            except (UnicodeDecodeError, json.JSONDecodeError):
                answer = {}
            ok = isinstance(answer, dict) and bool(answer.get("success"))
            if ok:
                # The keys, into memory only (see apply_owner_gemini, apply_owner_comments).
                apply_owner_gemini(str(answer.get("gemini_key") or ""), str(answer.get("gemini_model") or ""))
                engine = str(answer.get("comments_engine") or "")
                kind = "claude" if engine == "claude" else "grok"
                apply_owner_comments(engine, str(answer.get(kind + "_key") or ""), str(answer.get(kind + "_model") or ""))
            # (Set once the answer is applied: whoever waits for the keys sees them with it.)
            owner_sync_state.update(at=time.monotonic(), ok=ok)
            if not ok:
                return
            if isinstance(answer.get("skip_users"), list):
                store_skip_users(answer["skip_users"])
            wanted = str(answer.get("reset_id") or "")
            if not wanted or wanted == done:
                return
            reset_gemini_cost(wanted)
    finally:
        owner_sync_lock.release()


def owner_keys_ready(gemini_only: bool = False) -> bool:
    """A user's copy has what writes its comments: Grok (the owner's choice) or its Gemini key; with
    gemini_only, its Gemini key (for «إنشاء محتوى»)."""
    with gemini_lock:
        gemini = valid_gemini_key(str(saved_gemini.get("api_key") or ""))
    return gemini or (not gemini_only and not gemini_writes_comments())


def wait_for_owner_keys(seconds: float = 10.0, gemini_only: bool = False) -> bool:
    """A user's copy keeps its keys in memory only, from its check-ins: when it has none (it has just
    started, or the owner could not be reached), it checks in now and waits a little for them. It stops
    waiting as soon as the owner answers without them. True when it has them."""
    if is_owner_copy() or owner_keys_ready(gemini_only):
        return True
    began = time.monotonic()
    while True:
        sync_with_owner()                      # (returns at once while another check-in is under way)
        answered = owner_sync_state["ok"] and owner_sync_state["at"] >= began
        if owner_keys_ready(gemini_only) or answered or time.monotonic() - began >= seconds:
            return owner_keys_ready(gemini_only)
        time.sleep(1)


def no_keys_message() -> str:
    """Why a user's copy has no key for its comments."""
    if not owner_sync_state.get("ok"):
        return "تعذّر الاتصال بصاحب البرنامج لجلب مفتاح التعليقات. حاول بعد قليل."
    return "لا يوجد مفتاح للتعليقات في هذه النسخة. اطلبه من صاحب البرنامج."


def owner_sync_loop() -> None:
    while True:
        try:
            sync_with_owner()
        except Exception:
            pass
        time.sleep(OWNER_SYNC_EVERY)


def latest_update() -> dict:
    """The version the owner offers this copy {"version", "sha256"}, or {"message"} saying why not."""
    status, body = ask_update_source("/update/latest", 15)
    try:
        answer = json.loads(body.decode("utf-8")) if body else {}
    except (UnicodeDecodeError, json.JSONDecodeError):
        answer = {}
    if status == 200 and isinstance(answer, dict) and answer.get("version"):
        return {"version": str(answer["version"]), "sha256": str(answer.get("sha256") or "")}
    message = answer.get("message") if isinstance(answer, dict) else ""
    return {"message": str(message or "تعذّر الاتصال بمصدر التحديث.")}


def new_program_problem(body: bytes, latest: dict) -> str:
    """Why a downloaded program must not be installed; "" when it is fine."""
    if not body or len(body) > MAX_PROGRAM_BYTES:
        return "لم يصل ملف التحديث كاملًا. أعد المحاولة."
    if not hmac.compare_digest(hashlib.sha256(body).hexdigest(), latest.get("sha256") or ""):
        return "لم يصل ملف التحديث كاملًا. أعد المحاولة."
    try:
        text = body.decode("utf-8")
        compile(text, "update.py", "exec")
    except (UnicodeDecodeError, SyntaxError, ValueError):
        return "ملف التحديث غير صالح. لم يتغير شيء."
    if version_of(text) != latest.get("version"):
        return "رقم إصدار ملف التحديث لا يطابق. لم يتغير شيء."
    if not re.search(r'^UPDATE_SOURCE = "https?://[^"\s]+"$', text, re.M) or not re.search(r'^UPDATE_KEY = "[^"\s]+"$', text, re.M):
        return "ملف التحديث بلا عنوان أو مفتاح. لم يتغير شيء."
    return ""


def program_starts(body: bytes) -> bool:
    """Load the new program once in a separate Python, in a scratch folder, to see that it starts. In the app there
    is no separate Python on Android to try it in: there the download is checked (hash, compiles, version) and the
    app's loader goes back to the kept version by itself if the new one does not start."""
    if IN_APP:
        return True
    trial = BACKUPS_DIR / "trial"
    shutil.rmtree(trial, ignore_errors=True)
    try:
        trial.mkdir(parents=True)
        program = trial / "program.py"
        program.write_bytes(body)
        load = ("import importlib.util, sys; spec = importlib.util.spec_from_file_location('trial', sys.argv[1]); "
                "spec.loader.exec_module(importlib.util.module_from_spec(spec))")
        result = subprocess.run([sys.executable, "-c", load, str(program)], cwd=trial, capture_output=True, timeout=90)
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False
    finally:
        shutil.rmtree(trial, ignore_errors=True)


def install_program(body: bytes) -> None:
    """Keep the running file in data/backups, then put the new one in its place."""
    script = Path(__file__).resolve()
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(script, BACKUPS_DIR / f"{script.stem}-{APP_VERSION}.py")
    temporary = script.with_name(script.name + ".new")
    temporary.write_bytes(body)
    try:
        shutil.copymode(script, temporary)
    except OSError:
        pass
    temporary.replace(script)


def restart_program() -> None:
    """Run the program again so the new file takes over. In the app, the app itself restarts (os.execv does not
    work under Android); on a server, this process re-execs."""
    time.sleep(1.5)
    try:
        shutdown_jobs()
    except Exception:
        pass
    if IN_APP:
        try:
            from java import jclass
            jclass("app.tg.groups.MainActivity").restartApp()
            return
        except Exception as exc:
            print("تعذّر إعادة تشغيل التطبيق تلقائيًا:", exc, flush=True)
            return
    # Flask's server leaves its listening socket open across exec; close it there so the new
    # program can listen on the same port.
    server_fd = os.environ.pop("WERKZEUG_SERVER_FD", "")
    if server_fd.isdigit():
        try:
            os.set_inheritable(int(server_fd), False)
        except OSError:
            pass
    sys.stdout.flush()
    sys.stderr.flush()
    command = list(getattr(sys, "orig_argv", None) or [sys.executable, *sys.argv])
    os.execv(sys.executable, [sys.executable, *command[1:]])


def remember_gemini(api_key: str, model: str) -> None:
    key = (api_key or "").strip()
    normalized = normalize_gemini_model(model or "") or saved_gemini.get("model") or "gemini-3.5-flash"
    if key and not valid_gemini_key(key):
        return
    with gemini_lock:
        if key and key != saved_gemini.get("api_key"):
            # A key typed on this page is this copy's own, not the owner's.
            saved_gemini["api_key"] = key
            saved_gemini["managed"] = False
        saved_gemini["model"] = normalized
        persist_gemini_unlocked()


# A user's copy never keeps an API key on its disk: the owner's Gemini and Grok keys come with each
# check-in and stay in the running program's memory only (a copy just started asks for them at once). The
# owner's own copy keeps the Gemini key typed in its panel in data/gemini.json, sealed, so the file shows
# nothing readable: it is encrypted with a key made from a secret in this program and this copy's update key
# (a stream from SHA-256 with a random nonce each time it is saved, and a tag that tells a damaged file).
# A file from before, with a key in the clear (or a user's copy's sealed one), is rewritten without it.
KEY_SEAL_SECRET = bytes.fromhex("d8867d215ab7fb097f3a535a380696b36506ee694e0ef27fdba0c4f8fd77b658")


def key_seal_material() -> bytes:
    return hashlib.sha256(KEY_SEAL_SECRET + UPDATE_KEY.encode("utf-8")).digest()


def key_stream(material: bytes, nonce: bytes, length: int) -> bytes:
    stream = bytearray()
    counter = 0
    while len(stream) < length:
        stream += hashlib.sha256(material + nonce + counter.to_bytes(4, "big")).digest()
        counter += 1
    return bytes(stream[:length])


def seal_key(text: str) -> str:
    """A key as it is kept on disk ("" for none)."""
    if not text:
        return ""
    material, nonce, raw = key_seal_material(), os.urandom(16), text.encode("utf-8")
    body = bytes(a ^ b for a, b in zip(raw, key_stream(material, nonce, len(raw))))
    tag = hmac.new(material, nonce + body, hashlib.sha256).digest()[:16]
    return "s1:" + base64.b64encode(nonce + tag + body).decode("ascii")


def open_key(sealed) -> str:
    """The key a sealed one holds; "" when there is none, or it is damaged or another copy's."""
    if not isinstance(sealed, str) or not sealed.startswith("s1:"):
        return ""
    try:
        data = base64.b64decode(sealed[3:], validate=True)
    except ValueError:
        return ""
    if len(data) <= 32:
        return ""
    nonce, tag, body = data[:16], data[16:32], data[32:]
    material = key_seal_material()
    if not hmac.compare_digest(tag, hmac.new(material, nonce + body, hashlib.sha256).digest()[:16]):
        return ""
    try:
        return bytes(a ^ b for a, b in zip(body, key_stream(material, nonce, len(body)))).decode("utf-8")
    except UnicodeDecodeError:
        return ""


def persist_gemini_unlocked() -> None:
    # The owner's copy keeps its own key, sealed; a user's copy keeps the owner's key in memory only, from its
    # check-ins, never on its disk.
    sealed = seal_key(saved_gemini["api_key"]) if is_owner_copy() else ""
    write_private_json(GEMINI_PATH, {"version": 2, "api_key_sealed": sealed, "model": saved_gemini["model"],
                                     "managed": bool(saved_gemini.get("managed"))})


def load_gemini() -> None:
    global saved_gemini
    loaded = read_private_json(GEMINI_PATH) or {}
    owner = is_owner_copy()
    plain = str(loaded.get("api_key") or "").strip()
    sealed = loaded.get("api_key_sealed")
    # A user's copy reads no key from its disk: the owner's comes with its first check-in.
    key = ((open_key(sealed).strip() if sealed else plain) if owner else "")
    model = normalize_gemini_model(str(loaded.get("model") or "")) or "gemini-3.5-flash"
    if key and not valid_gemini_key(key):
        key = ""
    # managed: the owner set this key from «توزيع البرنامج», and may delete it from there.
    saved_gemini = {"api_key": key, "model": model, "managed": bool(key and loaded.get("managed"))}
    if plain or (sealed and not owner):
        with gemini_lock:
            persist_gemini_unlocked()      # the owner's key now sealed; a user's copy: the key taken off its disk


def persist_sessions_unlocked() -> None:
    write_private_json(SESSIONS_PATH, {"version": 1, "sessions": saved_sessions})


def load_sessions() -> None:
    global saved_sessions
    loaded = read_private_json(SESSIONS_PATH)
    rows = loaded.get("sessions") if loaded else None
    if not isinstance(rows, list):
        saved_sessions = []
        return
    cleaned = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        token = str(row.get("token") or "")
        username = str(row.get("username") or "").lstrip("@")
        if not valid_auth_token(token):
            continue
        if username and not re.fullmatch(r"[A-Za-z0-9_]{1,15}", username):
            username = ""
        cleaned.append({
            "id": str(row.get("id") or secrets.token_urlsafe(12)),
            "digest": hashlib.sha256(token.encode("utf-8")).hexdigest(),
            "token": token,
            "username": username,
            "chat_pin": str(row.get("chat_pin") or "") if valid_chat_pin(str(row.get("chat_pin") or "")) else "",
            "verified_at": float(row.get("verified_at") or 0),
        })
    cleaned.sort(key=lambda item: item["verified_at"], reverse=True)
    saved_sessions = cleaned[:MAX_ACCOUNTS]             # up to three accounts, newest kept
    for row in saved_sessions:
        if row["username"]:
            account_names[profile_key(row["token"])] = row["username"]


def remember_session(auth_token: str, username: str, chat_pin: str = "") -> None:
    token = (auth_token or "").strip()
    if not valid_auth_token(token):
        return
    username = (username or "").strip().lstrip("@")
    if username and not re.fullmatch(r"[A-Za-z0-9_]{1,15}", username):
        username = ""
    if username:
        account_names[profile_key(token)] = username
    pin = (chat_pin or "").strip()
    if pin and not valid_chat_pin(pin):
        pin = ""
    digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = time.time()
    with sessions_lock:
        found = next((row for row in saved_sessions if hmac.compare_digest(row["digest"], digest)), None)
        if found:
            if username:
                found["username"] = username
            if pin:
                found["chat_pin"] = pin
            found["token"] = token
            found["verified_at"] = now
        else:
            saved_sessions.append({
                "id": secrets.token_urlsafe(12),
                "digest": digest,
                "token": token,
                "username": username,
                "chat_pin": pin,
                "verified_at": now,
            })
        saved_sessions.sort(key=lambda item: item["verified_at"], reverse=True)
        del saved_sessions[MAX_ACCOUNTS:]            # up to three accounts: the oldest drops when a fourth is added
        persist_sessions_unlocked()


def public_session(row: dict) -> dict:
    token = row["token"]
    hint = token[:4] + "…" + token[-4:] if len(token) >= 12 else "••••"
    return {
        "id": row["id"],
        "username": row.get("username") or "",
        "hint": hint,
        "token": token,
        "chat_pin": row.get("chat_pin") or "",
        "verified_at": row.get("verified_at") or 0,
    }


def request_client_id() -> str:
    raw = (request.headers.get("X-Client-Id") or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{16,80}", raw):
        return raw
    return ""


def job_record(job: dict) -> dict:
    return {field: job.get(field) for field in JOB_FIELDS}


# Task progress is saved to jobs.json at most this often; a change of status is saved at once.
JOBS_SAVE_EVERY = 2.0
jobs_saved_at = 0.0
jobs_unsaved = False


def persist_jobs_unlocked() -> None:
    global jobs_saved_at, jobs_unsaved
    write_private_json(JOBS_PATH, {"version": 1, "jobs": {key: job_record(job) for key, job in jobs.items()}}, compact=True)
    jobs_saved_at = time.monotonic()
    jobs_unsaved = False


def save_jobs_in_background() -> None:
    """Write progress that was held back by the 2-second limit."""
    while True:
        time.sleep(JOBS_SAVE_EVERY)
        try:
            with jobs_lock:
                if jobs_unsaved:
                    persist_jobs_unlocked()
        except Exception:
            pass


def mark_job_interrupted(job: dict) -> None:
    if job.get("status") != "running":
        return
    previous = (job.get("message") or "").strip()
    job["status"] = "interrupted"
    job["success"] = False
    job["updated_at"] = time.time()
    job["message"] = "توقفت العملية مع إيقاف السكربت ولم تُستكمل." + (f" آخر حالة: {previous}" if previous else "")


def load_jobs() -> None:
    loaded = read_private_json(JOBS_PATH)
    rows = loaded.get("jobs") if loaded else None
    if not isinstance(rows, dict):
        return
    now = time.time()
    with jobs_lock:
        for job_id, row in rows.items():
            if not isinstance(job_id, str) or not isinstance(row, dict):
                continue
            job = job_record(row)
            job["items"] = job["items"] if isinstance(job["items"], list) else []
            job["results"] = job["results"] if isinstance(job["results"], list) else []
            job["actions"] = job["actions"] if isinstance(job["actions"], list) else []
            if job.get("status") not in {"running", "done", "interrupted"}:
                job["status"] = "interrupted"
            mark_job_interrupted(job)
            if job.get("status") != "running" and now - float(job.get("updated_at") or 0) > JOB_TTL_SECONDS:
                continue
            jobs[job_id] = job
        persist_jobs_unlocked()


def shutdown_jobs() -> None:
    with jobs_lock:
        for job in jobs.values():
            mark_job_interrupted(job)
        if jobs:
            persist_jobs_unlocked()


def prune_jobs() -> None:
    now = time.time()
    stale = [
        key for key, job in jobs.items()
        if job.get("status") != "running" and now - float(job.get("updated_at") or job.get("created_at") or now) > JOB_TTL_SECONDS
    ]
    for key in stale:
        jobs.pop(key, None)
    if len(jobs) > 40:
        finished = sorted(
            (key for key, job in jobs.items() if job.get("status") != "running"),
            key=lambda key: float(jobs[key].get("updated_at") or 0),
        )
        for key in finished[: max(0, len(jobs) - 40)]:
            jobs.pop(key, None)


def notify_task_done(success: bool, message: str) -> None:
    """In the app, a phone notification: اكتملت المهمة or فشلت المهمة."""
    if os.environ.get("GG_IN_APP") != "1":
        return
    try:
        from java import jclass
        jclass("app.tg.groups.Alerts").result(bool(success), (message or "")[:180])
    except Exception:
        pass


def publish_job(job_id: str, **fields) -> None:
    global jobs_unsaved
    finished = None
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            return
        job.update(fields)
        job["updated_at"] = time.time()
        if fields.get("status") == "done":
            finished = (bool(job.get("success")), str(job.get("message") or ""))
        if "status" in fields or time.monotonic() - jobs_saved_at >= JOBS_SAVE_EVERY:
            persist_jobs_unlocked()
        else:
            jobs_unsaved = True
    if finished:
        notify_task_done(finished[0], finished[1])
        failure_check(job_id)


def begin_job(owner: str, client_id: str, requested: int, phase: str, message: str, kind: str, username: str) -> tuple[str, str]:
    job_id = secrets.token_urlsafe(18)
    job_key = secrets.token_urlsafe(24)
    now = time.time()
    with jobs_lock:
        prune_jobs()
        jobs[job_id] = {
            "owner": owner,
            "client_id": client_id,
            "created_at": now,
            "updated_at": now,
            "status": "running",
            "phase": phase,
            "kind": kind,
            "collected": 0,
            "done": 0,
            "requested": requested,
            "message": message,
            "success": None,
            "username": username,
            "actions": [],
            "items": [],
            "results": [],
            "key_hash": hashlib.sha256(job_key.encode("utf-8")).hexdigest(),
        }
        persist_jobs_unlocked()
    return job_id, job_key


def job_key_matches(job: dict, presented: str) -> bool:
    if not presented or len(presented) > 200:
        return False
    digest = hashlib.sha256(presented.encode("utf-8")).hexdigest()
    expected = str(job.get("key_hash") or "")
    return bool(expected) and hmac.compare_digest(digest, expected)


def public_job(job: dict, light: bool = False, links: bool = False) -> dict:
    """light: while the task runs, leave out its tweet and result lists (the page only
    needs the counts and message then; the full lists are sent once it finishes).
    links: add the extracted tweets' links (the task card's copy button asks once)."""
    payload = {
        "status": job["status"],
        "phase": job.get("phase") or "collect",
        "kind": job.get("kind") or "preview",
        "collected": job.get("collected") or 0,
        "done": job.get("done") or 0,
        "requested": job.get("requested") or 0,
        "requested_count": job.get("requested") or 0,
        "message": job.get("message") or "",
        "success": job.get("success"),
        "username": job.get("username") or "",
        "actions": job.get("actions") or [],
        "items": job.get("items") or [],
        "results": job.get("results") or [],
        "resumable": bool(job.get("resumable")) and job.get("status") == "done",
        "retry_failed": failed_retry_count(job),
    }
    if light and job["status"] == "running":
        payload["items"] = []
        payload["results"] = []
    if links:
        payload["links"] = [item["url"] for item in job.get("items") or [] if isinstance(item, dict) and item.get("url")]
    return payload


SCREEN_PATH = DATA_DIR / "screen.json"              # (the panel saved before accounts were kept apart)
ACTIVE_ACCOUNT_PATH = DATA_DIR / "active_account.json"
screen_lock = threading.RLock()
# What each account's panel showed (its groups, its group, its tweet, its actions, its last task), in its own
# folder: data/accounts/<key>/screen.json. The panel shows one account at a time: active_token.
screens: dict[str, dict] = {}
active_token = ""


def blank_screen() -> dict:
    return {"auth_token": "", "chat_pin": "", "groups": [], "group": "", "stop_tweet": "",
            "actions": ["repost", "like", "bookmark"], "job_id": "", "job_key": "", "started_at": 0}


def clean_screen(loaded: dict) -> dict:
    row = blank_screen()
    groups = loaded.get("groups")
    if isinstance(groups, list):
        row["groups"] = [re.sub(r"\s+", " ", str(name)).strip() for name in groups if str(name).strip()][:200]
    for key in ("auth_token", "chat_pin", "group", "job_id", "job_key"):
        value = str(loaded.get(key) or "").strip()
        if value:
            row[key] = value
    actions = loaded.get("actions")
    if isinstance(actions, list):
        picked = [action for action in actions if isinstance(action, str) and action in ALLOWED_ACTIONS]
        if picked:
            row["actions"] = list(dict.fromkeys(picked))
    row["stop_tweet"] = str(loaded.get("stop_tweet") or "")
    try:
        row["started_at"] = float(loaded.get("started_at") or 0)
    except (TypeError, ValueError):
        row["started_at"] = 0
    return row


def account_screen_unlocked(token: str) -> dict:
    """The account's own panel (read from its folder the first time). Call with screen_lock held."""
    key = profile_key(token)
    row = screens.get(key)
    if row is None:
        row = clean_screen(read_private_json(account_dir(key) / "screen.json") or {})
        screens[key] = row
    row["auth_token"] = token
    return row


def persist_account_screen_unlocked(token: str) -> None:
    write_private_json(account_dir(profile_key(token)) / "screen.json", {"version": 1, **account_screen_unlocked(token)})


def set_active_account(token: str) -> None:
    """The panel now shows this account ("" for none): its own panel, its own log in the app."""
    global active_token
    token = token if valid_auth_token(token) else ""
    with screen_lock:
        changed = token != active_token
        active_token = token
        if changed:
            try:
                write_private_json(ACTIVE_ACCOUNT_PATH, {"auth_token": token})
            except Exception:
                pass
    if IN_APP:
        try:
            import ggapp
            key = profile_key(token) if token else ""
            ggapp.set_active_account(key, account_names.get(key, "") if token else "")
        except Exception:
            pass
        show_active_browser()


def load_screen() -> None:
    """The account the panel showed last. A panel saved before accounts were kept apart becomes its account's."""
    token = str((read_private_json(ACTIVE_ACCOUNT_PATH) or {}).get("auth_token") or "")
    legacy = read_private_json(SCREEN_PATH)
    if legacy:
        old = clean_screen(legacy)
        if valid_auth_token(old["auth_token"]):
            key = profile_key(old["auth_token"])
            if not (account_dir(key) / "screen.json").exists():
                with screen_lock:
                    screens[key] = old
                    try:
                        persist_account_screen_unlocked(old["auth_token"])
                    except Exception:
                        pass
            if not valid_auth_token(token):
                token = old["auth_token"]
        try:
            SCREEN_PATH.replace(SCREEN_PATH.with_name("screen.before-accounts.json"))
        except OSError:
            pass
    set_active_account(token)


def save_screen(**fields) -> None:
    """Save into an account's own panel: the account named by auth_token (the panel then shows it), else the
    one the panel shows now. auth_token "" means the panel shows no account (nothing is saved then)."""
    with screen_lock:
        if "auth_token" in fields:
            token = str(fields.pop("auth_token") or "")
            set_active_account(token)
        else:
            token = active_token
        if not valid_auth_token(token):
            return
        row = account_screen_unlocked(token)
        for key, value in fields.items():
            if key in row:
                row[key] = value
        try:
            persist_account_screen_unlocked(token)
        except Exception:
            pass


def account_screen(token: str) -> dict:
    """A copy of the account's own panel (a blank one for no account)."""
    with screen_lock:
        return dict(account_screen_unlocked(token)) if valid_auth_token(token) else blank_screen()


def running_job_rows(account: str, limit: int = 5) -> list[dict]:
    """The account's own tasks that are working (or waiting) now."""
    with jobs_lock:
        running = [(job_id, job) for job_id, job in jobs.items()
                   if job.get("status") == "running" and account and job.get("account") == account]
    running.sort(key=lambda pair: float(pair[1].get("created_at") or 0), reverse=True)
    rows = []
    for job_id, job in running[:limit]:
        row = public_job(job, light=True)
        row["id"] = job_id
        rows.append(row)
    return rows


def screen_payload(token: str | None = None) -> dict:
    """An account's panel (the one shown now when token is None), with its last task and its working ones."""
    with screen_lock:
        if token is None:
            token = active_token
    row = account_screen(token)
    key = profile_key(token) if valid_auth_token(token) else ""
    payload = {
        "auth_token": row.get("auth_token") or "",
        "chat_pin": row.get("chat_pin") or "",
        "groups": list(row.get("groups") or []),
        "group": row.get("group") or "",
        "stop_tweet": row.get("stop_tweet") or "",
        "actions": list(row.get("actions") or []),
        "job_id": row.get("job_id") or "",
        "job_key": row.get("job_key") or "",
        "started_at": row.get("started_at") or 0,
    }
    with jobs_lock:
        job = jobs.get(payload["job_id"])
        payload["job"] = public_job(job, light=True) if job and key and job.get("account") == key else None
    payload["running_jobs"] = running_job_rows(key)
    payload["success"] = True
    return payload


@app.get("/<access_path>/state")
def state_endpoint(access_path: str):
    """The panel of the account the page asks for (X-Account-Token), else of the account shown last."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    token = (request.headers.get("X-Account-Token") or "").strip()
    return jsonify(screen_payload(token if valid_auth_token(token) else None))


@app.post("/<access_path>/screen")
def save_screen_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    fields: dict = {}
    token = str(data.get("auth_token") or "").strip()
    if token == "" or valid_auth_token(token):
        fields["auth_token"] = token
    pin = str(data.get("chat_pin") or "").strip()
    if valid_chat_pin(pin):
        fields["chat_pin"] = pin
    group_name = re.sub(r"\s+", " ", str(data.get("group") or "")).strip()
    if group_name and len(group_name) <= 80:
        fields["group"] = group_name
    if "stop_tweet" in data:
        fields["stop_tweet"] = str(data.get("stop_tweet") or "").strip()[:300]
    actions = data.get("actions")
    if isinstance(actions, list):
        picked = [action for action in actions if isinstance(action, str) and action in ALLOWED_ACTIONS]
        if picked:
            fields["actions"] = list(dict.fromkeys(picked))
    groups = data.get("groups")
    if isinstance(groups, list) and groups:
        fields["groups"] = [re.sub(r"\s+", " ", str(name)).strip() for name in groups if str(name).strip()][:200]
    if fields:
        save_screen(**fields)
    return jsonify(success=True)


@app.post("/<access_path>/reset-browser")
def reset_browser_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    # Only the shown account's browser is closed; its profile stays (its cookies and session are kept).
    token = str(data.get("auth_token") or "").strip()
    if not valid_auth_token(token):
        with screen_lock:
            token = active_token
    if valid_auth_token(token):
        folder = manual_profile_folder(token)
        try:
            _drop_task_browser(folder)
        except Exception:
            pass
        if _login_state.get("page") is not None and str(_login_state.get("folder") or MANUAL_BROWSER) == folder:
            release_manual_browser()
        return jsonify(success=True, message="تمت إعادة تعيين متصفح هذا الحساب. جلسته محفوظة.")
    release_manual_browser()
    return jsonify(success=True, message="تمت إعادة تعيين المتصفح.")


@app.get("/<access_path>/phone-check")
def phone_check_endpoint(access_path: str):
    """«اختبار قدرة الهاتف»: what the app reads of the phone (memory, processor, its WebView, heat, battery,
    background permissions). The page adds a speed test and says how many accounts can work at once."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    report: dict = {"in_app": False}
    if IN_APP:
        try:
            from java import jclass
            loaded = json.loads(str(jclass("app.tg.groups.BrowserHost").deviceReport()) or "{}")
            if isinstance(loaded, dict):
                report = loaded
        except Exception:
            report = {"in_app": False}
    with jobs_lock:
        report["tasks_running"] = sum(1 for job in jobs.values() if job.get("status") == "running" and job.get("kind") == "execute")
    report["max_accounts"] = MAX_ACCOUNTS
    return jsonify(success=True, report=report)


@app.post("/<access_path>/groups")
def groups_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    auth_token = str(data.get("auth_token", "")).strip()
    pin = str(data.get("chat_pin", "")).strip()
    if not valid_auth_token(auth_token):
        return jsonify(success=False, message="أدخل auth_token صالحًا."), 400
    if not valid_chat_pin(pin):
        return jsonify(success=False, message="رمز الدردشة يجب أن يكون من ٤ إلى ٨ أرقام."), 400
    settle = bool(data.get("wait"))
    settle_seconds = parse_requested_count(data.get("wait_seconds")) or 10
    settle_seconds = max(1, min(120, settle_seconds))
    if account_busy(hashlib.sha256(auth_token.encode("utf-8")).hexdigest()):
        # Its browser is taken by a task (or will be): the groups list would wait until all of them end.
        return jsonify(success=False, message="هذا الحساب يعمل على مهمة الآن. اختر من القروبات المعروضة سابقًا، "
                                              "أو اعرض القروبات بعد انتهاء مهامه.", groups=[])
    try:
        names, error = fetch_group_names(auth_token, pin, settle, settle_seconds)
    except Exception:
        app.logger.warning("group list failed")
        return jsonify(success=False, message="تعذّر فتح الدردشة."), 502
    if error:
        return jsonify(success=False, message=error, groups=[])
    current_group = str(account_screen(auth_token).get("group") or "")     # (this account's own)
    if current_group not in names:
        current_group = ""
    save_screen(auth_token=auth_token, chat_pin=pin, groups=names, group=current_group)
    return jsonify(success=True, groups=names, message=f"ظهر {len(names)} قروب.")


@app.post("/<access_path>/group-run")
def group_run_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    auth_token = str(data.get("auth_token", "")).strip()
    pin = str(data.get("chat_pin", "")).strip()
    # «روابط التغريدات»: the page sends the pasted tweets instead of a group (no chat PIN needed then).
    by_links = data.get("links") is not None
    tweet_links: list[dict] = []
    if by_links:
        group_name, stop_raw, stop_id = LINKS_TASK_NAME, "", ""
        if not valid_chat_pin(pin):
            pin = ""
    else:
        group_name = re.sub(r"\s+", " ", str(data.get("group", ""))).strip()
        stop_raw = str(data.get("stop_tweet") or "").strip()
        stop_id = extract_status_id(stop_raw) if stop_raw else ""
    requested_actions = data.get("actions")
    if not valid_auth_token(auth_token):
        return jsonify(success=False, message="أدخل auth_token صالحًا."), 400
    if by_links:
        if not isinstance(data.get("links"), list) or len(data["links"]) > MAX_TWEET_LINKS:
            return jsonify(success=False, message=f"الحد الأقصى {MAX_TWEET_LINKS} رابط في المهمة الواحدة."), 400
        tweet_links = tweet_links_from(data["links"])
        if not tweet_links:
            return jsonify(success=False, message="الصق رابط تغريدة واحدًا على الأقل."), 400
        tweet_links = [item for item in tweet_links if not tweet_is_ignored(item["url"])]
        if not tweet_links:
            return jsonify(success=False, message="لا توجد تغريدات للتنفيذ."), 400
    else:
        if not valid_chat_pin(pin):
            return jsonify(success=False, message="رمز الدردشة يجب أن يكون من ٤ إلى ٨ أرقام."), 400
        if not group_name or len(group_name) > 80:
            return jsonify(success=False, message="اختر قروبًا من القائمة."), 400
        if stop_raw and not stop_id:
            return jsonify(success=False, message="رابط التغريدة غير صالح. الصق رابطها أو رقمها."), 400
        if not stop_id:
            return jsonify(success=False, message="الصق رابط التغريدة المحددة أو رقمها."), 400
    requested_count = len(tweet_links)
    if not isinstance(requested_actions, list) or not requested_actions or any(not isinstance(action, str) or action not in ALLOWED_ACTIONS for action in requested_actions):
        return jsonify(success=False, message="اختر إجراء واحدًا على الأقل."), 400
    group_wait_raw = data.get("group_wait")
    group_wait_s = DEFAULT_GROUP_WAIT_SECONDS
    if group_wait_raw is not None:
        parsed_wait = parse_requested_count(group_wait_raw)
        if parsed_wait is not None:
            group_wait_s = max(0, min(300, parsed_wait))
    reply_voice = str(data.get("reply_voice") or DEFAULT_REPLY_VOICE)
    if reply_voice not in REPLY_VOICES:
        reply_voice = DEFAULT_REPLY_VOICE
    requested_actions = list(dict.fromkeys(requested_actions))
    gemini_api_key = str(data.get("gemini_api_key") or "").strip()
    gemini_model = normalize_gemini_model(str(data.get("gemini_model") or ""))
    if not is_owner_copy():
        # A user's copy uses the Gemini key and model the owner set; what the page sends is ignored.
        gemini_api_key, gemini_model = "", ""
    if "comment" in requested_actions and not is_owner_copy():
        wait_for_owner_keys()                  # (a copy just started gets them now)
    if "comment" in requested_actions and gemini_writes_comments() and not control_configured():
        if not gemini_api_key:
            gemini_api_key = saved_gemini.get("api_key") or ""
        if not gemini_model:
            gemini_model = normalize_gemini_model(saved_gemini.get("model") or "")
        if not valid_gemini_key(gemini_api_key) or not gemini_model:
            if not is_owner_copy():
                return jsonify(success=False, message=no_keys_message()), 400
            return jsonify(success=False, message="أدخل مفتاح Gemini واسم النموذج قبل التعليق."), 400
        if is_owner_copy():
            remember_gemini(gemini_api_key, gemini_model or "")
    elif "comment" in requested_actions and is_owner_copy() and valid_gemini_key(gemini_api_key) and gemini_model:
        remember_gemini(gemini_api_key, gemini_model)      # (Grok writes the comments; the key typed is kept all the same)
    if updating.is_set():
        return jsonify(success=False, message="يجري تحديث البرنامج. انتظر قليلًا ثم أعد المحاولة."), 503
    auth_digest = hashlib.sha256(auth_token.encode("utf-8")).hexdigest()
    # A task added while the account is working is not refused: it waits in the account's line.
    if account_line_size(auth_digest) >= MAX_TASKS_PER_ACCOUNT:
        return jsonify(success=False, message=f"لهذا الحساب {MAX_TASKS_PER_ACCOUNT} مهام بين عاملة ومنتظرة (الحد الأقصى). "
                                              "انتظر انتهاء بعضها ثم أضف مهمة جديدة."), 429
    owner = session.get("csrf_token", "")
    client_id = request_client_id()
    start_phase, start_message = ("prepare", "التحقق من الجلسة…") if by_links else ("login", "فتح القروب…")
    if by_links:
        job_id, job_key = begin_job(owner, client_id, requested_count, "prepare", "التحقق من الجلسة…", "execute", group_name)
        # The group chosen on the page, and its tweet, stay as they were for the next group task.
        save_screen(auth_token=auth_token, actions=requested_actions, job_id=job_id, job_key=job_key, started_at=time.time())
    else:
        job_id, job_key = begin_job(owner, client_id, requested_count, "login", "فتح القروب…", "execute", group_name)
        save_screen(
            auth_token=auth_token,
            chat_pin=pin,
            group=group_name,
            stop_tweet=stop_raw,
            actions=requested_actions,
            job_id=job_id,
            job_key=job_key,
            started_at=time.time(),
        )
    with jobs_lock:
        if job_id in jobs:
            jobs[job_id]["auth_digest"] = auth_digest     # the account's line this task waits in
            jobs[job_id]["account"] = profile_key(auth_token)   # (its own: shown only on its account's panel)
    ahead = account_line_join(auth_digest, job_id)
    if ahead:
        publish_job(job_id, phase="queue", message=waiting_message(ahead))
    run_args = (auth_token, pin, group_name, requested_count, requested_actions, gemini_api_key, gemini_model or "",
                stop_id, group_wait_s, reply_voice, tweet_links)
    threading.Thread(
        target=run_group_job_in_turn,
        args=(job_id, auth_digest, start_phase, start_message, run_args),
        daemon=True,
    ).start()
    if ahead:
        return jsonify(success=True, job_id=job_id, job_key=job_key, queued=True, ahead=ahead, message=waiting_message(ahead))
    return jsonify(success=True, job_id=job_id, job_key=job_key, queued=False, message="بدأ التنفيذ.")


@app.post("/<access_path>/retry")
def retry_job_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    job_id = str(data.get("job_id") or "").strip()
    job_key = str(data.get("job_key") or "").strip()
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            return jsonify(success=False, message="لم يعد سجل هذه المهمة متاحًا."), 404
        key_ok = job_key_matches(job, job_key)
        owner_ok = bool(job.get("owner")) and job.get("owner") == session.get("csrf_token", "")
        if not key_ok and not owner_ok:
            return jsonify(success=False, message="لم يعد سجل هذه المهمة متاحًا."), 404
        if job.get("status") == "running":
            return jsonify(success=True, message="المهمة تعمل الآن.")
        args = job_run_args.get(job_id)
        if not job.get("resumable") or not args:
            return jsonify(success=False, message="لا يمكن إعادة هذه المهمة. ابدأ مهمة جديدة."), 400
        if updating.is_set():
            return jsonify(success=False, message="يجري تحديث البرنامج. انتظر قليلًا ثم أعد المحاولة."), 503
        auth_digest = str(job.get("auth_digest") or "") or hashlib.sha256(str(args[0]).encode("utf-8")).hexdigest()
        job["auth_digest"] = auth_digest
        start_phase = str(job.get("phase") or "act")
        start_message = f"إعادة المحاولة من التغريدة {len(job.get('results') or []) + 1}…"
        job["status"] = "running"
        job["success"] = None
        job["resumable"] = False
        job["cancel"] = False
        job["message"] = start_message
        job["updated_at"] = time.time()
        persist_jobs_unlocked()
    # (in its account's line, like a new task: it waits while the account is working)
    ahead = account_line_join(auth_digest, job_id)
    if ahead:
        publish_job(job_id, phase="queue", message=waiting_message(ahead))
    threading.Thread(target=run_group_job_in_turn, args=(job_id, auth_digest, start_phase, start_message, args), daemon=True).start()
    return jsonify(success=True, message=waiting_message(ahead) if ahead else "بدأت إعادة المحاولة.")


@app.post("/<access_path>/retry-failed")
def retry_failed_endpoint(access_path: str):
    """«إعادة المحاولة للفاشلة»: a new task on the same account with the finished task's failed tweets only, and on
    each only the actions that failed on it."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    job_id = str(data.get("job_id") or "").strip()
    job_key = str(data.get("job_key") or "").strip()
    with jobs_lock:
        job = jobs.get(job_id)
        if not job or (not job_key_matches(job, job_key)
                       and not (job.get("owner") and job.get("owner") == session.get("csrf_token", ""))):
            return jsonify(success=False, message="لم يعد سجل هذه المهمة متاحًا."), 404
        if job.get("status") == "running":
            return jsonify(success=False, message="المهمة تعمل الآن. انتظر انتهاءها."), 409
        if job.get("retried_by"):
            return jsonify(success=False, message="أُعيدت المحاولة لفاشلة هذه المهمة من قبل."), 409
        items = failed_retry_items(job)
        actions = [action for action in (job.get("actions") or []) if action in ALLOWED_ACTIONS]
        args = job_run_args.get(job_id)
        account = str(job.get("account") or "")
        title = str(job.get("username") or LINKS_TASK_NAME)
    if not items:
        return jsonify(success=False, message="لا توجد إجراءات فاشلة يمكن إعادتها في هذه المهمة."), 400
    actions = [action for action in actions if any(action in item["only"] for item in items)] or \
        list(dict.fromkeys(action for item in items for action in item["only"]))
    # The account's token: as the task had it, or (after the app restarted) from the saved accounts.
    auth_token = str(args[0]) if args else ""
    if not auth_token and account:
        auth_token = next((row["token"] for row in saved_sessions if profile_key(row["token"]) == account), "")
    if not valid_auth_token(auth_token):
        return jsonify(success=False, message="لم يعد حساب هذه المهمة محفوظًا. اختره وأعد المهمة."), 400
    gemini_api_key = str(args[5]) if args else ""
    gemini_model = str(args[6]) if args else ""
    reply_voice = str(args[9]) if args and args[9] in REPLY_VOICES else DEFAULT_REPLY_VOICE
    if "comment" in actions and not is_owner_copy():
        wait_for_owner_keys()
    if "comment" in actions and gemini_writes_comments() and not control_configured():
        gemini_api_key = gemini_api_key or saved_gemini.get("api_key") or ""
        gemini_model = gemini_model or normalize_gemini_model(saved_gemini.get("model") or "") or ""
        if not valid_gemini_key(gemini_api_key) or not gemini_model:
            return jsonify(success=False, message=no_keys_message() if not is_owner_copy()
                           else "أدخل مفتاح Gemini واسم النموذج قبل التعليق."), 400
    if updating.is_set():
        return jsonify(success=False, message="يجري تحديث البرنامج. انتظر قليلًا ثم أعد المحاولة."), 503
    auth_digest = hashlib.sha256(auth_token.encode("utf-8")).hexdigest()
    if account_line_size(auth_digest) >= MAX_TASKS_PER_ACCOUNT:
        return jsonify(success=False, message=f"لهذا الحساب {MAX_TASKS_PER_ACCOUNT} مهام بين عاملة ومنتظرة (الحد الأقصى). "
                                              "انتظر انتهاء بعضها ثم أعد المحاولة."), 429
    name = (title if title.startswith("إعادة الفاشلة") else "إعادة الفاشلة · " + title)[:80]
    new_id, new_key = begin_job(session.get("csrf_token", ""), request_client_id(), len(items), "prepare",
                                "التحقق من الجلسة…", "execute", name)
    with jobs_lock:
        if new_id in jobs:
            jobs[new_id]["auth_digest"] = auth_digest
            jobs[new_id]["account"] = profile_key(auth_token)
        old = jobs.get(job_id)
        if old is not None:
            old["retried_by"] = new_id              # (its button goes: the retry is the new task)
        persist_jobs_unlocked()
    ahead = account_line_join(auth_digest, new_id)
    if ahead:
        publish_job(new_id, phase="queue", message=waiting_message(ahead))
    run_args = (auth_token, "", name, len(items), actions, gemini_api_key, gemini_model, "", DEFAULT_GROUP_WAIT_SECONDS,
                reply_voice, items)
    threading.Thread(target=run_group_job_in_turn, args=(new_id, auth_digest, "prepare", "التحقق من الجلسة…", run_args),
                     daemon=True).start()
    count = sum(len(item["only"]) for item in items)
    return jsonify(success=True, job_id=new_id, job_key=new_key, queued=bool(ahead), tweets=len(items), actions=count,
                   message=(waiting_message(ahead) if ahead
                            else f"بدأت إعادة {count} إجراء فاشل على {len(items)} تغريدة."))


@app.post("/<access_path>/stop")
def stop_job_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    job_id = str(data.get("job_id") or "").strip()
    job_key = str(data.get("job_key") or "").strip()
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            return jsonify(success=False, message="لا توجد عملية تعمل الآن."), 404
        key_ok = job_key_matches(job, job_key)
        owner_ok = bool(job.get("owner")) and job.get("owner") == session.get("csrf_token", "")
        if not key_ok and not owner_ok:
            return jsonify(success=False, message="لا توجد عملية تعمل الآن."), 404
        if job.get("status") != "running":
            return jsonify(success=True, message="التنفيذ متوقف أصلًا.")
        job["cancel"] = True
        job["message"] = "جارٍ إيقاف التنفيذ…"
        job["updated_at"] = time.time()
        persist_jobs_unlocked()
    return jsonify(success=True, message="جارٍ إيقاف التنفيذ.")


@app.get("/<access_path>/jobs/<job_id>/view")
def job_view(access_path: str, job_id: str):
    """The latest picture of a running task's browser, if newer than ?after=; asking keeps pictures coming for 3 s."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    with jobs_lock:
        job = jobs.get(job_id)
        allowed = bool(job) and (
            job_key_matches(job, request.headers.get("X-Job-Key", ""))
            or (csrf_matches(request.headers.get("X-CSRF-Token", ""))
                and bool(job.get("owner")) and job.get("owner") == session.get("csrf_token", ""))
        )
        running = allowed and job.get("status") == "running"
    if not allowed:
        return jsonify(success=False, message="لا توجد عملية بهذا المعرّف."), 404
    if not running:
        return "", 204
    try:
        after = int(request.args.get("after") or 0)
    except ValueError:
        after = 0
    with live_views_lock:
        view = live_views.setdefault(job_id, {"wanted_until": 0.0, "taken_at": 0.0, "image": None, "seq": 0})
        view["wanted_until"] = time.monotonic() + 3
        image, seq = view["image"], view["seq"]
    if not image or seq <= after:
        return "", 204
    return image, 200, {"Content-Type": "image/jpeg", "X-Frame": str(seq)}


@app.get("/<access_path>/jobs/<job_id>")
def job_status(access_path: str, job_id: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    light = request.args.get("light") == "1"
    links = request.args.get("links") == "1"
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            return jsonify(success=False, message="لا توجد عملية بهذا المعرّف."), 404
        if job_key_matches(job, request.headers.get("X-Job-Key", "")):
            return jsonify(public_job(job, light=light, links=links))
        if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
            return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
        owner_ok = bool(job.get("owner")) and job.get("owner") == session.get("csrf_token", "")
        if not owner_ok:
            return jsonify(success=False, message="لا توجد عملية بهذا المعرّف."), 404
        return jsonify(public_job(job, light=light, links=links))


@app.get("/<access_path>/sessions")
def list_sessions_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    with sessions_lock:
        rows = [public_session(row) for row in saved_sessions]
    with gemini_lock:
        gemini_key = saved_gemini.get("api_key") or ""
        gemini_model = saved_gemini.get("model") or ""
    if gemini_key and not is_owner_copy():
        # A user's page only shows that a key is there; the copy itself uses it.
        gemini_key = f"{gemini_key[:4]}…{gemini_key[-4:]}"
    # Whether someone (Grok, or Gemini with its key) can write this copy's comments; the owner's page is also
    # told when Grok writes them (chosen in «توزيع البرنامج»), and then asks for no Gemini key.
    writer = comments_writer()[0]
    comments_ready = writer != "gemini" or valid_gemini_key(saved_gemini.get("api_key") or "")
    engine = writer if is_owner_copy() else ""
    if not comments_ready and not is_owner_copy() and not owner_sync_state["ok"] and time.monotonic() - owner_sync_state["at"] > 5:
        threading.Thread(target=sync_with_owner, name="owner-sync", daemon=True).start()   # (no keys yet: ask now)
    own = own_claude_shown() if key_typed_here() else {"claude_key": "", "claude_model": ""}
    return jsonify(success=True, sessions=rows, gemini_api_key=gemini_key, gemini_model=gemini_model, comments_ready=comments_ready,
                   comments_engine=engine, **own)


@app.get("/<access_path>/gemini-usage")
def gemini_usage_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    with gemini_usage_lock:
        comments = int(gemini_usage.get("comments") or 0)
        cost_comments = int(gemini_usage.get("cost_comments") or 0)
        since = gemini_usage.get("since") or 0
    return jsonify(
        success=True,
        since=since,
        comments=comments,
        # The comments the cost counts: since it was last reset.
        cost_comments=cost_comments,
        price_per_comment=GEMINI_PRICE_PER_COMMENT,
        total=round(cost_comments * GEMINI_PRICE_PER_COMMENT, 6),
    )


# The comments written for this copy and their cost, as the page shows them at its top. With a control server
# they are its numbers (kept there by code and by X account, so they stay when the app is installed again),
# asked for at most every COMMENTS_USAGE_CACHE_SECONDS; without one, this copy's own count.
COMMENTS_USAGE_CACHE_SECONDS = 30
_comments_usage_lock = threading.Lock()
_comments_usage_cache: dict = {"at": 0.0, "data": None}


def comments_usage(fresh: bool = False) -> dict:
    if not control_configured():
        with gemini_usage_lock:
            comments = int(gemini_usage.get("comments") or 0)
            cost_comments = int(gemini_usage.get("cost_comments") or 0)
        return {"success": True, "source": "local", "total": comments, "price": GEMINI_PRICE_PER_COMMENT,
                "cost": round(cost_comments * GEMINI_PRICE_PER_COMMENT, 2), "accounts": [], "stale": False}
    with _comments_usage_lock:
        cached = _comments_usage_cache["data"]
        if cached is not None and not fresh and time.monotonic() - _comments_usage_cache["at"] < COMMENTS_USAGE_CACHE_SECONDS:
            return cached
    token = _current_token()
    if not token:
        return {"success": False, "message": "التطبيق غير مُفعّل."}
    try:
        answer = _control_request("usage", {"token": token}, seconds=10)
    except RuntimeError as exc:                  # (unreachable too: the last numbers read are shown, marked old)
        with _comments_usage_lock:
            cached = _comments_usage_cache["data"]
        if cached is not None:
            return {**cached, "stale": True}
        return {"success": False, "message": str(exc)}
    accounts = []
    for row in answer.get("accounts") or []:
        if isinstance(row, dict):
            accounts.append({"name": str(row.get("name") or "")[:40], "n": int(row.get("n") or 0), "cost": round(float(row.get("cost") or 0), 2)})
    data = {"success": True, "source": "control", "total": int(answer.get("total") or 0), "cost": round(float(answer.get("cost") or 0), 2),
            "price": float(answer.get("price") or GEMINI_PRICE_PER_COMMENT), "accounts": accounts, "stale": False}
    with _comments_usage_lock:
        _comments_usage_cache.update(at=time.monotonic(), data=data)
    return data


def forget_comments_usage() -> None:
    """A comment was just written: the next look at the numbers asks the control server again."""
    with _comments_usage_lock:
        _comments_usage_cache["at"] = 0.0


@app.get("/<access_path>/comments-usage")
def comments_usage_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    return jsonify(**comments_usage(fresh=request.args.get("fresh") == "1"))


@app.get("/<access_path>/stats")
def stats_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    # The counts of the account the page is showing now (its token comes in a header; zeros when none).
    token = (request.headers.get("X-Account-Token") or "").strip()
    counts = account_counts(profile_key(token)) if valid_auth_token(token) else zero_counts()
    return jsonify(success=True, counts=counts)


@app.post("/<access_path>/gemini-usage/reset")
def gemini_usage_reset_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH) or not is_owner_copy():
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    if not allow_attempt("cost-reset:" + (request.remote_addr or "unknown")):
        return jsonify(success=False, message="محاولات كثيرة. انتظر بضع دقائق ثم أعد المحاولة."), 429
    password = str(data.get("password") or "")
    if not hmac.compare_digest(password.encode("utf-8"), COST_RESET_PASSWORD.encode("utf-8")):
        return jsonify(success=False, message="كلمة السر غير صحيحة."), 403
    reset_gemini_cost()
    return jsonify(success=True, message="أُعيد تعيين التكلفة وعدد تعليقاتها إلى 0. العدد في أعلى الصفحة كما هو.")


@app.post("/<access_path>/gemini")
def save_gemini_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة."), 400
    if not is_owner_copy():
        return jsonify(success=False, message="يضبط مفتاح Gemini والنموذج صاحب البرنامج."), 403
    api_key = str(data.get("gemini_api_key") or "").strip()
    model = normalize_gemini_model(str(data.get("gemini_model") or ""))
    if api_key and not valid_gemini_key(api_key):
        return jsonify(success=False, message="صيغة مفتاح Gemini غير صالحة."), 400
    if str(data.get("gemini_model") or "").strip() and not model:
        return jsonify(success=False, message="اسم النموذج غير صالح."), 400
    if not api_key and not model:
        return jsonify(success=True, message="لا يوجد ما يُحفظ.")
    remember_gemini(api_key, model or "")
    return jsonify(success=True, message="حُفظ مفتاح Gemini.")


@app.post("/<access_path>/claude")
def save_claude_endpoint(access_path: str):
    """«مفتاح Claude» in the panel of a copy with no «توزيع البرنامج»: saved, its comments are Claude's."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة."), 400
    if not key_typed_here():
        return jsonify(success=False, message="مفتاح Claude هنا لنسخة تعمل بلا «توزيع البرنامج»."), 403
    api_key = str(data.get("api_key") or "").strip()
    model = str(data.get("model") or "").strip().lower() or CLAUDE_DEFAULT_MODEL
    with grok_lock:
        current = saved_grok["api_key"] if saved_grok["engine"] == "claude" else ""
    if not api_key and not current:
        return jsonify(success=False, message="الصق مفتاح Claude."), 400
    if api_key and not valid_claude_key(api_key):
        return jsonify(success=False, message="صيغة مفتاح Claude غير صالحة."), 400
    if not valid_claude_model(model):
        return jsonify(success=False, message="اسم نموذج Claude غير صالح."), 400
    remember_own_claude(api_key or current, model)
    return jsonify(success=True, message="حُفظ مفتاح Claude: التعليقات الآن بواسطة Claude.", comments_engine="claude", **own_claude_shown())


@app.post("/<access_path>/claude/delete")
def delete_claude_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة."), 400
    if not key_typed_here():
        return jsonify(success=False, message="مفتاح Claude هنا لنسخة تعمل بلا «توزيع البرنامج»."), 403
    remember_own_claude("", "")
    return jsonify(success=True, message="حُذف مفتاح Claude: التعليقات بواسطة Gemini.", comments_engine="gemini", **own_claude_shown())


@app.post("/<access_path>/sessions/pin")
def save_session_pin_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة."), 400
    auth_token = str(data.get("auth_token") or "").strip()
    pin = str(data.get("chat_pin") or "").strip()
    if not valid_auth_token(auth_token):
        return jsonify(success=False, message="أدخل رمز الجلسة أولًا."), 400
    if not valid_chat_pin(pin):
        return jsonify(success=False, message="رمز الدردشة ٤ إلى ٨ أرقام."), 400
    digest = hashlib.sha256(auth_token.encode("utf-8")).hexdigest()
    with sessions_lock:
        found = next((row for row in saved_sessions if hmac.compare_digest(row["digest"], digest)), None)
        if not found:
            return jsonify(success=False, message="احفظ الجلسة أولًا بالتحقق من الحساب."), 404
        found["chat_pin"] = pin
        persist_sessions_unlocked()
    return jsonify(success=True, message="حُفظ رمز الدردشة لهذا الحساب.")


@app.post("/<access_path>/sessions/delete")
def delete_session_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة."), 400
    session_id = str(data.get("id", ""))
    removed = None
    with sessions_lock:
        removed = next((row for row in saved_sessions if row["id"] == session_id), None)
        if removed:
            saved_sessions[:] = [row for row in saved_sessions if row["id"] != session_id]
            persist_sessions_unlocked()
    if removed:
        with screen_lock:
            current = active_token
        if current and hmac.compare_digest(current, removed["token"]):
            save_screen(auth_token="")
        delete_profile(removed["token"])
        forget_account_data(removed["token"])
    return jsonify(success=True, message="حُذفت الجلسة.")


def forget_account_data(auth_token: str) -> None:
    """The account is removed: everything of its own goes with it, as when a copy of the program is deleted:
    its folder (its panel, its groups, its log), its counters, its memory of what it did, its tasks' records."""
    key = profile_key(auth_token)
    with screen_lock:
        screens.pop(key, None)
    with group_ids_lock:
        _group_stores.pop(key, None)
    shutil.rmtree(account_dir(key), ignore_errors=True)
    with action_counts_lock:
        if action_counts.pop(key, None) is not None:
            try:
                write_private_json(ACTION_COUNTS_PATH, {"by_account": action_counts})
            except Exception:
                pass
    stats_changed()
    with done_history_lock:
        if done_history.pop(key, None) is not None:
            try:
                write_private_json(DONE_HISTORY_PATH, {"version": 1, "accounts": done_history})
            except Exception:
                pass
    with jobs_lock:
        for job_id in [job_id for job_id, job in jobs.items() if job.get("account") == key and job.get("status") != "running"]:
            jobs.pop(job_id, None)
        for job in jobs.values():
            if job.get("account") == key and job.get("status") == "running":
                job["cancel"] = True                # (its tasks stop too: the account is gone)
        persist_jobs_unlocked()


# «تحديث السكربت» من خادم التحكّم: التطبيق يسأل عن أحدث إصدار منشور، وينزّله عبر اتصاله المحمي، ويتأكد منه ثم
# يستبدل الملف ويعيد التشغيل. لا يصل السكربت إلا لجهاز يحمل رمزًا صالحًا.
_script_latest_cache = {"at": 0.0, "answer": None}


def control_script_latest(fresh: bool = False) -> dict:
    """{'version','sha256',...} for the published script, {} when none or unreachable. Cached ~60s."""
    if not control_configured():
        return {}
    token = _current_token()
    if not token:
        return {}
    now = time.monotonic()
    if not fresh and _script_latest_cache["answer"] is not None and now - _script_latest_cache["at"] < 60:
        return _script_latest_cache["answer"]
    try:
        answer = _control_request("script-latest", {"token": token}, seconds=15)
    except RuntimeError:
        return _script_latest_cache["answer"] or {}
    result = {"version": str(answer.get("version") or ""), "sha256": str(answer.get("sha256") or ""),
              "has_content": bool(answer.get("has_content")), "content_sha256": str(answer.get("content_sha256") or "")}
    result = result if result["version"] else {}
    _script_latest_cache.update(at=now, answer=result)
    return result


def control_script_download() -> dict:
    """{'version','gg': bytes,'content': bytes|None} of the published script, or raises RuntimeError."""
    token = _current_token()
    if not token:
        raise RuntimeError("التطبيق غير مُفعّل. أدخل رمز الدخول.")
    answer = _control_request("script-download", {"token": token}, seconds=120, max_read=24 << 20)
    try:
        gg = base64.b64decode(str(answer.get("gg") or ""), validate=True)
    except Exception:
        raise RuntimeError("وصل ملف التحديث تالفًا. أعد المحاولة.") from None
    content = None
    if answer.get("content"):
        try:
            content = base64.b64decode(str(answer.get("content")), validate=True)
        except Exception:
            content = None
    return {"version": str(answer.get("version") or ""), "gg": gg, "content": content}


def control_update_problem(body: bytes, want_version: str, want_sha: str) -> str:
    """Why a control-delivered script must not be installed; "" when it is fine."""
    if not body or len(body) > MAX_PROGRAM_BYTES:
        return "لم يصل ملف التحديث كاملًا. أعد المحاولة."
    if want_sha and not hmac.compare_digest(hashlib.sha256(body).hexdigest(), want_sha):
        return "لم يصل ملف التحديث كاملًا. أعد المحاولة."
    try:
        text = body.decode("utf-8")
        compile(text, "update.py", "exec")
    except (UnicodeDecodeError, SyntaxError, ValueError):
        return "ملف التحديث غير صالح. لم يتغير شيء."
    if version_of(text) != want_version:
        return "رقم إصدار ملف التحديث لا يطابق. لم يتغير شيء."
    return ""


def install_content(body: bytes) -> None:
    """Put a new content.py beside the script, keeping the old one."""
    if not body:
        return
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    if CONTENT_FILE.is_file():
        try:
            shutil.copy2(CONTENT_FILE, BACKUPS_DIR / f"content-{APP_VERSION}.py")
        except OSError:
            pass
    temporary = CONTENT_FILE.with_name(CONTENT_FILE.name + ".new")
    temporary.write_bytes(body)
    temporary.replace(CONTENT_FILE)


@app.get("/<access_path>/update/check")
def update_check(access_path: str):
    """This copy's version and, in a user's copy, whether the owner offers a newer one."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if control_configured():
        if request.args.get("light") or updating.is_set():
            return jsonify(success=True, owner=False, version=APP_VERSION, updating=updating.is_set())
        latest = control_script_latest()
        if not latest.get("version"):
            return jsonify(success=True, owner=False, version=APP_VERSION, message="")
        newer = version_tuple(latest["version"]) > version_tuple(APP_VERSION)
        return jsonify(success=True, owner=False, version=APP_VERSION, latest=latest["version"], available=newer)
    if is_owner_copy():
        return jsonify(success=True, owner=True, version=APP_VERSION, control_url=CONTROL_URL,
                       control_port=CONTROL_PORT if distribution_started.is_set() else 0)
    if request.args.get("light") or updating.is_set():
        return jsonify(success=True, owner=False, version=APP_VERSION, updating=updating.is_set())
    if time.monotonic() - owner_sync_state["at"] > 10:
        threading.Thread(target=sync_with_owner, name="owner-sync", daemon=True).start()
    now = time.monotonic()
    answer = update_check_cache["answer"]
    if answer is None or now - update_check_cache["at"] > 60:
        answer = latest_update()
        update_check_cache.update(at=now, answer=answer)
    if not answer.get("version"):
        return jsonify(success=True, owner=False, version=APP_VERSION, message=answer.get("message") or "")
    newer = version_tuple(answer["version"]) > version_tuple(APP_VERSION)
    return jsonify(success=True, owner=False, version=APP_VERSION, latest=answer["version"], available=newer)


@app.post("/<access_path>/update/apply")
def update_apply(access_path: str):
    """«تحديث» in a user's copy: download the owner's newest version, check it, keep the old file,
    put the new one in place and start again. Nothing changes when any step fails."""
    if not hmac.compare_digest(access_path, ACCESS_PATH) or (not control_configured() and is_owner_copy()):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400

    def busy() -> bool:
        with jobs_lock:
            return any(job.get("status") == "running" for job in jobs.values())

    with jobs_lock:
        if updating.is_set():
            return jsonify(success=False, message="التحديث جارٍ."), 409
        updating.set()
    installed = False
    try:
        if busy():
            return jsonify(success=False, message="انتظر حتى تنتهي المهام الجارية ثم اضغط «تحديث»."), 409
        if control_configured():
            latest = control_script_latest(fresh=True)
            if not latest.get("version"):
                return jsonify(success=False, message="لا يوجد تحديث منشور على خادم التحكّم."), 502
            if version_tuple(latest["version"]) <= version_tuple(APP_VERSION):
                return jsonify(success=False, message="هذه النسخة على آخر إصدار."), 409
            try:
                got = control_script_download()
            except RuntimeError as exc:
                return jsonify(success=False, message=str(exc) or "تعذّر تنزيل التحديث."), 502
            body = got["gg"]
            problem = control_update_problem(body, latest["version"], latest.get("sha256") or "")
            if problem:
                return jsonify(success=False, message=problem), 502
            if not program_starts(body):
                return jsonify(success=False, message="الإصدار الجديد لا يعمل على هذا الجهاز. لم يتغير شيء."), 502
            if busy():
                return jsonify(success=False, message="بدأت مهمة أثناء التنزيل. انتظر حتى تنتهي ثم اضغط «تحديث»."), 409
            if got.get("content"):
                install_content(got["content"])
            install_program(body)
            installed = True
        else:
            latest = latest_update()
            if not latest.get("version"):
                return jsonify(success=False, message=latest.get("message") or "تعذّر الاتصال بمصدر التحديث."), 502
            if version_tuple(latest["version"]) <= version_tuple(APP_VERSION):
                return jsonify(success=False, message="هذه النسخة على آخر إصدار."), 409
            status, body = ask_update_source("/update/file", 60)
            if status != 200:
                return jsonify(success=False, message=latest_update().get("message") or "تعذّر تنزيل التحديث."), 502
            problem = new_program_problem(body, latest)
            if problem:
                return jsonify(success=False, message=problem), 502
            if not program_starts(body):
                return jsonify(success=False, message="الإصدار الجديد لا يعمل على هذه الاستضافة. لم يتغير شيء."), 502
            if busy():
                return jsonify(success=False, message="بدأت مهمة أثناء التنزيل. انتظر حتى تنتهي ثم اضغط «تحديث»."), 409
            install_program(body)
            installed = True
    except OSError:
        return jsonify(success=False, message="تعذّر حفظ ملف التحديث. لم يتغير شيء."), 500
    finally:
        if not installed:
            updating.clear()
    threading.Thread(target=restart_program, name="restart", daemon=True).start()
    return jsonify(success=True, version=latest["version"], message=f"نُزّل الإصدار {latest['version']}. يُعاد تشغيل البرنامج…")


load_sessions()
load_group_ids()
load_done_history()
load_gemini()
load_panel_key()
load_gemini_usage()
load_action_counts()
load_jobs()
threading.Thread(target=save_jobs_in_background, name="jobs-saver", daemon=True).start()
if IN_APP:
    threading.Thread(target=close_idle_browsers_in_background, name="idle-browsers", daemon=True).start()
load_screen()
load_skip_users()
load_collected()
atexit.register(shutdown_jobs)


# «التغريدات المجموعة»: the tweets collected in the last 7 days, day by day, with «عرض الأكثر مشاهدة» on the
# days from yesterday to 6 days ago. One part in two places: content.py's page («إنشاء محتوى») shows it under its
# link box (see tweets_part), and without content.py it is a page of its own (TWEETS_PAGE). Its look is
# kept inside #tweets, so it changes nothing else on the page it is in; that page may set --tweets-day
# and --tweets-tweet, the backgrounds of a day and of a tweet.
TWEETS_PART_STYLE = r'''<style>
    #tweets { line-height: 1.55; }
    #tweets .tweets-summary { margin: 2px 0 0; color: var(--muted); font-size: 13px; }
    #tweets details { margin-top: 10px; border-radius: 14px; background: var(--tweets-day, var(--sheet)); box-shadow: inset 0 0 0 1px var(--line); }
    #tweets summary { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; padding: 10px; cursor: pointer; list-style: none; font-weight: 700; }
    #tweets summary::-webkit-details-marker { display: none; }
    #tweets summary .day { font-size: 15px; white-space: nowrap; }
    #tweets summary .tail { margin-inline-start: auto; display: flex; align-items: center; gap: 6px; }
    #tweets summary .count { color: var(--muted); font-size: 13px; font-weight: 600; white-space: nowrap; }
    #tweets summary .tail::after { content: "‹"; color: var(--muted); font-size: 18px; line-height: 1; transition: transform 0.15s; }
    #tweets details[open] summary .tail::after { transform: rotate(-90deg); }
    #tweets ol { list-style: none; margin: 0; padding: 0 10px 10px; display: flex; flex-direction: column; gap: 6px; }
    #tweets li { position: relative; padding: 8px 10px; border-radius: 10px; background: var(--tweets-tweet, var(--paper)); box-shadow: inset 0 0 0 1px var(--line); }
    #tweets .text { margin: 0; font-size: 14px; white-space: pre-line; overflow-wrap: anywhere; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
    #tweets li.has-content .text { padding-inline-end: 30px; }
    #tweets li.is-open .text { display: block; overflow: visible; }
    #tweets .tw-open { position: absolute; top: 6px; inset-inline-end: 6px; display: grid; place-items: center; width: 26px; height: 26px; min-height: 0;
      padding: 0; border: 0; border-radius: 50%; background: var(--tweets-day, var(--sheet)); color: var(--muted); box-shadow: inset 0 0 0 1px var(--line);
      font: inherit; font-size: 16px; font-weight: 700; line-height: 1; cursor: pointer; }
    #tweets .tw-open::before { content: "‹"; transition: transform 0.15s; }
    #tweets li.is-open .tw-open::before { transform: rotate(-90deg); }
    #tweets .more { display: flex; flex-direction: column; gap: 6px; margin-top: 6px; }
    #tweets .pics { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px; }
    #tweets .pic { position: relative; display: block; aspect-ratio: 1; overflow: hidden; border-radius: 8px; background: var(--line); }
    #tweets .pic img { display: block; width: 100%; height: 100%; object-fit: cover; }
    #tweets .pics.one { grid-template-columns: minmax(0, 1fr); }
    #tweets .pics.one .pic { aspect-ratio: auto; min-height: 60px; }
    #tweets .pics.one .pic img { height: auto; max-height: 300px; object-fit: contain; }
    #tweets .quote .pics.one .pic img { max-height: 200px; }
    #tweets .pic.is-video::after { content: "▶"; position: absolute; inset: 0; display: grid; place-items: center; color: #fff; font-size: 24px;
      text-shadow: 0 1px 6px rgba(0, 0, 0, 0.6); }
    #tweets .pic.is-broken img { visibility: hidden; }
    #tweets .pic.is-broken::before { content: "تعذّر عرض الصورة"; position: absolute; inset: 0; display: grid; place-items: center; padding: 6px;
      color: var(--muted); font-size: 12px; text-align: center; }
    #tweets .quote { padding: 8px 10px; border-radius: 10px; background: var(--tweets-day, var(--sheet)); box-shadow: inset 0 0 0 1px var(--line); }
    #tweets .quote .by { color: var(--muted); font-size: 12px; font-weight: 600; }
    #tweets .quote p { margin: 2px 0 0; font-size: 13px; white-space: pre-line; overflow-wrap: anywhere; }
    #tweets .quote .pics { margin-top: 6px; }
    #tweets .meta { display: flex; flex-wrap: wrap; align-items: center; gap: 2px 10px; margin-top: 4px; color: var(--muted); font-size: 12px; }
    #tweets .meta .open { margin-inline-start: auto; color: var(--pine); font-weight: 700; text-decoration: none; }
    #tweets .tweets-empty { margin: 18px 0 6px; text-align: center; color: var(--muted); }
    #tweets .vbtn { flex: 0 0 auto; min-height: 30px; padding: 0 8px; border: 0; border-radius: 8px; background: var(--pine); color: #f4fbf7; box-shadow: none;
      font: inherit; font-size: 12px; font-weight: 700; cursor: pointer; }
    #tweets .vbtn:disabled { opacity: 0.45; cursor: default; }
    #tweets .vstatus { margin: 0 12px 8px; color: var(--muted); font-size: 12px; }
    #tweets .vstatus.is-bad { color: var(--clay); }
    #tweets .views { color: var(--pine); font-weight: 800; }
    #tweets .views.is-none { color: var(--muted); font-weight: 600; }
  </style>'''
TWEETS_PART_BODY = '''<p id="tweets-summary" class="tweets-summary"></p>
      <div id="tweets-days"></div>
      <p id="tweets-empty" class="tweets-empty" hidden>لم تُجمع تغريدات خلال آخر ٧ أيام.</p>'''
TWEETS_PART_SCRIPT = r'''<script>
  (() => {
    const tweets = {{ tweets|tojson }};
    const apiRoot = {{ api_root|tojson }};
    const csrf = {{ csrf_token|tojson }};
    let since = {{ server_now|tojson }};
    const pad = (n) => String(n).padStart(2, "0");
    const dayKey = (when) => when.getFullYear() + "-" + pad(when.getMonth() + 1) + "-" + pad(when.getDate());
    const dayName = new Intl.DateTimeFormat("ar-u-nu-latn", {weekday: "long", day: "numeric", month: "long"});
    const clock = new Intl.DateTimeFormat("ar-u-nu-latn", {hour: "numeric", minute: "2-digit"});
    const number = new Intl.NumberFormat("ar-u-nu-latn");
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    const label = (key, when) => key === dayKey(now) ? "اليوم" : key === dayKey(yesterday) ? "أمس" : dayName.format(when);
    // «عرض الأكثر مشاهدة» is for the days the script allows (today to 6 days ago). A day asked for waits
    // VIEWS_AGAIN seconds (10 minutes) before it can be asked for again; VIEWS_ASKED: the days still waiting
    // (the start of the day, in seconds → when it was asked for), in the server's time.
    const VIEWS_DAYS = {{ views_days|tojson }};
    const VIEWS_AGAIN = {{ views_again|tojson }};
    const VIEWS_ASKED = {{ views_asked|tojson }};
    const skew = since - Date.now() / 1000;
    const serverNow = () => Date.now() / 1000 + skew;
    let lastState = null;            // how the fetching was going when the server last said
    const minutesText = (seconds) => {
      const minutes = Math.max(1, Math.ceil(seconds / 60));
      return minutes === 1 ? "دقيقة" : minutes === 2 ? "دقيقتين" : minutes + (minutes % 100 >= 3 && minutes % 100 <= 10 ? " دقائق" : " دقيقة");
    };
    const daysAgo = (key) => {
      const [year, month, date] = key.split("-").map(Number);
      return Math.round((todayStart - new Date(year, month - 1, date)) / 86400000);
    };
    const canCheck = (key) => daysAgo(key) >= VIEWS_DAYS[0] && daysAgo(key) <= VIEWS_DAYS[1];
    const safeLink = (url) => /^https:\/\/(?:www\.)?(?:x|twitter)\.com\/[^\s"'<>]+$/.test(url || "") ? url : "";
    const viewsText = (tweet) => !tweet.views_at ? "" : tweet.views == null ? "لا يوجد رقم" : number.format(tweet.views) + " مشاهدة";
    const showViews = (span, tweet) => {
      span.textContent = viewsText(tweet);
      span.className = tweet.views == null ? "views is-none" : "views";
      span.hidden = !span.textContent;
    };
    const checkedAt = (seconds) => {
      const when = new Date(seconds * 1000);
      const today = new Date();
      const before = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1);
      const key = dayKey(when);
      return (key === dayKey(today) ? "" : key === dayKey(before) ? "أمس " : dayName.format(when) + " ") + clock.format(when);
    };

    // Each tweet once, under the day (in this device's time zone) it was first collected on.
    const days = new Map();
    for (const tweet of tweets) {
      const key = dayKey(new Date(tweet.at * 1000));
      if (!days.has(key)) days.set(key, {key, items: []});
      days.get(key).items.push({tweet, first: tweet.at});
    }
    const list = [...days.values()].sort((a, b) => b.key.localeCompare(a.key));
    const byId = new Map();          // tweet id → {tweet, day, li, views}
    let total = tweets.length;
    const showTotal = () => { document.getElementById("tweets-summary").textContent = "آخر ٧ أيام · " + total + " تغريدة"; };
    showTotal();
    document.getElementById("tweets-empty").hidden = list.length > 0;
    const box = document.getElementById("tweets-days");

    // A tweet's content (its text, pictures and the tweet it quotes) comes with its views. A small arrow
    // over the tweet opens it: the text in full, then the pictures. Closed, the text shows 3 lines.
    const smaller = (address) => /[?&]name=/.test(address) ? address.replace(/([?&]name=)[^&]*/, "$1small")
      : address + (address.includes("?") ? "&" : "?") + "name=small";
    function pictures(list, tweetLink) {
      const box = document.createElement("div");
      box.className = list.length === 1 ? "pics one" : "pics";
      for (const [kind, address] of list) {
        const link = document.createElement("a");
        link.className = kind === "video" ? "pic is-video" : "pic";
        link.href = kind === "photo" ? address : tweetLink || address;     // a photo opens in full; a video plays on X
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        const image = document.createElement("img");
        image.src = smaller(address);
        image.alt = kind === "video" ? "فيديو" : "صورة";
        image.loading = "lazy";
        image.referrerPolicy = "no-referrer";
        image.addEventListener("error", () => link.classList.add("is-broken"));
        link.append(image);
        box.append(link);
      }
      return box;
    }
    function contentBox(tweet) {
      const box = document.createElement("div");
      box.className = "more";
      const link = safeLink(tweet.url);
      if ((tweet.pictures || []).length) box.append(pictures(tweet.pictures, link));
      const quoted = tweet.quote;
      if (quoted && (quoted.body || (quoted.pictures || []).length)) {
        const quote = document.createElement("div");
        quote.className = "quote";
        if (quoted.by) {
          const by = document.createElement("bdi");
          by.className = "by";
          by.dir = "ltr";
          by.textContent = "@" + quoted.by;
          quote.append(by);
        }
        if (quoted.body) {
          const text = document.createElement("p");
          text.dir = "auto";
          text.textContent = quoted.body;
          quote.append(text);
        }
        if ((quoted.pictures || []).length) quote.append(pictures(quoted.pictures, link));
        box.append(quote);
      }
      return box;
    }
    function setOpen(entry, open) {
      entry.open = open;
      entry.li.classList.toggle("is-open", open);
      entry.toggle.setAttribute("aria-expanded", open ? "true" : "false");
      if (open && !entry.more) {
        entry.more = contentBox(entry.tweet);    // made when first opened: a closed tweet loads no pictures
        entry.text.after(entry.more);
      }
      if (entry.more) entry.more.hidden = !open;
    }
    function showContent(entry) {
      const tweet = entry.tweet;
      entry.text.textContent = tweet.body || tweet.text || "تغريدة";
      const quoted = tweet.quote || {};
      // Not fetched yet (or nothing in it): no arrow.
      if (typeof tweet.body !== "string" || !(tweet.body || (tweet.pictures || []).length || quoted.body || (quoted.pictures || []).length)) return;
      if (!entry.toggle) {
        const toggle = document.createElement("button");
        toggle.type = "button";
        toggle.className = "tw-open";
        toggle.setAttribute("aria-label", "محتوى التغريدة");
        toggle.addEventListener("click", () => setOpen(entry, !entry.open));
        entry.li.classList.add("has-content");
        entry.li.prepend(toggle);
        entry.toggle = toggle;
      }
      if (entry.more) {
        entry.more.remove();                       // new content: made again when shown
        entry.more = null;
      }
      setOpen(entry, entry.open);
    }

    // The day's tweets: most viewed first once it has counts (tweets without one after), else newest first.
    function order(day) {
      const counted = day.items.some((item) => item.tweet.views_at);
      const sorted = [...day.items].sort((a, b) => {
        if (counted) {
          const va = a.tweet.views == null ? -1 : a.tweet.views;
          const vb = b.tweet.views == null ? -1 : b.tweet.views;
          if (va !== vb) return vb - va;
        }
        return b.first - a.first;
      });
      day.ol.replaceChildren(...sorted.map((item) => byId.get(item.tweet.id).li));
      // The first tweet with content shows it, the others are closed: so it is clear each one can be opened.
      let first = true;
      for (const item of sorted) {
        const entry = byId.get(item.tweet.id);
        if (!entry.toggle) continue;
        setOpen(entry, first);
        first = false;
      }
    }

    function showDay(day, state) {
      const status = day.status;
      const waiting = day.items.filter((item) => state && state.waiting.has(item.tweet.id)).length;
      status.className = "vstatus";
      if (waiting) {
        if (day.button) day.button.disabled = true;
        let text = (state.slow ? "يجلب المشاهدات ببطء لأن الخدمة طلبت التمهّل… بقي " : "يجلب المشاهدات… بقي ") + waiting + " من " + day.items.length;
        if (state.paused) text = "متوقف مؤقتًا لتجنّب الحظر · يتابع بعد " + Math.floor(state.paused / 60) + ":" + pad(state.paused % 60) + " · بقي " + waiting + " من " + day.items.length;
        status.textContent = text;
        status.hidden = false;
        day.busy = true;
        return;
      }
      if (day.busy) order(day);      // just finished: sort it now (not while numbers arrive)
      day.busy = false;
      // Asked for less than 10 minutes ago: its button waits (and comes back by itself).
      const wait = day.askedAt ? day.askedAt + VIEWS_AGAIN - serverNow() : 0;
      if (day.button) day.button.disabled = wait > 0;
      const counted = day.items.filter((item) => item.tweet.views_at).length;
      const last = Math.max(0, ...day.items.map((item) => item.tweet.views_at || 0));
      if (state && state.error && day.asked) {
        status.textContent = state.error;
        status.className = "vstatus is-bad";
      } else if (wait > 0) {
        status.textContent = (last ? "مرتّبة من الأكثر مشاهدة · فُحصت " + clock.format(new Date(last * 1000)) + " · " : "")
          + "يُتاح الفحص مجددًا بعد " + minutesText(wait);
      } else if (counted && counted < day.items.length && day.button) {
        status.textContent = "فُحصت " + counted + " من " + day.items.length + " · اضغط «عرض الأكثر مشاهدة» ليكمل";
      } else {
        status.textContent = last ? "مرتّبة من الأكثر مشاهدة · آخر فحص " + checkedAt(last) : "";
      }
      status.hidden = !status.textContent;
    }

    // Every day starts folded (today's too); a day opens when tapped, or when its views are asked for.
    list.forEach((day) => {
      day.items.sort((a, b) => b.first - a.first);
      const details = document.createElement("details");
      const summary = document.createElement("summary");
      const title = document.createElement("span");
      title.className = "day";
      title.textContent = label(day.key, new Date(day.items[0].first * 1000));
      // The count, the button and the fold arrow together: on a narrow screen they go under the day's name as one.
      const tail = document.createElement("span");
      tail.className = "tail";
      const count = document.createElement("span");
      count.className = "count";
      count.textContent = day.items.length + " تغريدة";
      tail.append(count);
      summary.append(title, tail);
      let button = null;
      if (canCheck(day.key)) {
        button = document.createElement("button");
        button.type = "button";
        button.className = "vbtn";
        button.textContent = "عرض الأكثر مشاهدة";
        tail.append(button);
      }
      const status = document.createElement("p");
      status.className = "vstatus";
      status.hidden = true;
      const ol = document.createElement("ol");
      const [year, month, date] = day.key.split("-").map(Number);
      // The day as the script knows it: its start, in seconds (and when it was last asked for, if lately).
      const start = new Date(year, month - 1, date).getTime() / 1000;
      Object.assign(day, {details, ol, status, button, count, start, askedAt: VIEWS_ASKED[String(start)] || 0});
      for (const item of day.items) {
        const li = document.createElement("li");
        const text = document.createElement("p");
        text.className = "text";
        text.dir = "auto";
        const meta = document.createElement("div");
        meta.className = "meta";
        const views = document.createElement("span");
        showViews(views, item.tweet);
        const time = document.createElement("span");
        time.textContent = clock.format(new Date(item.first * 1000));
        meta.append(views, time);
        if (item.tweet.group) {
          const group = document.createElement("span");
          group.textContent = item.tweet.group;
          meta.append(group);
        }
        const link = safeLink(item.tweet.url);
        if (link) {
          const open = document.createElement("a");
          open.className = "open";
          open.href = link;
          open.target = "_blank";
          open.rel = "noopener noreferrer";
          open.textContent = "فتح";
          meta.append(open);
        }
        li.append(text, meta);
        const entry = {tweet: item.tweet, day, li, views, text, toggle: null, more: null, open: false};
        byId.set(item.tweet.id, entry);
        showContent(entry);
      }
      order(day);
      showDay(day, null);
      if (button) button.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        details.open = true;
        day.asked = true;
        button.disabled = true;
        status.className = "vstatus";
        status.textContent = "يبدأ جلب المشاهدات…";
        status.hidden = false;
        const range = [day.start, new Date(year, month - 1, date + 1).getTime() / 1000];
        let data;
        try {
          const response = await fetch(apiRoot + "/tweets/views", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ranges: [range], offset: -new Date().getTimezoneOffset(), csrf_token: csrf})
          });
          data = await response.json();
        } catch (_) {
          data = {success: false, message: "تعذّر الاتصال بالسكربت."};
        }
        if (!data.success) {
          if (data.asked_at) day.askedAt = data.asked_at;     // asked for lately (from another page): it waits
          status.textContent = data.message || "تعذّر البدء.";
          status.className = data.done ? "vstatus" : "vstatus is-bad";
          button.disabled = !!data.done;
          return;
        }
        day.askedAt = (data.asked || {})[String(day.start)] || serverNow();
        apply(data);
        follow();
      });
      details.append(summary, status, ol);
      box.append(details);
    });

    // New counts from the server go into their tweets; then each day's line is brought up to date.
    function apply(data) {
      if (typeof data.now === "number") since = data.now;
      for (const [id, pair] of Object.entries(data.views || {})) {
        const entry = byId.get(id);
        if (!entry) continue;
        entry.tweet.views = pair[0];
        entry.tweet.views_at = pair[1];
        showViews(entry.views, entry.tweet);
        if (pair[2]) {
          for (const key of ["body", "pictures", "quote"]) delete entry.tweet[key];
          Object.assign(entry.tweet, pair[2]);
          showContent(entry);
        }
      }
      for (const id of data.removed || []) {
        const entry = byId.get(id);
        if (!entry) continue;
        entry.li.remove();
        entry.day.items = entry.day.items.filter((item) => item.tweet.id !== id);
        entry.day.count.textContent = entry.day.items.length + " تغريدة";
        byId.delete(id);
        total -= 1;
        showTotal();
      }
      const state = {waiting: new Set(data.waiting || []), paused: data.paused || 0, error: data.error || "", slow: !!data.slow};
      lastState = state;
      for (const day of list) showDay(day, state);
      return data.running || state.waiting.size > 0;
    }

    // The days waiting after a check: their line counts down, and their button comes back after 10 minutes.
    setInterval(() => {
      for (const day of list) if (day.askedAt && !day.busy) showDay(day, lastState);
    }, 15000);

    let following = false;
    async function follow() {
      if (following) return;
      following = true;
      for (;;) {
        await new Promise((done) => setTimeout(done, 2000));
        let data;
        try {
          data = await (await fetch(apiRoot + "/tweets/views?since=" + since, {cache: "no-store"})).json();
        } catch (_) {
          continue;
        }
        if (!data.success || !apply(data)) break;
      }
      following = false;
    }

    // A fetch may already be running (started earlier, or from another tab): follow it.
    fetch(apiRoot + "/tweets/views?since=" + since, {cache: "no-store"})
      .then((response) => response.json())
      .then((data) => { if (data.success && apply(data)) follow(); })
      .catch(() => {});
  })();
  </script>'''
TWEETS_PAGE = r'''<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>التغريدات المجموعة</title>
  <style>
    /* The same look as the panel's page: its type, its header, its cards and its buttons. */
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 400; font-display: swap; src: url("/fonts/plex-arabic-400.woff2") format("woff2");
      unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+0897-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 500; font-display: swap; src: url("/fonts/plex-arabic-500.woff2") format("woff2");
      unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+0897-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 600; font-display: swap; src: url("/fonts/plex-arabic-600.woff2") format("woff2");
      unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+0897-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 400; font-display: swap; src: url("/fonts/plex-latin-400.woff2") format("woff2");
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 500; font-display: swap; src: url("/fonts/plex-latin-500.woff2") format("woff2");
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }
    @font-face { font-family: "Plex Arabic"; font-style: normal; font-weight: 600; font-display: swap; src: url("/fonts/plex-latin-600.woff2") format("woff2");
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }
    :root { --paper: #f3f5fa; --sheet: #ffffff; --ink: #101828; --muted: #667085; --line: #e6e9f0; --pine: #2f5bea; --pine-deep: #2447c8;
      --clay: #b42318; --clay-bg: #fef3f2; --ok-bg: #ecfdf3; --ok-ink: #067647;
      --shadow: 0 1px 2px rgba(16, 24, 40, 0.04), 0 6px 16px -6px rgba(16, 24, 40, 0.08); color-scheme: light; }
    * { box-sizing: border-box; }
    html { -webkit-font-smoothing: antialiased; -webkit-text-size-adjust: 100%; text-size-adjust: 100%; -webkit-tap-highlight-color: transparent; }
    body { margin: 0; min-height: 100vh; min-height: 100dvh; background: var(--paper); color: var(--ink);
      font-family: "Plex Arabic", system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", Tahoma, sans-serif;
      font-size: 14px; line-height: 1.55; overflow-x: hidden; }
    [hidden] { display: none !important; }
    :focus-visible { outline: 2px solid var(--pine); outline-offset: 2px; }
    main { width: min(560px, 100%); margin: 0 auto; padding: calc(8px + env(safe-area-inset-top)) 12px calc(18px + env(safe-area-inset-bottom)); }
    .top {
      position: relative; isolation: isolate; overflow: hidden; display: flex; align-items: center; gap: 10px; padding: 12px;
      border-radius: 18px; color: #fff;
      background:
        radial-gradient(120% 95% at 100% 0%, rgba(92, 132, 255, 0.5) 0%, rgba(92, 132, 255, 0) 58%),
        radial-gradient(85% 90% at 0% 100%, rgba(141, 98, 255, 0.42) 0%, rgba(141, 98, 255, 0) 62%),
        linear-gradient(158deg, #0c1640 0%, #13215e 52%, #1b2675 100%);
      box-shadow: 0 16px 32px -18px rgba(19, 33, 94, 0.75), inset 0 1px 0 rgba(255, 255, 255, 0.08);
      animation: rise 0.42s cubic-bezier(0.2, 0.8, 0.2, 1) both;
    }
    .top::before {
      content: ""; position: absolute; inset: 0; z-index: -1;
      background-image: linear-gradient(rgba(255, 255, 255, 0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.055) 1px, transparent 1px);
      background-size: 20px 20px;
      -webkit-mask-image: linear-gradient(200deg, #000 0%, transparent 70%); mask-image: linear-gradient(200deg, #000 0%, transparent 70%);
    }
    .mark {
      position: relative; display: grid; place-items: center; flex: none; width: 38px; height: 38px; border-radius: 12px;
      background: linear-gradient(135deg, #5b8cff 0%, #7c5cff 100%);
      box-shadow: 0 8px 18px -6px rgba(91, 140, 255, 0.75), inset 0 1px 0 rgba(255, 255, 255, 0.4);
    }
    .mark::before {
      content: ""; width: 19px; height: 19px; background: #fff;
      -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' d='M13.2 2.2 4.6 13.1a.8.8 0 0 0 .6 1.3h5.9l-1 7.2c-.1.8.9 1.2 1.4.6l8.6-10.9a.8.8 0 0 0-.6-1.3h-5.9l1-7.2c.1-.8-.9-1.2-1.4-.6z'/%3E%3C/svg%3E") center / contain no-repeat;
      mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' d='M13.2 2.2 4.6 13.1a.8.8 0 0 0 .6 1.3h5.9l-1 7.2c-.1.8.9 1.2 1.4.6l8.6-10.9a.8.8 0 0 0-.6-1.3h-5.9l1-7.2c.1-.8-.9-1.2-1.4-.6z'/%3E%3C/svg%3E") center / contain no-repeat;
    }
    .titles { min-width: 0; }
    .eyebrow { margin: 0; color: rgba(255, 255, 255, 0.66); font-size: 11px; font-weight: 400; }
    h1 { margin: 0; font-size: 15.5px; line-height: 1.35; font-weight: 600; color: #fff; }
    .back {
      margin-inline-start: auto; flex: none; display: inline-flex; align-items: center; gap: 4px; height: 30px; padding: 0 11px 0 9px;
      border-radius: 999px; border: 1px solid rgba(255, 255, 255, 0.16); background: rgba(255, 255, 255, 0.09); color: #fff;
      font-size: 11.5px; font-weight: 500; text-decoration: none; white-space: nowrap; transition: background 0.15s, transform 0.12s;
    }
    .back::before {
      content: ""; width: 13px; height: 13px; background: currentColor;
      -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m9 18 6-6-6-6'/%3E%3C/svg%3E") center / contain no-repeat;
      mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m9 18 6-6-6-6'/%3E%3C/svg%3E") center / contain no-repeat;
    }
    .back:active { transform: scale(0.97); background: rgba(255, 255, 255, 0.16); }
    .sheet {
      margin-top: 10px; padding: 12px; border-radius: 16px; background: var(--sheet); border: 1px solid var(--line); box-shadow: var(--shadow);
      animation: rise 0.42s cubic-bezier(0.2, 0.8, 0.2, 1) 0.05s both;
    }
    h2 { display: flex; align-items: center; gap: 8px; margin: 0 0 8px; font-size: 13px; font-weight: 600; }
    h2::before {
      content: ""; flex: none; width: 24px; height: 24px; border-radius: 8px; box-shadow: inset 0 0 0 1px #c7d4fc;
      background: #eef2fe url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232f5bea' stroke-width='2.2' stroke-linecap='round'%3E%3Cpath d='M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01'/%3E%3C/svg%3E") center / 13px no-repeat;
    }
    .hint { margin: 0; color: var(--muted); font-size: 12.5px; }
    @keyframes rise { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
    @media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation: none !important; transition: none !important; } }
  </style>
  ''' + TWEETS_PART_STYLE + r'''
</head>
<body>
  <main>
    <header class="top">
      <span class="mark" aria-hidden="true"></span>
      <div class="titles">
        <p class="eyebrow">آخر ٧ أيام</p>
        <h1>التغريدات المجموعة</h1>
      </div>
      <a class="back" href="{{ back }}">رجوع</a>
    </header>
    <section id="tweets" class="sheet">
      ''' + TWEETS_PART_BODY + r'''
    </section>
  </main>
  ''' + TWEETS_PART_SCRIPT + r'''
</body>
</html>
'''


def tweets_part_values() -> dict:
    """What the tweets part is drawn with: the tweets, the panel's address, this browser's CSRF token
    (made here when it has none yet) and the server's time (the counts fetched after it are asked for)."""
    csrf_token = session.get("csrf_token")
    if not csrf_token:
        csrf_token = secrets.token_urlsafe(32)
        session["csrf_token"] = csrf_token
    now = time.time()
    with views_lock:
        asked = {str(start): at for start, at in recent_views_asks(now).items()}
    return {"tweets": collected_payload(), "api_root": "/" + ACCESS_PATH, "csrf_token": csrf_token, "server_now": now,
            "views_days": list(VIEWS_DAYS), "views_asked": asked, "views_again": VIEWS_AGAIN_SECONDS}


def tweets_part() -> dict[str, str]:
    """The tweets part for content.py's page, drawn now: its style, its markup and its script, each
    ready to put in the page as it is (the page gives the part's element the id "tweets")."""
    return {"style": TWEETS_PART_STYLE, "body": TWEETS_PART_BODY,
            "script": render_template_string(TWEETS_PART_SCRIPT, **tweets_part_values())}


@app.get("/<access_path>/tweets")
def tweets_page(access_path: str):
    """«عرض التغريدات»: the tweets collected in the last 7 days, day by day. When content.py shows them
    on its page, under its link box, they are there (an old link to this page goes to them)."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if content_shows_tweets:
        return redirect("/" + ACCESS_PATH + "/content#tweets")
    return render_template_string(TWEETS_PAGE, back="/" + ACCESS_PATH, **tweets_part_values())


@app.post("/<access_path>/tweets/views")
def tweets_views_start(access_path: str):
    """«عرض الأكثر مشاهدة»: queue a day's tweets for their current view count. Any of the last 7 days (in
    the viewer's time zone); a day asked for waits VIEWS_AGAIN_SECONDS before it can be asked for again."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها."), 400
    spans = day_spans(data)
    try:
        offset = int(data.get("offset"))
    except (TypeError, ValueError):
        offset = None
    if not spans or offset is None or abs(offset) > 14 * 60:
        return jsonify(success=False, message="أعد تحميل الصفحة ثم حاول مرة أخرى."), 400
    now = time.time()
    today = local_day_number(now, offset)
    if any(not VIEWS_DAYS[0] <= today - local_day_number((start + end) / 2, offset) <= VIEWS_DAYS[1] for start, end in spans):
        return jsonify(success=False, message="فحص المشاهدات متاح لتغريدات آخر ٧ أيام فقط."), 400
    with views_lock:
        asked = recent_views_asks(now)
    last = max((asked.get(int(start), 0) for start, end in spans), default=0)
    if last:
        return jsonify(success=False, done=True, asked_at=last,
                       message=f"فُحص هذا اليوم قبل قليل. يُتاح الفحص مجددًا بعد {minutes_text(last + VIEWS_AGAIN_SECONDS - now)}."), 409
    with collected_lock:
        rows = [(row.get("views_at") or 0, -row["at"], status_id, row["url"]) for status_id, row in collected_tweets.items()
                if any(start <= row["at"] < end for start, end in spans)]
    rows = [entry for entry in rows if not tweet_is_ignored(entry[3])]
    if not rows:
        return jsonify(success=False, message="لا توجد تغريدات في هذا اليوم."), 400
    # All the day's tweets: the never counted first (newest first), then the oldest counts. So pressing
    # again after a stop starts with the ones it had not reached.
    rows.sort()
    queued = queue_views([status_id for checked, _, status_id, _ in rows])
    with views_lock:
        for start, end in spans:
            views_asked[int(start)] = now
    return jsonify(success=True, queued=queued, asked={str(int(start)): now for start, end in spans}, **views_status_payload(now))


@app.get("/<access_path>/tweets/views")
def tweets_views_status(access_path: str):
    """How «عرض الأكثر مشاهدة» is going, and the counts fetched since the page last asked."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    try:
        since = float(request.args.get("since") or 0)
    except ValueError:
        since = 0.0
    return jsonify(success=True, **views_status_payload(since))


# «إنشاء محتوى»: content.py beside the script adds its page to this panel.
CONTENT_FILE = Path(__file__).resolve().with_name("content.py")
content_ready = threading.Event()
# Why content.py could not be added when the script started ("" if it was, or was not there).
content_problem = ""
# content.py's page shows the collected tweets (under its link box), so they have no page of their own.
content_shows_tweets = False


def content_accounts() -> list[dict]:
    with sessions_lock:
        return [{"id": row["id"], "username": row.get("username") or "", "token": row["token"]} for row in saved_sessions]


def content_gemini_key() -> str:
    """The Gemini key saved on the panel (the owner's, on users' copies: in memory, from the check-ins)."""
    wait_for_owner_keys(gemini_only=True)
    with gemini_lock:
        return str(saved_gemini.get("api_key") or "")


def content_error(exc: BaseException) -> str:
    """The error, with the line of content.py it came from."""
    if isinstance(exc, SyntaxError):
        message, line = exc.msg, exc.lineno
    else:
        message, line = str(exc), None
        for frame in traceback.extract_tb(exc.__traceback__):
            if Path(frame.filename).name == CONTENT_FILE.name:
                line = frame.lineno
    return f"{type(exc).__name__}: {message}" + (f" (line {line})" if line else "")


def attach_content() -> None:
    """Add «إنشاء محتوى»: from content.py beside the owner's script, or, on a user's copy, from the one the
    owner packed into it (a content.py put beside a user's copy is not used: the page is the owner's)."""
    global content_problem, content_shows_tweets
    owner = is_owner_copy()
    if not (CONTENT_FILE.is_file() if owner else CONTENT_EMBEDDED):
        return
    try:
        if owner:
            spec = importlib.util.spec_from_file_location("content_page", CONTENT_FILE)
            content = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(content)
        else:
            source = gzip.decompress(base64.b64decode(CONTENT_EMBEDDED)).decode("utf-8")
            content = importlib.util.module_from_spec(importlib.util.spec_from_loader("content_page", loader=None, origin=str(CONTENT_FILE)))
            content.__file__ = str(CONTENT_FILE)
            exec(compile(source, str(CONTENT_FILE), "exec"), content.__dict__)
        added = content.attach(app, ACCESS_PATH, SimpleNamespace(
            data_dir=DATA_DIR,
            accounts=content_accounts,
            current_token=lambda: screen_payload()["auth_token"],
            # Any free browser profile of the account, so a running task does not hold it up.
            run_browser=lambda token, work: run_on_fresh_browser(token, work),
            goto_x=goto_x,
            gemini_key=content_gemini_key,
            tweets_part=tweets_part,
            posts_per_day=None if owner else USER_POSTS_PER_DAY,
        ))
    except Exception as exc:
        content_problem = content_error(exc)
        print(f"لم تُضف صفحة إنشاء المحتوى ({CONTENT_FILE.name}): {content_problem}", flush=True)
        return
    # What its page took on (an older content.py says nothing: the tweets keep their own page).
    content_shows_tweets = isinstance(added, dict) and bool(added.get("tweets"))
    content_ready.set()


CONTENT_UNAVAILABLE_PAGE = """<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>إنشاء محتوى</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; background: #f3efe6; color: #1c1915; font-family: "IBM Plex Sans Arabic", "Segoe UI", Tahoma, sans-serif; }
    main { width: min(560px, 100%); margin: 0 auto; padding: 16px; }
    h1 { margin: 0; font-size: 18px; }
    .why { margin-top: 12px; padding: 12px 14px; border-radius: 14px; background: #fbf1ee; color: #8d3a32; line-height: 1.7; }
    .why p { margin: 0; }
    .why pre { margin: 8px 0; padding: 8px 10px; border-radius: 8px; background: #fff; direction: ltr; text-align: left;
      white-space: pre-wrap; overflow-wrap: anywhere; font-size: 13px; }
    .hint { color: #6e675e; font-size: 13px; line-height: 1.6; overflow-wrap: anywhere; }
    a { color: #0f6b50; font-weight: 600; }
  </style>
</head>
<body>
  <main>
    <h1>إنشاء محتوى</h1>
    <div class="why">
      <p>{{ reason }}</p>
      {% if problem %}<pre>{{ problem }}</pre>{% endif %}
      {% if fix %}<p>{{ fix }}</p>{% endif %}
    </div>
    <p class="hint">مجلد gg.py الذي يعمل الآن: <bdi dir="ltr">{{ here }}</bdi><br>Python <bdi dir="ltr">{{ python }}</bdi></p>
    <a href="{{ panel }}">العودة للوحة</a>
  </main>
</body>
</html>"""


def content_unavailable(access: str):
    """«إنشاء محتوى» when its page could not be added: why, and what to do."""
    if not hmac.compare_digest(access, ACCESS_PATH):
        abort(404)
    problem = fix = ""
    if not is_owner_copy():
        if content_problem:
            reason, problem, fix = "تعذّر تحميل صفحة إنشاء المحتوى في هذه النسخة:", content_problem, "أرسل هذه الرسالة لصاحب البرنامج."
        else:
            reason = "صفحة إنشاء المحتوى لم تصل إلى هذه النسخة بعد: تصل مع تحديث ينشره صاحب البرنامج."
    elif not CONTENT_FILE.is_file():
        reason = "لا يوجد ملف content.py بجانب gg.py في هذا المجلد."
    elif content_problem:
        reason, problem, fix = "تعذّر تحميل content.py عند تشغيل gg.py:", content_problem, "أعد تنزيل content.py ثم أعد تشغيل gg.py."
    else:
        reason = "وُضع content.py بعد تشغيل gg.py. أعد تشغيل gg.py لتظهر صفحة إنشاء المحتوى."
    return render_template_string(CONTENT_UNAVAILABLE_PAGE, reason=reason, problem=problem, fix=fix, here=str(CONTENT_FILE.parent),
                                  python=sys.version.split()[0], panel="/" + ACCESS_PATH), 503


attach_content()
if not content_ready.is_set():
    # The button shows whenever content.py is beside the script; without its page it says why.
    app.add_url_rule("/<access>/content", "content_unavailable", content_unavailable, methods=["GET"])






# ============================================================================
# قفل التطبيق + ربطه بخادم التحكّم (control_server.py على استضافة المالك).
# التطبيق لا يفتح إلا برمز يعرفه الخادم ولم يوقفه المالك، والتعليقات تُكتب على
# الخادم بمفاتيح المالك (لا تُرسل المفاتيح للجهاز). رابط الخادم مثبّت هنا، وبصمة
# شهادته داخل الرابط فلا يقبل التطبيق خادمًا آخر.
# ============================================================================
import http.client as _http_client
import ssl as _ssl

# رابط خادم التحكّم (المالك يضعه قبل البناء). متغيّر البيئة GG_CONTROL_LINK يغلبه (للاختبار).
CONTROL_LINK = "https://217.216.77.23:8443/yPyHqJkUQvv52HD7xxuomYeST1xigjf0mLPoFJHq#b8a830644e5ed5eb80bf2ee7005ec4c29d7a60ad7f47ab3eee899bb04ac47a46"
_CONTROL_RE = re.compile(r"https://(\[[0-9A-Fa-f:]{2,39}\]|[A-Za-z0-9](?:[A-Za-z0-9.\-]{0,251}[A-Za-z0-9])?)(?::(\d{1,5}))?/([A-Za-z0-9_\-]{16,64})/?#([0-9a-fA-F]{64})")
UNLOCK_PATH = DATA_DIR / "unlock.json"
_unlock_lock = threading.Lock()
_unlock_cache = {"token": "", "code": "", "ok": False, "at": 0.0}
_CONTROL_GRACE = 120          # ثوانٍ: بين كل تحقّق وآخر مع الخادم (حتى لا يُثقل كل طلب)


class _ControlUnreachable(RuntimeError):
    pass


# ---- Ed25519 (RFC 8032), pure Python: signs and checks the «ربط» move order (no crypto package needed) ----
_ED_P = 2 ** 255 - 19
_ED_L = 2 ** 252 + 27742317777372353535851937790883648493
_ED_D = -121665 * pow(121666, _ED_P - 2, _ED_P) % _ED_P
_ED_I = pow(2, (_ED_P - 1) // 4, _ED_P)


def _ed_xrecover(y: int) -> int:
    xx = (y * y - 1) * pow(_ED_D * y * y + 1, _ED_P - 2, _ED_P)
    x = pow(xx, (_ED_P + 3) // 8, _ED_P)
    if (x * x - xx) % _ED_P:
        x = x * _ED_I % _ED_P
    return _ED_P - x if x & 1 else x


_ED_BY = 4 * pow(5, _ED_P - 2, _ED_P) % _ED_P
_ED_BX = _ed_xrecover(_ED_BY)
_ED_B = (_ED_BX, _ED_BY, 1, _ED_BX * _ED_BY % _ED_P)


def _ed_add(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = (y1 - x1) * (y2 - x2) % _ED_P
    b = (y1 + x1) * (y2 + x2) % _ED_P
    c = t1 * 2 * _ED_D * t2 % _ED_P
    d = z1 * 2 * z2 % _ED_P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _ED_P, g * h % _ED_P, f * g % _ED_P, e * h % _ED_P)


def _ed_mul(s: int, p):
    q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            q = _ed_add(q, p)
        p = _ed_add(p, p)
        s >>= 1
    return q


def _ed_encode(p) -> bytes:
    x, y, z, _ = p
    zi = pow(z, _ED_P - 2, _ED_P)
    x, y = x * zi % _ED_P, y * zi % _ED_P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _ed_decode(s: bytes):
    y = int.from_bytes(s, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= _ED_P:
        raise ValueError("bad point")
    x = _ed_xrecover(y)
    if (x & 1) != sign:
        x = _ED_P - x
    if (-x * x + y * y - 1 - _ED_D * x * x * y * y) % _ED_P or (x == 0 and sign):
        raise ValueError("bad point")
    return (x, y, 1, x * y % _ED_P)


def _ed_secret(seed: bytes) -> tuple[int, bytes]:
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a = (a & ((1 << 254) - 8)) | (1 << 254)
    return a, h[32:]


def ed_public(seed: bytes) -> bytes:
    return _ed_encode(_ed_mul(_ed_secret(seed)[0], _ED_B))


def ed_sign(seed: bytes, message: bytes) -> bytes:
    a, prefix = _ed_secret(seed)
    public = _ed_encode(_ed_mul(a, _ED_B))
    r = int.from_bytes(hashlib.sha512(prefix + message).digest(), "little") % _ED_L
    big_r = _ed_encode(_ed_mul(r, _ED_B))
    k = int.from_bytes(hashlib.sha512(big_r + public + message).digest(), "little") % _ED_L
    return big_r + ((r + k * a) % _ED_L).to_bytes(32, "little")


def ed_verify(public: bytes, message: bytes, signature: bytes) -> bool:
    if len(public) != 32 or len(signature) != 64:
        return False
    try:
        point_a, point_r = _ed_decode(public), _ed_decode(signature[:32])
    except ValueError:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _ED_L:
        return False
    k = int.from_bytes(hashlib.sha512(signature[:32] + public + message).digest(), "little") % _ED_L
    return _ed_encode(_ed_mul(s, _ED_B)) == _ed_encode(_ed_add(point_r, _ed_mul(k, point_a)))


# «الربط»: إن تعطّل خادم التحكّم وشغّل المالك لوحته على خادم جديد، يضغط فيها «ربط» بكلمة مرورها فيصل أمر نقل موقَّع
# إلى وسيط عام (ntfy.sh) مشفّرًا. التطبيق يحفظ المفتاح العام لكلمة المرور (يرسله الخادم مع كل تحقق)، وحين يتعذّر
# عليه الوصول لخادمه يقرأ الوسيط، ولا يتبع إلا أمرًا موقَّعًا بذلك المفتاح، ثم يجرّب الخادم الجديد قبل الانتقال إليه.
CONTROL_STATE_PATH = DATA_DIR / "control.json"
MOVE_RELAY = (os.environ.get("GG_RELAY") or "https://ntfy.sh").rstrip("/")
_control_state_lock = threading.Lock()
_control_health = {"ok_at": 0.0, "fail_since": 0.0, "relay_at": 0.0}


def _control_state() -> dict:
    data = read_private_json(CONTROL_STATE_PATH) or {}
    if not isinstance(data, dict):
        return {}
    # A new build with another link in it: that link wins over one the app moved to before.
    if data.get("link") and data.get("built") != CONTROL_LINK:
        data = {"move_key": data.get("move_key") or "", "built": CONTROL_LINK}
    return data


def _save_control_state(**fields) -> None:
    with _control_state_lock:
        data = _control_state()
        data.update(fields, built=CONTROL_LINK)
        write_private_json(CONTROL_STATE_PATH, data)


def control_link() -> str:
    return (os.environ.get("GG_CONTROL_LINK") or _control_state().get("link") or CONTROL_LINK or "").strip()


def remember_move_key(answer: dict) -> None:
    """The control server's move key (the public half of its password's key), kept for «الربط»."""
    key = str((answer or {}).get("move_key") or "").lower()
    if re.fullmatch(r"[0-9a-f]{64}", key) and key != _control_state().get("move_key"):
        _save_control_state(move_key=key)


def _move_open(public: bytes, text: str) -> tuple[str, int] | None:
    """(link, time) of a move order signed with this key, or None."""
    try:
        if not text.startswith("ggmv1."):
            return None
        raw = base64.urlsafe_b64decode(text[6:].strip().encode("ascii"))
        nonce, body = raw[:16], raw[16:]
        key = hashlib.sha256(b"gg-move-enc|" + public).digest()
        stream = bytearray()
        counter = 0
        while len(stream) < len(body):
            stream += hashlib.sha256(key + nonce + counter.to_bytes(4, "big")).digest()
            counter += 1
        data = json.loads(bytes(a ^ b for a, b in zip(body, stream)).decode("utf-8"))
        link, at = str(data.get("link") or ""), int(data.get("at") or 0)
        if not ed_verify(public, f"gg-move|{link}|{at}".encode("utf-8"), bytes.fromhex(str(data.get("sig") or ""))):
            return None
        return (link, at) if _control_parse(link) else None
    except Exception:
        return None


def follow_control_move() -> str:
    """Reads the relay for a move order of this app's owner; moves when it is newer and its server answers.
    Returns the new link, or ""."""
    state = _control_state()
    key = state.get("move_key") or ""
    if not re.fullmatch(r"[0-9a-f]{64}", key):
        return ""
    public = bytes.fromhex(key)
    topic = "gg" + hashlib.sha256(b"gg-relay|" + public).hexdigest()[:30]
    try:
        request_ = urllib.request.Request(f"{MOVE_RELAY}/{topic}/json?poll=1&since=all",
                                          headers={"User-Agent": "tg-groups-app/1.0", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(request_, timeout=20) as answer:
            lines = answer.read(1 << 20).decode("utf-8", "replace").splitlines()
    except Exception:
        return ""
    best = None
    for line in lines:
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if not isinstance(event, dict) or event.get("event") != "message":
            continue
        found = _move_open(public, str(event.get("message") or ""))
        if found and (best is None or found[1] > best[1]):
            best = found
    if not best or best[1] <= int(state.get("moved_at") or 0) or best[0] == control_link():
        return ""
    link, at = best
    try:
        # (the new server must answer, with the certificate the order names, before the app moves)
        _control_request("check", {"token": _current_token()}, seconds=10, link=link)
    except _ControlUnreachable:
        return ""
    except RuntimeError as exc:
        if "شهادة" in str(exc) or "برنامج آخر" in str(exc):
            return ""
    _save_control_state(link=link, moved_at=at)
    with _unlock_lock:
        _unlock_cache.update(ok=False, at=0.0)        # (the next look asks the new server)
    print("انتقل التطبيق إلى خادم التحكّم الجديد (أمر «ربط» موقَّع من صاحب البرنامج).", flush=True)
    return link


def watch_control_moves() -> None:
    """Every minute: when the control server has not answered for 5 minutes, the relay is read (every 5 minutes);
    else once every 3 hours (a move made while the old server still works)."""
    while True:
        time.sleep(60)
        try:
            now = time.monotonic()
            down = _control_health["fail_since"] and now - _control_health["fail_since"] > 300
            due = now - _control_health["relay_at"] > (300 if down else 3 * 3600)
            if control_configured() and due and _control_state().get("move_key"):
                _control_health["relay_at"] = now
                follow_control_move()
        except Exception:
            pass


DEVICE_PATH = DATA_DIR / "device.json"
_device_lock = threading.Lock()
_device_id_cache = ""


def device_id() -> str:
    """A stable id for this install, made once and kept — so a code binds to one phone (a copy of the code on
    another phone is refused). Letters and digits only."""
    global _device_id_cache
    with _device_lock:
        if _device_id_cache:
            return _device_id_cache
        got = str((read_private_json(DEVICE_PATH) or {}).get("id") or "")
        if not re.fullmatch(r"[A-Za-z0-9]{16,64}", got):
            got = secrets.token_hex(16)
            write_private_json(DEVICE_PATH, {"id": got})
        _device_id_cache = got
        return got


def _control_parse(link: str):
    match = _CONTROL_RE.fullmatch(link or "")
    if not match:
        return None
    port = int(match.group(2) or 443)
    if not 0 < port < 65536:
        return None
    return match.group(1), port, match.group(3), match.group(4).lower()


def control_configured() -> bool:
    return _control_parse(control_link()) is not None


def _control_request(action: str, body: dict | None = None, seconds: float = 30, link: str = "", max_read: int = 1 << 20) -> dict:
    """طلب واحد لخادم التحكّم، مع تثبيت شهادته ببصمة الرابط. يعيد ما يردّه، أو يرفع خطأ بعبارة للمستخدم."""
    try:
        data = _control_request_once(action, body, seconds, link, max_read)
    except RuntimeError as exc:
        # Down, or another program (another certificate) on its address: as a server that is gone, for «الربط».
        gone = isinstance(exc, _ControlUnreachable) or "شهادة" in str(exc) or "برنامج آخر" in str(exc)
        if gone and not link and not _control_health["fail_since"]:
            _control_health["fail_since"] = time.monotonic()
        raise
    if not link:
        _control_health.update(ok_at=time.monotonic(), fail_since=0.0)
    return data


def _control_request_once(action: str, body: dict | None, seconds: float, link: str, max_read: int = 1 << 20) -> dict:
    parsed = _control_parse(link or control_link())
    if not parsed:
        raise RuntimeError("خادم التحكّم غير مضبوط في هذه النسخة. راجع صاحب البرنامج.")
    host, port, secret, pin = parsed
    context = _ssl.SSLContext(_ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = _ssl.CERT_NONE               # الشهادة تُعرف ببصمتها لا باسمها
    connection = _http_client.HTTPSConnection(host, port, timeout=8, context=context)
    try:
        try:
            connection.connect()
        except _ssl.SSLError:
            raise RuntimeError("على عنوان خادم التحكّم برنامج آخر. راجع الرابط.") from None
        except OSError:
            raise _ControlUnreachable("تعذّر الوصول إلى خادم التحكّم. تأكد من الإنترنت ومن أن الخادم يعمل.") from None
        seen = hashlib.sha256(connection.sock.getpeercert(binary_form=True) or b"").hexdigest()
        if not hmac.compare_digest(seen, pin):
            raise RuntimeError("شهادة خادم التحكّم لا تطابق الرابط المثبّت في التطبيق.")
        connection.sock.settimeout(seconds)
        sent = json.dumps(body or {}, ensure_ascii=False).encode("utf-8")
        connection.request("POST", f"/{secret}/{action}", body=sent,
                           headers={"Content-Type": "application/json; charset=utf-8", "Accept": "application/json", "Connection": "close"})
        answer = connection.getresponse()
        status, raw = answer.status, answer.read(max_read)
    except (socket.timeout, TimeoutError):
        raise _ControlUnreachable("طال انتظار خادم التحكّم. أعد المحاولة.") from None
    except (OSError, _http_client.HTTPException):
        raise _ControlUnreachable("انقطع الاتصال بخادم التحكّم. أعد المحاولة.") from None
    finally:
        connection.close()
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        data = None
    if not isinstance(data, dict):
        raise RuntimeError("ردّ غير مفهوم من خادم التحكّم." if status == 200 else f"ردّ خادم التحكّم برمز {status}.")
    if not data.get("ok"):
        raise RuntimeError(str(data.get("error") or "").strip() or "خطأ من خادم التحكّم.")
    return data


def _load_unlock() -> tuple[str, str]:
    data = read_private_json(UNLOCK_PATH) or {}
    return str(data.get("token") or ""), str(data.get("code") or "")


def _current_token() -> str:
    with _unlock_lock:
        if _unlock_cache["token"]:
            return _unlock_cache["token"]
    token, code = _load_unlock()
    with _unlock_lock:
        _unlock_cache["token"], _unlock_cache["code"] = token, code
    return token


def _forget_unlock() -> None:
    try:
        UNLOCK_PATH.unlink()
    except OSError:
        pass
    with _unlock_lock:
        _unlock_cache.update(token="", code="", ok=False, at=0.0)


def control_activate(code: str) -> str:
    """يُفعّل بالرمز عبر الخادم (مربوطًا بجهاز هذا التطبيق)، ويحفظ رمز الجلسة. يعيد اسم المحرّك، أو يرفع خطأ."""
    data = _control_request("activate", {"code": code, "device": device_id()})
    token = str(data.get("token") or "")
    if not token:
        raise RuntimeError("لم يصل رمز الجلسة من الخادم. أعد المحاولة.")
    write_private_json(UNLOCK_PATH, {"token": token, "code": code})
    remember_move_key(data)
    with _unlock_lock:
        _unlock_cache.update(token=token, code=code, ok=True, at=time.monotonic())
    stats_changed()
    return str(data.get("engine") or "")


def is_unlocked() -> bool:
    """هل التطبيق مفتوح: يوجد رمز جلسة محفوظ والخادم لم يوقف الرمز (يُتحقّق كل فترة). عند تعذّر الوصول
    للخادم يبقى على آخر حالة معروفة، فلا يُقفل المستخدم بانقطاع مؤقت للإنترنت."""
    token = _current_token()
    if not token:
        return False
    now = time.monotonic()
    with _unlock_lock:
        if _unlock_cache["ok"] and now - _unlock_cache["at"] < _CONTROL_GRACE:
            return True
    try:
        answer = _control_request("check", {"token": token}, seconds=8)
        remember_move_key(answer)
        active = bool(answer.get("active"))
    except _ControlUnreachable:
        with _unlock_lock:
            _unlock_cache.update(ok=True, at=now)       # إمهال: يبقى مفتوحًا برمز محفوظ ما دام الخادم بعيدًا
        return True
    except RuntimeError:
        active = False
    with _unlock_lock:
        _unlock_cache.update(ok=active, at=now)
    if not active:
        _forget_unlock()
    return active


def control_comment(tweet_text: str, image: bytes | None, voice: str, account: str, tweet_id: str) -> str:
    """تعليق واحد يُكتب على خادم التحكّم بمفتاح المالك المُفعّل (لا يُرسل المفتاح للجهاز)."""
    token = _current_token()
    if not token:
        raise RuntimeError("التطبيق غير مُفعّل. أدخل رمز الدخول.")
    if account:
        manner = int(hashlib.sha256(("reply-manner:" + account).encode("utf-8")).hexdigest()[:8], 16) % len(REPLY_MANNERS)
    else:
        manner = random.randrange(len(REPLY_MANNERS))
    with replies_memory_lock:
        own = list(replies_by_account.get(account) or []) if account else []
        others = [text for text in (replies_by_tweet.get(tweet_id) or []) if text not in own] if tweet_id else []
    before = (own[-6:] + others[-4:])[-10:]
    body = {"token": token, "text": tweet_text or "", "voice": voice, "manner": manner, "before": before,
            "account": account or "", "name": account_names.get(account, "")}
    if image:
        body["image"] = base64.b64encode(image).decode("ascii")
    text = str(_control_request("comment", body, seconds=90).get("comment") or "")
    if not text:
        raise RuntimeError("لم يصل تعليق من خادم التحكّم. أعد المحاولة.")
    record_comment_generated()
    forget_comments_usage()
    remember_reply(account, tweet_id, text)
    return text


# تنبيهات المالك وتعليماته من لوحة خادم التحكّم: تُطلب كل فترة، ويُحفظ آخر رقم وصل فلا يصل التنبيه مرتين.
NOTICES_SEEN_PATH = DATA_DIR / "notices_seen.json"
_notices_lock = threading.Lock()


def control_notices() -> list:
    """التنبيهات الجديدة من خادم التحكّم (الأقدم أولًا)، أو قائمة فارغة إن لم يكن مضبوطًا أو تعذّر الوصول."""
    if not control_configured():
        return []
    token = _current_token()
    if not token:
        return []
    with _notices_lock:
        try:
            after = int((read_private_json(NOTICES_SEEN_PATH) or {}).get("last") or 0)
        except (TypeError, ValueError):
            after = 0
        try:
            answer = _control_request("notices", {"token": token, "after": after}, seconds=10)
        except RuntimeError:                       # (_ControlUnreachable منها): يُعاد الطلب في المرة القادمة
            return []
        items = []
        for item in answer.get("notices") or []:
            if not isinstance(item, dict):
                continue
            text = str(item.get("text") or "").strip()[:1000]
            if not text:
                continue
            kind = str(item.get("kind") or "info")
            items.append({"id": int(item.get("id") or 0), "text": text,
                          "kind": kind if kind in ("info", "warn", "urgent") else "info", "at": int(item.get("at") or 0)})
        try:
            last = int(answer.get("last") or 0)
        except (TypeError, ValueError):
            last = after
        if last != after:
            write_private_json(NOTICES_SEEN_PATH, {"last": last})
    for item in items:
        print(f"تنبيه من الإدارة: {item['text']}", flush=True)
    return items


@app.get("/<access_path>/notices")
def notices_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    return jsonify(success=True, notices=control_notices())


# «مساعدة»: رسالة من المستخدم إلى صاحب البرنامج (تصل إلى «الرسائل» في لوحة التحكّم) فيها وصف المشكلة وصور أو فيديو
# قصير. الصفحة تسلّم الملفات هنا واحدًا واحدًا (support/upload)، ثم ترسل الرسالة (support/send) فتُرفع الملفات إلى
# الخادم واحدًا واحدًا ثم الرسالة، في الخلفية، وتسأل الصفحة عن الحال (support/status).
SUPPORT_OUTBOX = DATA_DIR / "support-outbox"
SUPPORT_IMAGE_MAX = 8 * 1024 * 1024
SUPPORT_VIDEO_MAX = 25 * 1024 * 1024
SUPPORT_FILES_MAX = 5
_support_lock = threading.Lock()
_support_state = {"id": "", "state": "idle", "message": ""}


def _media_kind(head: bytes) -> str:
    """"image" or "video" by the file's own first bytes, or "" (the control server checks again)."""
    if head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG") or head[:6] in (b"GIF87a", b"GIF89a") \
            or (head[:4] == b"RIFF" and head[8:12] == b"WEBP"):
        return "image"
    if head[4:8] == b"ftyp" and head[8:12] not in (b"heic", b"heix", b"mif1", b"msf1"):
        return "video"
    if head.startswith(b"\x1a\x45\xdf\xa3"):
        return "video"
    return ""


def _support_set(**fields) -> None:
    with _support_lock:
        _support_state.update(fields)


def support_meta() -> dict:
    """What is added to the message by itself, to help find the problem: the version, the phone, the accounts and
    the last lines of the log."""
    meta = {"version": shown_version(), "device": "", "log": "",
            "accounts": ", ".join("@" + name for name in sorted(set(account_names.values())) if name)}
    if IN_APP:
        try:
            import ggapp
            meta["device"] = str(ggapp.device_line())
            meta["log"] = (str(ggapp.log_text(60)) + "\n\n" + str(ggapp.general_log_text(40)))[-12000:]
        except Exception:
            pass
    return meta


def _support_send(send_id: str, text: str, ids: list[str]) -> None:
    token = _current_token()
    try:
        if not token:
            raise RuntimeError("التطبيق غير مُفعّل. أدخل رمز الدخول.")
        sent = []
        for number, file_id in enumerate(ids, 1):
            _support_set(state="sending", message=f"يرفع الملف {number} من {len(ids)}… (قد يأخذ وقتًا مع الفيديو)")
            path = SUPPORT_OUTBOX / file_id
            name = (read_private_json(SUPPORT_OUTBOX / (file_id + ".json")) or {}).get("name") or ""
            body = {"token": token, "name": name, "data": base64.b64encode(path.read_bytes()).decode("ascii")}
            sent.append(str(_control_request("support-file", body, seconds=300).get("file") or ""))
        _support_set(state="sending", message="يرسل الرسالة…")
        _control_request("support", {"token": token, "text": text, "files": [f for f in sent if f], "meta": support_meta()},
                         seconds=60)
        _support_set(state="done", message="وصلت رسالتك إلى صاحب البرنامج. يصلك ردّه في قائمة التنبيهات.")
        print("أُرسلت رسالة «مساعدة» إلى صاحب البرنامج.", flush=True)
    except (RuntimeError, OSError) as exc:
        _support_set(state="failed", message="لم تُرسل الرسالة: " + (str(exc) or "خطأ غير متوقع."))
    finally:
        for file_id in ids:
            for path in (SUPPORT_OUTBOX / file_id, SUPPORT_OUTBOX / (file_id + ".json")):
                try:
                    path.unlink()
                except OSError:
                    pass


@app.post("/<access_path>/support/upload")
def support_upload_endpoint(access_path: str):
    """One picture or video for «مساعدة», as the request's whole body (it is larger than the other requests)."""
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    if not control_configured():
        return jsonify(success=False, message="المساعدة غير متاحة في هذه النسخة."), 400
    video = (request.headers.get("X-File-Type") or "").startswith("video/")
    limit = SUPPORT_VIDEO_MAX if video else SUPPORT_IMAGE_MAX
    size = request.content_length or 0
    if size <= 0:
        return jsonify(success=False, message="لم يصل الملف."), 400
    if size > limit:
        return jsonify(success=False, message=f"الملف أكبر من {limit // 1048576} ميجابايت."), 413
    SUPPORT_OUTBOX.mkdir(parents=True, exist_ok=True)
    cutoff = time.time() - 3 * 3600                     # (files left by a send that never came)
    for old in SUPPORT_OUTBOX.glob("*"):
        try:
            if old.stat().st_mtime < cutoff:
                old.unlink()
        except OSError:
            pass
    file_id = secrets.token_hex(12)
    path = SUPPORT_OUTBOX / file_id
    stream = request.environ.get("wsgi.input")
    left = size
    with open(path, "wb") as out:
        while left > 0:
            chunk = stream.read(min(65536, left)) if stream is not None else b""
            if not chunk:
                break
            out.write(chunk)
            left -= len(chunk)
    with open(path, "rb") as handle:
        head = handle.read(16)
    if left > 0 or not _media_kind(head):
        path.unlink(missing_ok=True)
        return jsonify(success=False, message="وصل الملف ناقصًا أو بنوع غير مدعوم. أرفق صورة أو فيديو MP4."), 400
    from urllib.parse import unquote
    name = unquote(request.headers.get("X-File-Name") or "")[:80]
    write_private_json(SUPPORT_OUTBOX / (file_id + ".json"), {"name": name})
    return jsonify(success=True, id=file_id)


@app.post("/<access_path>/support/send")
def support_send_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data):
        return jsonify(success=False, message="انتهت صلاحية الصفحة. أعد تحميلها ثم حاول مجددًا."), 400
    if not control_configured():
        return jsonify(success=False, message="المساعدة غير متاحة في هذه النسخة."), 400
    text = str(data.get("text") or "").strip()[:2000]
    ids = [str(item) for item in (data.get("files") or []) if re.fullmatch(r"[0-9a-f]{24}", str(item))][:SUPPORT_FILES_MAX]
    ids = [item for item in ids if (SUPPORT_OUTBOX / item).is_file()]
    if not text and not ids:
        return jsonify(success=False, message="اكتب وصف المشكلة."), 400
    with _support_lock:
        if _support_state["state"] == "sending":
            return jsonify(success=False, message="رسالة سابقة تُرسل الآن. انتظر انتهاءها."), 409
        send_id = secrets.token_hex(8)
        _support_state.update(id=send_id, state="sending", message="يبدأ الإرسال…")
    threading.Thread(target=_support_send, args=(send_id, text, ids), name="support-send", daemon=True).start()
    return jsonify(success=True, id=send_id)


@app.get("/<access_path>/support/status")
def support_status_endpoint(access_path: str):
    if not hmac.compare_digest(access_path, ACCESS_PATH):
        abort(404)
    if not csrf_matches(request.headers.get("X-CSRF-Token", "")):
        return jsonify(success=False, message="انتهت صلاحية الصفحة."), 400
    with _support_lock:
        return jsonify(success=True, **_support_state)


# أرقام التنفيذ (كما في رأس الصفحة) لكل حساب X تُرسل إلى خادم التحكّم ليراها المالك عند كل مستخدم. تُرسل قيمها
# كاملة لا زيادات، بعد كل تنفيذ (تُجمع ثوانيَ قليلة في إرسال واحد)، وكل ساعة حتى لو لم تتغيّر.
_stats_wake = threading.Event()
_stats_sent = {"body": "", "at": 0.0}
_STATS_GATHER = 20            # ثوانٍ: تُجمع فيها عدة تنفيذات في إرسال واحد
_STATS_EVERY = 3600           # ثوانٍ: يُرسل كل ساعة ولو لم يتغيّر شيء (إن فُقد إرسال أو أُعيد ضبط الخادم)


def stats_changed() -> None:
    _stats_wake.set()


def stats_snapshot() -> list:
    with action_counts_lock:
        rows = {key: dict(row) for key, row in action_counts.items()}
    return [dict({action: int(row.get(action) or 0) for action in ACTION_NAMES}, id=key, name=account_names.get(key, ""))
            for key, row in rows.items()]


def report_stats() -> bool:
    """يرسل الأرقام إن تغيّرت منذ آخر إرسال ناجح (أو مضت ساعة). يعيد True إن لم يبقَ شيء يُرسل."""
    if not control_configured():
        return True
    token = _current_token()
    if not token:
        return True
    accounts = stats_snapshot()
    body = json.dumps(accounts, sort_keys=True, ensure_ascii=False)
    if body == _stats_sent["body"] and time.monotonic() - _stats_sent["at"] < _STATS_EVERY:
        return True
    try:
        _control_request("stats", {"token": token, "accounts": accounts}, seconds=15)
    except RuntimeError:
        return False
    _stats_sent.update(body=body, at=time.monotonic())
    return True


def report_stats_in_background() -> None:
    _stats_wake.set()                         # أول إرسال بعد التشغيل
    while True:
        _stats_wake.wait(_STATS_EVERY)
        _stats_wake.clear()
        time.sleep(_STATS_GATHER)
        try:
            done = report_stats()
        except Exception:
            done = False
        if not done:                          # تعذّر الوصول: يُعاد بعد دقيقتين
            time.sleep(120)
            _stats_wake.set()


threading.Thread(target=report_stats_in_background, name="stats-to-control", daemon=True).start()
threading.Thread(target=watch_control_moves, name="control-moves", daemon=True).start()


# «الأعطال»: كل فشل (مهمة توقفت بخطأ، أو اكتملت وفيها إجراءات فاشلة، أو خطأ في السكربت) يُرسل وحده إلى لوحة
# التحكّم مع سجل ذلك الحساب، بلا أي تنبيه للمستخدم. تُحذف من السجل قبل الإرسال الرموز والمفاتيح وكلمات المرور.
# التقارير تنتظر في الجهاز إن تعذّر الوصول للخادم، وتُرسل بعده.
FAILURE_OUTBOX = DATA_DIR / "failure-outbox.json"
_FAILURE_PER_HOUR = 20
_FAILURE_OUTBOX_MAX = 30
_failure_lock = threading.Lock()
_failure_wake = threading.Event()
_failure_recent: deque = deque()             # (when, what): the last hour's reports, for the limit and repeats
_SCRUB = (
    (re.compile(r"(?i)\b(auth_token|ct0|twid|kdt|token|api[_-]?key|password|passwd|pin|secret|cookie)(\s*[=:]\s*)[^\s,;&\"']+"),
     r"\1\2[مخفي]"),
    (re.compile(r"\bAIza[0-9A-Za-z_\-]{20,}"), "[مفتاح]"),
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{16,}"), "[مفتاح]"),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._\-]+"), "Bearer [مخفي]"),
    (re.compile(r"\b[0-9a-fA-F]{32,}\b"), "[مخفي]"),                 # (an X sign-in token is 40 of these)
    (re.compile(r"[A-Za-z0-9_\-+/]{60,}={0,2}"), "[مخفي]"),          # (long codes: tokens, keys)
)


def scrub(text: str) -> str:
    text = str(text or "")
    for pattern, replacement in _SCRUB:
        text = pattern.sub(replacement, text)
    return text


def _account_log(key: str, lines: int = 200) -> str:
    try:
        import ggapp
        own = "\n".join(ggapp._lines_of(key, lines)) if key else ""
        general = "\n".join(ggapp._lines_of("", 60))
        return ((own + "\n\n--- السجل العام ---\n" + general) if own else general)[-20000:]
    except Exception:
        return ""


def _click_log(key: str) -> str:
    try:
        path = account_dir(key) / "click-log.txt" if key else CLICK_LOG_PATH
        with open(path, encoding="utf-8", errors="replace") as handle:
            return handle.read()[-8000:]
    except OSError:
        return ""


def _failure_base() -> dict:
    device = ""
    if IN_APP:
        try:
            import ggapp
            device = str(ggapp.device_line())
        except Exception:
            pass
    return {"version": shown_version(), "device": device}


def queue_failure(report: dict) -> None:
    """Keeps the report for sending (at most 20 an hour; one already sent in the last 10 minutes is not sent again)."""
    if not control_configured():
        return
    now = time.time()
    what = (report.get("title") or "") + "|" + (report.get("message") or "")[:200] + "|" + (report.get("account") or "")
    with _failure_lock:
        while _failure_recent and now - _failure_recent[0][0] > 3600:
            _failure_recent.popleft()
        if len(_failure_recent) >= _FAILURE_PER_HOUR or any(w == what and now - t < 600 for t, w in _failure_recent):
            return
        _failure_recent.append((now, what))
        for key in ("title", "message", "task", "log", "clicks", "trace", "device"):
            if report.get(key):
                report[key] = scrub(report[key])
        report["failed"] = [scrub(line) for line in report.get("failed") or []]
        outbox = read_private_json(FAILURE_OUTBOX) or {}
        items = outbox.get("items") if isinstance(outbox.get("items"), list) else []
        items.append(report)
        write_private_json(FAILURE_OUTBOX, {"items": items[-_FAILURE_OUTBOX_MAX:]})
    _failure_wake.set()


def failure_check(job_id: str) -> None:
    """A task just finished: if it failed, or some of its actions did, its report is made (a moment later, so the
    last lines it printed are in the log)."""
    def later() -> None:
        time.sleep(3)
        with jobs_lock:
            job = jobs.get(job_id)
            if not job or job.get("failure_reported") or (job.get("kind") or "") != "execute":
                return
            job["failure_reported"] = True
            success, message = bool(job.get("success")), str(job.get("message") or "")
            results = [dict(row) for row in job.get("results") or [] if isinstance(row, dict)]
            key, task = str(job.get("account") or ""), str(job.get("username") or "")
            requested = int(job.get("requested") or 0)
        if message.strip() == "تم إيقاف التنفيذ.":
            return                                     # (stopped by the user: not a failure)
        failed = [f"{row.get('url') or ''} · {action}: {note}" for row in results
                  for action, note in (row.get("actions") or {}).items() if action_failed(note)]
        if success and not failed:
            return
        summary = {"requested": requested, "done": len(results)}
        if failed:
            summary["failed"] = len(failed)
        report = dict(_failure_base(), kind="task" if not success else "actions",
                      title="فشلت المهمة" if not success else f"اكتملت المهمة وفيها {len(failed)} إجراء فاشل",
                      message=message, task=task, account=account_names.get(key, ""), summary=summary,
                      failed=failed[:50], log=_account_log(key), clicks=_click_log(key))
        queue_failure(report)
    threading.Thread(target=later, name="failure-check", daemon=True).start()


def report_script_error(sender, exception=None, **_extra) -> None:
    """An error the script did not expect, while answering the page."""
    try:
        if exception is None or isinstance(exception, (JobStopped,)):
            return
        key = current_account()
        trace = "".join(traceback.format_exception(type(exception), exception, exception.__traceback__))[-6000:]
        queue_failure(dict(_failure_base(), kind="error", title=f"خطأ في السكربت: {type(exception).__name__}",
                           message=str(exception)[:500], account=account_names.get(key, ""), trace=trace,
                           log=_account_log(key)))
    except Exception:
        pass


try:
    from flask import got_request_exception as _got_request_exception
    _got_request_exception.connect(report_script_error, app)
except Exception:
    pass


def send_failures_in_background() -> None:
    while True:
        _failure_wake.wait(300)
        _failure_wake.clear()
        token = _current_token()
        if not control_configured() or not token:
            continue
        while True:
            with _failure_lock:
                items = (read_private_json(FAILURE_OUTBOX) or {}).get("items") or []
            if not items:
                break
            try:
                _control_request("failure", {"token": token, "report": items[0]}, seconds=30)
            except _ControlUnreachable:
                break                                   # (sent later)
            except RuntimeError:
                pass                                    # (refused, e.g. an older server: dropped, not sent again)
            with _failure_lock:
                left = (read_private_json(FAILURE_OUTBOX) or {}).get("items") or []
                write_private_json(FAILURE_OUTBOX, {"items": left[1:]})


threading.Thread(target=send_failures_in_background, name="failures-to-control", daemon=True).start()


UNLOCK_PAGE = """<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>الدخول</title>
<style>
@font-face{font-family:"Plex Arabic";font-weight:400;font-display:swap;src:url("/fonts/plex-arabic-400.woff2") format("woff2");unicode-range:U+0600-06FF,U+0750-077F,U+08A0-08FF,U+200C-200E,U+FB50-FDFF,U+FE70-FEFC}
@font-face{font-family:"Plex Arabic";font-weight:400;font-display:swap;src:url("/fonts/plex-latin-400.woff2") format("woff2");unicode-range:U+0000-00FF,U+2000-206F,U+20AC,U+2122,U+FEFF,U+FFFD}
@font-face{font-family:"Plex Arabic";font-weight:500;font-display:swap;src:url("/fonts/plex-arabic-500.woff2") format("woff2");unicode-range:U+0600-06FF,U+0750-077F,U+08A0-08FF,U+200C-200E,U+FB50-FDFF,U+FE70-FEFC}
@font-face{font-family:"Plex Arabic";font-weight:500;font-display:swap;src:url("/fonts/plex-latin-500.woff2") format("woff2");unicode-range:U+0000-00FF,U+2000-206F,U+20AC,U+2122,U+FEFF,U+FFFD}
@font-face{font-family:"Plex Arabic";font-weight:600;font-display:swap;src:url("/fonts/plex-arabic-600.woff2") format("woff2");unicode-range:U+0600-06FF,U+0750-077F,U+08A0-08FF,U+200C-200E,U+FB50-FDFF,U+FE70-FEFC}
@font-face{font-family:"Plex Arabic";font-weight:600;font-display:swap;src:url("/fonts/plex-latin-600.woff2") format("woff2");unicode-range:U+0000-00FF,U+2000-206F,U+20AC,U+2122,U+FEFF,U+FFFD}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:transparent}
body{margin:0;min-height:100vh;min-height:100dvh;display:grid;place-items:center;padding:16px;background:#f3f5fa;color:#101828;
font:15px/1.65 "Plex Arabic",system-ui,-apple-system,"Segoe UI",Roboto,"Noto Sans Arabic",Tahoma,sans-serif;-webkit-font-smoothing:antialiased}
.box{width:min(100%,360px);overflow:hidden;border-radius:22px;background:#fff;border:1px solid #e6e9f0;text-align:center;
box-shadow:0 24px 48px -20px rgba(16,24,40,.28),0 6px 12px -6px rgba(16,24,40,.08);animation:rise .45s cubic-bezier(.2,.8,.2,1) both}
.hero{position:relative;isolation:isolate;padding:26px 20px 22px;color:#fff;
background:radial-gradient(120% 95% at 100% 0%,rgba(92,132,255,.5) 0%,rgba(92,132,255,0) 58%),radial-gradient(85% 90% at 0% 100%,rgba(141,98,255,.42) 0%,rgba(141,98,255,0) 62%),linear-gradient(158deg,#0c1640 0%,#13215e 52%,#1b2675 100%)}
.hero::before{content:"";position:absolute;inset:0;z-index:-1;background-image:linear-gradient(rgba(255,255,255,.055) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.055) 1px,transparent 1px);background-size:20px 20px;-webkit-mask-image:linear-gradient(200deg,#000 0%,transparent 75%);mask-image:linear-gradient(200deg,#000 0%,transparent 75%)}
.mark{display:grid;place-items:center;width:52px;height:52px;margin:0 auto 12px;border-radius:16px;background:linear-gradient(135deg,#5b8cff,#7c5cff);box-shadow:0 10px 22px -8px rgba(91,140,255,.8),inset 0 1px 0 rgba(255,255,255,.4)}
.mark::before{content:"";width:24px;height:24px;background:#fff;-webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' d='M13.2 2.2 4.6 13.1a.8.8 0 0 0 .6 1.3h5.9l-1 7.2c-.1.8.9 1.2 1.4.6l8.6-10.9a.8.8 0 0 0-.6-1.3h-5.9l1-7.2c.1-.8-.9-1.2-1.4-.6z'/%3E%3C/svg%3E") center/contain no-repeat;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000' d='M13.2 2.2 4.6 13.1a.8.8 0 0 0 .6 1.3h5.9l-1 7.2c-.1.8.9 1.2 1.4.6l8.6-10.9a.8.8 0 0 0-.6-1.3h-5.9l1-7.2c.1-.8-.9-1.2-1.4-.6z'/%3E%3C/svg%3E") center/contain no-repeat}
h1{margin:0 0 4px;font-size:19px;font-weight:600}
.hero p{margin:0;color:rgba(255,255,255,.74);font-size:13px}
.body{padding:20px 20px 2px}
label{display:block;margin:0 0 8px;font-size:12.5px;font-weight:500;color:#344054;text-align:right}
input{width:100%;height:50px;padding:0 14px;border-radius:13px;border:1px solid #d5dae3;background:#f7f8fb;color:#101828;text-align:center;direction:ltr;
font:600 18px/1 ui-monospace,"SFMono-Regular",Menlo,Consolas,"Liberation Mono",monospace;letter-spacing:3px;outline:none;transition:border-color .15s,box-shadow .15s,background .15s}
input::placeholder{color:#98a2b3}
input:focus{border-color:#2f5bea;background:#fff;box-shadow:0 0 0 4px rgba(47,91,234,.16)}
button{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;height:48px;margin-top:12px;border:1px solid rgba(36,71,200,.6);border-radius:13px;
background:linear-gradient(180deg,#4a74ff,#2f5bea);color:#fff;font:inherit;font-size:15px;font-weight:600;cursor:pointer;
box-shadow:0 10px 20px -10px rgba(47,91,234,.9),inset 0 1px 0 rgba(255,255,255,.22);transition:transform .12s}
button:active{transform:scale(.98)}button:disabled{opacity:.75}
button:disabled::after{content:"";width:15px;height:15px;border-radius:50%;border:2px solid #fff;border-inline-end-color:transparent;animation:spin .7s linear infinite}
.msg{min-height:22px;margin:12px 0 0;font-size:13px;color:#b42318}
.foot{display:flex;align-items:center;justify-content:center;gap:6px;margin:0;padding:10px 20px 18px;font-size:11.5px;color:#98a2b3}
.foot::before{content:"";flex:none;width:13px;height:13px;background:#98a2b3;-webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10z'/%3E%3Cpath d='m9 12 2 2 4-4'/%3E%3C/svg%3E") center/contain no-repeat;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10z'/%3E%3Cpath d='m9 12 2 2 4-4'/%3E%3C/svg%3E") center/contain no-repeat}
@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@keyframes spin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
</style></head>
<body><form class="box" onsubmit="go(event)"><div class="hero"><span class="mark" aria-hidden="true"></span><h1>قروبات</h1><p>أدخل رمز الدخول الذي أعطاك إياه صاحب البرنامج.</p></div>
<div class="body"><label for="code">رمز الدخول</label>
<input id="code" placeholder="XXXX-XXXX-XXXX" autocomplete="off" autocapitalize="characters" spellcheck="false" autofocus>
<button id="btn" type="submit">دخول</button><div class="msg" id="msg" role="status"></div></div>
<p class="foot">الرمز خاص بجهازك ويعمل عليه وحده.</p></form>
<script>
async function go(e){e.preventDefault();var b=document.getElementById("btn"),m=document.getElementById("msg");
var code=document.getElementById("code").value.trim();if(!code)return;b.disabled=true;m.textContent="جارٍ التحقّق…";m.style.color="#667085";
try{var r=await fetch("/unlock",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:code})});
var d=await r.json();if(d.ok){location.href="/";}else{m.style.color="#b42318";m.textContent=d.error||"الرمز غير صحيح.";b.disabled=false;}}
catch(x){m.style.color="#b42318";m.textContent="تعذّر الاتصال. أعد المحاولة.";b.disabled=false;}}
</script></body></html>"""


@app.get("/unlock")
def unlock_screen():
    if not control_configured() or is_unlocked():
        return redirect("/" + ACCESS_PATH, code=302)
    return make_response(render_template_string(UNLOCK_PAGE))


@app.post("/unlock")
def unlock_submit():
    body = request.get_json(silent=True) or {}
    code = str(body.get("code") or "").strip()
    if not code:
        return jsonify(ok=False, error="أدخل الرمز."), 200
    try:
        control_activate(code)
    except RuntimeError as exc:
        return jsonify(ok=False, error=str(exc)), 200
    return jsonify(ok=True)


# The page's type: IBM Plex Sans Arabic (SIL Open Font License 1.1, (c) IBM Corp.), kept in this file and
# served from here, so the page looks the same on every phone and needs no internet for it (the WebView keeps it).
_page_font_bytes: dict[str, bytes] = {}


@app.get("/fonts/<name>")
def page_font(name: str):
    data = PAGE_FONTS.get(name)
    if not data:
        abort(404)
    body = _page_font_bytes.get(name)
    if body is None:
        body = _page_font_bytes[name] = base64.b64decode(data)
    response = make_response(body)
    response.headers["Content-Type"] = "font/woff2"
    response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
    return response


PAGE_FONTS = {
    "plex-arabic-400.woff2": "d09GMgABAAAAAKdgABEAAAACL0AAAKb8AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoQaG/cWHKtsBmAAjz4IUgmCcxEQCoXUJIWSFAuUMgABNgIkA6hgBCAFg3YHgYYbDIRCW88CkgPixrb/dUMJNLJ5tG3IVZHu+Qg30E1MLEXku+phULoOsbB/3wtsm0bz7G4lTUBl7JH9/////29IFjK2vwPufxsbIgFYpkaZicnEHCJFSqhcUsIx1yBuLXuAo7ucSmxyv5jgMrerpcU/cg4Mi1hbhi3nbAlKStUW21O0adZqTTlsGyerudQSVuuhZIIWNza5s093qr5Gu9lUzeH4QgcnDiICEYGn+7yljap10VpKwe/BPeZdUO3pEG22W6L5VfFqEcHcnbl7utCp4W6Vi2WYZAVjeLGA4OA//anHihm24eWQHfDhVKISOzdnOpy9Vu/y6NyeZcXf4f1RvcpYyu+X1cHVtZJ28jKgkWk/qUqnN3mv1Ht3XFE7iKifFTWA/+eNjdG1dv/pPIEL76pLwvSPFdytwdvK5+Egy+BM/Z2XhZ1D1vroFsP5ppPIfTLnpX/RxwA6bj2vQFDIJWGKpj3Ym+IgX4ZH8Qn/T99VnfsisqohTeVQ7KX4BfJrJG3l8Lzt3v/3b3Rd3aXLaF7TNTU1REi5hpEIcSUrdktLuMJF0qW41qVoSojGdNJwp4zmNQcNjeXa0PeN1fdxI6tnFpA9gSZSCBLx+FVq2QNKHPtIrsb/uaty6HOzn7nrM3KvUQIkXMOH9vSuptTZmSAv8Txe4tWeyu/yW7qahL4UC61oJ4rKmQV8c19r4H5p4FaodSskEiPa//e+NdyNTcajBJLhrz2WwYAmPrDovIh81/UzaIEDHo82n06//5EFPCMYMRoko+zEiZ3cOJvNXQBu7z7+xC1zCYynf1R0u/VHiJe9/W9mzrn7NvlCNrokGFVqNxLVitIogpQEofruwDlF8ddltf23Na7Zz3VF2OjbFgnREuzBGHxGkglnFrCaa9jDRMS/sKg6B2ibBWIQeWSISMsRIohwUiIgLRaiYs/NjLVLF+l+m/tVfsX+f9/7X/Vvv3318qOJiGWtZ+aTUKQt1BfKYLFkR2HJRmI1RqLkBb///dpdrduMKe+dzXgjv08ynbguCWmqIRFJgw8miZhhfH7THj/UqeMlhP5SN2asx4yKMadO1alTpz4lPY6JMaNihDBjRghzQpgTwpGGGRNnEgCgyGT90QhygqkhmTK3SI0p1PcnXiATirRSwRSDT7DkrfrefmgQEG/uaT3e/pk0aa1DYZRAoVCnDtxUjxcCc6kxkPv8/gPXUnhkG15GfiQoLgogNzOPv2CV3QpJQQfbjiWsPAi2Irjh0JcyKqTSPcImDJj6SOLfv+ffSZqX6i4X8MAGq3DlCNzf1qkiK74EbwSEgD/dQ8bfv2RmxrcAD5BQwPgJv01/5Zf4NkzT78goqSQ7yYeivvEhLBzB//fTZrn7aCWH+lejVu6gFM4l1GQ/PSrzKTaB7iSDM7uLME2VapEgMUoAz3+maZ/i1kMBMzJn2QJ5RlqP39La6AcZOOQ34dp8kxCorp5i4aFQ4gwoHQqa5RrHpdZ6NjBD9QCzxnO/9UHyQ2cia+MfJIkzFk5LeruTJpl47LRLGGkUnfRVk2qlnZb50OMAHkJ55l91VauPx7NmI2zkUmYvxZY4G0J6/RWN/CXxJX0bg020YEIGlgkwgTUTkCWBLcse7IH3BibkBM8bUs7VTLdvyyuv2uuuqWMuujLDEz+nNiCHPxnR5am7SFVlAa9jVgWVVMh5VzfhJvR4eFib+Xjg6WLDaprYB08TrZpFLC4Vr6SVvL6WQJIFBur/f02zbZV+PZGl6VZzwg55ELb/VznADix2M7vZzUr+9Z6vW6VvdVtWSO04xE6GUL/knFMlB9weAFwBLQl2tNvPhCe+mbNthcNaJAiHsXTeV8XhfCdZrg23oxL+wV3+amupfUyh+NwP/vlfa3XsYhKbaIycr2tvxdCJqFdJQ5NKw3pnX+L/WuW97N2cjH+xPyxhbJ7cpc5VNlJyI64OGrMdFkgC/25GzfsBt5krDgkiEiQEkS3qKw+i+b7/dap79u19BhMGIUQjmkYIIYzXmBBMCOGS36nDEWzTGh8us4OUp7O7kXajP8YQEQkhSJAgwW67vbZme7+59KVv7E5NkeNyKQTG+fdY09ohdVudvVMEVMCJYunZWr7mDpE5mdmkLuGqVHwIz+pSrtI+z7kGA0bqMHjA//bFK+e6WbipUBFrZXgMQ/iETwghw5pGLe7uXZ97mkxLV4qooKAoSI+Z61Ts9wwR3hYFQ/lRTAaTpQ4HzzfNnPeZpMyWNJAIoQvLXyfyLdu7W5RJGhCADFEZx8G1Zgg8okCIVRBESM4GyGxkI5vZggzyUEgkiSRewaOGuqv1NADTSAXRzAAM8Y9JZphjPvofSl1KUUIlOujmJp7xxDssniWaF8ngTd7yLp/5knIq8pv6NNKcuWhBSt2U1EBLH3xl8sgnPDWNDN/wVh7freGHP6Jfdg5SdxgUDjyK1F5ibcD+0rYB+VskNPvuILAP0NhoM8PXde7vQ3mMIBwNC0cUETaVODZJfFJFaTpunfoMt879mwTeGlFgSoktX1XxDZ8aP9PfJBfUaUSgJW0l2WjTTa/eot+gGDbCmLFiwhwsWEBIyJKldNnc0q8kpGv8iDUBQHvqAVABBk0EKCAAaehwhhr4xNgcyF/aqTTI31LdOsgQAETrBUDAoC75vF2H2v95DrLfK7eCDGAgoAGNNmHfVwFiXb4c3n+fCCd2N+JggIDAAbmZ5IGsCgIORUmYeQCddY4J/zb226nAOtV0rpJrkZ/MNt3kp4j3ufsI/KMiHn8rxCAH7LLd5GNNX9yYQT06tFioRoVixfJlShanWASEGHzFmjVCQjPGDevVrskvfBXKFMiRJRVERWOARIC9gIjqRSCKlfbMEFA1nMz643XfaYXH7ZLamaGZhnuTU2sbSjcFDaK2JYQ2kOf1iC7WlwuTPF8sgLiqh/huG0IbuVoYN6sipKTguTxq5KHOBPc1qyjhTquRGrVqw4uah/2nHTxXlMAle+w+Uflm6ZFnjjnZyhuhzd6br7/TDu0yw8te6OkrxUDlTwWXJkerIDgC9uTKwx2k1s18EASBwhIodCYbOFNJ+/5EplBptDq9wcjEzNLGUZVq3/Dw1fihTr0GjQTatOvQqUvvqUkaf/zNxlunSVOmzZg1x9NXrFqz/qCFhtEoNILGoHFoETQeLYomoMXQ4pzZAcu7N82tguX9zo0KGGUALg22inz2JJaHNLaSRERKYoTcLPEAlbhcjaADdhdWLDPzKLsLY0wSuvhQqra8cCtdTSyeR6KIEXKISfj00aktW/JjOMVuP0/85/Dne/bn1X8et5P/OTyOHlXgUu0Kt5QH0v+m9uxHwFBDgAJ57S+806Tmjy7D4xq2HTIwMaxfUBTkU58yzvu6WcQzLyVbswR4vgnhip6s84aXy4qb9E2TtBtForcr9k7BxX2FlWQvsEfJq6E88jt9B0PhaByRyhMp1abmFlbWtna+qlDrpxbdBoxYerBAFoDesuiNQAfU+ltABsT6ScABuSALpOg4NCBXTwdhgEQgkzsDo6yaIDss+rPknxPRO7cDbb8HBdzqZ2AAgbqOmD3PX0/7GnjpXsP91cvdRzd+fdd8Zze8kLB2Jk73+XVvnKPHOtT5cOacmuM5pjM5/pEI2fN/xqd/Woc/3BlNnl/f0hDzZV5N89RMcFx5DaIxh8Ev9HhfsGrDqVzv3dD85vaowzaaayS/vp90c9d0sKEu6FnneW0jkZndvxs2f3OXagNt7cwNttTpO06XnDd77o6LFjwkOb5t24XvYS/ceAsiAHe4hquzflRFFVVaoKSC6l11VaKi5SlTLaouuyAOWdynJ1xmRebHDXVjdTw1qVWtQqkSRR6QL9e5Jg3r1qLKh5uzpYvuxMQz4z6HnOiALDnVvlvUyJlHjIBx+miglXjjBPO05MJMwLNSKMTVpyoN/lMgEe/61KbB31mIBZQYIIcN69SgQpFa6C+g4biLR/jilTlqBLmYzeRcCpBJoU7O+Ajm25TNp8mc2ImYBxM47ZOY6Hgg4R58dovG0AcBLzVaezWVlFV8/04PEFQAqkAJyNvvIiw9QBo2FMgwcBOQk+x1YPCkCxMfw3Uq5jgGAo1IXF9pNZiuCHQB4svZldykDdOLbDmTbhUnZmyDZiJtD48Gs6B9qR2Y8yxNo3Uc/6xFrRhDOuIMY1kbkZhA2nV1M6744rsCrP/cUmCo/eahq+sERr53HpKvARhyLz8kHR8YvPEfko0LpMIsgI0L9fF474EtD/nH/aUCWxbkx+3FA1sy+PofFgmkwiutLSua1C18PHjNfS20dM+roqrsVxgpL8DN2HL8soTgzJxTfxJic6k+a1nrQ/GJIsoH9gnw2B7AsPXhwcPfngsu8KeHFCT8Jdbh8vb1MyXU3c1r/UG+ThWDXhW67lZ0Uy1fyPGUVXKI9Cjd5Wgu6wbCLEqGIOc0m05DuTVtNDzk6IQnfibHMZrNueiNTudytEbCyKJW2Rd5FFQ4tRYaoj3z6mQyYjUwGpHKGM8BsOdT/6wtWUlJH1uTHy7rYXZqiIFzw3FlJ1SYDLMgwlEwEzc4DKaLLRwBx2UzG21Y2A/xM4wfEiYZ+g8o5dV4chBsj8cCf2/4B9zV2ULeamySC6v1M7DW8U0f5LirPWT1IAJXe86KQcZd7WlLB+mrr9gSnYxRAyUWqYx2H1AuLeaLFbju3g4NrK+pyNd8M1rTMKwN8+ZU3cC/FoOdca2twz5PhFwb5c2o7W6MNy09lZ6qkh3LR2/JFMYxLV6heugW3azn929cJ4LQfpPwI/Rti5AI3BuWf3o7QBF2XHIBEXI3qzQ/zLqOLs4Lsxm/9Wp9foxlGGGM6SCwJEM3BbEzgdC/tQDEz19z8beYCbZAB8TbrPC/9Q3jgTfoRWGPN0tWyl/0UnnXEcDCZckwcUuHxs+Q63SdR0PvUDOtQyg4rrqpFIF4LdJPiGlSHSI6lSIHaBA7+EG8aVbSyDD/emsY7FIAMOtFw6cpAZgYsYgCOsAEiQkN4EFkxzEhiApBgDxzEx0KV3/su4Q4RRDuBwooeLDpuGBx35Csx0P/VYMC5GItp+e3EEAXvzgPBfGDWg18IabrhD/Q7zyGVmVHcsJ9Z2m2GPUc6wPHYR146PA/HYVOvnHfE28ZEURadzgMWQIp/YKvDFBcM+XQpdCk70eIgfr0LsjFFC+zTgNdHIAjaQaOkr20AfOgi6Y2JP/kT+ZnoFGHIPmviPJd9I+MzBTHDEgx+9PjV9dE9yX34f/ky1FuPPn9XJXzTz5sCfS+quvSgC//4qrqp5t+SSM/OQSPG5HS5LlLDXoeBQRGY2dv50mRBlrO22aUp6IvaHb3fvI8e7e7P850HOQwW4aP1nb/pQF5n/qy7fCH3E5ve//fT11wtPPhL8cldLsU/d8MX4/woYRTV38k9jViZW/1fHhIqDBU30I8//SaD4NaIUM3w0HFMncPKua5sdtFZE+LAv52cyM8SclvIxfSMz6VhCTpMIu1T9DH4c1RGO009+mthFsIeg653O0F5p1Vt7X9+fY0uuZoeUL7+e7nJE7iS7NbZ4u8+PjS8OLjTcGLjyd/PHq8WPFiexntxce5n158HJv54mPfl4+V/+JzXk4IzS9d2Hrp3l+Xrq0qbi3ph13q0uWlbZMvrcsuvjFcwiRsWQb/WvcBSC8v1OWL5HEcxK7B97FFCrsxXGA4EMYgDP4xQnaAawb/KMEdrV8FI17LiYslhTV8CeE347Pb6da+7upySDAezxHQ8KOtgJQE6P71DQ6/X8B+yfsl75f8+nGzfv3YDuyX+/oRM9wvN8ZaA8ktYrtLAiXZoRv/Iru0dP1ej34fLFwvdYWMRaO2y7giv/9pcUBVn9A+qIrfIFj/7XbqApQPkxopyq5B2OxwBX5hCiOtt7RARC0yEQnX0l1MCxC1yEQk3FE6/tdEe7mc/UEP8nvk20OHfpD4YfS1mPr6KaR1uPhNf/MJGqW7tJVJNV406UmhCqZK6iQaI6/a2Se+83x5/TpmBw2WI51r4ZCTLdEc3qrkDxKwj1EG6B649LhWpfEmJdIsze18kT3CIu15Di+3AiEm0aFKQdZdvDaVSCbiiW3lIahRW0s14IcTrPKlb1EPEqpFBzxKMK/xIcKLryXokhq9rmLN+hB0yaxiTOq6Ww2oO89v8XWEq4MGy5FkLRyy2JLM4S0nbsc+Y8V7fIV7yGVS+PRpp2oLqbMidVqBcNq5SXZJlqRkIcPNS1+axEgYAf/aOp++522YQAJAghU3HJO3Ai+a5PyQT/KW1bSZwL1y3Vw72ncs7qNySW/A5SQtZD5fcH3s6Tk603NAZHx0aHB6hPNG26XJ1viYI7WHHfCKst+Q2C3aOxK8mxnf3ceGDbMTLQB1khUiylzXv8lBf3UiHg10s4uKvYGOcL/Z8s1bWb0PwXXO1x2e1/73rPPb17R6lyeiSXcTyqwonEvlKssyq+fwFZTpJIiSoKnn/9K+PrdHd2C7XbjSIFWUaKKSqvBWm4WksVUhTaZGToY6XAQuSKhCFjweipIEzBZvtQAPYq2dL4dYiy6w5kZOXg1r7BcC6NLihFr/gMWuaF9FZLKI5PkNv2PGtvhEVjLI6OMIZf3JK5/Th3pSoB9kvLQPOuX6U+jyyq5AOJLLLh1vyXgZL+OXI3szQhcaMdoaaS2tpfX9TbEwQhrFtt0Qx1zdcOV+pPEReY/+t/+k8/t2w9BnoHVJ74OKG472ZQtpMd88npYTBaBxwNGmrA7yTnu6X0SGXrs0dWqut2xz0FcUdr6wU6FXdkiGMlEG6kfdLo0GcjQt12MSVKIkBD+lFEJJxHofrRQtXGqvUKWSd+Z31lV6SjWpmJJeRW+JWoneFS9LZRSryGWZ2XSuOLEuT0YkImBfGhUGlt0ZQnqYk0og8aE9CccHrgQhplGdqLKk0vAmIaKDrVSUQL1WklBJ10orrqhVgvZbm3q+bUXiIE8BT5aVzxCYd+tLWRxzGk9qpP2iEB0PU5mgtkOnDsstuepBZocaHYI3bGtjI9zQtxdLIuAi5ri+XOizDB4vvvTRqdezvLIqEA65OpXl+EpBNkPX7iw7eoaxOSDNYIK1rPDEIm7ZsVjWIFL70Hm7y7E7DUcen6T9Nslqx/BO7Zm1cH+g8g25jLSYdz44bYA2OGAKZMjzO7+QR3JHBqCwxw512SEZwhSGrJcEov6Vtlstr/a+cAjWGP1aoiQliqILJaIudOyD1xtvEF2/9cm3H/pQKXS9TvawyBeT9X90+6rn4Yk047j7VLkqJH93+eOzt65/KZ/lh+9k33VOPMm+EEnAVcIoBt7tPnBPQw1yqDqqRAnuiYID7P6C3fkgHsqHL+Lpzm/cTqnPmnSUVx1w5k6cot5U6MHShJ6CZLQRl9skwLK9A1KEHEnS0hz7jFNtytP+GjRvk/KQuYD5ZR68NlG4+ahTc/HsPnkwTBx9Fad3OOGbZRCHRuW/8ZVtaiWS+HJ28G3GY3pGnzWg0Hw/txTGinmr5Mplx9jtiZHaxdT59G50brZQmwsutxiCPCjL9UwCdDhe0lUbZ7RYU2yoDVjUSyKnuehOl3X0kkheWyo7k5mU2o4da4YwXCb0Ng001LPRCcB+/ceQzzQlgb39f55p47eS0cG/bfGzEkCYSmBgO/HyDHlWYAlLWMISlmHeJNx40tv/5sQ9AxxNDPVuIQ2FZJ3EC0hAIiJqDPOdn1TAnct8xzM5ryUE7PDWCKnN+G3VigfiG7ZdJ77S8E0z+ExoJrQTF2gPWmeJPiO0UOfg+3JsH+q73tpXdLtXQ5QjuIBzOIsLuIDztF/746812LEx5Amth4P2TVL3iOwoNLsr5L7re8WScSE/GkyWenU4SmDX5fSsNcx2y9QZs66TpjJ1nWxxTk+Ri/0tU1wnW1wbnV+3DvFqfUkHzYslVwjwc7gOweFSjQEzD5YZx7BplkmrR7bhrOwFcNq/nPBqLLZxoUtYl4ReTifCFzdJD9e16XDfS1MK05H0iJRfdTSswtArsyRjsWwaSpdDnUcBjNQvovVZfSQlnscACNMMmMc85sFsH8a92G59RCOFm1X1Dxf3XR/xkZT4da9GtjdsiiJyfDxpfzLa4jw7tjRKYlGnjkWMrfnVRtbVUsJuM1rH2tjM5iWp28qLsCjdSisltXy0AGnLsKui4XYYjoaprrA0Ew2D4fb70XChcwaVxtXSYWcKSC3hNsxr4eDSo3ZeColGxTa9B1NnrX8s96Codm3ulelKk52rbGLoXmotj8/xTABu79HZYC6IWv1O9ZaE1qQV2iltId2Dp83q6NCxONWXA8lWgEG270/O0IEvV0+58TqxNV+WbGO+0upeRXaWqTCSFFCHxit7XVb/MrEo0NP/nQZUfOHxqUrFDOHfT2Itn3r/d2ybRmJTdxOoli79Y9Fc5J7/f8o6jevC1EG6Akyrhz6cNqZlOS5dWckUZdiCzyobsaOhTSvouG0ejMjaSrmgtd8yIyU0xTMcxTNQOEqcj3dljl7yUWYVk335MbHV8bhFAi+LjLDLIua0hl1pJlij+81qg9mTLi+mC2Xxn+512xJUJECcihI3CIlIRKInXlSR0Wp74/tQFI5GW75eqGzjdh2YWDQw64H9znYKBpgw4zlt17sUZ0VGfGjUZumhwMLpJ5XkyicKlrKmNdpil9iqVRCPhPENlhQbJcAHy6XH2sJzPRh2vbiEJUbApWPNV3qdgJo9lIcFD3lsjXt0+nZy1GVf+gvA0PueZIFqAAWBIQKPgCQCKwq+JPEZ108C7ZlOu5nBTBIYpCM96E0mHzOeHGbxHc/xjyVbnZKr/HVbsYoHJ4Ab6to3JLpTd7/9qJ5vOar3+41bH5dBQSQgePgWc5f8nQd6uzgpoMCfq+M12cbL574mFDgDKz1QgGDi8CBQQKM/5nE7UTe2mzNUAQrk0+Zo3ACEvxgGgACAPwvk5wD+IMDvtvytzm9Bvh+Hw0foj+tHFEjr+nuSc2yzM68O/H9Avipy4Rs+zbLn2PHpN/yb/YjnORHpYMmjFNKbW6Mv5/G4xSs1C3HhBEewx5rdarbtnwvhmd+BUfzyZwcAMCwRosQS4kIcEr/SPmTD9z+kYouQIUvOVuq2MYjt3/wwi11f+9jN2n62Dsah73w4xfEvfJxwkvMt18/laJduM7/wOOadQGAMffqw3oH8y90BO35kEzeX/J3d2i9OCmDrEcTFsjWXV90C9pOMd4r4LH5gpPNmfJnps9f3u+/DBwF2d7o1Fq+HK29fDGTnwSVOJR7p2d7y+HzM6GC52EcYPNwNsO6xI/ZN/SkWRm2OjA5NqUOWopQzB2kzpP11JTun9ajtS/brzlRA6u2s/Va0XN3rbuSL3+IP4is+4T3enb2+3UciPE+0ZVTQLIyi2gsGqEMCnUJlZ13VWRGwaEsF8Kn3VKsIbReZhFED5zh3gThxwrjKm7roRlIIfOYtqXbGCwXEEKCbFbkUcNF9dBPcV9Tq6a9lq91EG96vvroWdGcI3KG2btDGSyZaIk/4wA8M9pGCA6pIVlEsM8MD7QF7WjW6n/JTg/1oCAyB/tOJE6cqLiFW1JMisbShVtWCLqWNxrHEWu2f2i20Wx6wbcTmJZuTFlh/XBgRUG5zCQjAjEMDdNKzrr+3RQGAZrWJyzi20b8aQFPCIVvAdMw75J3rk/UYB/9KgI43f4AghN0C2lfDkCTaBjWtozHYEMMKhyx8pYLAVpCQyAZJlaQcH9fkKYiqVH/J8ENEZqQhIb+8caGwyhnCYg/WFFcwm5EAwgsYb7D4gOMWWO7Ej7vuZcGA5T5YmB4rUIElCnDEgYPjUXxMxETuJiK6cfC6bBt4s8oB2uxxoM3pEaDd42GBcSmTAgIMMVqDhUIGKuYMRpEysUEGeagzyCBDDDHIIEGtE3pawL1uEAGerCK/roPrdwv5WnQj//VUHz2PrZPHQ4jIx0VDHvJQhj3c4Y8AGFSkBhkUryIYXOwukAUAvC7JoNymdiBO3oF2FAfGKTmwTrl+hcABQeWMs6u6stmudOCs3lk4wlY1xcWQtNFmMlIVSZLftN40kYvWfr1AVJQs9JKu53tZEEx4AeJFZ8e6x0S2rfjQrdSt0q3WTYesgdFQ1WTtQ2aFNeuK3KWOyIqqH0yfEmjSK84AX5db14QzPCbU69aFcgTHLvi42sWRr5laE7ZnxLNi38H2xbDrWyNThckp4opB/0+1VIAWhkZi5EMH61AATZvw8qBjESv441q+kl9XItxb/42WOznvIBMaZEGI1Nb1KIDYLsMHe+lhkwVxCLyQsCUHgflRW3cAJRQMfmuT45gc1T7JVeWjb3gxUqfeAm/Z3nIrrbb2oKxAEBgChcH9FRpNReZii8FoMlusNrtCqVJrtDp9/Dx64nw8PwijOEmzvCirumnHk+ms6+eL5Wq9GzbbrCswUhIlAlXzxV+ByZABlWWZCGUdhhXFBq46nhAhiQAvnQhE9TsCghprQMzmmkfc/p8ISP3zcERieVPAhlVOK0p7MNPo7/HMYrhfFwFGN9nIZqxgEKE+iPTKFskLDRkKGBVkEDQAARYDg2nYyZI3pnAzmA5denbY5Qo8XNqSngzSBcjmQHvNT4BAD4SqgQJiAwj7S5DWNSJ7vcat8+h1QGphFOq8uusSyOs3gBQeidkYvJj+kuw6anQvSqHSH4H64LDJzAVyBPIgznRc4NzlGWLzHs0M1D2ZOdRvaGtAAwqAUEKwAU6G28SIIr+sfO8LNgJDSN94IuBsRqVBc2UHRP1/kOKC4UP4jMCW37y8OXqDwJSffE+a44ej6PA9NPtoc2rSRjVsbH1r28KlVqP9V81kDnPOj3vEw+69SsopPU5RHQ4D/TBMhi6apCM0rMprkW5A9qbd46KAbWhYk/ZORNozT6MrvkWMe+ZJwm/3wEV6IszjU14ccWJvxxBKqMcW74Xn9aJNGjd232hrwoi/9f74Z9iQwU0IxA38tHH7MY/SoELeZhs2v3fXnUzQL3MGmLK5AlMwl0nzN3esfegFtEmjRgyrUa2qmUrLLLXEYq1aNDfTZMoiCy2Q1KhB/ZgYs8wfocAo0As01J+IhPHhAgo7dLsuzdppR0JJBY6c8h2Q8hxhnutIkwKOuEp0+Pu51whOJ9Epr3rFywcLAEiWe8npRS+cwnnL856771mvNz3jRL3j3nDM0XpHnHTYoc5BnRV94WvBYF53wH77TnXettee7m7Vdp/+6Yql6ua2BVEhh/Awi4YZNWmAoRMkAx8XGw8H6wJt8fPx8lBRUpBfgFaujFspGSlJM3lioiLCCujpmtGqEBIUoAFSy29nVMvMuYobuNvIYrptQ+npFHAZoZYRUgUhR/YRAd5sWaCG7ouAPnErc3OYXkICQER4DJ553EC77hoIDhbmcWgePnfVFZdZoSAhHpfd+8wlF11gkSVTRnNw95x3zlnFyBKBAjcHuatWje92BUiwdWtWpzNw4HdAKqjZmPY+biqMT/HxfIudeCux3Fp63CKJO6pVqWRO6L+F7vzEu10xUSga2lWnQXvxbSyynX7M0lHHuTrriquuue6Gmzx58ebbZkyycJ9b64effvmdXAsssjTJgEjR06bLVIjlefrlhfJ/LmVSbwNJZFtRKFKiTIUqNXnyFShUpFiJUmU+4/qi3FcVKn3XoVOXbj169QUFIRAawkBYCAeJQHhIFCJAYpA4RIRI4iVIFJAkWYpUadJlyJQlW44GCzVqskizxVq0ClmiW5t2HTp1WbpU+/rtOwQjKIYTJEUzlg0c1/ODMIrrpu36I4yglu24nh+Ez2usrqbt6JGyqpt+vliu3k1nsrl8oVgqV+qN5ZXVtSPOBrwjeP54Mp3NF8vVerPdASCMOq7nB2EUJ2mWF2VVN223AH1DqrJzzcjyGgJDhA7ysAu7JipClr27+t4HW/AbGY23y2rWTk6/AcrbaEzVdKQfYGBY1Nhu7WmnYG9UajiQeZVz5OhfciwnOZo15LgdA0xnywQu5AA5144E1nM9xuGRN3I8jwcmr1CBT3HErVz6Pb65ZisBgchs5riThaxwTwUpMFVShUdqqMETtdxGuE6eIdJrXidBH31I1Fd/XsqUyavjh8kCvG4XQXoT4pDZtC8n61hielvm8b6VOIpa7SguL6fk6GJW2nCJz5eyTridapaf2VFViYis22oPO5g74KBDHLI1U5OWeNvVHtVnwJEhI9sZM2HKzOGUlVF/vvos12/AoCHDRoxaYcxKq6y2hqOOcXLcCSc5O+U0Opc8b575FlgoT77frXHAIYf9419HHHUwDIyFcbAIjIdFYQIsESE0LA4TYaPMFWcJSpe+ggwVZsxUUdZKstVVdxNNNr/gonvR81JKRdtOu1jYbY+9LO1jxdp+NDbsHWHLbrhBoHAoLEoURQAQERo1E2jRqk27AUP+GjFqzLh/Jk2ZNmPOvP+EFi1ZtmLVmnUIQILgsu34zFG0cFXdtOPJdNbPF8vV9/OCKCuqphtmkuXFdkJ4SV1yYsgUVDXd1pUx273txwkRl12JkiAhn5UlT2Fk91QUq7Kqqquptnh1JVRmTMZAgzHG/rgwTR1B8arpR7/6XV31NdRYU80JaqmtjjqbaXYT1yMPW7Vju6ai4TbzWMPkeSfUeeAhthix4ifnmT5uif2vCt8WhOPOukfA4ELCx61HPMtaZ8J6G2w0aZPNtthqm+12OMdO5+LqDDdnnXPeBRe5u+RyXrHYEksts9Yf/vSXY/5zwkmnnHbG8RnFv56SFjlK1Fixo8eImT1f5fkL5siZq9LcleXJW6BQ4XrqbWH3e9DD2CUXU2xx+GIK9chjYZ4I91QElkjPRHkhQbTnIB6rVw9STB4EJjq5jc/l2JbA+6E2ICocWDOuHV+BcIEucSJbKBhu0xr5lQOa8LEDCa9aXviX5YYXHqjwggOYUkt+Chq+tu1mgaWDorTZfAU65HMa6EVaGwKCXVnBMAttJ+gIL9gucyKRDonaiXkWqNC36LhRPi8YoKi2oAAIJAAm/IG0lJ0n6hM3NeO4L8LtMvzYlhaxhCA6M6sQgYA4m0h7KVmTQRNmLURRgUq77HGtz800W65frbPJ+RST1t9U4aWXFb/afoKYv2tBA+zhTgAYIYZ7VrMxj/acCouiUWgYBWDHgLL5s5CUE2jY63HjOwVInnZe3IC/sMr7AfUDgHm4BEANLAAD4AAUQAFBOBLP+uvgBwwYzAEyoUi+Q2EQjMyp7tR2evo0eVo8rcfpzeR51zn7nHteu//KYxSgMDgCiUJjsDjcvHwHQ+FINJ5MZ3N4IplKY0+lM9k8gUjhI2uOBKimjmba4nNKqhrauvSNTEjpd0Yzo0qNoksomYr1SD8pvv6/b8cBION2eZ60s4cP7rLDCoCTOtNtLdFYPJFMpTPZXDz2vpElUpnhiWKNnT9HXOJhzooDF+ZTyyJCcRnFZTVNHX0iopP2kka21h5rBqtHr546Faf6NJ/T+NzZ5JXLd4cVzffA8FtX1k0A/P/bNfFoW2c+BJx+XIhzRmX7bUgDZ1sbM/Q6Juiljd5GXQwaLNxc2BkDQHxQdOaOnf5vrk9wpyLzi9240Hbsbu5u/q59yc0n8SHNrud4zu49APgY+uuOTFrmu2chQizYJ7QDND18wDvtXOMH+IL46z4AO+mSawWjMCg8Shy1oTaWdMmXkjEtpJYaN/2GogJc87KNTuzPoxnXl6B/4aF1uE7UGTF7bl2JuKBfWDfKpwKLUcwKryiAe7piKxngLyypNt2aNOsRN9c8Xb7x5xFBE9CiiPARQ+qV+qfMZTUSyZTugGOLjT2EmP1AlH99woz5KMlV4Ty7SZQUltFm+NbPlvvbRg0R5y8FuehgoLkoSbCCPgyUWVq298BW7cp+2YId28Jd28TNS03htJ3dhv1Ulo+Y+zuz/O3e81u5VVvPeBV2LzI2I/pWSH2+vDqI5U0FBnMLOJ52BW1hmbAjos9JBx2y3wGHHXGUV157L0WqNOkyZCLDbFy794sNzip0wSX/p5SgaJHmfJp3IUU1dVZXvES1YndoSL9hY/40QbWWYar9aZVV974P5fSxuE8cXq39KrO22ptqeulNH+JoIjJ44NB4JO7AIHd2bJ/apPbtcGCR3J3f3xuMbe+29gMbvwMG8SYvfGczeAtou5rKHXeCD4nhCpnSNiFJhn7hNlneJhZ32AzZzZAjL9L+tuxrVV/39qQt6DsupkJ7faEGgd93kfbjne713Jx7/MGG7d99uI93ZL/t5H7dhU3eyi35v1LI3veP/WAXMInAh2YwwJtGcNyiFRK36YdMEIMABNLL/yYrCwZwadmQhY0GNNugX6N1ejWZ0Fd9jnS15MlUR+FstReqpB0l96JXxZbS/LgAlwWBvTGrAjw4fV74+zBnl3cpw4JB/UQUG760+zXhLNUbIDEgo4xfz9dMP1jmZtoynwXm+ZtUZTVrduWfUgNCYMQi/5qf9uRyGr+6iSHiyN5ciyA2cccTb4YzkrGMR54mr6Y2gQQTTiQL8i1Q4FzMPO+maVEBCfmeRv0GjRrWZ8T7wSKrQSP4L9+iwSPjI4oUDw5Zd23IyyEhgjQlm1B6uCLEkey5egm1C4ENJiIGvKh3Vc+YjQR+dCxEkgC6EVhoXI88DdZaplKbbVbY5Xy9XMBLeZLlJ1IOro5mo0mcdTwHfW+RuYZpdj6mNAXhpjK14eVrqvMz31OXjoxlIE3pzkSGM581yWJhRdWUVgzWVFcrjWiigxqueMtAQ7zLYBDwgB2GypJttOnmy7fLWns8O0w7Rx7+EIY9xOEMflhsYumM3bbbz9w1dnSoCKfP1hFn2TvrvAN2M7PPYU4AGVFXgmzAyBOMIYBgJQAEg4TLGfIbQMs3isjYt64ERbytWr8P7Hv5iAioOR/0KlDL+41XcqIzjypwy9+Bmj/Qq6Ba3j8qTvWJmaUkm91v2C+7W2NtiqmseFU0Pqwltzut3wiOH0vvHR/9aOVm+uuQYx7pVRAKnSedZEg1ZWtd2Thz/w0Z6JbPhmPgofbS0vSS3OlIbsdkrfHkl6kl+cWRZe5VME4aJXutFHcXYJMxzWcTjoB9dWX7zk05+fdhrmHSSmtzCttJvjqlfLGiB9DvtilkhZ3q4yrGS3KWAZ5m5A+5nQ2ZLLteRaTls7NLniNruRcQKHDgIcFG0QWAoAQAaW0BNgrQ/i1Ar/+A7p8Bqv8Brn4FGADAizs3XJu+psFPRM1rpW2/Lsu8mwWrRKdU5PjZUWPjXIimmjwogqA/1XBHHmQrim5TGg3FUbpYhQJIa6jsCcvcj2RW6lGuOpUMpT/oSvpLOt+chpAytetDtlKA53VK81fi6JamCVh6SRC/aVZo+WIguRdVKWPTV4zpVTqTe4lnchLfqKtL5QDUSechmsAo1w0iVZ6gecRE7Tzc6iwdu0xnLWWP9lG08ztTDTqOwstavibd/gxxBbqS29glEU5ry8fJ1Mlmp8srM4ZPlXRzxspAzkWg7ItRHqgZeAhnMQaygsPLtZ1M/GdPjEETpFPF4h7RgtekyyVy3yOo0higGFgyonm6nvM5tZsWBTXkUYiCyNYjCKVoqVUyIITDUvcyPbgnwvBA0ve7EUq2YUA3kwI3RgWSjQArTtIExTQZQymdNEbKplDKZzlSma9W/kZd5hV3tUqHB3K0QSUKEOZuDJGBlsuNFMCikadyLOcyhOF2WOQitHO7cvR6vpDOpYWUS04hpyLmdc0Xy0oNZE9D6Ocq9pcYyaIju2IuS5koxXIkLjd7KUwqydDOjkuBYXwqp4Jif7SY3qyXoA1aohbdXz9/vT40s1OBXNdzSOGiUjHPcRoMHbumJM2H7mKl4IK6PB6g4G6RGCDJQmdKCyeiDB8+QYjdnQzhQVpS4scNhRITCMWH21owSahZmMgnmLLdiz+HY8kUVVJhEEuiCKHCSRIJjhiaMOY4ijPo0ywDIUQyHk1MjqOgDofhQRZlmAroEumwu6aSO86ONQeB6+osliJ5bnPLgoooIAEjh/FJR9Tk/ysSMUkUMaHWJmUqCQwjRYYudS4PEMo4ScMwpERWZt4TWnqdZOBLQeYjkEwC9jCghJg5BijicSQsfhiIQDIlDNcYZRzFhHGEu0IZVrjGoc5W1rFvdN5wpZEVQRuYQRzitxDmm+UenuK3nuUwg2ZwiWP8hrPQPTDACpsL6mvsOeXxCLIQUGWg6la5kDAoMbbPKJqsocxvQ03oXCqfG0U5wAmq3+MjeYALEv6IubCeWaCJfRdOwkd9I9ez8cSOm7DwxyipVnDQtIagIKjZEJGFlzOu0HCxK0uCMMyaGr5Im+ypH73aFRJNyHA5v1B9wj52PgeJ8eEyek2ULOMuu/hN/AYGCI+ooBFoBEMYLyONgBSx4ltQX2go456zopusOgWCiX2qxx/7YAgoPUvjSJ/E9SUptKRc0hE2SWZrsWUJVFxjzokrs56t02T14+/VDGI3HoWQ0Y3Aob5OUjpG44godu9zZQvUNikPSpUWSpKCWDJpDkSTba3jWc6te2WCnDvUw12hRZGar3e5IpEAmjY0YFBETRoe1hWudNryImqvUDCYKGqpTt8ImIMGTC1mWDA1dIRcCqyQK3CCi6wcfDeqCvlz7UNkVKRi+4aiIqiBK4tmZh67gCOp7AbH6Gu2ct8JqAWRh0V2EVnQPytk4xaAlLPaHKprfLykC3i9IPF+26iMuglRceLsb9mjfBM74WRbT/QqGFBd1TzKQgmIV2RMxy1eGPOVXSysLBUUKoGRDkVcpALRPFVBTzEUA40xR7Qqng/N97mScTsZg58DkGnrwigYiSKgNs4b3uZCtRtFEBU6x12aPIdSkmsC1so9JEKz9OG10iecev28Y1sx9zKDlNL9jgp2/wFuuZEI8sSKoCG18UU2KJO+OzFfhoQBe0ZwQ23eooyLzU+3K5nxdFNg1HCuXHcuAWwI2ouPa4aZ3jsd9kskpCNxdUBZdi94olrK/J8dJqWGhq1E18xpUg3btZT1NC9dVOc6hOfawEl9oUFKZq0zK/bROxdFUfw57WpkG4EXa+JuIsNL6fHXYPe6qgRM/0ry56lipXYEU2WC4MZS1cSD2ihcS3zubfyGuFZgqzCZBMD0D/4WCCWXbULodffZ1cARwavosxMGlp3Bzc/8a9Dr1nsjsoasDorllrEfYlzfItfSB4eXdhdblxUUFqRp0xOtHZaGc++0njrt5tpmnzZbK5YY1+Uep1uvnGoT2dJ+2o3xsoqHZe9Qk2wLBk4hFPoTAusezEu1cOkVn+yjUhMpMZuKPHOYaZGJUSvCYF5VkAYvTgTOMBqIYhOQn7+ar0iUcdRXHUpl65XM1fWg7LLeueypOMDcpKIAOJrRG71G37PVQpAzrl5u4tB5f3KKwJKJG44dN5MrA+Q5SY0MTqAYhklM0plaCVSnHYoGJkd8Hmri2PVeIpN0pA5HSEtmOQgvCrQM48GcsgXskMsVUVFoBCPQjpVyqaFfOL/p65JarfoYo3GnxLsA8nJ4PmbHWtm/pLziruAYmIFrbwDSP0XxIKCR0U9inUKpBOP84LchEWytiEuglNOPGUxpqp6jGNIk4jKG1FYRYvf9sXPJqrPAUpWGzb5qanUDgdxKdEAbUQHGAxNDPsOcMzZvNVnrk4KW1PYxeYcv5JmMwRts/aAuDT2czIYctNucsd+rbbHLKFQLSUM1aJtZkYWqiLZ2gkJCzWZ5ColyQgjFnZxboKC2bp/CnX8PCajxb/9rqDMnT6Lj0SmQN5zCogGU6AvtzVa2jjHoV/j2iXkLEqnOgS3TxxfiBtRz8tCS0r9D/WyITIkgp3e6lyUqI13F7tBEF4TLGIFsy5cViu64lxhBCm4dOse9ajSKgG5RCzbmnCpgNQ985tDFEBr7sktLBpVcpN39Dz6dn9FQVwRZ9TChbL2FfWMP5y0wbfIXqvRftTikZ6hCp6qYoT+StaNHi6L0Bcd8urzQRzl++2yrssT+qtTxp4ttPMbDT/C9U0bmi8716M2LkGoIe6ZLHIYPu89SkxcGRpsoVMtjlg1whiAlQvKd9hRN1r9Bz6QFiq6pw5dE9FLKxlV/q/aEJBGIrXQ3xo5srN7uVlBmArfr5KWmeDPVr9HTMki12II2LnCpeW59iGIAychq60dmT590K5qsVIlTS+IZk0RhG5kChke5UKxSERCcFDcdjrjMIC4Y3U+qIOyvBNumlrYy4Brg+iG+HJswCnyuhGbVnUAehCRYZOzBdb1CSExM+DB3eTJa7JBypRhoDkVGZNgCdxLvAlEyCel1tu5TNsz0mcpsCx7PoXyzS7WaKma1xNZXDbEWiuFGbh3O2M2UOPgggVTibadO8RT7FMW4BFiu10tfbk/3B0mz9FoZXAeZ42I5WobJWsF0Pq6h8c32TZTNnWF/+wDR+mey7xBT56VAMxZXulODRVxElZ/NEXlI9Sd3WE0pr3wECBD7OrLGfF27KZddWZ1V43TKKFVge28TdJsxomKzs5So98L3F5ZrP7m1uOJgjYsUz5BSRaY6pkaFerBQPz/pFJPDB2/p3MJUBxBIJpDYfW25AqmgpNIbnMpGP9udlo1sdrLsmcRBxm4jRo3YK01N5zg38jKeIz+nd5xQCmP+1y8mby+XduuJsd27llk+xj1sKLEU5tUcsP5R1J/JSt2mYNufuFkgAMt9hG7ONGZwZfsztGZxkSsHCkpZzmTIKorMAYPLz1UYZ7SxbM+4pobtt52SQRuUmDd23ZWge/guHjln76YBoP+hsVK1c3pk81lgabp2l+KIV2x81mdp8RbfXGgKp3AnF9tcdTRKK9KikTNYvLHTk+i4KILm8V9rsXLBl9BWUqyLu4duWYlVezqd7zoXXsbM8XEY/9qcwqG5nf4woEQZTDdJ5GzMK8m4u1TR/UFabswd3W7SFSjHgVbrNq6LZFnK3PONxs3h4YXL3n6oGxrQaxro65vNW/jvBgfdAiKY4bf4C2SsY/evIjAr+kj0+76jkFqNeLykGfemAQO02L8UNPKym90knbFX2DM610fLq4ff+JLoYq2rK1RFtqLgq5ATWtIj8/T80PeZDQBYt6x6Hd4Ne9is0n6xcvH7ES53qVY/jdtg5jlu7jQf/L/xIeuL7mbYyKTTwzNnOIVdN0B5cO+w7nF/E7y6/LMm3zo/S8Z4sVrriA1K/02kKbpVW/g4gpXumyJRGVt/a17VQdXaXdRq2f6U8gD+DjfjFOTe8cpY3yJuhvb+YU7JFK4clbYyYXCGmQWjT6qHHFP2jPBSXYSyaGUefnqEYJYgGMmtlB+fIaItjGcPXsMceJHKyqzbyi0+IyejIXvqHqRlKbTnV8qHPpd2LHCMxdrdCZ0Rtq2FC6wvblDd6abaOTACEkaAw8Ci7GXwaCCAzGKsY3PBQAlXvsHMae1Fk7Xf8VvoLzue+9PGSsliONWHkRYtdyHAvzq4rqZsyYAk/ouHU1lBiVltbPoVg4EcX5p50Nxh8vD7Pd/8cRAe8vEuwziweWvHsWsGvOaA1SJLAO5fVLP7faTZ+7MjMsvH/jBUFUXmnNb0eUOJ/SgTlWhttQaMObKNgIuBeDjdPuSonSfU6KVJvJ5UNEg3GcBfRevhUjsOcHRLQMcOPeu4f3uP0B4IRWWOhpN5xqdEUyrhdQqJ+vhpS1L9Y50brRkzK9Ve/ZUqPMRv/fn5vx5+/MdDJ20z8Q/flVdfN7lXf6TG6+Fn/2R7yF/++Owu7j+R6N/RX4mPA6xqA8WJxQwAtfF5DfKEkAVsLhUdtFhA/hIn8klq+W2mxQFitvSnsIDVupJ/vjeeEARdzXZqxe6GhPgyskMZauXYZYjpcnzDyYrKZB4K2sahJoSCglLnCpvLWxJUHNpDfMnkEpKh+Oc81MoACwoocMKjvzWR9c+2PDZ0F0nxZP9mtWOtLeAZDvwpydIUlxEtQRLUyTTHwZ79FTebgBxZaOQxOgAj5gzUPAJf7emRPcBvIGZUfvYnr0IOn42bvVaMfhJhKp2TR6kc1QrwFR/AE2cFPnSu3nOHb1KEOmieMT6CVzwgR54/zTpX3hNi9+P3AlkP+3646E+ibUXAFzWw67oQMw6DTAASRZDexwxSNAdTftsRZqufVZ7o064xgvr/DD2AZAzTzxiScPCtTLQlfrv0i1RWp0u7fGN4J0ONA80nqEsadfzxMNtx6wyHc51HNhrmTj7I4IpU58Ps+jGhIAjqO0DIpGqzcBJzQd3mzN2RnGwbltgi8jZLSC+BbfDSDL5cR4MUywNydArbXHKHgUWZRLo9kmNZKqfwwa6CD5mEM/9DRceHR/0J9VGxT7S0kuizRgzdXl6lVelsOzAb6JRa/+sW5MTa90zGbLG2doxQRm7evjWCAf7E9RcDhxcgOQZEEVGiwAbZ/1XTeRckyCCFY4GTZkEJzMHyc1QSEppTu6drqhzg/H7sgvqIp4gs/V8ak+8Wgu0Xrqxo6AI9JXvZn16RJy0E4BlgNewE6ThJmZ+RJLveBdUtZHSZIFT5ISfIEUpqkz6Q7JMo2xPHjlG2ObRzq3GOO6P75qoBpdO5zLk7eRtUO2azFWRBXR7qhPqAw1FfIij/+sglbkmLYTvtvJEEtbcKJHCGghNZNlnV6aD6Rwjba23nPh70ZZNJBIMJswuogPSgWwgGlWqWIsMHMGuw+LSDn7CgXaF+oi5FXii/YwiaIn6HxAF1Ygt7qbHoerbW7c3eaRAqsh6D210hGUrc3WcVgkCwWdpAsDikOz+w7AA3E5b37bhz0GnYhqjQagtIYMuvp2R+fN6yoDG3+mtLSGoNyw7bIvI66lVFbtoFBTGfKq+VAmWpvWk+uDCVv2ziDbYIrhSQI8ol2mX28RmyaZXq2C6scoReGhpofiHhxTHhS1EtyLRQp6IwQsCiMVnCzPaOMWI6Kt+IpoTg+GghpVQe1uCWZ9wFGjBI+6o/kShcCzFzUOEq8ybrw6ohBr8N5na7tubhNKvd3XmypHuFzQwVlMqq3CvDCKIstRtQwmhywmPfB44govHAVam3FlWbXHVI5gR1bX6bnuLssY0dWpn1casQWAfgrmlxgA3Py+MAB5LPF3IA6hGLmZMSgDhuXiSZBRSr1Y/xFhS9oSqdqGj5GCUaac9IEAWD1ClfN9pMziZOyqtoY4cKRW9Dyd1vsQAmXNU3MhKMAjUZwzb4vApNIl+yBpmGaP0l8JOgwQdvNuSYxXGlFgfkCfkQvntHTBUey7PNZsVII1jxkI/dpjqUW6LIcptRRJWG4hnadCo10wQt6GAgonrBBj4mvk/kB28BL5ZR7PElDePjkjX5GLuFeB40G5yIhppzF4cyDtyIEczfERM1qK2oaiN3I7fQlh6FR0lTSO4FOpp+gfv5Asuf6uOeomPylA17S+65ejRSAEM/JZpeNFTVu1pEgpar4esd8PXL1SRotaiqdygwwmZ5CohXfqFzo4PNXPlnc8p+O08VfM3L+1c3HHS53V+6v3Ir/1RB2MUMqcvtEs3KBBCodbe52918FOovFYTdyJCed5+PZcVKDEasO973LBXChrdhckEx5bfnPDo6oQdDquBbLOe6iVZQEInsdOyMRAQQuIJSD9//ly2AQ+GQKNT7SyWtUtb2mi8r727Qx46k+QnS2A4nMECnDwDIz+4DkRooaGALgbAFAA4clTqwlUwMVW45iPEacJ0BzE8QreB0FjFt7ihM1Y6Np4lrXRXhV1bHASR+0O19WRJapWm8+eQCS3lG63P4dJ8IKIKPdQOOAb53mlCZ5Cd4xd+KFnwjfHaR0uhSfHmhlGx8CnV35QAWC47vGbBlJc16wF7qtw0Q8RZRmEwDdbGEwW2oM711ceHpEMPNCFlCd+NQWPRuaEiYFbrtvl2hflffmYl3Jj0urydaQSy0S0lwjqODdgQymKgFwg2BuECMmpiUtEpxUi30NmuhP2pWsaSx1t4mXr7HYB6jUzGC4BxDjhsGVZfsJXyh7iSuZ+DzNJKfANML3rUORA6PduNMjt7O6cM6cllxD9BlR6PKsNVBPSVZ4InLXTmcUJc0PTWCUZAJsQkHr6NddJFGbnjlalxA6HqK5hQ6BabX5dvw+fc0aG6znpQEPRVyCM/J8N+5TPTYtDeuYCerDgI9Kma0wFqVY83RiY/ABuwSJurzoK8RQeWVqZhRA0EmH3qX84/7iEuPaqzBHBNed1EZqPeX+xt8AT5z+2S3A0PwqvL14GLmtt8uqvhI7QrGcySRYHvmr76e3+ls1Tsid00tImJDJEbJa2VHFyPvch/RCrJUR1Rqt7rGF4nmawcRvhHFUEbVG6HQ8HHd8oG3PJzdOt+KQhXOTLabd3PIIvTqK70Ezf8ai0PzNu9h3F8FgWXT7i3hdWMyibs4//7EykUDCmpz8HIepVIcqKzwm5QWoAvvMxx1H51ZNK3aLwAX4LRNQ/YXCLn3i6QdH2B8tvYk522YHoHANsToot4y9ongr1rnyxC9yZvH4EiQL02aZhete4opooRFkbraiKm9IVyN4zjW1OKCdjQm6O+tJOKWr5vPQZnkklYp86VqYuNofXBZ+9sm5mH30aUxxguDoTx1pPu+BVLxNLJtmlShFPkMYiAUvCwOFxX1FoyvclZnhiAGXj2MCdoRqOAcF1Ejcsak00TZ0zOSVil1UTlsDr1ExXKBKDdWJdtaIptL8cEWUaWxHsQoc5ODxkhb8YQDALCFgN8633S/VG7izcvIDRBYljG6rtdsGr8ihImEt7T2tGHuWFQllATdWTZwCLP2msbhqs0MlzDVgZlpggcYDlpPduRNPsYUWLvFEEC/fTtT7LMqofacUldua4mUGjR5muxlrLPl6S0on8Mr36oeIy9OSTTm1NW7qNU9jQ2ueQqhFrr/n53lQxehSSQ2CkUigeh6Z1y8IQ2RGhqMDYqvJluBZdRQhOJ7o3jYpX5ZIYBAxefNGEXjRr0UugQ6lS2toimPRz5A4uOyfwwkwL0rciLlJbB4gIjHIrA8IsDD7iVaQb7MDffiopy2amn6Bu55ddThlfwgRH6V+djcWYpg4KIeFMu7ZNm9ZF62V3G1ThICfOly3QZSbi5uA99UAB4kH7y7hT9IvA7PPqbJPorlSxy21h5LUWPP5aFNe1illaGwLPU6GXRlig8Z0phE0iql9MRCszuD89A9xX9+6ywate6dukwHrYnybcP4ShwNAhnLn6x7Be7/ozgCM3Lo999fYLJoPGjkonSwazdzLB+Cjy7rXeno5HmKc2uM/SxSW22dKRG7UVCRLnTJSjt6dGiZsEp1XaHRTTUdhgeoJjyxAb4moORomBVCrh0v9j8q27ZhyVN29MrhrcS0gkSO1RstB4MkeX1He7y7u25e6+Rx9zzFPqI8v9j8i4EttmD2FlgeSCBhjNqVztHp4AEQKJJBxXGqtnF3VnnxCg104nwOnymhiRHqDtGKXWXtG4chUU6ckevOyt1oe6cjP5L0lbvnIvusSGuhTeDAijBHdO5QlZALbav8X87A56J3+cLZlu4Ih9yzEKg5V79wc4pICQS68ycH9niv9Sut7dwyq7iuONCwuEoEX2hOFshZpUI7M9cQUrxGmz0mMhzX8Na8cV4oOe3HYLyLGGvZy5v9QLinOmmdM4H8XBRZFhu8NF7FWMqla3vaxUTLn76CE/uWH4q+1EzNr06WQvTjH+f2btRUrSVzDRCYI7EgVsa/yrrx1zCDhoLmOBPmFkW6FjJaJg3Xdi3d1VEzzeRb+SbWd5IhohV8Fbbq2HX/fnDtd1raIQi0it3k335zk8WDizirDhzs9W67ieVaeQhgcCIm4E5VpTYHdxLMyfUb+PK/y4kE7wLBvwGcPzsK0yxVA14c7Aq1I39eJObCL1pyZP6KQJmM7v0T4omj9RuWRoRzEubD1AmqVHEvtay4UgfqLFrJV6CPzEsqCzFXX2MW0+xPILZYDLEf0xxis74ml7gOAjFgLXmzN1yGac38f/IYPTrdrAqhmtXpjJ5eohVch8Zu5oBA3YPet9ncaHc4JT8Ij2KumDu9op0x8xfsm+g38saVX+RUyuVYRmpRBBlFl35Hnfsru79iZjqJ1FxbaxrrNUtJ7KawV04v/wviiysSe1M2gO2pGxH2dcNAcbxg/jFL9LJvwao2euc6M70jvYuEPNsVrNmatlIBgWzsyM6+uTM2L9SjnIAprgN1JTX5kWnpcdVvuSn39F0xr2/6ArDaASvmmrnk01Pv3psLpXvpJ+m46KW1eU1gmf5DqXmsDcgGp4JJaKd1ZR/j0oGt+LCsARfTsywvGB8PbT5+4oPqVS/DPyWuPTR1iwWBwtKPdizMzM9AZWgtRn3XYs0taVEFcwB888z6w5cnK/09Pz+943WapyocGK3LjRCKSu22Mv2hd4XJXRg4saulrctRGGXVabTThyoz61eTcbgmWtdp2yskUGSPSaYJjTU7NtQmwX2SIenltCwff0zSKk0fLaDndZsUA+jRyPINS9MMrV6Cjxm4eZMhp3o3vd54E3H0lN4F1Q0iUA2aQj3XfU1cEyaonhYmNEnhXHA2vV4XiMUup0YtdUanyr3kbFWRoaZp1WQFVfO/Js2hf6MQG5p1gCPTdp/j1LY0cAoPQKBypCJgHQxWFxu0a8DPa8/83iK2uD86J1xn7tz/rmb1Qsy2mac6iVaQl3NQQkLrHDGnAotKlNQldrpA6E5//6p89qm3X9T6zdGPrYZlcw1zP1ZCIPGQLW2KUdpRZil2+5cMKgujX268aZD61DGFaPXlxL0sCUS7MybUgk2l5Kqjq2RNahHFcg+icyLSXjHrr7QLGWsuf80CvpgpJxXicKcVvzSQ8/DwO5BMWeJ2Qkzc9H+3kga1ozVvu0wAKVcUqeXrk1rPRS63s1N0FH3PW1iLV2WqNWs0ECgQfNEhCY0LXfvoPgHe++ulXs9HiIDAB4GBZnS1y85JKngS5XRJOnusY+59YICew/Rt12TJ3FgyjT4A9I+htz5cUwfmUKH1C2DGzdXFLqvcC9SYgMJoz+XJ+N+GsEI3T4FQzNMpDOEr778lADV1cOJ1pBztvP3ZrytRdytJXIVWf254PkcYfbGM9borDPy/lfs/IloauURikv9sQ66DO8gso3Hl0iyC5Q6HB0BunKPwCeHW95iQevrPkZevFAPch2xcw1gJYu4g4CzxFfF/E6WnugDdofye/B3xR/QTDZWlsurGaKOs+rbce/RzNjPLaBR40mMQKC2KeusuucIl7iKDpFaAPbors6xFKV0ob7QHwnc23Vr+F+qQNkJg7nmGeDP24d62OvK4Tj0dJmh267Pb7O8H1z6IQuVKUUgkb0bbOeBHu/pH88+F4huWIh0EpJ6tY0u05deQEaBlwyNm1PnmaA9NRBTlwESwTNhNWcTIuCbld/g+PK4fT+zHna5DVKYYOMwqQvvkKJ/f+zHyESaXouF/O3BxR1xVfeqwPWrXh8jv//z+O6JMdIJJczcxOF42YtfMxFJtVNt956tyMtvhGqrur3t6XjyO5tYmTUOLqwLIWUGUWF5mVgkrTY5yiURXqljxajmLy9K3tXA4mTVTnI/XSsyKRGXJAr4VdTbVkNhV/z2w4PNBERwkxGrF4VJklV9irsC0uNvwvWNJsSakY/nicdw+2mTqsbGgt3nnAh/CeZURm08A/Bn0vJMWRbLSvkAYLI58KCS2xvjJOeIEzVu+fBy3zzv6hDP0YVnIYlKa7MuXmkwOJfsOZtJwi6+qvBl1TdwXpeSDw1XRYAACzaqYzI6KqmNi3RvrT7FqiAPQ6t0up8NRBIFiohXsgMAOIRL5p2S+EAq8/lKKYPZ/XJt63VdVrDR3mrC/SHZ4xmSDz1J4X6n0311bMAp73ITKjYVWuleGLCG9cKDc9FpzqnsQubE+BIOAHzWLNh6URr50oMJ3jBefQdjyn3IbIlE+BIa97oAI3lSReeuPM7piFHu9wnlGAHIQnWxwr3VizxZsNC93APxUtWayzRtUZbZYnL6WYIc7WR52z41klKzeyLubl3m3y+oDOe5RUBb5Q7eeNlbljwIPAe4S1GbeskHuDyylsMIElYulY7oFvHJ4nMfhqdKeyXzqOPr+F1x3Zp+Eqe2fpGObuf8smWB/vFaiV0QqjQvYOzRcVLaPg/LIr8CB7Jl3nN2M0j6BEer97mCs3gIH3Ja+tx5aBXJe3b++HuvgmEJQqhMOtJyuub9hZX40snmGhcvWYkUoWH8RNamHvEDfrazo8imhoPRazYi7PuhXR/gMqgl89FYHCHxsFce+OIBGX8Uup1LmTTx1hUHhiQtmpSJUWbxA2EVvFVMt1SLG09NuKINefoQP2Kc2rrafZuPxmVdogrc27pmNFNtSwcHD/BgYi5lGuEfRaHIyBbk0eYUL8wEHIPnuSrrsXvUhVDH25K+Hlg/sQ0zSA5FAq5HwUW2sEbmZfydXHDPTIUnbSW3TAQIWAjnnAlKzJFnxuIa0caGsUIMgfaPukWeh36h0zgFpA7n5DoYB16LR6DXPdpHOE6yg49iuiG1MUzxYzJBk7WFQldT+muoG5EKDSQkW6kW8G8P0QuLsOciEIMrydfN3LN60QDlfYlPcUh+A9qC5/9DR9H+4n/cf5aRbVOtWPr0yac1RET+65cS9grCyKmPBujhRG0+E969RdV3hdrh1h3kA56CEhLLcc+JOIkq5MbsfMl5e61o28QD/bxj5DSFzEwb+Fpu9Lhs8vWAWNLidPvpiOdm5Jd/4kCew5UCNkaS/SmKQ23MtjXabBDralNfy13KqozRUIqJYZ1fweCtmKVYRVBoOlGsDnKdYYW0BL260+0UqlV9ktPPiBVpW+KkgJ7+Bl8WMZIuJAB8wFLW8UVsxkw3fme2zXav9aTquoCb9cyhH7u3ZxarFmf3Uue6FNon8Z1i6v/B8oCqfXtlAvPwTiWVRw1iSn2e9+/R8H5fdlN9W7cvdq1DfiawcXhbGnRcLPRdrIlcdrUlGX47L8GW6upx2Qjt89Dg9LhiW+hw+1Tm+YLjYYVtZ6ruQsaak3LyoqORsn0Qg8Di3TMNVhjqthOXg2RnOwg4Pqtgd21fxPZ4PlFds3Ca511H/pnObP6dhLQkIcZ/MEXFRj84pQ8Ip5Jaex7Ds8wsdJIge59mUckZpSSlDoXTSPJI1pYyTtsJCs82oh+qhStjenNvbg2quF28w+rcTGtqNpSYTd2UboT6wQxpSlM8QGt2G0kKjodRNaCy2RHFimaCXy+0V8u8NKo9uAFjUWJgUknZmEerbyDi0Exr8290eIWyKgP+5ZeWpNu/07l9V0AH9/cSfTd0AK8yWrfDQFf+DnMDzcvgYUkBAJvrjw0zq6VcDxwfgg6d2WBrH3vURI0HAXHqi88DpE4VXXtZ/vT0PuP6SJ/dAnhQmLY6F1u6FBPnFd77ccVqcWz3vpVeJlpCKmOPMtbLDpG76QrLMJmzSNwv24lyv2sbFIzWMtK7iF+ASv2PVVdtruGXRwl2H7a0WZmLkvZULg8jSPZ9mLcJv9YerCifIf/vWpHQUmHBNwjpj7R4LuFcX5JQjg1q2PuV2uuMdCmij7ZAJZHTvXxBPHIyvT1lYpZVlq/49RJgcXMUjX75OZT3H1BvSq+eMrpU67E8gH64jD9IznUocxyKxUX3ZqvqO2khkSe1w3Wp9c+3cjVhpSdZLzXdm6qUlJr9bplJtN086jCbGzzru4V5/WmS9Y9DuJU/NOKJnblMGOd/uyUvfsGfFoRUzBtQ4Xa3Myq0om7Zql22kOgdvegHphBO5yYkHjtsG9sdJEVMy0O/S6d7/B4xv+p7OCvAZ/jPlOMPC6EIWcI2/hZknLD9fLtJ1D3VM5MmLnqRF4t6ORLZ2JavY+JL/pRVGByGDScf969/HeWdLz2rIocoo5xMYIURK0ycg8Y1kcgO+P/LsqQ8Ly0t1FoJLTe4vQeKq/W0UOdntDLJNQsteSU/qPfai0jHKSRGXrWPRdr5uRb9ZasQ7yor3GHbm3q1fXn7memd2eJmKbMtAp/+prooWrl9xdzxljOSO7zGx6xdPPY2cXtBXLUD/0s5svN2/Lv14lLf4/jJnrF0gbZUAtJFa2VDytfQT08dPpL8Wpe5hvd+W1KRf3z6IQZ478K78LpThHty/uXGVOB457DgsO6gUK4+onrifROpqYq6gIg2+8Lxte2OPBv+s97DxO+2qB7tLZgnu0ziygOBxGo/I/vSWsGZdXTmZux3GV/GVbr5+x8tMRBIPYkFXKDN/jeNKv6pQ4Wq3etcvtndr041NlNy0XMFjUe7B9xcWWU/hRP8m9h5LPo8U8bEZx1MYXwtsajWDwlIUqvmUN1FMPvklzIc81WIR8ZUojPTn/Imac2dGHsrmP95E4d+w0PBRPCb1/zvz85mdZ5QqdMfaplU7TPIXZ9voVgfxFcIRlnAgNtLsS1/OroL7TYL3+TjckV001K8sjG5ZKzGVs/PhJ1U15xSEUJlbxfRMJ6o2Pw6CsrLyu82TAVSf7drrlUQgupuynb+4t5U3/3ZqX85c4TpzbZT8XsrpTDfrt3z6yt6Ygn2cNHwo6oy3ncMd1vdFwy75a4o5JzMrxGY3wZ+q6tY9jVq2bbtzGduUZhnfqdfTEW4ULkp8gbotSohX3V+5x6Gvrts8HZTpLV9+szb7ImzRfZv2W2t/cZe7DX5ES+vB79f4/is1gWt1vTXWLaJw+Dr66OJ/t6Ga6Pgkmfgkqe77Xn1EjdOnS1tv//SalJTAmhDhaQHm9fB/CP6b/of24mX68tymXaRTpPslNplG+k+erA9mPUFHk++fHaC6Bt77GYmWYSC7lWtikE7hX/hhkkZiEio4Gcw2ey8bieIIRJw5nBsjSUURv7n/JxRlL37XoGwFDVb/MVsg5EvOq8cE+v24U8BQVB9dT8CcIlBP057WHyH8Slalnf2NSkXcXUAVKRAMq5iVRaHvFGEev/szCwKi275p5It2JGH2s4lnDCV51d4+5oeLWA/1D+mZJAqQoPDUPPp39j+8hQWGWYPOorGvLkVCsAYsz4aBYEHzjWbqkr8xkB16TWorhtXfYgmEfMrFykvfjgr1s6QeEpG4htqobvxzupXlfqD/APyjSH4vCOupO7a2E7qTg4It09HE5ySaAptMpS13hiKVwZ6VX8nOM+kkNkawbrE/bYyvg+veG3i1q+PVrtQNbmZeWi7pY+YFZASBYqCwOCx2fXxlwzVZCMtGC0YuYOWl5V19POzzDPsC5zkSIYeBQqKJAg4Jg0ahcT3fFeqzqR0A05VmxPSELcxE5mS0ZqAwS+NBQCNdjuDHHgwcsFwE332YoNF0mBHfmCYqYClppNMEzDhggUa55Zhi7rnncRgGYOCZc+gb7+zZX+6iU/C5KXIaJgWfx0G3ojkEfApMk7T16LvHz59fF51e5/dL/jh+fH3YSNCquyrlpyrVp0rV3Uf0VDotxS1LccpShxdMOxz79zsc01RqSq6r+2hLcq+xMfmISdEkuEeoMWm43/mad2rK+1pn5xMpZFbr5P27F7TVGi41PmXomFsw29REUsgcsFEc8Md8GPsM5E0+qpceGX/XtVlukcp+hH3T4RdzxR3+b2A/yqRyy2bXu+NHGN1f5qZ/kY6x3PRUVcvoC3Z99MwCWe1rl+O5Hxwf5L6a+Ijr46QJzs2/4nVHT+3/e/PEP5t77Id/m3Orp7Brg2oUPiZyjGj969IfH9DOj4gHLXaTNKcmJwmAmMyRgrB46OIhq/DKyXk3Aw2Xs+Aaba9/3WlZH7GZSm0mom7IWzHznUCz3uVqL2hif82Qnc+sMeuZqp4J2srtapUOSXdect1oA/A6AJ4ELM00SFojWiWSmPh9IBKRmiXDMtkw2zbltBkBO/D8MRQQAYwDu1VpNhjMSqXCYFB8yfCKRF4Go1Ykqp1qZ73+0snuk0aitFXCfO0366wFS1okneQXnm/LTDscfwGAAy3MrycnzoLqJwanphhEhvqImgQ6ZHLl4fk66LI19vypVOWU2ftumdC3trj3u64t8dmyd73mKWXqVL6dcuPfvaguf9ueyirP26Eul+rxAudjTqSNT1Bj9tFzpnPo7CmW4AMPkn8Vyewree/OCzKMAEpgOOqi7CnMMPdacuXikiwCP/oeNujKXv+eB81Wqx5+8DDCnId6TpsMyevH9pYl9sRMSIis1H7MQ5P2IgAANLLi2sj+m6JNADBKaz98qGnvFLYEk0LIS4GpcHjcvIArEHAzMTgCAYcBaXURImG4cd6NyklclvyVKIG4PDTXd5xlyyg8lq2Llcqk/mhdJFDmoDcbjt3YDEcQPzUZidW4/AKgsjoP5BoxOrVVhYPuZd/GYG5nZ2G3os8iGCPN3Q34pfVH/Z0o/HM0htaAr3JOV6XAFA/T+kXLiqW9Ne8VQfbRL31pK1LGLRS34A1tj3rlsQljF1/No/ZxFDG8KA07PyWzjwJi0ZQO1kgkKUi0OXT4F7ZJTmr7ygRVQAJAVFc84MbZMPgU96ccxrwlCMH+fG0PRkzzq/JaRlpL0x/cLCFE/izYsuQcnatRZsbELUDf41SCVpo9Rb8enl9WIcz9VCZ/JzfruY1daI/0Bks25mdgFWi2NNdpxllLy7FN8SjxpqHXSRtukSTbRfT/16HxPXQdM6HuWJ3qoL6PwyzDIljb1irpcY8ATlq7DUk4H72DZ7ve21ddjcGZMLj7lEzresk3dVc3pT3LMX5SorWlnNA4ckR6vHJVxshZCKyXy+tB653hjNW7htWnT6sL8vKs4QbyOAGGgOobnk6Wa3jpeZ8XYFg8eI8iUL8hLIL/xQEEJwWcY3ynT9ik9O0k7vjgLBGNQ5F57Y2qM2fPffmeg5fAsN4KMWeIvJZf6hcWvX8wV/RYUKuN0mRM79YOL8GkYtbJQbPc4PP+dznn5Xf0las5En6KNGP/59st+ZJs2DIHXXJfSv/3mSBFrQu4YhXxitymNymP96E1LMpHAKcIc5Sy+4iq5eDp2vab+reeu60xNF7QnWyeev28MSSFitzU9QyNcZeB6ZwDc/AqqLeUJc1bs0pqkdEVj33XDJVcrDW3bWVuJ6+HeKSlk7K3DObNwWDKG0aiBTW416VqPAO7BUWUEil4LD6Dncnfr1CThd9GsEe73ZaMcputCFOuKsfPYMP/3iRSHlDawpHvUs16FFf2XxwipPVlkBU01n/EhWi/h0J61XKQiBku3HoetWAfRbtIwXXWQvi0fhhVSS+C0hdl+z2kO1O09Mzinw5QyW//d2/p1+wQ4hx6y5mPuZNdmnS7/s+mf9z7UnYsC6PwSrtdUP/eCffxLUWKsXeMNmWN2I/JkJFF2UrBGxzkY3teRexQ7sCIvrq89djVzVmwL03KkCpVZSiMvFykR+gcJJdOlVLJX6a9fc1kqw82X8aezYflinW3zPs7b9qy9sRDB81tZ8tI+bpA4tMmcuk/04WzHEEMzP1r41c4L0WXRlOjDXEHjbmd5Qwt4mzx8TOITMTpBsHpRmOscjMahcjKepzdXy4RU1AYOEpzU0BF5M5RCjOHQez/oKRchcN+D1AUTBaJwMzkQDdLKJiohfpjII2zDAfLnIzxllFFT4fuKpeetQfW7E1RjEXd2lGa3YDBU6zmEPZAFqClUW+IJl7V5pxZOIgRIdjgDhh7GE+wMNk0ipxNJhKJmfN2s5v1xaHxirQRJi4/8YF6323BuDXAGIADWAIcgLhPJ3Qmh+R20rQSVaI/oQXo/w+y57B1dHfvyHE93kwJ7ZdKgiQc3qtGAoll5gUADdtNKlva04Lbl9c95tCxqhauW4JXUxxNgtTNmxuJmellKtQUAJqbCkohUUHIqHNvB+M8ednj0WyaR5h/2u0zIKBC74pEejfcjnnmqYfTNaLO0NmvgPC0y4DaCN9/gNiAVe8lvPljVGIki0LuhnI+FOnJazAekMB2FvLzYfutjHOoppbp+7OwZ14LbssEagmuQEcn8Up4pg/my2d/c06XdRKzQfxAzoY+GpCu70ivkrjg54sHZPTn/t3bub+n8/B55DDyzyFkc2CoXJqBfP/oJjYSHGC7Yx1g8IGqZxeybXb2ANwpXTgkROGKD1JmZQfDA6DzwpiTv4SZXW8SSMax2w6/idXurmOarqZrsmuyq+lquia7mq6ma3ZFFjKgpHKBwemMHWEjy6PPscV5nmxlQ56EUd+VJ3kqEa/cZoLmvi6NAldl8/k+sXOKraear7yWRZanHwbyR6rEoJ52zDfOhCKyUyNorfikK7HI886jTplaZl4gC7P8Abg52rQEp6GvtPbL3eRBp1yj8wbCFDAvxN+o3KE6AelySS2J4/jUkyJ29vn4rYTfn8foP1kIRkbG0gwIYwxI7FRJ7L6f/e46HRceA4YZJ52/J7t320JwOSxkdur2BdtTW+xhHp2uwT5OZw3fnPTEqe8Ff6zDgvPgqb6SKF2tOqlPAZUzFF6QuEflIpc3hgjmScoz84y83BZAz9Pz4vNUnp6XlKeqRoynFOhVrubhopSpRrlSTaBgH3KN7uxhjFXzsDFMcLATzwA1dgQRpcYiO5uP5v32bLkjYnbUOgBQ/T+FERIbkSf5d1yZYeqXCvnVk9y2WOc+GEpZDJVwf/jGLTNocuNPg9AtP5OniZJnFp7SOwOWRkbxPWFGHrA0KoqLZS8Io9BtC+H0Asos1+qTHCNmYYMpg+sx/TDzxuKt6yJPUedmpI/lelSRBRmTA/Uz7TuC2rth81Q4a7vKAFmSCmILOW5Q8jeAx4AAZ9gtBjAMAwTZH1BjY0cYwDAMEHzEAKJ5QD0YwBkQhDEGongV5WcJYW1dLAvPKV3kS5/BXRr8fP3KY3yoh48movdGcMe9KrYFlBKaLYRzhQ9LmWQeY/M2YDsW7rK0055TJeDSRcqWMh+NzfScb4v6GwVSVCwxtsuZOdBYyJshy0bbYRqVjXqXTV2madl045JNTVPT1DQ1TU1TzRRgOH9zkk1N02RT09TZXUArU+3YBe9sJlfOMIfph3aPgbY+418PQxWPz6K6yXq5gKccfjjmw28IrGq1mW8GtNjv8EUTvfO7XLpE6gzh2b/EP9pN5IIV8CXrJUx3Ohv6dIRv3V2hQ8r0qU16Mt2km3STrtN1uk436SbdpCfRTXoSvUYfY6CbDw53s/1Xf8ZUFoXLyaWppOU1P+K3DsGXL2FyMLqs7EIn1uPBpPXDiGfIM6LoEC1HZSbr2BuO2etzHRVvEH5sznFZMZ5mUMY/jcJ0kk5dkojRCaSaGC7AzagrxFBZipFGPEPEBUUZL6uyBMeAUeoYRMhuPOgVq8+aYFiQPhlS0OovBh/ZrZbt2ezdsP0K4Of2XKR95agHD+tnR8Jl8Owblr0cb8g1mLqNcB9+Y/XunKFNTpUDpoyZzDE5JieZY3J0zjgGZVQrGXxhQbbALhqvbg+jHuFqBKP8vpH2HgrX9GiUO4zOIYty9+aLvcnIuvKWrd5g0igXRc0isyipaIyBPm+H+xxRPvT5heVlh5nxLFdSqwRwEU9tIJ46QjxFrNUCUK1Nx1a/1e/t53xfOFlgk5vzt4fBbBQuJ5eGhLD2SNp8LznuclSjw+F4mW2uY4DOjdlMHZ04hqlj0JZFoe35KB+XZv0IEzaDKJOdwA2cq61b80i2wMaDF8cZ5ERh+iBTRW6gi7teZxBNybbhxlCnaaxzgQYac2lZeqxaJMFgdWeVkaiQqdCfbfS96Jpt2VK2CjorCy/mrlSnGAjhxWJgndkL+qAUF2O71d7jDIaFce4wAHhukBsC5qqx2hJTh4NsKZvTVZZsOXF24xgIyU4GJ5EFzJ2074f2BtgWqAehk5mLaeQkh+0kZhtJOrrwICoRdd+AT8ZTzkqyzLID5o7aM+mwKpEkFZ0klbNS+FmYOU9ItpSRjCPsuMu+9kQf4HArVSiiACSpPo6BNQC504hsqURUjzDpk01RvcyYzaDtdCPqeqS7EQ2YuWhFuo1ojzGwUUdn1KODUgoZqY2sRxhYixQxWS/G9VzUNhv/vZGv8Qvzt3VYWsppTab3A1Z538Itfle7x/t0aOv0nWvY5vXremgVJrw+ZJVZzmZamVZkpVsmWKED2HE/QFbKehFWAAF5CamgN3TqMCe+4PTmBNmXMjxgfylbMUoxrjcINmaVjUH47YlMi4H3Gfl8FWae+vidzSRltzFNN9PNdDPdyE2tkJtiwfABAoUDIAzZOq7d9PCazdRKcAP7UfRImdcxUz7KZ5tNKcm6lMFyENycf8uH9LC/iwpcYFOB/1JG4CA4jbi7LvWQZSmD6iA4hUI68dylENcOE34cY2Dm2H3mZ9bP9nJgEarxYf6a3XidIRaygviDPIcL//PuYIZLxQqi68ROv9vWHNt59zXyUGzHfo3aOkNnNp9KDnkuwVbZLjE4noQq3OfuTg7jXrk669ztUsgSHrgqzaV5M3qV9QiDZJ7+szzvnHp81B8Go/xRxz2n6buYeyWWivklPuOpaHvskZ4mcXkwxfPdj7A5I5+H/8dBnFEb//btoEyD5fzRzXzKhwfj6vlaPvyMnm/mm/lmflK+nj/GwLxN7/M+9wxv+fnEj8Kv0r5tyXiCszZJ+hhqI+N/7rXpJSyXCMoLGFfyWA4PvfkfT36KrTP/Lji12P/CYL8rIJ0ygdpGYnXhdzFbM9spQ176lLjtY7zy2oznHSb++Be7JjW7ZnfNo7qSuhbXpbr0Lr0LzXxg+ZhdWpdklo5238imuFRAC+f5cBX/cliC327O9VXO93Yk8sJucVsSnC4vN6gtA2h53WWua+ufjNqo+npfgnGX36cKmz8r9UFLlMjebRWc0pb0sQNrO9cMUBq0xHNPaSZe5iRGGm+NnPKvQql9F/f0WuRCB/tgN0qQL80DEykMEWiYkY+JrZIIY2HCgPloFuZ4JzdGhxQVkqN7nT9RUXIkl9HtY3k9tSw1BJeokiE5dZzk1KZIbi4ya+ofZ5EOC48BghDE71UEmL2EO7e0oVxseJLibg+d9KAHMySFpJAUIq4kI64k4oqQWO0Rq6SHDeViw5MUpZMuupiSJEmSJI4rm80jbat5+yJbEICO6Jez6yigH7pyDXaDSiw/WnDowllBmA7JDskOoUOuFk8eDP2kflKdnGc4wSv9JErgAUDRrZPupruZbqYbAGAag8sHw6YJqpcZ624VDPFKwQeAomcn3VP3ND1NTwDANFzA4VDtFKDwbG8xhoErCnMNdq+FCiY/Wg7uYgabwcnBicFW8mXwWFxLJleiXFNekTZPY6790PYNuVhgqWBkzY2Xo1u76MvKLp9MDlygNRvR1TNS7viUpYKRNTdeTtRB4rzdQ5XIl/sngzWfWzPP1a0Mc9ZyfNpcXtx+FmEgC+5mJpdsiihuZqeANvT4Ofef5PFA2gi15Ek7X+jFaCx5K7m1spUMZDHiLYJ8o6BrvYa3eXhLlsfv5vZ8WpGhDVh6qI4wUEvGv5hGljBQSyadZwqjsWRLLqQTIm2EWrJ5W397MdCLvWthLGDJUdkoGpEBy1qv4f0Z3srhuc/1NGBffcyxVwO6YMCSXnPPCKOxZOCtG8KAZW3EoXavpq4X38eW5/FpiljkNPX2aX/2PnPVUKIBsjd/FeaRJqQBAnbM6zgMoEE2aa4kBGiQ4/SHAlVaQhOK7OP87DgEaJCTMlfaNwI0yImY609GgAbrAzyx9/KIj2PLoXzwzVwUlWiAHMqDQTchQIMcyr1BCwGaZhf/PdsB0CBHae4rBGiQPTpsbyFAgxylvfW5tIQmYKzxE8dZHhvImW3RHRKdRaE9JA3/+Ybd8bpZ+QTM6+bwrbJ9Z8973bf5vltl+M+O2PKdH477QODntXIbg1gBXKxlv9DEXg6Ygw8CTAd5jARows/NiR5Y0Drza8WCji7EVUdTbHljuL87u7XIQDbYEJT6DzNcS1sMXyVFo0zTuddcJUF8c7A8EvMvXg00OBVr4qj6ytSUpG9XedfLf4DENTG89xjN1psgGv+51ATgZudsciW+UfLHaGj67OaOSePOr7+bbGK/wlr/Yd24Bnz3Kwlnyne2+r76fQJ+eR2XwybIfByO9iQL2jT08UqXZRXeDtJZ9Pen4+/eSwSM315fx2ajm35zczyLu6riWpyjYBwyr//RFWVtLF0b/k4Kp/k8TNHE59qut68jLAlq9jBSLAwBmkG+buuKL5Jrd3RcFnZ1983Rttzvlaubd04269w/0fpvGq/aWP6mf/dyMm41btf/r/8P3TJxcP3D73ELy6vRzbW86ZaL2hb7yz+PH9qwNrJPs7i2vb3u3ROvTWz58s20bvENi+j+X5rroW2yN0rdef15qPwHGti3u1xA9jHOXgQw9O+d7/+neyQs9REAqgBqzL6xUEtcOjsAzzmIaHLS6pF6dHUghFUTPVVb4LIgyKESJ2YhPwQewKp6FNq94CAxYqFBoGoUZ8urhbK3KlGXjfUFiaczVT29fNRUlqBGiJJOWspqKivlzat7vE2yPTbtVRkzeg1AW+W4WIqupthNrkBWOeUsVC4uqESP6MCBc88UHRHd2kNfOJFeBqlnraI75lYphQe2mVZdXy9jHqgdabzT8ggU6z3XkKZMbGZhZjgyKgp0KDQ6Y2L51rJ6GnRhLBaLZDMcsZaKDmVGJ252L6FF3OEw+AgOmTn4AHUJ0pBFHR2lrrJyAYDFh0/rdPyctZypb0cXK+gJjCveZB/qlHVWdNpcYFXdaEa6xR1xnLB5yPhpP1KI5DQo6vqZnDg+Zf3dO7m2fEkRM3fNrVLfelP3jfSOc5X8587Xla5qEn1RlLF8XgB8yUEENhouWmf8fmHgKBIdRcEe7vakT9/i+CD/tWAToIZmd8sCNCZ71d2mqbPYchZXRxatWLQgC3TgIrIILfwoBBbpVWPHLEOOoaN9qn7+K9ZmSZgXjNX5fQoqd7jP96vNMXA8MBsdtyIucZkfOeO1jNieFctIZ2a4ZO0y+G2raLZJSSeI9qqMGW30XEzjDZFG+3RHXMEdRqzfmDXSqBZ4MhCP9s4HaxK/vmjOGolnFjGjgezdZicmnq5SMaONnosar0sa7as6YitF7oBtgWKAReKvg/Kqs3Op88/FkCz6tk/BnQP+B1M3Ppf6LTVDVnCRC4n52lElJ1IIOkL+RE7K3+ySvusPx8SPvTAa79SuQtYAOJZRLdkNyjegPWs2NipWFaWbmGSlchevdBevguQEZAI1UiM1UiM6AqJAFzHpkn7XOvNhZv06rGwXt2CQDduk6wnVfmUCWQaqjTUaGqwtXPWQ5VtOu0oLulm9TXgbQrVfGUG7e0pX2I7FTuxn9+GxOxrea3zXTcQ90tRcNK6QzXDUqCjQIWXkSje76itG2aJSKqVSSKBSKu3nvZusOI4coerDleD+dMI/KWwW+1GfWy6J79JyhDPgNCtqQS2WeQf0AbbZQRpJHBy6fCzVwfQVW/00E5mD7nbC24X3Ad1VZ5ektyv7ShijUysMsWfM00OrdK7fYlTrZfpZOlfdieiqbVdwaa5NEH3L/k4O/Uht11olPTQNC6JXDUv13f6VThRs5BeGhFoKTrP6KmxKZRCfmqtqi2mXTmjqtExpLZ92aaaHjWN6ypnvLFa7dDLT021mlVJfldO6fufa6dl8vmDL/OhCcObHUbbUFxzSZZj0q/lrSfaY92o+A4gz+ZLKyr7C4bv5tmdVytVX9zKwbjWhLumpZ/5w0ofle6IXWbPGskPuHXf2UOj40/U2AWRssqyfVlb8EdAkT7xoCb/zMvf9leH3kDcVUSl9R98vk955/LV8n2D1K4jss8Yy6Z4eCgpMMA2z+qPxYYD7byusEdhFyFa6IkSGkSuli6eWu38S5qtOa4nztn8L3hm4/JcxLY/shvF8Z61miCVf2ScJ6uryuRT4LXQITP5E/NDu/4lOgu9rcRRib6HzoUSA1rsKFX8isj6+ZtTk5hM2BzlLRBqVROzUQQ2eakDeHKU7H60MtcU0sfCkSz1Nb4dSkxKf29flsbg4qvtyAZQJsaiGfMuF2ZOlxnWbsrdkFVd4ojiqY6iCKqiCKqgCJoQVAXXbovRg1160PlGAkBKxAw1WNhysHlp1iakflmLTqoyak78MLalGxq1u9Eu3RzRcTd3URN0x8W0arkR8kwbxqDFV9u7V2HzDFFF71quvFJhbxGUbnzayo9OK5Sj0jJw153/WXACf6Nj8VqWE3wQeUrvUW1sbEo8iRoURRXYI62t3ranT1Nf/ex2M2rqRcwqs0++MTijFtT+tg7WGRp6Nj/o1rHOjnpxdHehpdSBc6hItj+pA1wmJuKeHAeqHV6tqUj1KStur5FGlTa02BmpSHygRecTRoAZgdZNYXQTyqNKmVuvFkVWKhTwMml/9PurCII1xg5j8hUMcqA1pCjMgRivDbQN9cNIMDlpbyVgc04rc+K5O+klIOpRme+E+7vZPaD/tV/un0wC4y09Jl8PLzOJ9nI6RDukonemkd593TTxk5/okzjWzNiBHW5nxLmpCURRFURRViQJP0IpSUu8c64iKqp5a1oisdCBw7iA7aUGsUJvlnrJGZKUDgXMtcjClSq2v2EbSFS0jxrD7oLLjQBFd98Td26J7dM/NZTRHczRJky9ociM9hSZpMpxkqJIqB5VdnJpruVdNTsKiZc6twKSknhFj2F1RBoqYntBl3TukrBFjipvJaIZm6J/6Z9nJxo5OEeir+moNXRAp556UeyVP+SkaRc1ovkaMKS4xU4mWnXcBOqe7inmLLAMCR44tPbpI1bcBuKss01yVglq2MDLdT2WAcGViFxe98+3nebowy91QYYINQZAnW7N5OmHtKg8Ckj9U7GrZkoInnqUMpsJiY3fO8zpNIPdEd39DwFZAdfUbMvueVRlHKkOxM6IzdAbu9o8OUM+v2GEH4Add7Fz95JWGjQk2n9I5AyH15Kf8q1v7NtXcwipoyDansOs5VZPOf8VIqlHJg7x0DBOAjS9XP+gM8YR/ZIi91/LEK42xs79HGo55x0919PfcadAA+bhHzguQq7utldXCBVq1exeg+cxESJtk8EVDi2w9U+i34rTmQ4ergc2efoXKEHLOMKSGB9n5/3FEe/xUrDyjpDmfLq8SY071JB9HX13sYjyPOdGLw7HyAP+7tZQ6YlKkTl3qqy94QL6ePQAQfiwppQwX4YnGVXG1V1G9hufdwcFG9khb178IdR6CphHiwAc/3l4+4p9TFA7/43GDGoD/zB+C0+836H4WAM6vD0QBRaSAeBvb614NAaDQn58/JgBAnr8UEFr3P8K/3K/RSyN2xfeDL8M13MLXUjDMBUbhfEX/9rjK498Q9qZxpy6Kj6oFvkQKi+somDRdm0zUIaSyHJJEtmAVrRT+myGfJTlYz8c1qVnXU4C4Ev22DmaRq2/vMRD3g9TjCoz8lphFXj/ejurayZ1Spe78Tjk3ueT8CmyzD9Fb4cMrg1/DjqyCsoP2w7JB0FysoSeQeZ5d1OE5jcVoexrHSEaaXHzkFAG+xiTBO0wFgXYd+chPp3VgGnWs6GwOLnPbvY1/3PAuGnn+WACghw/fG6/lhpOLmwWT0jbTvneIokbOVzeV80sAGMCbMAeRPtaNDHO8TW3HEY1IjFxFAV2LfnZNKeJScA+vQlO5sXMmGw+mE1oomF5Rs9MD4g5lVTfQ1qBCTbJ3KoJG5Z3a2OSi1gRDx9cR2T+6+sKhdlzTI6BdoJTWnp6Tgu4NBgv234zclTMWkr5slfHOcHNOrTyZpWOkgasLL8ri4mCLNvfxmXa0NVk7+2b60d5szGZMMQJzLwaxTWKRETsJfCbmi8MDplUxXBrZ+GYVS6uVjDdluwRmMjoxizMLKvoTW95SQ5Bu42KS1mgMfYFWPC8y24dOfsPs3HPNqD1CbvTz6LzGLQDAiZokCzZ8V4EkuhgRSRqBx3WZ/OpCY41aRu2qhBJ9XVrikvrpC0eImFXBR5dRtDSOn78DizcIytAXfWJwcBtNyxMHEj2sx7601XQ2ZVDZbQrmcuPk3TSNTBpw4GSwk2gxBkaRUQkYx0x0LiV3FrZ2ZGXhi2lIDo1JLzdsl+1PYIWHZYFNnkKVU2YaLZkB51K7cTWBZA5RGbhwSbDgU0ruSNdMP5fD+MnjOP/BihU7SZLDZpLYCZWuifwSgcFcxKcisklfwnweJlpjD+Zqf8F+XbiMgfHUqY3ycZPNQYP7kDawRl/SzJbTNqAUZHIEjHBP27tvUlTSo2qFX8ZweehWT85lUY02GNd3ZJ0eD7IpYcm2aAaZ4/SaHohuyCZHaQjc3y8GQrX6o0ZllK4SLXf22YOC5GXPml95vlNSNxdFZmCdtQA4nTV21laMGUoYMyeKywY4lq6ANExJAg/5DayswUEvNL7xfYNmS0JNIiwnrkkF26FOM3KXIimVTX/NNBk0WY3UlSzR0oRsI55J168IZ7G67uJgGnghDzw9lw2vObzRhjhn/bnY+taxNkrWTO6LmIE+h9gM1aUi9M5I0avle6BQ/WOGE65ZseMcDAVCplbUgcOtcG1ijJqALwEl+Jwjkf66iJcdW1WWnI2ZamNsFZF4gZu1AB/jijm5FGfr3rS1LWyOnxD6Fhy4c8kdWz3hRW6haV439WKhJK+be1rxujwfzeFWvD2emJrhUH/5scBRS3P5xE5sM1ojeS4lHXcLcBYb5hB02k1Cq/0lxbo/lrEvpwe1wBwxBXNq3i0jaMUBgtaD+p14J8bxmEr8YiqD2+rYjwlSeudOWAS/3PnSbm5chOMp1AB6Txm6S/efgp7pdE3AHRWTuIBnImcs9DjpWlBvS4wc9ICJczwfuv6r2Rz9sGZTJ7pDviE9d2ZZmGLfAm12RXW9VdJkUG9fDWrFMk1Z+xZIrriCsV6d+x73YqpOESOVDPVx53lRFe3gebAr7Xa+5wIusys8U38zSTfZ9sygxCRpiHuY07l+oLinYSYrZuxZyfXjglKFPg1GZDDJRY6CzAJ/wbUGa/7u1zt/coGno47WS1kdWN2TMzXYdH0jfJwUzvrab//DastnP0l1dooOPLPvPykQxY6HozsUvg8C9+8tqMjmXPrvW1lDmY85aoJu8C2MBzHj8bS5nxExCXCr/rYPT9Tx05+pC/vMqZi5skbdx911b91b99asZS23Hxp7S93caIf0RPm1b4Zh8Rl85a4ZF4blhMy7iWvFiuviDnFxlgkVXyr8OPDmYmO7a2Z7M45Ju2me2c+44kRevBRC/PWlTt6TEBexg98U/WVEo1uVMkYq0aCSTr+jeP5yA9JVh/bFcEgXbuweVt/TPFMD+7A6hK1G6PDKFp6qdV35KuWDNvSy0TlZ4waH1fc0z9Sgd5BD05ncUw3oAhjn+/YjcW9ukSL/3InrJNp3fjROUfvfxMiZ8lhTe70p1QGhKZ6pYsXYSOryUc6dOWeeWNvlXwN03w1WZMxsrYGvrwJJWGzZMt6S+gtW0+FtQi0xlaTSWAWxmSHr7GH9r1B6wIaHzQ98Er6Z/dY92auZTPyTpLtHhkcqG+/mvLR3UZscHRCMmO2ZrzEAWj1HvPBjI6dVF/NSK2R5vgcozVKW/puZbpxiYdm/YUo7bsPeDdBjthflwtqGBUxwnDYsyDW9u95oB6QMDDJgrd84MW338y9+mtJSNiamNAbh9ziDRpExuoYik9jBZJSNMV1qLH7k9Dy3e4MLBc2YG6S4zXonZqcVxJIlAcmwTFIANdP0Q5tgrgMjiLCelYHZAVjXujDClpCORZdcWfXjKdibmpmwh40o4ul4fFyP+KgnXIlgHFgKOJmUklyBZIweYzTRGk5hj03QKwkMpD5kkGQt252uqkI4GJIypprEWBcF5ZgXU5FVX0o0JMe++X8tkO50rpXc0s6IqZ0EWzsrh+51AYDPaQAFdRfUy9NYSIoDTmkgfFuIlpkGkrkK81AZbivnbFodg8m+gQJHVXt2Qij1ORvBNzk69icqxCFwtsQtfnC7mbybC4Go2lGJuNJnjH2E7ovk+66T946Bx7ovF/mPTomL/Aq/K3/rRK7QuG59FTgEYGOoPcFw50m2wQ50qutODU1rjvtbpweIwsI6H8AV7KZ9uXLTRyFJrGVW9Jyph1O25BrcvQJkT1bxTNwTTdSO8Bm7a+do4LAVg+jJzAbGK2MijGir8sTLx2nBBtjZdIWf0zdHGzNrClTt4p99eWGBXrHtfZaWNcVEwxxCN5S1nrwcqMw56TDFcyjQhAZvwWZ/CFN1Km3kZS7NS0HdZ6jVAc2UEGYuF8bcaHq1MFMfABr0TMLcIt3r9Ca3roVNSz1D4KMIfvQReP8DbpqgLXOlitxIG1Tj5ySzKMDPUckz3fKZBsOZQXBUjaWU4t74OC6HxyFjMlHluck4qNRNCrcV43l1XPQ3WApIRB3j7vCw4/VEAnmkjCaBmMMQQXQgc17btStgKDw+oPB9GxEBUSSELMcgVoRaDbc/52EjCtPRgjEx4IjKxdZAAFWkYAhArakHq2HOrxwoDx9bgqCQqgBrcvR99UDb8a4lc2KERTqwI4CGAlhH7pUexPTsiTawsMXBym74XJIPNTLmUlxcOkzmgwSC4NM04x9trIjq3loNQxkz8dbbou2MdFOUkego/YA2GW5Rpj4q2lWD+xWVyBvKe49xmZuwDTGrtGrU+vXWwBmk0i68sy0taXNfxmbXY8m63Fij4xVkU567wuyfA1WqN8WoQ+yIuoqahz61emOzck+o7te0/Ya2P5Zxmhw9e/sT668tRmsblo7eHMdOw19Wevc96Lv4fQ+/H0hwKRTQSljmWorNG3Gn5lwSbfjYkzfDoXyHhLsl4GJHx1MLG2w+3XKQb2SWnnXdOfBnoWfFKNaJQVr6JkzM1NCXC4OC4nLRJKOJ8c7j2VUkQkRjEq20aYwyREiSZ197BXncULi3FwiBnk1r8uQmD8MycgkAHXITnRACtjABDfQZuGi38pqa8uoOBSC5zy5jz37N11tic+tgTbRJCIhtSoAHCMlX6YUPO64NMB+QndakuCHOX9q9nH3/obAuHsjTSjanpTvlAavSK1fr334QvNDAiQjAn7gC9lti0kJg5jMDhmljQV5vhL6gxP1ehWKOfihFKEX+sKpZIGqOMRIvpJRn+pEa5qP1Ytn3k1g5G36cb6Jn6zIIiJ4pmjfyqSF+RJ52Tcp9sh49PL3J4Zrysj6dSrkqfnVn7lbxSXsQCQy86a8jtUXF3NXyG82D+MPjPF+wVRvXWcvOirS0gHDV9o1oB2ObpV1mzvcDZ8ZfidbUP0hGwxd0KIaTg5GM9gN5O+Nxnm/P4hwA5iYCbRz789Z7LRkLSKxibSSXwBEm5IlwG/EBh4XVBSPTJEnQhycB88l2C+Vck0Y0B/rsBAiPJxY8EYqUr9vjZZlVkx617xxgN7zhD9oSGck8bzt20E6Ad7nz13zMvz06Nv+LN96u33qlWT3yiOZmFSF25MDTh9T1iWaDSLeJf/z801Tkea/yhvYKpUmRt4BA5oHNg6q0m6gxOyK30661993p5fSKXk63qEBv0l32QJYsWQq4t4V7dbEnh3cPsp+Qhk8+97fM+IDtTMprlYTnVVTGFiWqYEDOJpW0kQlp2EZl0zGhprz6cjonua9p4AhkhpjhCq3uFy8zAFJvPuQxUbvKiiHRUqSlaencnd9fGSVAaOFmICDiCKYObJgcXlj2WmNbNQUloIbengrMpvDvyLZqVU6+Mx6bguccL6Ua1nEK6IP3e+RgLvdrP0Y/Gt2yrA7nujrTXHNSqiK9CROGc7GuSxuTwGszyxnkBU5BVtqwYOIrMS0ex/Aa596dUnNNwnWUkPbarQ+ACtNIH5A6OqLXBIa9hO4fTYNtOghFoU9XZt0GFvvZ7rrWvw/zV7JAYVEP/iZr/zH67GhGGGR83Zn6wNmqZCw4wLogxgR1b6sUwQwOhmD4gpO0bPr4kWfy3tLKAKZIVKszk3OVsZGm/W6nPvMRu7aYg80SI8kW+o1p0uomTj8ImsgO2wxoP2awCeMRJsAJ9+14awogKIkBiP9APDwQiKcIDA8pDHZb1jCIe3L7Q4RYEiP/Fvy4pJo6x0EizzFF3KBGP4lXEih+1I02NX2kOpbtPXorbC32XFmeXHMLejZLxpPM2cbtkbWZSqfz8UgpTilv1NDmyT1LQmrhulBYU1EcRAyjUdumptKcyVML13cguBhPnFKIrAIWVEYO6NRFWgGwBc2QawCm6lZ5qgnnKjB0fwst65x7Xfi+I+sehmZusJnLvOHxOsnWLs/J2fGkdnfoIdmW59kZDf+fHH75Xy719+OaN8UJALC6ShqtkZqr9hUec77xPLRDIPdRF00puMrZ7CxZPteB4qWtddfjrVutx+kLs3nI3b74roa0i77HlNyc76m4k3m9/fo380L3hbzblOBrYySUup3m/g7vh5ADr+vdkRf0WZrLV7jYlm8pBgdP6PENk7P3jgCfO7O3cwYKw7lamem42IWpnVZeJ05LjuUhNWLrgKY5DlbHVqnyAD3Hq2fMjFy1XNZtPBLzKn67fYXRhBKuiXbmFTZC8V6ZWMn7C/b/qphVnlSq4mTuaTYGGwPT516oX0C2gx3oeegC784DvWSRL9HMn089LD+WgWl+Gp+WT2nQeOGp4WS0mJ3sGtkuaxtnj/bIzr4wGQkWVdwYahi5Z+8b3Hvjsm8c/cZkOkVqzwTcOWpHVBgYr1kwljJ5+2f9ej0AIFgZa/8Yw+gdSzM+zdkoY43aJ57vVKWWpl2FG1s4DyuBopGYt7lIElofL6EgPqVh7nfHXU8qYXtKInme+v6HS7GpR3F0FrYOXoJpfvJB07CjAbCBFfb16TdrN9RBKU/xNnDe2F9MJBv5MaSe3MWZrhf9ut1/BoUZLTtWWblyHZhZ0Zn5Z3onYXZ/KvfdN7q3cjt7pfWciE7+KcCuDhy9s9fPf9siMaY500wPC+3CLnJjoKX9NKjo7J7sqTrtvivvdj/XfVPenD3qTnpDWupPbxZGEMhUB15u3qw4E2Z7oLkC0CjDIYHjSZJveCVyDNWMZ5+GQafhstncNZ/63+DGTAi0AragwIyXjKk4j+jYygBiAagcyx6qpeZsorsb2cjd+ke6z8lzsw/YPTyA4Ok/re4I6AcFXG4+L4RbeUSZZousyTg7NDUCipy9XMw0TXl+a2Mqqt2DHGbPsoO7VONqiS9T+Bpyn5wqCRS6uU3oV4YwhB+BPwpmBPL3rbZV6tRvPH0MGZDRhjBYK9BrYQSHu62CIq9RXsqk49AXnhJW632lDwDaxmdB5kUIJ26vUv0kKW2KZMde8UqezUNJqhF1y5PE7H3rPIAPHrbsmaGArDLjfp5AkyGvTPr4Xx5Vel0ObxhhTsdbZ/utrW+AgPW+/9C04B1SGkXWbHg0I22K/EmrBSRkbSUqzXEQodrS86l55E1r6hy2CpbztsoEWQoiS43XoqD4Rh+aEe62It3Zyb3dm1tgNMMQ6wdl9dIckDnTx+8GPeusv2OUN2FEycbc1HBYryfjVNIAAjvBahr3LhmBNMPIMJoEzWl/h1iQLpy3JEhkQ3SJ8wgOJAMMCI60MLtk0XG9VXTl2CzwsAIx6/S+7ETkFCk+iUQ4dDuZCsytjNHgusE0rpGmXV6ulSJZWN4NmI83KjncnuEkXpIuVpQA9Qzlco8ESoqMgMrClygAFQqrL4xS2ZkUOItRyu+lkvjtGi5vqybb6txvJ5cJpSIcB1AUeW+msyCJZdawGvYHzK73eijrbQAxnmVNmObLwb727KfYJb8R4vvSxl+1WWNMsG9AIAbzlP04wlO7ZIRvIh2chmgTgmno89D5DAsyQZclh2Z1tp+7948Zxzi3Cubpi1u7sKPAUKOUGWRYk8swHfqPL4c8glKBiW3R32J9KLoxTLytXfuXalq9Qz/pYfw1yx+aD87BJatmZnL6ewzwK0PlJwD8aNXwqFz2dgEAFeJx9UyyYmYywAAfg9srVSaychCRdU5cz8BM4k4KY7IaIrPZh665lcV25kqQL12nsB9G610bdK7p9OyNa1kfb50lrsWRS7d/INJcVZecSI4i1hMHW23mk0Hg56uoJtxVgZ2mdpSGMFJ78E3L/P4ITK9I6ZxRep4TwqPHS8dy/lQ2UYozFL7J/S4X9WhD3rGrD7pYGh6gTgnq6tk3r3L99eLIfb5ZbC4+5EnqqzzOV0uMWY+uTSddJQGJNtgGNIq1WB/SqayB0/i0XLB4qHI5PHdp7Rm096Fma9pJui/nzzzjEXGIzwaOZ95imAHbgedkZRR2mdCOVc+FH2pJ9/z1J4cP+3Sm4LLsZUJeXKe0j89fztWMT/B87j4Ys9iymPdD2Eg2djGpBeczrpyiJYnu6R6wREndIzyhtx08fCFflnhNMaeS9/5FbhyaPviNmdEXmsN+PNlKOdxA1hNXiPVN1hv8XbBL9muQk/OihMS5H9P1sTxTAunGA+Yd++lOQHPkGSU62qT0u+GoCBAa/juKkyfMnfgFWGZjNr4rdmgPKXX7DUxSmnUzcATowm47yg6ELNKx0N8rbYTl2FSbaXNt/3Sms8ThT0i0BC3s4AJD5MxTGWHCJbzpRO6rGtu27Tfj0fYoDK6NA+a6uX7ze5I+dYrrWCoQr4wrophk+ZiEmGWNVBKUFjoHX4ah+rNXtPAKjutT+17d4cKDnI9HRS8A7OOJIZzk9J1bpBHCmTKYENLwkNAY7N15sxdzVFEE+TDv4JcxOzUHpZxSym9XHyzh56Y19WmR+jiUpIe4Z+eRWrVepqNHF0f3yu7gw1Ksq71jwyzLRlm2TbCpNtPy7N/u/MNJWmmrarXsnvcf2qPIJIzO4HW9iHtnwy5l8BDrKOy0c9cYolP9zIpyx/a6DsCaHGYwIwHdjtxu5M62XXy4y5NkOhp3dfsBb3/M++ZRH3Gus/CGi22srb9bUQxRLQUzY+YC4xnfCj4NhhTxpE+c6RmsskhWkkUsNukn6exqJ6lJ4honakZ9UyDIBGc+QJFJ2tCOgfspzfE6o65nTyrbZECcxuxAbdQ6vWK+ka3hjQJEicppR7M+lil9/oHok1wWXbkdWfxKyn5bG0gym7umiA4fWa/4CqkV2UrvTtHIcajPkdck+VigZpOLM9DKeoxr7fFzBQeLaD5YTMdNBnUAXZx0Ka8uZVPh358MwqHQjVeLCBAGGe/ICWcoHU62jinVsjUcJFWrHhZiVFpGK7qc0WMAa714JFh8cZfQ59SOy5psLjxoZsfqptl7dPIyMSrVQwhKCMEyP1Oe69a7pY1m6hmTPjrpY7icSF/GmJElFjozOxEeFO6s7gjvhH0tiTAME+KqiuebRzcjhdd4l4+WEfV6lanIC6JI9E9d5703yhazfqL/Z+sMmE402dqSfyv+az7piJAgQ08X02zlDd7jAp837y+snWWiWbociilQsMmZs+GcCw7c6Pavy7ecLnkxBRqKzjY9v93piC9x60J7tZrT0/Qy3RpInZeDpc2XbSlXUlKzZMeeIzfc/fVcfnLqZ9SfT3ZNPGaogYIMLCPg/YU6c52DTx8tYA5TXIJN5hzIuVnHrU14NgUp3gzTBx1Kskptqc8UTA7eAXT1dYlASbjarYfsaCo+BkzO7rGA8kkxbHTfIjPQAh1x3z5jDGFEpIukrwXwe1BT1vpPSlzTvf5CG2GOrSn9DLdq1jeop+qp6KWXllT9YwLolEHlUd7o5+8+TX6WNpaUlPTENVdT9DTcXt3c9vjrpGuQ4TuhPifsj3CPpw8MFgz0fqq91tiSars2amTAPu7gsdF1Anj6R0NXAu2rRyD+2ivrxt47JMZr30R8RCavPrsvrc5j6A5swQ/vq0YTPwVZX2ox3hH9c9WY41kyYmSGhXoPOlCqIK/0kWKbVDg+l9iFhZGGO8SPSMMvFjfk9MuPhvdbGv20OyNh3WAMAACJ/FkaKCVvVpVn7IB12XG9yzICdCkDBgoAu+rWjK4vdCKSsCPjmZG/zpi6wkBDwFTA2a0FRkytXjGpOgdhQQEA0XxwPOE2wavr6xwDvMQP4gN8lBnVvHs8Ub4yZrU6sHgLACz8blcNEBhkwadQFCQMVPa4EBonmuFBnKEeFBR1r9Ag4ZGs3hwLQnhBOR4xImsFyTjltUxmfEN+aNQST3YUfxlhcnZ/oKhAVEhMf4O66Ot/+J1Fr/4Lnt/0rk/Tijfu9Bx55pvRt1k9HFIzlZqI7suCa4hBw7XFnYDAh07l5yIWfsbVdwBYCom/U+Q9rXaEGEYGlU+PblfCJyKig1fx61MJToWQiIioQgIHjodf/AZVzcNQUFCnGSYXY6wmWXH+QvxN8pf8J1/n0ynTmAIA2r/OCVqZekoJnOepwwoNDX2i07ug3jd65sp01OwYf9JPjw/e+Bpa/NvZ6kZ8Jkyp3rnwtCz96i/DaXOIEek48HQ9KiAPiYYMCgLpx4EKajabp5hoPgUqBCC+Bm9L+TCbzqjK9um4M+ugYxZJNWgkJCQ+lf6iyQIkzgxa6nCsseDoBxn1Ttm/lQOUgkVeWaqSh9RYkqrz0FUAQlsAcd03NwoOeKdutpXPRgg/Hq2WvuCoiECyFeBd4NHBlLs8lED43lWshh1Yz2EGbHngVVAqfnas/w0XWeS+IpwqbaXAJ/x/VWWA4M0WllUQpmWT5j+/r03+vxoJlKbMw6fYkQNP8zaPpmwV+QXn8a25djQspN7AIEP4NIaBAT36nl6G7n6iLkQcXw8HBwcHGjRo/k7z861bY3P1NqPowek4cgkICAhgwYJVdaZju/7FNjZ4xhZ90odgx/YTt0udf/uJjfz5cKcniY2NjQ0VKlQX+wmL5YEin7l8xu254gL8TNBifvjqp660gHiyMipX2E2uhpdWcRt13XSqRxdf731qAbCBfpqQpq5cAlX1MpwEYA5U2iFfST+urI724Y9HsJ2j6OhXrgqtaoall/o62aAqRI6GHbL0jDxA5KyaFMhix0AL65M3/aJ+w0gLjitWSD4WvhBSxrpHFJxZSBPjzN8LT/yUW/VXWlwx41lfAUlt81n9pkdBVGqLaBEj2vAxaMXHoQsTAiPUr9yy765AS4JWA1elAXxUdM/jQ1RCpnrF4YgOOnPCQ6/InfzqvUf3OVefb8fw/SZD9UR/15u9fSgqFCPScbhB3cE9YBKjLKOcW3Sii1VyLDpw7l+FwPZL0lBmI8b09D6X4TAuRyCaqkhwr/8RHJjVqFyJ8TNm/1qmPuFstPe2O9VvP/hEYD2vyEI291cW/zSU+3PFrud6TYKYfE7akyNdAwcfI43qubEXiQ3O6nK7owdPuS+HZE35xFlY1V3VE0SolSSh3otqHe/swbUb5F2pXZ0rjlc/qLVZ43mp3l2+WrizfRe/a7QLDRNQJ2iOUepy0Y7TM41BIRwUXBQFkF25vm3UIM/dJ0MHOdEbNw/p7h2Ko3n+tGyMSMeBp3mbR3w737/gb4hZV/SXmZWOprurzEGOHDlyxFKd5cSJEyfs977V7knJCd3wF19P2khl7xlhidb/uF0tTaTddPbzF85WDp944IySbxGtNC8q4Db+4ZmCxPontR7nJakGFuyMfww3QScq/NNqFn6fCEh5OetUrhgJe0mw75gtxeqSQDGVUwaFiaqqYPYLTEdoyhBzZRoztbo4C4gculs0/rU9M7hFDcWyFcnIGLlK4FAhkc2dOBA67rsF53MxW6zEVL8iq7oDNqxf/V56X27aAg9iVFmUnTw6Ayhx78vX0yb801UOzMoBSxxPtARSjLyTWS0mBLGTbZ6s6SqaKQPRdoFGwuNWYlmX/cJK4D3eKA2wlY298k4HEY9phTfgkZXUo4Zd+fmAt926PHgbLb6qJcoTuLa/iaHChU+v2jklXsg3ehgLBs5BP1Jr6YL3EjbTmJC8YGT2xKGPldYc/Iu3SxsAHt4sRBT2aOcQJlHdYfUoiyb8UgsrJkil02XIhOllK6TLLoKtlJnxu0DpEJLPkGyjIWpWrb1WgEr6Xz3G6DG1oXYaSGG6rIDYMTnU3GMSIQWFX4+a1bjTo1vtDqz6LqFWs4NDj9WLlN6TuHu6zIkHAVDpgf2SV7w2B5n/EyeC+guALU+nhADAtvuKD68bTX7lPWsAIBUYAAiQfn/wpcmVnxfEdFUg/vPVQUlaoWDaf/sOPYFVSNj98NZUoJIHyH+KXuzqiFp7NE+POAQ5dX22bsIT2r1RRwhhKOpmCT/Ac73oRwihAagbKxD0U3F7j2OQsCrVjlXJfyszZj8hWf0JzaW1K7JeZXmPYtYoB+D6IAF4H/+qNTgCIlkD8p7asIitj1vG0mc5mGfjoMuCSly59eDZR7L2o/mziayBmlwxZ/MKHy0PofwT08kPQsjPeh/T4x+AwJ/NNE3Ir0ZKbrrjOtR6VRrX3lj+bHi59Hhsx9eaAPRjkEzyI2JiylrnR9HVB61tc7AbX909Ho+eTV4P0Yxn9SZOSY+30Bp5fFjJRvsDamz8tZxEX/JxMjip6nG0xFk6tnf2aIkjhD3H1Duo5Ygm9apG7Edzov4DVxNzjYnJEkzEimVgnZWjvcZOiFyTgSbOgli80HOu/gHIJKfX7CZQSYgOTngooZFiR3RbKuSgkYLxBsjy6vvPpgCqWmJCgGoR4ITW7qYHOq0pl2dDTIhAtQhwQifkpk0s2GlijYG3Wkd12a+Q52qPA24GP3qSzaYnZn1tdYbgU3taTUsgG7GxXX5XrZKBWtubAKvA/fupANDUc3ayHMQjkUEf1l1FfPav/cuAeEz/VPAIVM9kLFF4JJNeMIAoL08fZABRFuJzJHm25uUkfVthBX5wiUhTiluAWMKiq6o4Au7zPaKx5ms2Ffcf1BoizYFggV2GHoO+kTIMVfHvyn9UlGRzwKx4jAA5lsYGxAEN6j2KXRrz9yqheghUyO9X4E3oQvUdCxCQRHZ2O/qyDGXyaU9gEmlUQt7JDDJ00doQAJm5P77v/a9leH8rkfXiskBpJxLysMZgKEGtdVA1BBAxpF2tpdKz/Ir5LYj+jfNp2Id545S7TzAiAJxGn1xf/+aCrTgBsjQH6etk7UZCrbo94YwMkPeGAGlXWxA8t4QB/zpSTNZRREuadvCH+nAaoGx1r3dECvb2AODpaLx36qMLvp9EgDwQTabie160Z0o8RhexWr9p9G/Wb5yMWUYKQq5Z92IRKeacNLff69ui1Zj2qreVuACIHUX1d2e1Cns6bz1WO77F7fTxUuntFdn0kvo75GPIxgEECEoKsVEGLBAg8DEGchpU/kwKF3//Ai8CANOj+8sTENRgnoARF3gCBU3REwgmGLfQSLd4AoM+wyiu24AL+fwOPZjZ9pHezvFyOUafVejwjtdGvJmo+weyf0lr9mzsdcBh11zgz5GbG7zt4cXNWZedo+2IC9zdco0bL04u8GoUb57dptCj09H1bTJFM+V7dpbSPhQ2L/mxZUe+3vFV4kvpfAm2JHzjgN+E3X+fQKF/b2CKEnyD8xLrfMhda1fK29j7wl244ALnG+78ygz/WwN7FXOvsKCEay4JBihIJBARo5dPGi5uoxilKMuyXbaFUP7SJnPx8drWDK7Yxx00N+MRz3jFOz6A5iy/+BOarQnSLVcm9yDn2axEqrVVnidHdZ6dkUzCNpctwp2X4IeX1HULn8M1bbNfRdhzRiOOrN15v1OXeuK2panq29IOQK86kEGmeJWxjEO8Kfy2ynxSNHQxYJzhi2MSYpx2etPHvOXY5ZQXl4eq2KOyKnL0BhpqQrlL+NFVjXzjjHVc2ONe47iqleSbUX1zDkLNt4ZjnG451nThmte16YKHntTvbB9vAbstAe50hkaO4N/ZTEOB0PYnhgvOKYj6lj0zymif+0K2A9xmvL8botTJ6JJ3KMVU00w3w0zfmIV9trwDRONPKGnZSnWuUq5agSd/7wao9fxT6821ittTrleH7GgohqYE69yCrNA0l0YVJCwueF/5BUJIpemGadmO6/mqpmPDtGzH9fwgjOIkzfKirOqmHU+ms66fL5ar9WbYzjBwOsuAcj5jqjyW443PWOrxUdV0w7Rsx/X8IIziJM3ymQZOZxtQJmh8Kc/174+nBxp/74KLoBhOkBTNsBwviJKsqJpumJYNHNfzgzCKkzTLi7Kqm7brh9F4Mp3NF8vVerPdASA7uiCCYnhW6uHAcrzwtMk3rIGkD0/Tsh3X84MwipM0y4uyqpu2m0EQOrJztmfd9uO8bq50k9pg3XlmB4UgCBrBIFgEh4ggeEQUISBiiDhCREhUGh1mMFlszpgEsDnht3bOnNu7cOngyApSwsbOwcmllFsZDy+fcn4BQSFhEVEVYors4NVq1Iqrk1DPnMZJpzZu0Wq3367DHJ3HsVuPXn36txqGGmJHLGbMuAmTuGrXb+MtMBYmw0yYT5DI3OrONTqDyZoCiF0PNg6GXHCxXKrnPDyu6sx8zoVll7k6y/ca/PJ704XQpNmz7d4664Lr0dyXZSg8uhZQ7V9X3LwF/wktWnIX/BoN6BEjL/7JjFHVdGyYlu24nh+EUZykWV6UVd2048l01vXzxXK13gzb3dn5/uLycARACEZQDCdIimZYjhdESVZUTTdMy3Zczw/CKE7SLC/Kqm7arh/GaV7WbT/Oy/V2fzy/fvsOwQiK4QRJ0QzL8YIoyYqq6YZp2cBxPT8IozhJs7woq7ppu34YjSfT2XyxXK032x0AQjCCYjhBUjTDcrwgSrKiarphWrbjen4QRnGSZnlRVnXTdv0wTvOybvtxXvfz/pIGQtFZAFkZbEx2Dk4ubh5e/0f7QnEKcNozs4tXuk17I/D/fHVsCNaBFhzG5rX++X9C+t/5uDg8Gov50enVqKTGoK/yXqJZ4v2fDok/wUiiEAjBdX7tyX/G/psd8ns4JnRv5C9RUmTxVy2/VptcGR2ID27mT8z8r1vhaRYWW5Tio3GdPvpLNyx2q7tB+LlU/Br10qmo4koqvcN/KeGwaloei0fPk/OLlbx6remFnDv+vPJ4/tHeC2wod/s9NK1gxlkTiiXlZSV8NH8OSXLwEvVfPqnqczpcdJ5WzR8iKZeKFqr38jpL8oh+YicHL9P9mY7gh1M/VzSHAHPUXuDGcUgiB224YQBWKFWtMC/BJbfOfb2ge/H2H4UscrHRqM6BJ1NqKAUEWHKaCaNgdiqp1BA0yIJe4CAtmpoaBe6QBllaitoGs6lgRpaajFXgxknkoEXIJCjiOI5fvwu/beI+qPQR14IgUAAGL/Fh+reIKo/3jX+sWF3yVss1OfRA1JMpTs1qZx9z7S35Ln7HoVNJpRXM2An0PtbpHF4SPB9oSmjMdfD6munmmKieHseQKfrLRrYOmex8V/3V+7UhZYTVYHaMAodE1v5tOVrZkg2RnjbfoKACb7Qn1UaHbLO2KS1AVaVC4Ty9lkGDPUmUFWytgKFyRTK6wl6n2MA8/MDRNbbU8CMlNy7qEArcBXnb/ewkuCAwBCrMqCAFL86D+9i3Os3ZvEpYyzkLicoRPin5AcwTOgAgUh/2Ue8TqYGEjjpIl3O62CUXciqupFLApyvtK+1xoUoPCX55K/tw2J7f6iIWCG5fQJlA5anLSEIDY8sOewus6Iv27aXp4VFfDpdhH4pj8T7/UVTbLxp+XWOB0PCx56UvwNPqFwua8mCqm8iGzv2u9jjGFMzdXzyhshWo+8V5JobAXVsDvJS9JHDHScFKzdnjSePxKGkE7jgOSZ0orQR6sY3AdxgEtGR+kEYwBys1Z88nDiGijUbgjpOCLsxgrPhRAkd6q+9XSbnFQyNRmLJrnDENRG+j6Etihk19ptu4WFB6RleZawsLbDXpSLsANFeUnJzQghNT+ND9FVIVg5SyrN6AaVf0ZgetaXvEV5Wk3Iqg5qi9wB3HIQnrYB4oFIzGAHCpL1GC9gbpyNHyaE5r4mcbmRgG5BfHQ0lPbTaMHl3SDrrYYauoDcFVrttKfl8NWxbc6l4hceRa6bgPIpkz0QxZMClFGH9DlUZCDNmXoW81tcVod+YItnTY3pfuu1TpMWGxnGuXdqrJ0/XKXiaelzl/unI4ZtH97FST5/mq4jlBZhYzC2anGlvOeQmrXLk/MltUSweFYpeAM+6XKr0CKO6jpFa9wiXdZ9PTEJJpk2M3ephnV5ninzD4h+OQ1FRU8IKiC7lzmhYX0ghiKZ5BOkxDunVZDuabqqDpiVpcHIcagsa8khsWhAK80d6VprpppXgR/pAYCoJGg+nB4P5irfXVrLzOJlO6RNsyOF9VpSv6TXMDX/i93xN+FVVswk5KeayM5BGloDXWt0h1qp3JEauFLpA+rbEXzE7FJmTJbohDUtBa0CAoMNHySOyNdyG3t2skYEnd0kdlEBGUHl/OPguO45DkVGxCluRR9piQ2r7Z+7P2gMlPrQwiOC+yQTBPpgG3f9HRwjnVn+ShBc8l62xxSqPL1zsDqy7ZlZDkGMiS0iYyDeYjh3HFxwOLUOJB31sohShHD5wvzxK/5arH0jD69wgWWVtcAk2ZKpGXu5847ELztpqXsOKJrVt/dCwxKpJDu0wlpxc0ZZwbOByiPidF+pP0zXaryARpXVUBgsBFN0Nfk7VNFxlPulrfyHtNl1OE95+QWFD/HF3JV+eCzyTure0G3aYClS76Y0RfUfVXLnmopHqdlXDQHFg76QZFc/Dcy3yN9DcT3QB9jouvDVsHMuhocfursa+oaZMpTWa+FxrHJ/Wcj8biKWobzI4hmNc6JVxb+dAhxPHx7HCwirZ/L6pEteF/6Xyr4ZnvnJU1WF5eO/9SigoCzWZc4nxgno8ur+Y5eHenV/mZ9Yzo3LXi6xzRqByCGckvQ3eEqWtGJ8QURzqp7P/BmawdMmLlR61HSisJ9zu0uxJu8A705B3pSc9xlF6iW68yIgO96lijDiJX0nKGRCN5QY13xCcDikVLr9WLrHgstsaiQcjeRErnObSdOvMeJu+acZ3rkSsBADTJYlGFEoCEcwPKxYw4VpR4AIhm8lx05rt0IUPqOwDdJTmTFyGLkGRpQYteKoaAzOVC2e1NjxcSDwAyXJxiwZp5RBCds7XWrFbd+92l1f/X7uPhydFYLE+fTSd+brhRQCxQ3V6TMAoMa1KDCC2/SppHuhx6r9NS11VXTdsBdOjQQRqrsRqrZLGIRSxMXYQuQhehpi0Ci8AiYPZ4jddYvXaAeMRDB7vgCrrKlLLokDliFTz6LcfB/I4p9uGoFUM7xjhtxdSOuYbSS1oWYg94ILk0oCg1hdmrJ7clw64HVFa38nej9DMk+7gnvb3vWXV48j1RvFvJxtGmUcJR/pMyWPHF5lcCcMGH/EjY7/4pSzyAxS2/epC5HGjl1M45k6Y7fjEus9cfeVvdK57w69XF7kffNv4/NxgBo5RWk5y9kU2JrkAtMea1oI8C2FZSRMkUhb1UtHrooQVlKk2BMMfoRK3lCBKspKlh/dnlWVNf68XZ9+Wz+YTz1Re119dXJ9+dT/4Zl09jGsMniPRwtw9VPtloo9pwT39R8uhaqPzcgJkcH3QtzG0sMzOUhJQKBzNjg7ERFy1qLerXJRhxQVdncTmqBI4dMoBaS2H/l3v9YvaNELtyrxrVP5yigeYF7PK5lqEefjhqVjvl5bz/rHG+XC9GTcYsF3DlwXPxjl1hLoZXS3TiUSroqm2FzvqOOm5p9RWH8aH4LjOndhcP5NOupS/Hp5+GYlVvPglqL/hXCBN9Myl9Ls/OukT0Bf0Mo6WssBM70KzHrV5+EzyzL18xCe0Bg01PQKGYtWF8qBLqBXyNsREbsUGBM4mkpgDGp1uIdfEjd1Sx0qq5XUssanjw1ePhSSZMnlrho1p4fxhn2au4/2PXL/mI3ZLkhe9hh5eXI/lFcY58mU4iIa1PHm6WR74XhZnvciqvaHoSs5q4iEqus0lMSbkOAcx0zuZgypFFZHJ2M19ckdx8yy3yZdb7TeWHEhbqw9Qf2MK5eDlpL/73HZ+sr/hKY/HF+JdCOXmKflf277EvHJK4dK2YI2/zadjEs8Uc4h3+KzMdy4VgBAUYXsT8AoFIIlOoIFTwPCp7ZYSbeu7OXOfReSGVFOu/FS09NYJRtlHIIJ/vprr7a8ZtU4vr0ViohBnG4UIwzbA45eql5ptnBPJ83DmZ/7tYiVLAJcVXg8KPhjeLUR5cr17hVGS9tKPdpNyH3M3qK2mEyfWU4aJ8/H9/3VNZToJ9tHantIG+3jn3Qc9Mkr2JtgSBcNTeE4XJu49LFyXBvr7Y7fcm1meh0B6/3ZDZSNBoPit0lPsjVaygc+P1TXxfcqiMV9dXryLRK5pqOjmUtJmX4J4+/xaQ2cX8gXrOTlvdkPFHublOTH6sjf16cTdiymZ0eCD1qQgRhhAcDeQKp5T5AX/Ouf++6vZYz8uEV4GpIWHVISXHYe6whup7L7ueSm1L7kRdo3aiih4FAPl13rd5meG7/fXi4rHtkVURbHEtHD0envzbhjC8Tlot447UVS0qm+bJg/LBYmdmpoc/1o4ECh2ZZDWV6nor38qZKN+hDDzZl/fj7jGd5u4zgZjVVvhW2T+Xh4eXRSAW/rZp434sLxozbiV1q0KGrV605KByWffa8u/Tj+pDUWv07lEhMULFbTULpR5KUcVGqUf+GCe9obz6g3HrVqoFCB2IF8pIl69Y5/hiHaW63sq3Y2ajmpdnslx9Nd9GEmdTxCMShAtM9A1ur+6v67A5jTfe19jZonkve767/XqwXvkB334BYZQqg2cONzwfR3uZOdl2SDAfgLE/JhhGZ/tc3ESCynY9q4RGwQIAd/7S+YnBREwXgtmOtBohTdjG/AXheTZalcmPjpzp1cKuSS9x0qujt4rykTArJV8YN+0pxRYU42a8oYwRtoq11ErYoJDHuWf69X0zhqK8b9DAS+9hIEfwk9+6ZTtIoKioFrOpNgM5ks+qqmarhVCd7KErXUM39MaiInWN7HQKHstRPK4oWBLAavQyJX+rNIOpjAMJebrHGC30hoC9WFl1G6NZ/G1eRcYc2NL8sYPDHoBdr1TEIxbir6RtP7YH+wtG6fyzxwvv4HT+oLio9AhADtIB7CP5eQA=",
    "plex-latin-400.woff2": "d09GMgABAAAAAErcABEAAAAA1rwAAEp4AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAb7VochAIGYACEUAhSCYJzERAKgpIAgfUUC4QQAAE2AiQDiBwEIAWDdgeIEQyEQhsTxTVsVxt6s6oUYDc3tAk3ht7tlISE0XwU0u1F6k/Z/39GghwyLKC7QGtV5/5FRrAcqrsio1yadKtLhY7uWsN0qwqd5eDl87qfjBWcsPmCjB1W6idFlIPFE69gl76Hdb5MEdaRmpH1BljJFGnxicRfJHm+urWEXHLkLe87Nv1lfNw5AxH90wlmIxEydvN4E5J5yqnJFhF0iOwIRGJZdzgD20b+JCcv8c/7F1Xnvt/dA6BnTWRgBDBlLmQbIptwIfb/edrm+3dH2fkJo0CxGbPADoyqRQWLClziglUHsTUDtM1+AyysBRYhgqDQ0kJfc9QBR6mkYuWiyn27ju/9dBV+ZPodm/957cQSL+mDbX79QhtA+v+4B91zH2QmHoxJNDORALXWmQKXqFwugH3+IU72dtvd7gaD0YJIu8sgjcKA4wizwGacdP9/1bQ+CBAgQQCMaTgznMniSGN5JDkoeEPMrf2u2pCKzm6vkovOLjfbRWe9q3f3dN11dtEtJHCxe36LXjANhwFGXuq3SQQJx4OxF/eqZ+oKnF8dEYZDIvQMwucD2k6jcj5Gft/ylxZ15zoMVwdwA7SNaRuTAj8ZK/A9HhlkkEEH70B7TgCAJZOVjFvIJfDmzcw0GuMUztX/bz/zBl6SvQuzcAuTk06BpsD/pMISCY2gFoyscNnVXWFiRF0Yrn+ntivZhV3p2C4wh/GBbOWiOurVndMx2L/SbxEgBBS120krxyB+kisVFmjmHJfVkFUoNaOwz9RauxsioVkli5fAJ2E6IdGCy5nIy8r/2dTaGSljJywfANTYhqiiqjv4O1pZqx2tLJllZU2kvHurDZkO1nLyBCEGmdfBI+Tq0h1BdenuiqZLecDwfF1M7/7r09HOh00jeweWYdY0e9ESFHB0hvHw/1fjfwboeiDhB0txW14Lr8eHozDUgLYNMByjQDn/P1P7TPtWoQly7fSCEGRcqz/PGWrlg4iDMTLWBiHw+jX6FwqFosEa/B58SlrLwaHmcMway0KhZ0A0vvWpnImMs9FGXxuuMoVKlblQWbyhYqW5gjiX7+/3ljdBad9iuhMySJFS6pz//X3txNIqXtvtT/bdviMcwQThCSGEEMIYoz6Hv+lzSWg6U0pLkNE0HDJySMV5+jW7xpQak/taE7+ZdAsoCF2WJnx/RwowA4DCRDGGmAqDyMkR5tkB6aOCHHUVct1tyB96aBAwja845H4HpOSA1Y/Oikqw+l3R3QpWKECvLyCIS8/vbAWr/y4BTHYeBODhqBqjo4BgQjUl90L5jpHwlmReBtM9vfPakkg0gbiDxB5jNJGnPrywUpbSFKTzP5Sfvvvotafuu+mys4577ZDXUfZR2OKndVFWWGFRveaaa7qJRvtvqNe6odqmJqDs8KllHXlyPionw4qWRrTKs2zjA/Y26HE0qxizDmfHo9MkYO8Ybc6Oc4Bz2ZytOIZtY5/pbfv4vfk/bvmLjmXxeXpQxtzCdixh/H6Zx/LZNAp7TCssZsHrLxRKgikqAEMIs1nmBoyQzNiethfGxBJL8a0GfxsE2EZoRx7oMJUgR4W4LNTVw8PQgEWPKwSadg2Gqqbb7E1fkQv9LhPE0p+AAiu+HAYDXwKQ344SpFCCpsjKISOuAPqL8O3CaaFQjuQKzDNvtKfWDAJQvjStJv4mhrI0t1RAhy6swiDbbv0GibbB/KVL0wAzlXGzEEvaBPFiOfdpshNakDIFDH16W2TAB6En+LoMbn/1o025ktNO67XR+rlWJiNNe1q0zRAQl2WtwrcCKG+Ff0ytlTMRSRAIq8O6vVxrgdetTnsrDdLKBY/xETVx0YY0KIIoAgCwZtdVb1ZgbnF+P7hPhHiJBWCczFMAOSICGhWGHM1V1NNPXD3VJ2+Gka+k1YF0JZnxZzO1WqVilUFK7M67ix+aXGmhfxMiIoBOPC4jNLpk8bsbZi8Y3b8UEekiJ3A3YkiPvKt5ZSeLF4KSMeZnND8wi8kxLmMLXprpFsJESW0VwMzmHzpt9s16zTXVbgNwUHgn0a/PRByEKTyP6d6439mWm9qEjjEBn6r8waekZkz0N38zr/JSPLgRPVfKJOXR/FUHDDFMOZXiPgFvA9aGCKZR0r8fRmnFsohAgam1Ug1Ep+PkoaxsMdA11P5OnW+2Ul3eYM8sE7Te/nRhn6LAuX3IneV5vHHYcbXZ3kUIZJW0bmGsKt+cEUdzyrONAM1a9mycYw0mCilS+Pds7SdnezJyofHFDkmoGoa4WSKaiVH6ceL5hhrq84WjEve9IfV6hN8VmqkUNfHAYrQrS7pwImX6cZUzKip1F4ImhXEkenY0QkV+QwvVQsChEVpCkJkm0JR2ZPcS6tsQvlnpZAQgoDybGASQx6um0hgbVdzj8j2IDazXrX/fh9j1bytXAmdRo884lbpmkyq2YwIIF15uda7ZlqjsRQm0rDrJJFTOHG6aJ+AvjM0msUqiawkiiJF8se5v7RfnV+uXQlpISoW+0eM+RGHeKvvtwyh2Eom0xPdOt2uZUmvubSaSt/PHLw0A+ZFXmhVMDuZIZ8tSgU9QxPBbjm8ysGB+lMmfNsLe/fgiOrUuqc/SRiJO0zS2rSt5xphkfwdjVnN2t/Lr88DS83sRljdcoMZXvepkAMrJljRO3kZr+AE+/6SjPXioIZnHzRAOIOlOgEsI0+vDqXJUS72WPNFR5sbVM3m9RWoh+otH5a0oPY+xRR+FU4I3DsjKqgSdkYYNGtHcs1PBR8UsctrkaBPcDWbYMEI5/I/r/4nbXtcu2UPbBaNGydzY8xHToH7qKmaU4BmxCcfvW93rnw4zx72UKNwYxhlI4ZtRBOiTl3Wv9CrmHaOqkSFEB5Wfe35fW1YqEwfFTebQZJAB/c1sqxQDtVS2LzY2kOIwnXWKmXGQet9BfhWM6aAbVFI9kAeZ+mSVZCJ08yk0az/ClPA6fSxtnbeTaCJ/Cwp8VRvoB4SVPBqeKwqQNBB9j+0mSlG5ZRNJrqyJdYRFgDtdnoWR+6YHUaDj9IdKQT2C7vzWCUGExO7FJ0+PNIDwRLLR0n0AfTmXoGDgczyedJpdvXqQqME8CZivM8XtA6RUDJODfEsPQG7215KKjtC3yQILLAv18sOH6dX+nvBE1Eq6lTnsV27E36lyp3imRm5/IC7vk0WDpKjbZilsoSj4LTKg34D9gHCv+LdwJc0BDnrtU2C30ZukRnD1qQQI7sD8f4cTTrbC3Vy/M4tKHR74KGg0hZe26xnnrg74KlKUSlhKDmtlpgH9aGLvF0IplTDHtQHYfhN43BGZkpMX5Bfa31UqhdcZIhhajHttcJGVzGyzTKIs3sHALnfIFuWt014ezBiwfAX5+C5a2U1U/9dZ61dZ9XPPk+98hx935f8WKmkiBAVgSGG5XKhUizQGUq1WYWymtLTU6Kz17do1trFnktjSZfGWoxpfkyaRWrSI0qFTtJFGkpDbQUpBpdxRZ7U576rBrrttFITyllisEMFCCIQKFSvOQLGiSUiE4AgmEclfBITHkpsA7sAugMvhNsKK2eXbfymg2Dd2QrMWmJgqx6nG7D7C5vqxRS1QLG0B3SguOII/D6AyUAPoAbh0V0UwbajllVk8s3N5Y5EYmtc8oa+AA1sdgKtoLxx9zQMQ7nxtgIMmwMnHeuJJEYrJxHIGU4GzCJJic7hKngSi+w8NBkDoKFormTJwLGjYmTEC+yIAV/uejkIR4tdPpDI5iv/OFUqVWg9AA6BvcGeGxYAYaNUYZAv6RjeKmTk4xSwAQE7wr98kMPalTLcTmEDum4z5PRmD+NwEgAbB3elPIwGQjSFMviZAsRUB6P35fdrlSxAgP54D/1B0Kc1VI9zcl8lqJ7Dfig25KAKs2+8NW4QzgueO03HuwcTC86HWXrjUs9PSWJR3dnya+pmfO5uCdwKYP/XSD+iKJ/2LmbzBZtfvMFqnXr44giw8nxL8/Za2tEavEzA6+N/rsc6yOXmsMMFMv20FMhB65MZpUx79jeWFGieHSJBYOL9UpqeWYtDmyjuqGKer7i6fqNzZCj57cDpQPk6UjtrOxFAQ6HjNY/d3e3g1nrAqr0LD4FMg1jzFS789x6NmOXG29AaS+Iycy6+8QhSXYaJ9KcAMGl9rKS/oA/tx6p/OUamVKwKGZ4AtN+IuLwPLgz7Pbz7lfhjB8tdUHIImjwmEtLKa4B8201PBTmowfoymgqo9wHZkG2nN4gidtieu9JmRfL98JVqyHuX0kvMAt90g86t10plgPEqQSWdTkQuf8/QNR2ecgfyc6ns/ky9nC3vWpKI6xrig8Os1conZYa40Lj2NjDBnMeOTZqhZvs8m2CUxRCuKVxcqguFOihnwVfpM1HFblHIim7PbYYhs4pQZdALyaZAlDbicTLq0o61WFSRNvlj0uK7f54PVkfhNulaFqyn9gFnFXsGdpUJpRrkk9dkR9NBZ5HIMfxAqh7YdfnVODtRhz/oT7hyVUZFUb9jCcs3dgFwCRsp4OTmJhh5dqFw2zDbDaDVlw6zHPdsQ9P1t/s7zBuBUR4ibxg9Gr7kkfoOeWVZmcLRKk+KKyPa48HMGXehCYGa6n8VNXrkUuSHjZxIL+KhA67aGRwcMsGVFdnxac2ulCRVeoovR9lUFq/l/D1FRyTmX3JYoe+6Ft9754KNPfvhj155//qupa2hqaevo6ukbGBoZm5iamVtYWoDmcQSBUBTGMBqDATOZXJyFkKSGooQcjprLE/H5sFBIE92lmJLQpWI5T8lXSdSoppsDpHQ6fq1bBPPPItWx1LbcDmatZ5dtw7AXWUqQzPJ13BtQeBP3Vl542zss7xLeI71P+CCXPvQR7mOOT5Q+5fgsypyh6CeridzNyMyzBLIUaVlOWG4V0urcxhrrsW1gbWNuY5MdSDu/NddnD1t77WNpv8PoVFTsnXKWS2qR7MtbsNvAdKeei+DBCYIReEh8lCA0IehSMaRhysZSw0AdQ/WMNDDWxkQXD0OYGjo1Izi6BhbusnSPlfusPWDjIVuP2HnM3hMOnnL0jJPnnL3g4iVXr2Cvsb3B8RbXOzzvufnwuztCGAq4jBSFFsBz3Sem2WRvMP0UFBPLrLUOgW6WIJaCDKR7UIoHJe0GIfRbIGsDwronJGQJCjjo5eTIvyoYvjs8MMwZ4kNoaB08NRybGOwZeA+43TvdxcqF7nq3p1vSzesmwu7orrcb7No7wjfrJdRB7ZWd06StwVprGwZ7Ku4uttaGNWuTtoL6rI7X9Gosdxlrdk3PT7kdZZakOd7UI9j6cQGWAeKEgJE4KLygpQ2X6fwIMAmFMYyIsDDEtpUipaxt4UGwLxo4WEE7h4Z2kU5jE2jOK78115jg/Wu7wtM1t/HJvJqlxIpippRJKsqZYWFSmDUyLyyq8oqJpKwcDHPjwjy3CFYVg1KQxMqJQW6SmmIEtiFz3S0DjiIABUyBDqTBZLHTBirQdDlQHCakUG2FbEoq3xUlvFGUkafiTGai16FCzGqN4i9VFCa7znWh6oVqyVGnka5+YK+qoEgtDlAa1NFEF7171ik7oLZfuAL8cw20dBsvsA2Z664fMAkgwATaoPqXZStNEXzI0FH0CcP4itDFoUUR9HUWiBYT7pBN7wifmxPVqJ51SHZCjVQulBSjRLB9L6vrxUb74w0v+Au/bcaP2J6q6heuoQZq3dzN9BhtNRE1a/fn5w8UHxV2bicf0Mfxbo6x2E/qQFSNiaBqEJq6JcbAhO0Seuh/9AZkiEZkjCaCKZmRBVmSlER8bIj99T86p+KiQ9ERSaupU/KbtK3HRYrHJtOJcDKodlcKJztyhD3HWYmMeLsco4x/pBAOoBUBhIpk69bf7XnuReIt+Yj2SE3Xdexi0kYzgWMYQc1zvfAKIb9/RVStdeGZ/9y9n8g8Z9yNcuF8Zl2Q3RY6nmL2H0jVZtWou3QFTbTRnfZQ32WgDvTIT79bMSmbtmSWx/PYQi/lalTbR0ScPneGSG25cm5gnYA2UH5GHY1+k30DbeAqRgKMDgqew7AkSdsPvSuSlvDKAwYzLQ1pLBCcZjqnFJ/OqTOv0HPCFDVq1K/GOp00axo9WIKBtTR8+oHtOIVRi+PiR252Y16cQCMU2ORACGDqnMQqMIlolwKmItWle14AjUXqBE6fJLmRVSAMRgBBCAik+rEMMq4ADAwDAxDHH9ER3g7qkb8j/qtt5/X69dq5J1NYS6inCfu0tkJ0vKJWbL+sCkX9nOK3WxF5EjkKyisvV97lULTKSyH7JgYSMpMAUQYp4PaBqZnjp7vWKZYmCoeV7rBMyGAGymdLMEIytNoGCMmAMRO9qVU2g1dhJXphZ7szQNosiPElA6RBkec+gGTs1KFFzF3PcAI7Cp+xE8NTBncHIlw8XAxwZYYBqhKSheemyJkZ40WzKAnMoDDekA0r4xHj1VQCUxzjASOzQJOk9r2JMXYiFpg49g+9iCq037omO9BA3VkFwKHen4acQZx2yrSaPmiDaoh2CzgX2AQAB3+kYnQVrPNGWSYVoLuoYmNAewOqq9eBMQZQQAMWICFgAap2A/YRhYYAZhIIF6VQnaFG0iOYYF2s03W/HjbUujZlvAA7YBfMwe5YhKV4G5vDnsOWcyw41no9zIT5E4lWpN4wqwpIoC6YxwDZzp2P7bBTx8PfD+m1wFTQPwb9OoC+HUx2n/hPnCfW4P+/poPNCwAf/XqaTz2f+j158aTgyfcn9bgfFyCAPYBTgPOA64wG2Q0A2QHYNtLv/fPX1Co0yhxdUsk0aDTSWPnS5WiTp8Bkk0xRL02Tds1Gy6b9fZ6R8X+QgRbdWo2JrsZMs80wV49eaoMNU2W6DEN8N8J49z2gcccgU/12z3DVPvnoszoH7Kd0SL+DDlM56ZjjTjjrlNPOOOqcS8674IqLJrjslutuuOm2a3ZaaJ75FltgkSWWWmW5FVZab4211llmo6022Wy7LSbaZo8+u+y2l8I+V+2gh4kixcqUKFXOlkS5KCHiiTVLxscznVCSLJVSVKqWKoqIVIY8YEYfxigHo+dq9OoY1euM6jNGdQajV8Fmn0pgHXVSH0L3nvwT0k+Q9L0fWMgzz/BTAtpsjGMbpApUvrkSiM1eBXQ51Pgp4dw4BdkiWVG+DE8dhwe3bcIVuL6i7WGq5dxmNTVTZQqs8KrTdRn2NadGsVeMOS2TjcWMfkoEw0hBJ1ASbjQ2NnJO+U8mvQs3tY2IAn/04dEQU7EXFGOy2ThWcZRwRICSSybriKOV5FQe0VVRXcxclLMbCEJwEqJcrrfDqUomn624ZcpnhuumbqandN/taYAcJSihDUq2sBL9SMQLP0J05PAF3ilzXCJJZUpmV3YUhjIYXw9+GAJCYjJghtHrZwMyAtQskBVg/l+ApX8A2hWgTgP7/QQCgEJALxkk8pZ/MBIdRxKhFQ4BIfwkWT1LQeGJKOUy6vWMMyr5J6uqYVUqiqYHDuoVSGkRwlqghvEKX7vA/r6SyLjxrekaHb/3E10pVvOgGo0g4njwTzdCVUG7e/D9COmpyOtFXmW5F6XaVjJSxFTKnEfBJriHyV4ECY+Uxw0ScV5KJfhCiEBRVwWRxbNI8YURNW8G5yIS/QOLTCtlVkpVKm+ebbUYlk6ufvlsOfIJ9c4nKY94mYxRNeJcFceGUVWJTsHBfd3ygyAIojyIlGG4tRQqEHZBjEwQUChFiGGcfk60UKkxmLeMJb5S1qX9iSJmxk1lbV2OPIfsuV4mRO5JXgglirlFmkSZGVeJUpsr7rHtLMshWaA8UmTTh9tikn4ij5B+rcJgKnGAQBjMi/kV0S0uEDEXwmLoiMoHImqjLKj32OAb8TCbIBCBmBOQjjB+hFDN2V0OxN97lQnRcGbiiF7kFeLwQFQPJRDMfa7qrwKfPtO8PRhvcIxUMeq8cP81ATStGJbilA7k5Efvbi68bLSnMxQuvMgl5NK7gUByDfo2Vx/fcB06ZMYrxcA9woUyUUc8V33c2dTeSQvSeSMo8gF5hXsvTkdrpGIlF6BlZut9wgSdk3GC1aJBKVRqQwu5qWTmL27t7kVzeyHDXwyWS4MowTHyOJYDZOR4uui90ppFitICiMMAD8cYOM7AB8QHd6wZ947NkKud0vn8FK4l2tK6kmpXvi2m7zG0fZ8Ncv20LSY7njZXAR2JXwg5l+y/RQWNlyB3xAQVa283jxWM2mOctaTuPPoN5FzCmjU50/dcfgg5YlHc3mUYfNrL3b3ZRKWHjdxmzQdXTB0jbmcp7ZXY5k1igwpSioRoxbiKKZlcrg64bS919iblgv4Ipx4RxqyFNmyz4WNlCfL4y6/JYc+OICQ9vDsbTtmPGh89lT/NbZ5i9MVMp6E1SJPiuh1Zr9wqF6+Sg4OepMsRG2BCP1VwjOM2WPBknc3H+J6OEqtFFPukTs8NUoRs0M+WQXFlNgG+yHFCGygTgliulyJkKX1oeaZ2HJgVQPFu1fS2r4jjHLPhdxJOWlFs051il6RsQJRp4am3WMuvLRE7RAHDFGBSsp4UBqjX5jMjgF3JLu32yaSv1JAJUUnrs3fN5QmqIitDT1px3WVT7uCS5T9L61tLEKM44cfgGeSbewncLda0DZ2VSrHrWn2LqqS0IuF8fPOSQ26aCNlh86bY+NjCoHsk77DbmRaUo6LxRQ2aP+9u1T1NeNbVBieLFs3cniTds+IgK2e8OpCWWuxbdJinveuFnV36ihc3HAg/vMG6uhx+i2tLI163+/FW4z7+3i3Wvb1GGy3MssFA0GGbFFgOXxlx/erTVWuu+cq1GzRzE3dgzpieEMsTqndtUMy/BVRnzon9cqpafF/3GVbBuwWCXUX82faZ62nEc8Ks5E7InIl9oCsEC71KLEta9J5U+e80m0K2tB4lTFXHMnblChssi9qGKmsQ+Fp6GQxtDRJQyQYo1opxvmhO2CfHE4FzzXgq+9lgbNZvbJy4yQmwCFcboUX39Y5U4lctpE4O4DgHDq/RgLukZZAlzKyOvrGnJYUkW4gv+Srf3+m9veFVn/TMe3zyjHB5aN/Sw8718giexgQdBIsltVstVbzkjPvkylRC20m1TJ20Ll4cbELfktIzghGoi2+ef1Lviw/cfgKTbOToycXhGbPBT2AeD699zHTRBjF+bJJoay2eW0f8XQ02E5tOO32xlOiabLih8K3GhUxFk08903POC6M7SoV6hZBaTaskrAe6nIL2idaZRgZHdBNlSFDbum0z/lRrrtcsuTfqHHxxAI7gJSWB6dLMr/p4VsNgoku7jEL2yJG5hRw0211lwCFPMHcB+y8UcjQDjZKLeKMIebRHhoEIuBWNykI4A+SzGm5B0JEW+eBqsIdHEj1yjnzWoYFQ+6r9m//I/MV/UsA7WILSUmUVsvA3V7Jno3kU3W1t4vFzkrTkbCw9V9vs3KGiZtgEJN9Ptu3TNhSdb1qVV392VXAPqvyqpmb3XfJsBC2rq3fdJi6krtr7XKBRNFqqYl/CjIiSQ2OqXlK13yEiwYVs6XBS/UXQq1UBiwqi9onqZeXxe2BK3Upxps2uxYeo2ZIUbZrxIAYXCQ/MhAgnGYQajvVLyFLooPd2xAo6g+VY4wueP1fbKrSAE7LshQMol5K2dJQSDKHK/ZFD1TD6Q+7bkmgtF/TDrWzQSkvFQksh65RPgjQh/9CKRSugW06uJpFNk1PjcsoPm42nG0KbX8AOmrrhVH1VmYu2UJW/FN5lEkHmNL83bK1OtGjVKnWzkE2tyng2OP07eqDPp2r0tTlktuljB2Zgq24gwyu0xssjwcJHC23DDyeiQF8nc6QKZQ/3Um8R14j25WbVaR4TJLK/Ro0Mr+CSumFljPgQqWWQri+33HwJAFxJwlGyDwGsEgejzkHWA9we4ilJJB8WA41zUDSBCdo36swHGzI4jEpaL8FyUykHm+WdDT0or4UEPNm3m18peIO355bl+BL4QPTjxAIHzKISBF5Jlh0j0wcHRPH4g50qysNi5i/XLIjsBUl0g96gy1v0wD0Mz6igrAef4GfxSWgUPvC4csT0xL9YU8dWgZMsvKXXQ/5jmLVzr+RLDsS5jyoBl4c/ZdwXKhBL9Xm0kW/tObqNMdQNNENB6tqlrNFfXLtAbxGXBkqcCB+x7NtE59E8t+s+fjF4hoj7fubb64fN/WAiScfwqhfIvg/LPEsb+/RPjrB27p8qJWE9LKX52Miqz7Db66+ZA6E/O/z+jEdQIFD8D8tpd9gM3Pjhoq6VOylHjJTp8vPe69CZcC4a9ON5D5zpevHoycG25+CEbDcgFm53zsRtXfzmeO5JQgXMQXTd30XlvPhf4YrLDPxJO0CPjLNLHOs1SehNCYfVkQXdJaLDhQqQ4ZO1UF8IPXK83viaA6wvyp0HWS/Yi9yL1DgmsOOXKm823Oph7XyGhYWPNjeptjWgXZuiojQJDsR1wO3WPIbDCgFBfVGhGbEGXvTMY6t7KI1PfOVoeKKcB/Jdl2BWkuMG8Yl/wdc8EiF8G2fF9A6B7CAHnnbOJnd8ok5KPlhEiGDR+8hJ+rTPnWt3Jd0RHhVXn5h0kBDFnSm1pMRpskb9mv2i/FykSr6QBpk6WSRKtC6VxeOUyYZIlOpiEYRO8rRB/HxR8Bxy7cQpnfs/bsuD59lgDYEEs3LTgxotPS2rArleiY06CJ3zlzHihQcoa5+7BHFn7648U1AxzxAUiN4ED54uYoobf2rx+ZHmzCo7FovVeeQ8kw8r2agMKxVe3FUWv/Rw4QOFzSbuPVzjc7IBkFbiUegCTUHM2e0Zalfrx62Kr4F/nc1GJNHRHGCZkJl6DruxYXaoG/5SyBB2PUF+SmioSrdcp/QIdDCr1WoVUEgPj7JLlqSSxGsmyEPCUdhDQsziRohxtRIxFq2cTdeFBEaY0wkMDHwE1HlagCxQ8+Y/ytqwoYIXhbAwmhbH7ltf6QD3BqnyZGfWd1DnliupGuIzYo2JWWREKq8yoMZiZk46S8voWlJgRrgZq4XbysDvGK3GL2gEOM164UhFDda1vrYBkxk3rGmwY2/VhLuivFw2HcYDw4OXSITs1OkdjV5kYGwAGbhMDOQaiCX40oVdDov4chP9dVVdRRf1dZVfV8d0yJFKqf5QPucc14Nkap7kAOIYhN79yjX3LbErv8LvT4UxHK7+zHz6NyVPYcFBp+hRUv2wmiX8xagcyHqHJJIDdoLSwM103P8+Qxnf5+IiaLPcRwmkNhIt7QkXYdk8t+JZPVTZTmSXLKnqnF00u7Pq9fN0LCCohJukEKRO6zBqELLu/7RnKUx+SrxO9UZGd1dcfvZlffpkjtt7nmg9KT5bO0rsdSPaEJUgqasz+Zc56pASnf622wr4osWVgrWwqeJUucbT2VmNFRfKIbZrbn/l0smW0zUhgRmpyVgtNa0KfBGNhhRYEKfFWgIBlVAjDr8vgAduDsdEBCtdtf6HWJ2kVLVLmUjiuU5S3ishKpGkvYY22qoJhQNTChLkD3QspZNtfd1Z36DeXM/prlurefz66lrheRo4s85GSn735TqEKpVYIKz5Y26oEMVMrmwoOCk+K+wKIcqq2qoUtn0IGVrQhSR2BqlDmao7mIjTgebp10FVWYJKpCcfpxCxO/qHaMtbq/mOZy8F4lC8ug90H0+3fmz/AAU+sH08XfOx/gPXBkor+od093TJbvSP9DzGZcq5O4mxV8j1V2RP/DWen1j7NGXH09mdFN8Xi9dxRjtYIsQv7LtaTixOlAdpzGC0BqxdxEKWmsUr1Qg6E36+ajgp9Mt4z1utvoc2N/hTZ8t4dSSTDtSFZg5Oz+F+fN9zEkmV8zcHp84SdL6oe0PL076hexG7phpS8BRDqms7AvS1d+9RKOSHJhTM83ExsB4O2R0ypKa4Mqzr7G1d2AzGIAwQcZ2LSbBlfMrRJcHDdasiEXkb4+EuiWPqa6cEZelZhGZYwyL0KEtyn9AVnziZFJ4CcODnML4mPrE/yT2lwBXmMDdLudpmJ+zdcleTeF00IlrnaepTgImlwRoIEs1P2AC5i9vDDmqGNGyyx8dV1dpn0s7XwWP4tx3e4RmmtJmcIDVpjb/ELjOSkWeQiofBdWScJmWhDmeV1J8JF6GuGbsX6HQmB3j6R9w2K5zp+7r7roxQWhe88lcHRczY1umPT5CDIly7xEUzzjmqCEA3ieYOTAxOzqc9Nb93IjBEOxEco8BFcvr/O5h16FCv3N0kWheNita6m9NFILBP7m7mcmFdDagYwGWu6oqjOc5gzymELFgSjE+UJdq643H5YSaui+dcV7UqNcpW1fVt/xzqEO/lo0+k1WBT7YoA8pV/YO2ezpJQz4O7U+OPkOPBW9qzKQ+SgUr2qZP3SQ5dQ/H/3Px7jEsPzbc/8Ko9prK4vKhZ9QRUsiXJaIv65TXoi2SF2jfY2PHdpF9mAd2GRpVd5Sje0l7WHPcquZ7Xo+wgOjBIDn6Al+KWU+OKamd7PO5sb3uY3O2uGjA5U3wESfAbnRUD7t3Iv1+ONw0n3TSalzaSjEyNQ5dP9MtwXyN1up0a8aVIn51CMVG8vvCj4yVNzbY7RO60FM3zZM/VTj9Xm/o08344e5Yx/VFG6sNg9r/ZPxxJjfso477UzwfLm7j/unfyl+Fvu+/mH0Ql9KXDl05t7by01IuwBBONWkqD6mH1YRrLqCjw1gaj+A1V7kOHqPOnx7U/jscYz4Q/fbnQ0aYuNNpQB/cnRXcnztor9uBMtdrHDrGcMlEZvGxz0YXjbRHqKIrY1bl6SGfQgfLIhzexascssdRTtoXrEPNgPf0c9Ql80xYPWQ3+WoStlcGz/Bt//+Hmx5F/ubgLsOZZoYcHnBfmb/Tj/C+WfpNFsvZWe2H6SVrHTwOqWfm5q77Wy1zseRyfWl1NPheu0UuBWQ1dv/9w81rde1zM6YILYKcLU2YiSH7F8nlpKV0XrjVD1a1Wr2wDNhgJj/UuiHgcpCz1nmOT12CXudgRjq9BzSWfC9VoMNjtQvNQOODLp7jvoYIh8SrXM8/gtAG/hG6OcW5xnBLME/woL2MnzcRIoqtrJEGY7WQm7yNPEJNwnLdiHBPm9NnNDDMcTiiBkQCo15Xo4ABgZp+fPV6ill6VTNZoSz/+r46XrMSQhL6w//B9C0Ra6EVYANf18koQSbvkMA2vty7wlwvsQy68m3PsbjjeO8b2NDoBh9C3z/Un3AUae6Oxh5N1MivQPqdf4a5IsBwiMzrkNh9dk4OOR+gJG6qSFYi/N8SlrhegtjVynBF9k6cD8UtUO90VMNVx7S8EK9Rwt/q+ix9QgQbBdZoCDa5D3HD30AIAZe6ZezANphf6LiZoP8Q7LjBmvpd75Ce5zFnVwEIkimrXkSBLs8rX/cF/AF8FoFZzgRm1AoLws3B+Od6FpaV0TYB7mhPS6rm9lrZQmOgZD2MmTOC56NCEeqVoVQMLFsuqnYf9bBUMYDZjvhGzAZNnMnm2onIEP38u/veymE9Cb4xU7v1QaEY93+XaLbgaHghmswNBWG3B7bnfoR6z8MO9kUoDNNo5o3OUfQPYIbD9KC+W/Gez/Scplv+4QtxVkl7fE/iV8pX/dCkdmCXW+NgkE66vW7yNf1Yr9ir4e74FKkWC18+tZ/PXXVqAdh9/VRJibYDQnnL3Xet31P+9SpKtL+S4X17yXA3JKBRtbsTUTuGOiXNG9OECdoketz11dMFX4S2Nrd26++Jx/YPZ/u2WGLJW3N5s3dmhmdksghz1CuWdWEq/R86f+o0ZMBiYgd+m+PKWD6kQrKw7yVIokqQckPf4XQMiOza3IRSVz4NNqGxuIDQiR7/86bq2Rr5IOEunY2sIDfs1iBqmhRn8fDfVXX5GN/fHPoz8hZSvp3NfrCqqepHr/sh46+dwr1YVixSZw+CH2LBGMru46qqQfLYCq+Cs/jp+Alu+i+mLePVaBftT35UjKUtqz4Z7XZq5eu0r64kozVNPPFuuredpnxVDJXGrFp7fsEVfjDvrZuxP1fbdtXhPNqLkIg0ONq3Xc9hPaUFtxep/dUbI8aiTuV3sRivLCP0Z2x99cZ4gBcq4gnfZTfQH9BhzrXLYESfc9wJJeU/lgCasfegreoDkarfXEVeOsNYx/tE7RzDIUr3u1TWb4g2TNqzB8ph73cQBh5lrGS0bV62LTFKTNtGHf/CbIri9sX4Z/0dJr9gr7pX8yF9WT1KkvxUa7P7S+zWY4u9mfzm2/+GTd19pcDEmTp6YsRqpM5/9fBw8nSV48tNxj7K20e1vS6dJcntqlzo8xzwnPJ5I3cLkJh5ZtHGVdBVj0b0ZKANW4xFjv0MRPGPAGFJZuFL25sg5oeEDkbCn+BOiHPWolQanJpe2XVY73piKIh18acRuDZSjE9olb4rXPHx16Lfh14R88Rxf93Xtot8kIrgaZqOiejYGWwkRBIF0J31AIppXFyALG2It6rXB4AAKKRSiRoRNxnQ9ggozRrPxARFW0xhNqRBACXR5w52xmFTvVdsVOdtPDGRLb0sdw03gElN+GtTw0HciEcqJcHCpdBAi5hLVZ7jaUP2R5vM2bqrjlHE6Nm3kjN+KrPqXmzgzWRXxHCUpk/j4d2wZZYxypf3GwoNTTbLPZbGpreU2aA0FXGMuly+7K0D8Y4Ex6rTAskUdcR47n0k9GpRr50p17gYMZXldvPeOjr5zSPQ21GE5JTgdFx0rL1CaZ9Xv/71kevh2xOlPhEIsOb2KmFp6RGKVHJGKxuGv+2qffn6vQLD3+adr/XybzCt71DNvWz24aWSrkAFsVNF2IgMQfMManiMs8C/i3PvcGP85+6JYYd7EPLbcC7yVwGPEwzy0Ga1AfKcsz4QxUkx+VTeBUpeTXnxhKHxYvIPfCFZzLwWrK+UpuqFPBuWdNMvLN6AbL7vvqqkDiqFXoHLa/ZNZwqQbXMX3PytwyZ0VX3DTShY0K371Dv/U7LLZp/g34/JWB902YKTtennyEUEU+5Y49CcZfSpvyiV5MXQCBXeclnfwh9W5DsatcbBHypL2gK83kfGi59pW6BVaecM8siWb/b+r6w+v9w8n/J/G30JGFEHAiNiBAEeHcXL0Xz411NVUmNo6OJTeEivsQjo+89l9P1chzoItnjy+975AyPZZxym0UR0QrxOr/cZRP33N3f07d8r7xxfMIbiovQ6O2O2+dJzumQbSUjRwWqEnFfcBMThqF/80fiK5fCzQNsp2i4sqqpoQ9MAsQCzneI6FODpPu4nx3f2YTO/AUadwhn3fW8ht/myDNPYqrdcVL/IHXNROu/3w326VcFp7WSLqrX/BglY9FrD6QVrG0PD8Klj6+9TKjuqz4gv3dybzAstnq4/Apb8/CdnVi9UHrzwK29V3Xuodo9mjD0seTj0MbpiISZw10k4Y4xPAhkiIRQMVhTVU4vLLPgR2ZK86QPkOmvbVME1ZJbuo0TE72msa5LBbBzxe5Ad+aBVH1q+ttYEioGz6W8oc7uTPYLnE2xJAXX1Ef7tSP25SvRn8x9BiQqXHgXJrjvLNn+1ldQ1egR5gD6Rs/5+zSzwtQBvAG7x5nDIRu506yhPMZqe5jOpPF5aJps5EN71UNmtbafE99+42cqTyO7ePnAPS7T4w6dF/b/LIkswhAKnpOkUM8lVaUmAEqxONjQIK6a5rGxzq7xqOQ53/evVfwQ1/OSSUxV+VF5Pm3icdniAGYDeH47ae4yEqQVXcFXLdeY2htQIgqEL6hhXqFyOVty3uawA5VNWkO7swqCb4kMX1bOZqLxXzU58z7aEDyo8/Z6VM4envKzcOPYyNfG/NT/RBrfDaHXmUlm61O85jHBJIG+fnkEkLrPbXGgFOyzDU61KFyvAFa9rsT7Xd40qGQuaQ5MukzaOQ1HPGH3j9BZRO18JJ3D+NRgBuFLW7iRLiMomQNA0r1OPjatQEt4cV0lgUNqhWIlwZfcNZagPHzsqNwDMiP4r9Fz/OPhduG/8Ej0yBOPhzBD9ZOPBw9HJsPLDolH3lOdBg0Nuwy5mft+axjaf+m7o7SfjsPtGR/h36cKN9Y+65NL0d0ZhCa8CURbAidPKqjfKnx/WUyoWljinZQ0b3sWuo3Wod+354HMlhY8Ny30m2sE4hOTF2mfL4ybrupdrKeut4xfG3WKZQ9WLm8S88dBaHql+JT5A7rifaelpaJDtxfezz42uDqulT5ORzhAU2wY0Vzxqgqjbi/1p0CEf3w2rnY5QccteSi4ALzjS3sOTyKuIqiajB0SCSiKM9qMNUfYU5sagm2x63ZVQOHVbauLJzspiZU1XM5dfMD/p9eR9wrA6zUqqx70vhzwfHaoTucmqlmMOe/9qBvBuqRqxBVvv275SQWd/gNgL6N0Ufv76YLxxg5+g9MvWGlzDskubQr6G/DEoDZtJTV16ZWMZb/5jBGurrRp4GNusMOAxpJyuvfd7MFwa5NG5QWPXxSV3R85+lHwdApxusr4TH5NtIYWzx/j7lzYeEatCsNbihO/yVfBrxcJc7m7G7rbsg3bxSzXaz5QKAOM3y2ufqqW/jXAmottlQUsLF36YaLtbKq2r4XViTr4GvKkKnhH3MQmafkNc2YlHUV8Kb5NvIsrzQEyYNYCnlghyA071leLTlCM9nZfAizbIh9ILpRW+WVHW9t8K8LCZ1wCoEFboSzdaC40Dd3C6gBSuITBGcohioa33xpe38/UcZHuXSUt9B39FS3NFQOJz6ehyC88cTDqe7yiHzx3MpmvvMx/nGB9zAfoeuPLpL7QZcbnCotzZkXOTwGrxKieQnTAjN2ZzQDz7w5gKxVGhwyd/7S/WYBZX6xs8j7VZ9PiHj8yo7v0J7/tHBxuGj4/gHkuWbZb/IxpC/R68oqKOWLJtrUPa4Y7l3sOH504ehlzdHS23lQlNiY7Vw5bbZJiWva7qResGyIdZGjGsdePAqxSMRfq9yjoPhYw+6czlYv9jo9l/J/N19KSNypAMbyAE2lFM+MJKzWQnsVTmZQZ7qMN90k4GbTB+gqIqcp7iKnaMsy6ioCteojMrvGuoAdVmpz5DmQ9fWWW2tf/ANZtd8xzqr0a6r/4xo+gC21+3VqT0siovfL5an75l1VlvLN+y75kfWWY0W5655H+pwvUstcue4ebB6XNoRcHCRTh1z59Dw6PUMdw4N3yYYfr124M5xA4G91ufOoRF6rQkY93p+dTSvvZzJz4R6nTYfZHI89urb5Fd+T3Vq0D7vkR7SW/+9YWD2e29pRv36bw8wiyvA/tFySJolP/26q0cuLuHKzAQ8w6rP7bmk1Wfim8pOvfm+/Rp5fcZ9ph9TTcST0fN5K0jR+yX6YJAzaqIHPQN+NUNoU/9CXEtq09xj7hJgnRna1L+4a1CYCfwIRf8IZHXrYv2PIDP+PMfGwEtB7ihfYawXYsbwikJu0rm1MnbzImf+6vpnr7GfMH/Chk+gi9ttQV3SnoDw2LJlEL4UrWIeX1QTStSoxSx8zt7EjsQgxwGehBmLQE5ixibvfUFbRfRoamrOXrhx2UgejVWg0ohZeMwuY0fGoPbD62PQ9q8J7AK7l2fdutrL1mbz7vY9W2rGjvVd6zZr1/qbS9R59H62BvyX8/VeSRAG8+72kIRw5id4/NNPoHtVgPTD6ydohYYiAPpRtne4K5G2dJD1sUijVMMhwVpMKqAG78OiPfpZiUZPqtISHuFvenp/SkZnk2qS1it04jCuYA93Uf/e2wil/N3A+VfST6VhTAgnkYkporojoAXQCtqiGhEuhgsQTs0BlWWClRw4Moo9VESjxwA9jWEAwZ+bawgDDpcXUp3hX8fC2+kJeclSYIF7eE6QiHiQuukqRy3GvZiaHZ+cavCvV4jHcwsdf9l31/T8c65H7k01GffypMO5KrtY9KgltJ2asCosbqtu1wkaEPOd5i0so8aKEy975QNMwsM52WszFYlMXPoF+blfVe/UIA9AIp9J9j0DB/vvgf24D9WLaE0m3Nr+xmzPrcyCNtdobq7R+TqOHiLXes7z4fYlPiWy6gxbxlHuNU/s1U7kSbjV2HJSa2Ubbje2tchQchM+FSuR+G5JmrB2WKE6VCyubHj8uivUykoohFtzpywEvZaYYgnMuiZAgMtVnkUEeecu2dQJzQF/MqHYJBD6cl1mPNJbT4UpzONfaHQlPaGF1vz8j0iZuCBfF9GytBu6Nt9TmFsI9GxIM6Fnzv4j/0H00PMyc2SGYhM5Dod6hlKmW1IqtLbQeNHKV3NuLIRYEJYmtA9tQmgafYOVA32WE21DwFpt5dymuFxdQng8RHrA+TGK0LLbweU1l55/Q6XoF4KwOQziFWlwsslBnFhYegyabzUkQ4KatE1Ug9vXSrD+Ylcg9K6MSxc/iqBWhxLaaQHW1XDPO5FadREsBo2Id8aCCtrTbkCWU/ibh7NGZObvN8KX2AjREhphr2Ir9R6el6Ttugr6mN5oPaGtrE0o+CJvBNRgQmiM3RIANOOY/kqQ9i9TGAPDTGuT1LHFJAgMFNqIL9NILsjqhAv30QDpTiaxpn1MDMJQw3g0fSwABu7QbdPc3NdIkEanstGUh76aNmbmd0dNYEEnG08lAOBZOxblH5uSZyU1MJCT2lTy+7VLEN2rf/fobtfu1rSDcU5QIOqRylRTr4kCqqgkbrWBekWSBOhoPsSQVq5YUc5DiB1CphDIUqtODPCozxyYANUJTFrDTcJkSsDoRvFf9No9cTMsoovVp/8m5SyedAcsOx9wGTGVQq2sRErMxZwFldkGBDVWlTJMxkJkfZyYsFR8PYJcOlCtioED57EzNGqDwANEVYNo6J6ZziHqdeQ5iZQfrVzC/OoaIdLqKz0yJsB9pTmzLIbwn9s30NgstvDr3vNWbAIJc6cp5MUl9fbzgFFMcOgNxsBi/6nEiCsOXBJeST4aaVRgjPA6yIrmFkPQFcDNrQ8Er+Jz9ouq1gE4j2qM3lnH+eDapQxCqWpjY9wKRVKUV0UZNE1BYH6gbsV0xIxLqI/i8MZvcKt2O8KcPmpwTr6VsTBJMivbyOq2sHfaQpf6oWR5N9XwzMMyU7ahpS+NgCWkCQ9VPQtNaO4384RcVtsOYimC+h+WfegV3QPSf9Mwou7ESHc6vHNF/ECNfHFSMQm7mm0Ty0rzJaJVotWUDBFKgl6mBATxQISxEfgGG0yhCc1RfwOQJQdKjp30GDefY8SDzAvZ2g4udSC8su+XV2b/BOylKq5g2p/QmgrsHSEXDB9n+riJDFCkY9RrxOgOabzi6AcLfhhIpiJzunLzYPGgLmIXGxADieWP0EYAwBzfEGJ+fLiJBAlaEW9FpZjNDTNgn0wwHxGIpuON3tmYNMbLI5z++YU9esWEPrcNPS/UIUocBy65YlMfiFa07I1GjJxssBRQf2O/X3ff5n11ABuOjZv4+9tubdzeuLu5q84E53ikGYzMXsmfyvQpNtgUBRMlGYDNbhslVk4Y+kyJnhOkmpC79xixaKKAa816mf0ZWKDQpPk9HVMzMV5lLGujcTCU6STzpA/JR/1kIZxT7oupzODEKiVf1sLpqt+kxVWDFiQOWq2rnbPeScNIYfBzNZg4VMoNJLRM8tgGBIRJI5kG7kkxx3RrKy42MwECeMOya7jdW0p9nW6yaGttAdA2GV+hRYsWLVq0ay3abpQOd1JLFC6ihbZjYehZh2VplsNjpNLGpLaXXt2kWlqLzYeqRq1KLJUUdhljcynjui71EM13EFbNCoE53YL2TJBM7m4nGLuLz+NExKUzY0WSbYWYtC+yRp4gvT4W5etKqRWvx0tC+RaXSTqzZBr0OLC06H64EHkDizUBMKTrTleNUw2EegPj6yiheEvQKmRnw2sMoCvl9wwNtaJ57sY4XTJtooBvomvY63qiYNE3YWKvWQgPS/OF+TRB9dguNn38jX6mWuFKAJiSRCuwhHH12PE3ZO+EKLuJGIMkiaHHZ160kfx2k3mwbU7Ygwlz5UQOlJmZgVpym5mHnGamm4sdUurCoYAqEH9uvnEAFidXWs96LtyqXxXxyrFDJJZi2e3sR34FOgA6G1d9tRvvil2d7OROB4lt14ltWtN/hujX7GvI+ECfzvXBwRy3tIQEec3rQP0ncH90lE7dW46xUx+bw573eww9LRbuo6gV6k4USK5OKhyLt+UTyjK5fzDawTDqsqg5k4sRRt0V7uOM9gKT1BNGJ59Hz02VI0EYTedjuPFLGgMQ+q/OLwgAfriAX5X0bQkgRBcgqbvBrDd5fWazT5UkOq7/+TF2Qg+ID1rv+/leVdZUW5MI0PDEBuMxwXlqaXcj0THGfTj/0BYZGvnoWQbuwxMp/xXQVdunASUAvUiV/BTg7CyfzUcS/VofuTIFxro1ixBrse67Izfed3J8p8cWeS1HX2WClIKHc2403xdrxJLurdAjyYJ1Aa6kVg8yWYYGnbRIosCgMzjNHwIjkBlhdJE9cE+uUmt7oPf5H4vgB2NBwkZ+Ly9f20vvTRDmC97LKOF8/ZEYjnRRonBVgCb2c+oD0e6WjaakybU86aElh/Ep9MKyais1U9Iddne/e8FinRd1lgyO8Hg9ma816mUuW4/uordsrmFyJlPjq6GhG5IknRe8iE5cWabztRi8UQ8Yh76ZQgAz1fpJp0/Y426S6RzjWSniDc+zzAN57PLR/aRVXlky+FNarsvR3/U4BnjcE+k1NhkPeOaDdN8NFlzVGgRU1hAZuN8xC+QwC2aqOoI4WG1lD1a11fbrVn6wKmpDfsxw9XgXbDY6c9wyql/7yLG5eKraQ3n6sxrfFqNA3X9Hw2+9gv3jwS/od+cPOCYwdzSkzksIuiRqtIZOUdBbf3ExfXR/kciCq0PV8y4O5SZZO7Q5noe7GaKvL5UJLHDp6K3G3pnhLIUGasBlNY40KV9h6mhSq8IbqIvVjFltkaVZtOHhQDxT1xZuQUDJNlAnmR5lJTjaw/2E+zgT54Oq25JKIgioRs3U4IvMFYUpfuZPmAD4sgCANeQFIkHktVfzRI3JQGjaQzPTIx9ZUqN8iVkjZ7rQ5oNez8NiYCGEmCuRIjCwZ2MiqjYEbHSKQ48oavn1Pl/m/TYeX5XcmIaNEhusT2GiMmF2VtWkItEoqC2VLNXaXY1ZkIIj+ADmrfvobrxeOgBm6pFC3rqI5CtZEFEv9wAIEprEwIalWSRfCcDYMxwuL7i7f05/1Fip5by9+3NFg4aldcJGnU8P9waVHqA6VR6pPSjhswr0Cgh0Zymu8wBtVtkk2+P87iWQHKDSL5ZBX/+FZ6EY3WfsqYhipPJVM1MDlkb2xhoaYCoaHYTp4noiKAXErjlF3YED32bvItMxE6aFRr+L4rnQUNbgr6zIo5y+hpkBMAzsWF69EcZ0vxd+LzJP7+cVYGCYu6ZAsklBasngB75uPwk+ja6R/DYkR/l4S0A7pRgBoW5R3Sf1eVyKZbZuWVqxJbwqDytSAxjStN6euDFlXxlq+oyzk2hgtHaB75jpE6YDNFSxebLBhtSCDod4ER/iOn7ATZziDu7hAf6Lh/jnwOlFBmh4MOdjcF3xEYAbAH4EuAVAKhIAgAOgB2AF4AjASwBoJ/wAAAAAAAiAt2YAMxfGe6UBwOUIeljhCC/hI9zAj7iF27iL+zjLqlQZ7wjA5VDBrNIT0QqiLqn/e2WdzVMLOhzixeBDQvuk6TrPD8DN4JRmqu2zukO4hwf4Lx7inwGjl/TgjoIpQGPqvXEwgDEpBKbJRG5w3HEZgmNlpZJvF8efoBXaUOOlEMH4cZ12ejkCZV8hMGqrgat01aF8102YbaOwLV3jK7KdmfCE51ZAlCj6hcPm5xX+2hdTInhxJOZkEyTF5dZljXhy55Ni1ppJRT2o/zC9HN0dz87imsnKLiZW5x5aLW0wjC48jAB0PKm9Vq+wG1sXMgWc/8Is90JWBlcwl4/Jnl0rHJsZP/yst+07qAsT24PtBQAkw7ZxjsRKOnEoja4/jfVED0wpwDGkIKIXHTRWZND1g9C6OyrVbcLaTKLKV/smUCMIST9GYyH5vOONMpQdqxcKVWyR+Yo6ukpUW3fCet40zSqNF7uMxFCFtopWbGaharS1tDXK5vQs0+H5oHEz4jx/mR2OGAFDT/VVojaaq04OxnqmQ7a5kyiWxvYPZtwl1JLak55CDYy6nojFzoVY2/XX+YpWpRkD9nEBHcNCMqylhxRHxzvghV+Dgz8tgAN9IAdICMcJwMLAFUy/ja85cMRORXTZlbMUPp0WKjE0Q5z9xaaiQeMtkrVm9ancmTh2QLmdQwo7dJviPQnz7v9llCufNyPU2vE62BXebqlnqe724Cnd4gyBcfbPaUjOiBP/DVlxJRd4Da1yrtDqncXNtRp2dl4jqMYOSjy3Z38Jpql6UN2GbQCvhjFbIjafdKCprjrQVnIQFsYGgCl5vhzXS31JIOtogLKXQENUGQRUQ5uPkD47p1ESoCEqHFpDEmlNpEwVuo2aWV/bzyE2dqyX9zKwQl6KtLISEJoEgFjQcjI5S3QlzdrdZKoHEo9taqvWzJ7mnGpraasC0CoXKvsRhwOf0ZVJHPMlV415bi1ei9fitVjGMgDWeWsS79n4wHlREtvwlHDmb9+RajIqoEs3/Bq+vYMdwiVTvSuwRW060OT9F1iwHAkSP6Dkea8mETiMfhZUobRrJUqnK3LF925KksYuCnUMKaISKRwPeXSZ2341oXwuW0yTH0QZcUJrZU0NifWX7i/pzIkxKG0sRBPz4WveXUwLZqzyxhzY6dlvEKVWR8JJ5Yb+Z26CZXm7lAcwCSZodStuQ0eYM3UueKRxxBEiDgBMPNUvlyeCktP4FqpeIkmcqnbp9cNUY+h+FljrqcAWJeomIjg6l1A1/2E06Sopf9EYGS9LANA8vIGkA3gy6XuJxqNbntuCu/u4sFsUfyrkjhW81Mt0Fo9C1qyG2aUPc0TlMMlIw90sSzmPmcy8Y6HPhqVREzakiQndL3+9V65GojThyx1KbFTdt2lzdGq7I7hHjUyU0AcYymjb+sqlbesrmbatv3jTtvUVTiVTtxl3+zhDQIcrjtrWVzBt54mqqiI7NagkwJJeoqt40GX6g0N0qQ/vj6/GO3z5pt1kHkRlpiaQGSZh05xouOXmCizb1l+caZ6R8NscNzk87/5F1SBe4qb53VxKN4qXUGu35A3aAfi3FfMS6iOU1vkAg8HZc/twZmABe959POmmA2+u4OH9jrx7XAA4tdAqlNIddPvdAKP0iwwXYAoBQ3spskv7dufpRQx29sIaXsN1nJdWDEhTI5/wAFkjIGwIQY7xli7M/bOqjPCX7cU1e8nZHAjMgmzw7ZpbIdL/9qP+PawkSuUVANllIP5KaGuakaS+xnd/2ff/kGCz6l7gwf+nQD0U/PMWvWKGmqoGOhxeIy01WmcHDEyzoF4Dah7xEw9Q4qY6mM5XT8EF3vwQDKGRR6lQysxDgwTSz1czJ5fX7wi3rdYJ1God34hDdK2LdGdXz5HRo48Qh3dSkgGniweem5tyukW6+mxHVpQ4rVc3yhsewfpnBAFAL35P+z2e/f5vmPj/AMD/bpXXLAgAPv3u/6rX/s+ex1GBwFQEQMC/hb+38j9YI/j2TEDu/8CMshYG+O7pd61FfAfJ7Q8CPSecIOik80r5bBa2G+T6LeV8VLPlVrp+XRszaKV+P9dkr4H69i/xSnJ+uTL6lsXdBav7h3W/MO8l7K1ku61K1ke0fUqGMhTqyTy48Tu0g7j/OW0RrffbxknVDVI3WybhYcXLAfOemc2OKlia1S1mtSy7+RnXfniLEhMCEQtvuCPVSKJGNIMUSchAOPwXU5iWwO91TsItFt12sXDe3HhX+OdMy6VSyceXXC0tykPHAb6zOsTRDPFj394lvDOeiUsdipR4cdCm4SVBsWT+Tq9y6322+WQP2/rIQCWxuAibWNxyrM/yJH/oFxn3ic5o2EdpuJRtEXR5QnqP53bCbefZNr69JqbreHuaEggxcFECi8W8Xwi3hahtS/0/kjYWm06wIaIFiRcWtDjO9Jz7jo+tXyrtT5GEwIUDvyHI3OvfR/DjBmOLwIFOKbgbd6hYwbmvdXAmg1PfIiDwwltuM6q/FQeZw9dElXCf6wCeEFkx98Ho3u6H1O9cRvCn7S63RXzrgGvCAeyOrGrBK2/2zMe1BWkPipvOieuEz8ef3cDuNC580gqMxyqsgB4HMQ3K4Pd6pNvcAr0MPejCTTPbbOlyk39CH4GAjOpYNjZiQADTQKH+QkLAFLX+B3VTgVPSyS3Es+ItgklskRIotyhhRh/SOGBs0QkFKRM6AhfpDnE7EcHv1qVKpwbtujni61LN+i+jTac6AunipEgUI1WGZjUGy1ahVZdonSpUalDFT5YadXo0q9ApT41OpL+sTSssAF8AfwEji8FieRbLNvi0sR0gH+wBlXKVO1ORmyXatBtCk66jr8CE7DAclqShOr3mG6rmsIi1dZeiahQ1qnf6d6vGRwDoVyN2///wMgKSQpKKFSdegkRJUSRLkSpNugyZsmTLkStPvgIyhYoUK8GDQ2tkbGJqZm5haUtnZduOtQt2XbSxZ9+BSy67whcIRWKJVCZXXExIRxQxZCATcWQhgSSYBpyLlafbZbcY5rZyZsqFAZp99ttjr5NOUTlisy3WoqzBYchIhCilylmIdChTTGXemmiyaaaabrkVxjFGF62CiS/kvlLCXLGdMMk6h43PzAQMCxzVoEmzRq1arNLmvXadunS4o1uvQXqaYbAhhhluqNVG6DPFZyONNsYoHx1wzhmVtquyw2zVzfROjbPOu+CiSy67otZV19S5YY6dFD656ZZ6t32wMEvffKeOVRgpS3kqUpmqMMMKO5xUh5ua8MKnoaULLwL33DfTDBJ3Pco9dR7nGVHEkUQaWeRRRJmGqLL+mA1lAgAwT9HXyXuAHmvQVt+88nLtr+n3qgwCrX6q9PPHGunJ/uOzHJwWD09Gk6/RJXP6LZbkLP1ZSvKrr1EmJVcr0Lp6DSFI9589lALnA4T50fQOnD6ZmAw4YIQQShjhRDSTbQQgkCCCCSGUMMKJMMrjoYQ8pTLSdTAax2OACSGCQDW49knuB99c4bwPPwl+MDqzMvDqeEMfG1x8/LtE5G+D7Z+tKPbnwTbfiOangjD7FsvprYS5X5CQ9nDEYyIYf+/Py665oBUDMB6+scftW+jxI7UljuyaqnhOo9xDXvWYXeNFrqg5sDJR3RB7w5M2Jun1EV94zbFO4axd94JDOxhrp97zrEu8PmZtppFQjtfwjMt/ISwFUJ/pS5943kbjFHH//s7LT5hBfZaJnoSLO0XCv7zTlHdUMD3p2arcUHnMxlxdpxva9nVaObui42lXdBrmpp84UtTn2VgaSNmO1/ekSwYk9AReJyt6WlvoQ8+7Yi516uSXlIE9CB/Wo8QvjpTQTyU3yCG5bXDQL3Jk+kiNfmCHpknXAdsUpEMg142nAAAA",
    "plex-arabic-500.woff2": "d09GMgABAAAAALDwABEAAAACRIQAALCLAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoQIG/9yHKtsBmAAjz4IUgmCcxEQCoX3OIWzGwuUKAABNgIkA6hMBCAFg0gHgYU5DIRaWxQXkgjfO+7d9X+hYTEydg3vrpk8GUmTOkKdu/dkpnI6NhWQz2bWXwsOsG0aH7PejBgRlX/h7P///////0XJRMbsEuglKUUAZIKqqqpzv59Kc3fF4G5uEZmOhmgirIBGt0AUy4g2iIhsAQO9NQS5gdNJdPAsvB8wSo9hClfy1l3MmxyI9ovDTtgCulyxKPs4HE8tzk16w77yhSqvN7mDu2tmpmUzG67ScWjv8qGeqfUpUb1engVzg3IvyBTUX9m1BkzmfuwK9uKd3DJFJx/NGO1qcUf7LVdhioEaBRWey7QxtO8ZVGz6om6mjUYZ0isfWZtvt/3pBBsrjo2p0ylc8prNQRKDGfGdtxjjjV4ZcJPPoQUpvqtv6798+vfnKHJpcpbPh8p31WsNaw07FJtkTnfOOISMhP0ScRY/6T6brmvkv+QKxUHaXZi0OlYz8auwYqm+4qhRuEKj9r/2WS6SuFGjShBkMqPyJ9skb1VKbY/qr8qLGPh64BfzTbGd7IQZPuKIXMHVhfWt/alT/pLmWo+lM4X+Mc2YyssAHbdbKEKsnceQu2pk6HoMnz9Pc3vv/3932203xhi0c9ShI6wGizISo5q2g7KJMgMwCoxqIi2MojYAdkvncOY49llnH1GdsaL6qJDsc844ZM6MrO6sjH3mzOHqZOfqzGidXYqcR2UOKPixns3O7v0Dj+KVUrVDpHnJxEgSD02iNg9F9B7Px/f3X60dcV5mFvR/ye4egSqOGsTc9rsHcjmTLYByvDMzUq5X/v+fe/439zpfU0nDABuBUCBhwx9p927per9EO8z1jRYllbSb5ENR3/gh+B7/39wQi4tYhOX7Ry7ayTxSWUhY0ra4RzObye1uc6vmnDi0IpeZCl1dKcgIdlu4WmB3K18W0AZk+38/p0kKqqwmUSGdJxayekB6e6PX8m9y78+Nk4yFJFD8N7We387/Duh8/rfPOUdK8T4eJSwPkcW7lL1QlhjWuIQaaik1hBpKqCXGUMO6PsK6lFJKqOUZlxCXGsKyLDHUWpcay7Mua6whLHUppZQYYoxhXWIIMcYYY6mx9sUY4vuxxlo9WkKdcTCl/lNM7paHgVHyqLKlyvoPIiD5IfoHaE6jQLCYXHJxIk4SIgQLUWJG5IiUIMGKWIPoKlBbnVLxba1PvDNtv1s77Uw6/63zytZu6tus76776w4n74EnrJEjpiumLZFzTkx/k18IDBIdwiAhYuDJRq2HWbSZUmCRzkXYgCeemA2f+POXAlBSOK3yWqARgEbmgW3irUbz9hArKrbBiAI2ZdbZkM6qSgaRhSWVGCyLjNQwvdMz2wvUyzR7QBFk98TZURI9UQ4UYRA9D8y5VBcKp9MmYveJWiiBgXnW9BDCZJ8KAB7yl+39uSrczbah7dLiTyElQiIRkhCPIp54NEEJhK4qW5mUib54EDezIvSMVxzoVN3nKpMgPUhm6ooU7550pIQnfsY2fEN4AS+oqgJVSDuj4zqvrq42I0nua3OOdMGjt+P9Vt5PeISZU8UVL+Dp4wJ9MwHZcAAPvoQjXKlQW4eK7fgKXhz0Pj+Af+tb6w3Mwl1X184yfSBQAWFQyLw4mxCIAajotg8aJZiGLxh5DDN7EGgZkxMU3QTViZqA3do/YCb0bjn7Qsdj1cNi3TpTsIBVM/+marX/A4QMKLwFJecgbYotCYUNIdXxQhz8meHHn48hwAETAHLJbJCQvExKQ+mZgxkQwCBIgKi1QGfKGzLttTdEJifSgeGS5CxuzrmSO71rKl/TXp2qy+UVTbP91WdhM/3e7qQguTGQhu/x+vikNDSpkKp9GfPw/fKd/YeXl+ag252vCIpBmFKl3NTl/sumdkkVCtWaNUyUonmP37es2e2pTXPE2th7ufmkbozhnXA8j/ETLk0X8UJMc2ShkBp5KHCscCAkPHwsq9n+82pu9y53jbkQJWDMXErO7/TOxn99DTvkJqXQF5IjJA3CoZIC4chG4DEGaRDG0RJIosAC/z7V9Arg47GJtJdLuRW5yWk3zx0fUGa0TpPL4RbPPUfy4z08LcEnrQq2UVy5yaUptfADygxAKTNaue+mtls7lXrL9ZTAP7V0NtRmZZBEuDMyc28edEV3hn+7tI0ijpz/n6p9pbr1UCBnPA6lw5gHGpdklNSzxn538k1CsvCK1YXHh+qROPpnls3VGt+/11qBoLpBUuNNOEGSb5zMZr1LGDuQHQ5Qvg+jKMrT9zHjMT3lTqveWOzfWSXu91XOZSc34y02wxLG9tm/pL3KjZTciLsWjYJ2WSAJ/Hchee9/LsWVRowVa7q2Yxp4nO9X3x5p912zryaEwYggjBDGGGOyoQhF0fTMffwtqG7ZRasQEw9BsIrTorsDQeQCR1YUuTDO/eWxKPD7/fTzUiTJM9XViWsIIgy80tqe/x3Glv/fDV+3fyrRYh+cAajM/3xdfo6cV+vdDDYgjLGEJNRxx0vSf7f87Kd9f0m29M91nZZMSWKBCAZUpB6K5c3Xo2K/Z1jeFQVDMf5gEDFZ8jIbQADqFYoIoXiPSKSCpEIWtEFHz4YNO/YcGRglS5Uq3Q23PXx/5DHiCYWeKUSxL7754RcxZRwl6i4MRHGUVcXPeOMmY/Tk4Km3k2YH6XOcQWeZ8pAvnrMfOciK93JRnpfBwk22xlQbrbXXRgclu+WYu07E/TB5H/rR04Iw0XJ853SZPERFCMkYakgRljEOUCXAYJDSMDKJcplwPJXCWU0ralpVl2gw6DR746zfwzAEGTknyAcm8b6Q5zdyQWFZ4pw/BLIitS4/Nw3YMzmwziOnHNudesT53rQB6JhvAgwBiHwMRS9/uUcI6O85d8xY0D9kTOhM0GMAwJwrAETQB789dybI/5u9wOmh0/gJegAEw4FGTxK7CMCf+3zLE603bLEcDg0eQsuNtHYp/A9cAhN+GnQvsEM3fMYrF2xsj3nAfVaWbfXO5s9BJeaZ5QZTTL68Cc4HjUHDB2ZseZB++uihk3aO0UIzjdSzQS3VSIkUSKbWYiREPMT+bk0gmkoKd8DWVl+7dO7UkbqqXWVFORnrViHA8KMunozd2ZirnvLmnSL4Zqf/lwYP7tuVRtZV7EVcZ2JBjLmHsfbu4tQ2eKYkPu8DNxar5PQ4I4c91kWvBUuZlgr3psOUpBkaI9clxIgzniJPI9XK8HsRsy/+YBJcnhaXdZMNy5jpmUZEZx2kJhbE8WvCeiZtFsfGyHW+y9iIXinEAq5ON5qV6FiGjqg8esqwSN9Q84S6My88jaaN+yVwy9f7hjEnGIpE4whkKp3JMqPk/lgqV6o1Wp3eYLLYO7kDgCAwBIbAYHF4EpVGZzA5hpKIJRUXBT+rNVqd3pB/tzs8PJ0uL/c+HbCOACmayWJLB1zgX72pi6J3m7ndzcZqiKHq9OnVTUpEgAuPcR/7mm9/dBYncdjX8O/zp74dWzalrVmxYE7EbB8ITfFyGf+RUd+wQQP6qfSQo+ZI8AMufX4wdPCp4D0wywdDZ4muhSpPkQMGyJX1ZnV5sYlHQ2ZunDbJzRG272yrEUPfBjPQ0Zg8JcBdfjtfps2NO/aAkcvqS5W8DLyuRewDmJj1adkdIrhgLmqWBZPnyZgFa+MHPQ0Et5N/CfwfGmKuH4IgMAQGT6RwhQqV2WpzcHR2cXXzR5JZfKl17xU+CMFpn6f13ZvX+uLZY7135+jWXO4WfMexXDv1O758eLLtkX4AgbCyGFSh8Bs6G+MtMTABv9lCDEPbiEMExn7u+T4+qtB3WZdzf6bn8ozNwHTPsWmaGpaCRbJYrHRdV6NqVa5srVS8guUtW5l5qJvz6r/fe192n7zPuk9jPsszO2FmPSu5lblM5kKG0p+utKUlTXmehqm0ypmiQeMuruIkqrEdhUmrLLgeiZiLEDPG8sREWMMcA9F3T3GPwiSYCPsenWj6uR97zcue97SvZmNiIhGfcZ+73OBqQk4ICDZBn04B87W/sEtr2EfTnpUtf3HQvUfTksUtKE7okjR5zWGWz6U/YL3tsnayndVOY9zoEz3VA93RomZ1RRc1pgGdVKeO6pDqVcXoZoin21gde01W9s8dVXsvY2Ey89eN2m4pvZqIzPgyiaBJV0WGAARxxWuT2yZJNwi6mFiOqjsWbRFnti8Mt9fWhSzdLzkNOlUrVyRbOlfTH/shh1TZZpMmKsASST8ZItRTQy8y+LA4u2SsahtbHmUT613HGlaW7IITz73cJS5y/kPPaqYz3K1BJzqeMdGqbnet0x3s67a0qtl90ZgG17V2NesdMZCYYyLyFSwTqXLDecd8a5PF17X6w7gBMEA7qJsfbdke19Db6u7VoHwT7pk2QojSrLMTdkftILYaRp+tjrH9jloNS0wVLTBrZhtqar2LeDNaN0NLfqaPtrqxr2pZgAqmJBveCFlL1RyYwgNblhnlEDMwVdjZkfCwFwPEkuEtMAXY/nNagEEWrUNK+wEDGVdHIO0FDNw406sjAwwEPjp8KQkIVWUUGO9DtjR/FmC8A3K5/GmAcRHc/VbfgHEWhORJmiD01UttsdTlnCLepRwgrPHeQ6CLKScD32eHuyrJbkM2/I6spmDp2SzBpJaOH+k6mHCPW/I5lJLRTEEuGYkbIoZcYjc8yXBG/d7i3mFm1166JQYwnlzmn2nBqAXu7rZVgNEVCIlU0t27evUvoRPI5rsIAaM6yPkmHMCoAu6u2gzAaAsE1fJdMHzP1QzXfxe+Gsc5WQ9DonNOkhFL1M7JQkhJj/VaNCKJ1OdWWkVxPR+FV0XhzflZmBQCnbkZXJjsUNduZV+QtIXJG76Azjs+gZoqu44eatsV6QlCBK65AB616AyY1LxTBlMLXnr192uWI6/RzNGk34g71bDd/lwdetzeuqnaZod8QTfsKkFQFhAkYhYIbYoihTXLqQEsW0r1Hc9bRilE9doJsouGSXsOeXFr7q9DuBctE4DBj3j9xjBGesUzV5M3t6lsXN1zZeHKHitTbW9r6ROQUTXr1vZOWWL/5jfYCPrhTWc1BdimaBnNme42tItW17MNb0y+cK+SKy/Mg6jurBzwDjSrbQyOgVl/On4IExT9LXQw9adGDbr+gp+PrTy1kgMhOHz9y1chCIDqc2CDoC+pHzB7BUF6SsWZlveuNMb3zJFjZIcP/DvjDhweIKyVL4EREw1v66EDRhgZtp1jGFrR7lGu0yAFGrgAV6CnBELQD3X/uO60my2Abac1txgSFjrffMjUdUOMg/WCJPbWHT5TXs+IlrTIrhp+rK0jzGZ57eNgDf6zPYbs0ljsYdwuh8I2IDo30PHjy2mrUV0E5XEPQRe/vS7b76UwiFr1IAKVdsxu2uWtLb37NsIt7mbyndiAqNP86Q2vc/Az3R+Qf1YRUzdhpyZEmBWdYtWqU51yn9HC0dDaR+A47Aj+3TNQ7aBzK7+ro6SeL7CZ53Vk1vO4GnX94CIhkzXMZblyJpT5KpUG4BPNNFy5XPFjW85X4ozk99cdJEdGDrk5XW5sHYLvKV+OtbK2VVlTlxMm50gZTDQby1wXdsns5w/0x6+1+8bCNR0EEr/b/GUE9oM7eXzC2JPJ5/DP5Wyxh7yl8NT7zV4XEeAeTl82W4iOC/e9fxF07OBfSeSZ1IfNu5cGUbwZ8GL25msfPLtt9Av5fA0IMPNikptl2MlubJsWlQ8FoxRMGGKgNHpaavpY+l+O8bsDgfbR624i+L3LCxmz/ouBr4QhGg2gg/DlkhOr1uP1wmw9e0xMt90vHvbUtVq32t7OTxhv6ecig5Ha0gmMVVQdA5VXxfRVQVtkva4gq7gy6+mvmFL9FdFSh4wqvlQHxD3J601WUscTnjqroFrvxtmz298qT2mg7T+bzWmtc0LJiq45rLmmW6GmUX52yUtFpUtaIkYhiFkBjtHPUYeI1oYfcuThRJzXy4G/ffQixg9Hen8kO71L71MbtyGGPSIyGcZmG80gJ4vt55tUXaa8lwvRpXvTEMaSYJ14XUqY9U1yDE6sLtG3mondxQOES4PllRTjxdCfrJ9RCOEtCDbjw1X1j0d92REed0OV4njFHpgbm9ONEM0khn+8GL7xTowuVin1rQ0hvAPBYuNFijmrK7WUnmP/mO4TPVa73o8/lYf9Y7i3d8eVLozVnOkMJztFKUpJ7raKdIrQ3y7hHXYxkd5c/+vn+w/mRNI2O4osT6e5pmiZD0/cJTsQW9mvYJxVL0fjf9mI03fQbfjf4si0leIsB1Z60tvkI0Co7f/NVMd1NqmN3SjSaOV1A04B+oZytlxEfK5fRejR2D71l5jSJ36BxI6JD0kiqdz384Xg5MXV+KLLBGqUF+JrsWoitHbfSB+CmsOrAeknpgrpsau6RIAgm9YmZAY++9wQhlYeDU+frPJyokr65V/Hf7bv/5vkh/9fYrIxgu+F8EJo3+O1q9caw4Q2UgVMvMmHfXPE3JXyxTWUP47joHrEvortLDHIX9aGlKSE+YgNwhe0ISUpYT5jHcL/bN95znl2jA1b+j7mYSN9X1ul+8aKMJdqobJW0JWVUKZYavUhhZIykgc2ggdttvNEd1vRukLXgy54leRllNJ593SO08rJflJHTVl1VbWrsqmonDNTZhbrlcRqRXcZi+IRfde0kJBQdwbTJsM9cMjGaqQYuuHGvLdwTYN00rzap3e4u28gHRYR9LmV9kUVIS1ZYpzCXLa3ZdbLPq1ZlXiRrPopVhlRodnTzbVLUTSfUJxdITgZdMGrJA+jGGrdvTkwCl11Yi/bnd3awm6GtLVYySUvF5iZOScZEbMC3Snh5TLRFNgzvqM7zGQwBubrZ5vrrP9Qq95/z6eBvPD2AJOjCvKG5XsLbFuOgIneg+nOmxvmGe9C0uvneRW6ay6mcY0cx3FQldwnKvX2QanJh56dnY1JTVIkhucH2YkNhwWn/LUv3Q9XRKz0jLO2t+iOlYjdYhnzNeMwhr6S1BLqWnmgaGSh8aB8+xMfCiFfLW6RQg6EF8JvZncSZjsr7TDh36HluntZ6Z6XVacLofM86vCh9v/AOt+NUte7GnaV62KJXJM5VKFcV6uWY7GOVyJXRyVC9UzTMWeb7tOPj8t/jIcn292OYGM1EkNpqNQ6xl5Xg77ozW6tpY0q2SPiC/hcLIwenu643dLxogX95tjrPsHZ0knRO7y+o9aokqt07NWOxVZdKLGZaaJQHbprWLFkwc4lmUvfM5aKPJGzMrDUbATo33vlFTVVXoNyMZo5QYwbHWt/mMlgxWCg+qmA6Al5Uh4KhWrJDj44mEFPAIAefPXdPAJzWO6+cGlI5aMHb19Uhre7JYl8mX0bmWJmZpJIxHxFN+ZFuAw+f/pkRukhnGGv6I55YWnNzyj0tKFO5aFU8GQprqdQiAc8HhvRo00/uFvJlqzN61LMYy9fMlfa8zzFEVTrUc1dLctZPJWrb2xb7mqZyfVcrczJ2lzORYl4RKsWQmM1053WnJZmmXYy3RsHW1jrkcO7VKaGWkPqhCb66l6J7lb6QARBcGsWwXgSx228oGjeEE9wNnzisKlVxtHe3g2xg62lgmNzhl56YYtmvSbOhk8cNjV5W7RewVYUconFBV5mYi4iMRsRqKdKeum6DiZivB6VGGZ6W3rvwRg4VIPvxMJa37aISh7u56rAhJ6QJ3VIkgGfixgHM+jLwL28IYEZ8nKDe9vBYxwU+9eywojBNktnz5cmy9hrN5hCskkc2nnGKMLV2/FIbZB+6foKTzhbO8cIy8BMI31oS/UryoHiFVmIB8JXeMHeTfCDv9b6blRLw5+vM4Guq9rNMopFbptnfN2qZYvi3ShCZkyb5Oaoc/3nEm8rd7vNrVdp85F6iDRsqTukgdQQffPR7EU3aYhqQSWsyd1qljQM7z122yc+KdyeEF5sQPNpeIIzsxOHURvsYWd4a7iwanMhJH3BBR3L+PJVXIc1lyuqt0tYwJyI2W6gZFacpi5DXjm5FkxgnKMGNlwwU/m6Sbu/6sPczSfjJL2vrokeDseSKXWIZXX89VamwNiD9e05kDbNxNynjOUkMLWcgamEWLRg1mQEP6fCBWdzagcuKqvCmCbanfKG9wBuD34M///dveiuDdt4V/U8PWfS/+/thyLqTEhC6+D8pCJqtaVd42rV2NDkF+MybNfGDtntOtA4zJdPyqNuIFl6FPRH1laRkCL9l6/lUUOzNA9WLIM5L8fujWl4XaXtUIZS5KMMgL8oQxlKmP6eVdbUs444+WlLKSaaJc07YJ4PeSd1oEX6U/+P1pxpgREpofQFJpcK5awWdsX9o/iEilM1SYA1xaTqpix8CuqdpK0H3TZ7I35ooRdTWjtL19rfv/HKtgnrs+u6+e+UVNl5odMBX9qSSAI0toKxGIuxGBu9D4c4LJky9Soop20AHmvHAHDfTdveLx2P0ra/pIO7bjqaXG3bQ+fa0XjTcVsTjnZVw9tsbJGAZtZ7jx+7UIprAjrpUdEXGfsF0Mk6TjaxWyZmcVlclpXF5DhmcVeyxtMN2pLNkhz3+2l3NQuuYBImYCImYzImsFIqR92M9L08hKH7Nz3YklHZDs8J7yd4FayaJVccJS86qGhrAuT0y2RHVuVI6pRWXOpunl+ouSg6O21mkpvKO9rBaay85n2nf+qdG+kw75vJwx3/CUiNDrfJuzrckj37c77/qQ61VlHSBDVrUOTRnzYRf9W76c+E5RrMbZCX7BxqQsNfzc2fhVVNNH7XC88YVQN/pd1rtngNfcTk51I44llz6uhseiP9+ik69B66sxmZHfVV/zoHAdxoKmPE9E1lknpHfhldqYpCFKMIxb58K3/vqrrG+YO3FYGu6GLnLq4JP5/75dAvSil6tH+Wtyt1zTECqyUnr3OG3PQdlf5//yUgugV0qE9qKOt+3OyrWVsl2JnZrDQ3tqbS3GrSe7TsR1lel/4IRHOOBoBNZbtL2IO54FTgYBZrJQWp3bv2RSVeL7xpKR0OVWhK2rFXvotIKpYE3zqooFfXNhQ1FV8JRqap/aJAEuY2R82n1PnUNqq2M3UB4zQBbFcI2/ScraxUq0O0sBopejau1hW2zoh6XwgezHLfn19aWzPEdzHY83FleIAUpEyfA1I1DeB2PYc4qGzaHjrULg6eweZQJ9PRk9RB+Xqgm5kO9dShUGQfMlADkYA+oJydr2riWbtBoyAImb57FbAhaeOyWr7gaV2UrA8PU7IVB9WXqxY+bcz40omM61UHplbpuq7ougiPh5mzwxhoCn1F02Bq34g7UonEc0FqG9DIMUxsiwkDhdu6bK3sYI+UDHZiOHbAlX+wcfMljdtucEkf7Zj+zHRoXGVuTIgUm3tZrDXinvuhodlf7GlnFFHFqBGfR0i2STH0ZX3PbRmHBJS2LKQjDWlKO7HIU3czx7hSLYWXoXS5gsu4+uxyvun7+vuSs3x1kIPeX/cBftPy8EvLUdI9+p95GMlnHTjaT9dW6qbk04jUMgDM7JD2K/U9tDD25+4BBqyetTa8Vv2S0qiuCWlI6w/x5NnUQenrISPPBwsZe0NavT3sLIZRl8qIk9KUkCKEkYDLHsc1b1dL28FPoYpozRu5633erowofDtXgGeXAiCaODwNA4rhKYnUtDaJyRxXJxdcdA/FvOi9FXphEC6xkMfiL0GSLBgpFpw0SatMyvHlfdoTyXBGsZDFSCLyOL+RExfzOyrlDzzKZTaqyDP9yRS4OgJwr8b9MVcWdhn5SpmT87ja6rmxTvWJdz56Jq4iIdnTcR6465rp4GqiexgaIUSv/OXVNJ3BVXsZp0oPOSrIquEDrDjBJOj+ErwVPieIdvMxx0I9OezBeDbiSi40HPc9uW/2fMx2HdiPimwrycvGxiolKWE+YurDCPKHzzycP2L/iLGahZmRnpaakiJlq4LNSwwYSE1rFcC+qT3u3bqAbwHGBBxQ8yA78yqhLt/xhje9lSpKo06No9HS+xEDU/4E0XJE0Fj8zJ3Kd9DGGjY9iBIDeTsC+oMopn4GEO0l3gNNAWojqf6oytxODH5yZE7OQzPRXwME38idz07UlVyP8AWgGnEsB/ajwtPtX5nT7ZGXrA0pSYlmHgjHIjwF+Vd83oIs2JbbPWV+IcPTOAFljzFYmPtU7qsUix4jfWhFTUlBFuKVEA8bMaQB5G4P0rLrmy+B0Dkgp/dzFPVa1a6yopyMdau5/OboLM3t29sCf/I0vmzk75NzRlLQZ4d4u3V+RvHx5Gv90dM/Nv4hPlJccaCPwar/ckcPQENhpmT8uIK/6NP+mNRUHz0qisBP4jf8rX8jyDc08VgfNMIH8oZkP8CuoK6PKL9DDiRIkE5megQd64Zz84ICi8TqgTBRNUPNilJgcm8RxZgG+sbKtSb0VNseTysvdMVkIBH4RRDGOyAKF4vPzVgN3IPoR9l9wJY9B47cefDWRHOtteerK39BenjAkhVrg3/5CIQSG6MHlYIGSXs4QB6UDjgWgLgULvuDGBM+BwPRINJDCstw7kNMivZFvek5O1u7ECDWHA6IXYcDYtx74mHCioou/L5uBCOEImBOxHKj5gFLyXRSy8oxx9uy5MRV1/7SnOXGsXnLi6Hleo/6bdtw/Hp7cEYhDLRAjoi5qHlEoVTCiBYe0yKLH0shWk60imgDUTyVHVSSIJMNRU39UnVGxBEpU9iMVMbvhSt/76CoHppGOVCrxd1shq8bm9HU7RGb7jrxkl7bTJSdybMQEBYLQYKWjuiScSmduVZACCHEMAhLgKPTV/gWBC9p0PA8K3B4X3nr2q2aFXWEgQoSKlhfwdoKIitIq2BrBbEd3YX5FRrp9jq/4CSYXp7ylb+iFS+kkvsGwYvQeSLqPLEgyfILFlTQZURI9sLo/H2SUA3Ncg2rjRqu9Rq+bTRC22oUbdAo26gR20Wjatdp1O53hhdJR8sc2J19HZHO/HGEchC0AscAyIRZ1Hrb46f2WZBkoSlN72a84XpBWhIrNuw46v93qbKrtVGCxJnuQdNlYRfJ4rsDHD3O1/MpOHqejxa0iu0y2qKJd0ILQw09LKVSGqVTRpCZqvFIIxOfUimN0ikjyEya9p7FHWblzyDdHUZMZxoEVmPO/s1+Djzf9KamXOBtX+1qJLr8l6/jh4odlwIo36Vf3Czc+/XpodDv17gZs6HboTWnoOvfdnwDvg+ZNW46tP63yW+g6XXTp0wCL8woUtgdEaKKs4N7i+CiC6Tdf7PK2qzY7amF+P2XVUwZ4/XSmokTpHTe3fQ5Fv5uNxHeclJOsGbkj8eefgH4P6LMFA0l/2o7ZoBjrjnhpKuOu+7GNHIjN3Mrc5n3zHMvvKxBDXu7RjXund7tvcKrWa1qV6e61at+AxrYoAY3pKENa3g9+7Re9a5PfetX/4G72/0JTmjCE5noxCY+iUEmOalJT2ayg05u8lOY4pSmPJXBpjq1XZ/6NAbfzd3YLQhryZKB/AZzUGJSlNohygyrvRBjxFHIbEBlQAoxPufuqPJgd9R5MgBS/fIAtvr72h2OOtmGcLZcb6Fr23rg0tvdQa33uod6HwwILQYjs8MfT5n1ReSjQ2LNFUSPItzooSAACEbww5l00MU8q2x4O5yPxppox9dU9VwHVSY9VPmxfin99SJEibbCardRSAf1ACgemaVHHsQxyB9MPlDZnmpobhUADSYdVAisyXboif67Vm6lcsyzOitTP0QPIuA9CXjm3cC6Te+h6CkNx653uwu097uP3AAPjgkFgFwy4IoL8jEGMv8/rafyBUKtv36YWU1QsAMlz/OOdhj5/2HbRtJ8m+U9TELutexqeWXic+9C79QvGxfiJfSivt21L3Tec57NHs5omhPoYbc61oYm17X3C62oJN/abp04szWTDe8Gm7g4RjuC/LPmqgyxZmI7nb+s4yFV3MwtPzaj/ND0fNe8lu+4HyKt+0FdrFRYmLf8KEmRwm5BhhL3lW+nPLn7yvHNls2zbfi++t/6vqi+WPPb6qOIdeFTrdjd/8dM3BjY0XVcKMazXvSsK8G/6fwhIXLOESL7EBBZaJ08Y8K4MQlxjQcCWbDWGqt1aJc5kDbzVrnLnFYtmqWrzliiPZwp6hQ4RUH+NiqwQvQSpHOxk64A5cqUBn/p2nylS/OUzs11i7F5t9Q3951WzXm6fDaDt2pRrm5Eb15N6WkoOudLBF1vwbmkU8fZ8D+6qN2rfbW5oFXLvpqd16TxdAPNpkfby0PVnFOvTu1bAnlqVDdVpG3Sn5oGXdV4+FPylDu31wqa89GASwGThsHRhlIsDGxM9HehFj8vDzcFuTKyd0HzcXFykJIQH4hITERYA50K2gPRiAoJClBTKaescee1ZQfCrUijb5DTft4TxmyV17Bbw3otmzTJkY84Qk0uLJDJ6OkTPzKhZ0V3PpYVTw1NpfhOy4Lm/KRqCMgkom/UVMTzU4Z8Ah7nKwUBf2AcD4tB+4KhyIEhF4VE+JygYWZ1ahcMcGXtVNbSn/n9x/OrLIYDh0HzE15NVvuqzu9/JmwIGOSjf/760/y23vVlqzAtxtWTIrFs/LZU618zK/rHjpM0y4uqbnp/CbOU9NeKbO6ue+57sM68DjE9cssjr4JqeEPtmdqKpuF4VP4/V/bxiI4VPQ9Gzly4cuNOliVbjlNOO+Osc8674KJLcuW57Ipb3njrnfc++Ch/tMiQQx4FVKASRVShGqVjQYzDeEwQoSQjRdV0w7Rsx12tN9vd/nAEIZhCUAwnyBMAIRhBMZwgKZphbcf1/CCM4iRtu34YXzCCWrbjen4QXtTsZa4IEkIIJYxwxF0ZZYUqJ0xV1byuuiidddFVN9G666GnT/XSVz8jjTLaZ2b60lLLzLLcbCutkuBr30i027f22Guf/Q446JDvJPnBJb/7w2V/+ssVV/3tmlTX/d8NN93yj3/9N4L+FIAOq5dmV6FgwbUGwmiXKtTfd4jkiKPs3Wzp6MmPO3nmtXoKFHLdlMadcqi1AGg+q9ExOn2XMp0Hizo956cJ/WQEo/9DsYQskwljxARj7EMlTFg9E6ZLChYzZtjM7PVNmCMsGHPbd4TOjsqwffr7hO9bZonaXvZ5tsOcE5uY4qwKohRrklee9SmqwoasdCI2b31ILNhgkgs1nJSSTSZdiDAy7spgT1WLY9+qqDwgShgHH+riSMPnZk73fsKZVVTl2UadQ3/LL/TRRS627R6TxpHtwiajO/3Z2mmvp15662usXk9e0kbJVJtqpr/mWmipldbaaKvPTOZR/3Z9mEcxi3ks8jiWeRKrWMcmtrGLfRwIMcBAgww2xFDDDDfCyHWmK4S8zpuQM5LRjGUlv7MWatbzfzayKj0RiIIoiUhURE0s5ZKVaIgFaaGueupr6A1veku4mmqprY4G3tZIfwOMMdY4480xz1yrrcFbB778dNRJZ1105S9AoCDBeuinm+7HUSaqoAJVUTWgTZ545rkXXnrltULFypSr8MlnX3xTaceufQeOHDtx6sy5C5euik5EnLc9P+MkzfJhMSqrph1Ppr+WlZ2Tl19QWFRcUt/Y1Lw5FwECIiJXVE23aWXHselsjsfzlBiE0ew/Kiv7TCZ01Oqxs9GVN0lmp/zgobcdHwZLqW1EJmmW4wVRkhVVMyx7dHHsrXg1fr8b2vpOSfQwdqz12D6fi4dWWGmrbbbbac+9ocKkkUn7+RZIsnDVLVxCluHbMcR8/JU0TkHFOS5xjVvQcY9HPPM0XvGOT3wZZbQxxhpnvAkmmmSyKSOmO2/Tk96MZyKT+ZjN/Mnf/Mt2drKbLab4v6cEyye/AoooqqBCCmvsQx9ppoV3vOs9//O+Jpr6QHMfa2mgQT43wUSTzLfCAgstItwqq62x1jrrbbDRJjFixYm3RaIEm6G1HpEHEyaI+Pln42zUgE24n4PRoYoC6mx57aYcG0SbbCCnmYJ5XNaMf7vYaCi70Mgbyfn1yNqVkzvX3Z3pc35WNbdqM+KTD8bavBR6CW14Wwo3pq2jHi+KMVBmbY7OZg3nc3bOWkHeOeNVOGB6Ss99yPvWaKazCD9ilaVVT+Lrj0HV2LlKg3P0HmgDmbR1kUJlF0LzS6IbJTUNWw5SpHmqyFc/HUYiklGJfwLzMrlpSEv6M5TpfM2BEioYYopp1tnkiONOwmpd9qEDBeiqtAGg+18V70bP3brnGlHxlCMUSC/B2HHSoHg+BX/vacwgUPd/pnNrAbAHaPssvAQAINvIWQCMBAAEAAWgRyFy2dYD/zE4bwleewASozWbpLQ84x19x04P+8+v8bvua6YPdUt39qWXgCdsIaC48eQjQIgIz8RLkCQFRqp0WfIUKVWuUq1GrV4ZotKZbJ5ApHCfOelTQFBOS8+SWYjc8iqgsKJKLLXs8pvIaE6ytHEJg3OXXvfvKUnTbPrz/OaMQxpmdXYGx+3yqNv4g/hfUcAq4+pH+zFr9pBcuPPiJ0iYKLHF1WbKUaAkt17zreN9nb7ElZRP6uRPiZJGLVOPss0193wKKqKEsKWXW7jHJHbw6sVe6uxF1/wbDoiy4UPH7vZvxPs/vd+w/t0AZKv/NHG+AP/uSeDAR6boB/vM6gz54sx8uKqL6kXOHZa7z8XtbhMAEK4Ie39x92tNfhJd9Hjffi0SgxVeO6+Eqykg3MuAN3B4Hwu7XmMBALaFy7sTOinn42kOoBGsx7xuwDtl5F8i4P3g24VPio82+aenXhZAeSpSDdWVr4IV7Y/BnDO7Mm8lPbxQgB7b++HCS20syMU1vLT91TWrTZ3cynv0aeD1/QH1bXAjG9fkpjUboM9vYSsA9oB5LmBuQy9wjvOd3/y3stULHafgBPb7wsjuj7g/6x5yDnNyEQV7NtWIVHdR+VIqPxwEEvEoxy8BJEtdZnJSn+b0ZTBT+YLXigufLPKqpcdfiiuP2wZTWLK1dnsKG9rxete59XXtdMXD25r2Vdve1F6Jrk5Pwv7t/RbmOtvZDcXnxFaJIzsW4xna6rTLBRYbbjsA+OWf/3b4KigbaBRPpyM4sQlLeEISmohEJop0GY7ItMtue+y1j8loPnNNdiCfs5fjHOY0R0KU1Moneo+az0dlHfQRqaNOIjh2rGIFSnxSWklkfMFMg6c77HvbfGW7+CEd2VazfrTBOefddmcIMy5MnIrlX4Acz7ZeAGzholc4nGCs7ELLjm13E7spSIvZ0eEir2DLiWb/8tKab4gVJS4KUcqzxHB0BeyK2JTlTcSSPOu3f+WAgytkbmsRhxqox8CRvmZbQIoad4+iUq7nXU6U4nWhjDqt3KxVjpH3dyMb3c7Gljjsfi9pmK1teFvr395KN7g3Arn+xjWDmv9t1bLNsEMoz7DBPKZwEMYrvMzXNHws0Cw8RGuSK7KHIAJkHxnRLy4xj26cYxatIPMg2nHKQ1He8Ybumqqtl5Ya+dTH3rbUCvOstNBqDxa3+CUvZbnLW9ayl7mXq17a0le0ox2qroWGbhEvWDjv+s0GXTy60pa1q4QEcbjR3e5s53rQw2l3uKRe9HK6He3YrjHC/DrRyRn0c7/4faxMwzqPOf/qP4php3ndfvL7lygp6gXCyK59x2M3cOM0nOeykIUtahELXuTelYH9Lx27MEKZWHmZWU5BrLosLLEcKDlwYctYTRLRsKpJl1nNl5rO17HCXA0rzSx+hpMIPv6EmyiNIxnNOMY0EoEHEZOoxCiesY5/4hKYeFJkSZO9l8ExSshyU85Yg9aQthDTmZbg05PX6c9wxkPOUN5nMqOZzkI2s5Kv+Z6/WctBLuWRgTgro6CsxFOYxmrw1Bu3TS3ESJ8bQ9GAsEK7SjHTfHOsk+CIS477g1U6NF8h5apouStWzopgq6cQ/XXQ2zABpuuuqQY28DXeHAtNNtdEIwXyM8MwAOrZGnWC4TMHvhSgrrOoqwh1jUZ9fUANUE9BOQ5fxA4rmhFM1+xHaQ57q5AA/MsJjraKkMI6WkUJKqHu1TSUDPHgeM01Git4nq7C3Mk+OMgtDmmA6B9e1cohAeViTv7KbsxNq9hRGBnDZEQJvLONb7si/4hyjnri2dDyOEyCLHGJXOw4QQQvueMguS5BZqv4M2mnys+rdnahUMTXlVNxBI5Z6eio6g2J66zqEuWxZWMSD2O7N5Wrb2LA1NGjjqw9dfeKS8bDjiUQEsm0jHkV5ATZWaWk3ix4lyCyZQmIUhBpCdPsYQDAbQIA4pEAeTHQ6tEAXf8CtDkfoP7xAJHfaAgAAABcm6eZazikCWGou2ksIy489o1wAiydLcNy/sEIHEZlEYdD5Jv2CC66ZHRcwcewpktTwp0mtZjFKfy9Fw7nIyxqFIZuVwsqQ0mvc8TrG8Uz6Ua5cSbnd/wXtR2vS6Vr38T9WfszqXlM7YH4c9XHD8dZlzknmO47BeVH4lm09mXgdcfSawrDO/jaar9m2p8hF3vqw18QjoUXUJWQjsq9r3lk3DT8E9q+7I6sNaZ7jhF9tUQ+vW58osQ7XFfb7YMqm0RAy+Q/o6+Rfdq3X4hJNHm2+ZcksmuOuOFrehNH/FL7fyjZsKTGqF6sGMRnm1NXGPofq97i1ADWS5oPitjtDQe592d3OjtfuCZUe8410iyxLczyKVOp4QaKVdjQfGZODLDB7g1lFNRGDTRLBhIDCZtBkZG8vUyaJer2QZ/bI9rydESZJKx20JV9MFPTNo3Kcb9dj9t9YjqNnG88JpYzL+aZjWpeI7SyOrfr2kmnp2In1lo9bbFFR1O5YjrC87uE19xjx4gNW8Y8Px9rOr+QC6GX5XY77+uhdjop2eiqO4JkyZYy3ju9wiPOsKJeZUK0sbaS/YOwUWkV3RQ2kB5SaCmZEqVs0WovF9dP6MY95NHqMti6bmMWU8/3z8/3PxL7vOAV9/mFAaoedo/eNTgHCKjhdZ3VZdnhxIR5RJMsa2g3vh+hrfJdw6hmtZYMNau3PbflPaUjcvsYHOuBKL/XpK3vlHw6N/JvoJmExNe/f87GwUyC0zjKJnMU8z8qjNkLTNcPErPM+sBnIU+YcfB94yccR55LrAYLuwWKRBY5fkdaS5MmrjDeblZHnUWsWWVi9KapqsiL0elZ6Rd+AM0EpVjIHEttKVbF83eQcQwwmpvUZNHMtouUpbnTK1Ljfu46I566ujNYy1UKaMBpAaIUccoDRY7PZOIiii8dG00Olnd7LuanDNtAybOWcdzf3w9luriFk1pP/BmkOdAOZshyrhBrCVa5UqQxw6i9eWUuKUfG3YX7x6Ac4bRhuRpDqoAwA/mx8EPkHceoWPlJNCiQ00zs+HzOmH03GscHGnYOtP9OTwxK3LrXKQpSEFs7U5yTaLBOYZRHqhpU0dfxlNqLlKfTGr6JUgHRDhCJxG2cEkN0padFRmRsTGe8VRz7Oe+gjH4j3Tz/piLAcFBOnuQnpCGQUEWJjoZCwe6JRC5ziYFk8KZ6KWeBqrXAALL85FtQhu2MU1VawcARE0NZflxdDE8OG+agJY8EkXLQ1PRW1Uy94LDk1YpaoslKhHHW5Jq9ppB1zNzWWB+IzwRoWYryWgQaYYsu6mSl+tMEc2V80pBlJB7DQbGvEYYndlYtJRcV3VSEnF4JiobTSjpfPd2lwlDeso4SlhIs5S2uNfpjsTlECsKYOfWYlSuIHf0EoL6ixam7vkBTFunEVipGa6g3AJtovmg8UXZ5o/IcuT+6asMCQ+7K3IrF4cr998j7KnVqpQkBUnEzOXniJy9gSQ2eVaZtktXf8lpoYY+MjhIiuH/DFYORukMUU5ZJqV+cH42MntpK8DjEUtLOKULxdPG9ryXKKA5KtuJD6QkNTVPX+wLCQdoo4nHteTs0NApPoCREwzAOlqjJnqg3DtvlzTK6uPBeHe3RdjaxLm6+BR+xmjOr0TmHa4FQ6Bpg34vtCcD8QU3ciXqdLjuhLOT34TLKz1Lr2UZex3WYa5yfUhqyVT7G/SGGMxEN8oFtRKFvt3sEyuixVVlP6/+gv3/95TuBR1ZAkgIMZOGOnVRBZT/K2g26LxAi2uf1C6DIL/gZIOrejajbjw6RH4fb52MKcxGRnFBKPpGcXMqsu+cN3sbaF+BBnfeANvq1s+1UlY45+9nd7bWLVjynhfpYD90mun/LpfSccZpfnFwitJUKd52qiJxwNHWgGBlkO/dbu3hnaCwaVqXFaiZp1Q8miC7v8dxLJI67Yp0k/rYexotviHuM4SQIaVibM4mpYUDdG1Bd/A44aecVoQB/pWmaZFe1tdlv8UPN0wIiFev7dcRAVFLuMXsDNdvkzjfKkBKK/ZFuO2nsWooYXqsrHnTW4AXw7CqXqMv7TUNfHZSXLiKKVoniax+THJu7ukVh3NhabcHM8XH49YfnSPOJzclNuj9b3GtOU0mEsMHH5QsqkLvN1nS7HmtDmV7SnjD4sokdiMMTnp3dua69urnboE+JXAIb3Gj+nF7IFu3GUbfsIEy2s0HYgrhM3JcGE7kqw65aOp/a8vtdbZEbuRtTBm8YnLeZ3FHCjPNQWbWZtXE3XYRLidgtZ3V375pJsrSZ0piizPTHIwemkGjiltdzOrq2NCiHSCjSOTQafhsTMkpdnWbUfOuS6QwdxNEaxO7GlO9V5nuPkVohTh47+tQrSn0+e7zQZdUllPcN3NW7tzv7+MxiMKIeKMULT64RA+4FJc6SVTTCVWRCFw3N5IZmms49rNYejxyrYXAdNKF2PZ+efR08bKjRSzu9UPCge74zNlQqhZ6q0W4Vj033pAK2hxZgTUlGQ12RrlMMdfGGTcnjyWl7AVkOLbjnB9SJIimZ7POFBNOqc45HiqizMH2ioYsghkmHuy4s5PJnogFNlzbbdWxgaS9E6AWyshwtHl5zSXvAsTsnhReRut0GPWjC1lwwOmQlOAiGYoH5tN/IyHqOje2dN/W5sjhP8NdoQMFtFIo05ip3U9tcWUdY1RWP8empW8d6OgX9uXLaSfVjcfXBPBiQ9e5BeXn5MrqYSOjcA2woRtNYZ9awd4HDcKVvbdpa+7hzwKrtvPMyGQCUbEYhyPyxGzklvkTQB5JCY9V8vGj1etrhq2OIAaVZ3EGrxUrC/LrAXciW9s600g1VNQC/y/tS4pJ1QLfYBh9z5Fo5tbwcnAlBEOXJp/6azmWm7C3+GNL1s4TxPQ2nneZmSdraIPVl8/HxRur26SOJKPJTyMOHKHCoovYYa3SzUGppQZAnaNpRn0s1mWtPELqoZQWkcmKirnPrstJnROPHdtALx+bHbiM/+TI+dVM3jggh6LbaJkFgdMmY6lQ9D2XJuclCsHGwin/1WWHRdozzhGEw5yiz4ks2qt7rdeOq40BaDJf8CMbrvAFTA3g8hRQVSy76zTy7DJpju+XruQkEd27RlUUXdBx1YUDk5Kc1ouBJd0nSJRtklUXEzWAc02WEgWrh0rBVwIhq4ox4d84h10ycJSnRlMbdwX0IsPu4zcrR5IAni8sLM7x/0WxglK+tYBqgGybjoYt3euOBgZVx82AiV/VsvFcHlRTyV1kDjuKFyqKQpohqHJbHSvPZ8RFYDt6jCXVicZN88h6XuRi2CwPD3pPMxVDuRIr6rVpxToD2fuimR12vRqT9XAIT4oD1dpVh30mbuvob5kWX/FT9p1IaynPilgMfY6XJDBKl6fb5IPxWljm5myeDRMEx7UbbG0UHh/SNlGbF7vN9NJG4yj22MGiV7Rv33J7vKFAEdTgkYfVPBsnAZnNzmaS9P9bFJwyVu9puYX0MvmlXh7p5r2hjcBTpJDeOPZmocnja1pD85oy0fZGsRQDdO1YteQh6aETBB1rqeOptg4McvRVKLaNcsyD1nUfhXYlV7/bW7j6Up1OsSxbTx6WVjEgr5eQJIdFDvlBKbKAqwmJ22CB0yWxzuZCh7UWX+ebU+ojh23d7YymXpzeuntxVg2yxdk3q4n9FHH0FufZawNTFMchYP2znIV+osPYUO3QOYlDRex7udOuPseDbkn1Y45wSOQXaCMUKYjlrp12gOeGSXzlV2Nw+UZWCs1KCym0QXT1Dk3ZOdOr026bGkXNuUJ06aNOcc9NOD77RSJ7TJWWjnNqkFFPvOK2kzamXaH9kUIsX1pWuXGC9BrFx1fcdu4wuCgFaxHe1pWIt3Iww5dluNSP2RdO5bWcd6epcpoaHg0Jcokkn7QpWFsrDY8kmh+OT0iGPdjuLFtJ/qG82BXstxfE+Q2Krr+V3NO0F/i7IipbNN1X1WZfz9GSQOR3T2NEvjT9edan0HP9QKYpkKN487DbeTOt6NvbjAoLlz/N/lDqGGc9Fh0cUo0jDyIA6whum66Vx4a4eK++f5p1Rq8Zu7e3LXlfPdHXXxvucUniFrv9v1g4A4smw6WvQCsw4df0atzL2mp7tutMJePR5b9CFZQD8dhkxygpTHKlLRmBnIUVnJxUR5x3WEuFjLawoJBpJm/xrKApn1JqXiatneX276uBGTNtFe4EsLi+P7/63btCcOCv2BeVfpTNUMN2jDV4PgZjY+kABq5hvAmQhopDvPo5cmZtbRd2we2o3+TePy6RotJImFOxuo74gPJDm46t4oaRKovwUmIb26JKaEvS6WRgm8kTxwbvkt8qFIbwb4a/3aDScf8/vfWLypida10O2Q1d3Sy12PZnKUcqglYFAPOt0wQxlYPuBxKHstVPQBANNYBdrQV2IDMGPfPv1I37BFWqFYYTfaOkjvbFno/SFNB4jZV9bdyRYhHXgxNTxf1cU5rm4Zt3nHL6gGvEAROwfPzR/+35Pcksvph/NXij2B33yhBeQxqwomPjVDGWHxvYudGgV5wzegP8q/BEsSuz33eq9VU/g3kg8YOPT2pF2x2UKXck9TYgMgfZb04B8CSXlIMzlD6wVdr88tjk3uC8eChpavIqMh9LP2mS6Wpiyx+G4ZZMcv3/wsT4Y5TtCtbNjZnOeK8fIR1I5/JARwsROTB4NQPfXa0742hB/UUls1SZyEvjbXPl6QKt94tc/0N94e4f41vzWBzyUenLu53pifygRf4AQIErKon6bJIW/hjIf9jfeTP5+E9su5D+c/4S3xcCUTpbJEcxdtQ1hN83Ye3CtUb/f2nLX7e5qkBneZJR9QCF5wtjA/q1ZBsbjzsFkMgdLAYikBTsKKu1SKEsXHqhPGMRkICh6AiV0J2CyHNl9/7UVyWDMKGmcnHcokZdnZpBmGJR8oG6iNBIncabfkqExmksP7B06EnCmsN0pR+pDy2BhpwI5RwJe7/K/2J/OfXQp95Mn5EBpj0RmFGYjb8O31lW8xzBQQ63IF1zT9/ZrbZ/RKY16Mjru/SLN3yfRerqVrOirDB+mZvi4B5tRuX7jGauCdIPBLojLkxtfU4oqtGbuUaMWfjWlv6myAgp3/tGcUFq/I5n8ca8tCeOIHBwGZwFZj9BvwAE9WVhneKelDJRNvdvB7QFV2O+ANoLV61+gKq9aD1fsOLhQbET1RCKAMHRmM7Y9xo9I7+12TjrO4c/9beei0XT1uR0VtH8TOOiGAd8eQtGeXIhn43FbBzAo1jI3NSlrK5PSHWZaWZc5HTOWuZVOgxnWIvyUxT7YOGpEVw4A0n3dIiJSWPdUvZBN4XPYsX22w1ma7RVLfS+3nWf8vOh1Nhp6iSLPrJ1SmTWIgq9kg7YelrbPjAAYlPgNl85zTsusDqvT//oEaYvTcp18NSORGv418L64M/zEMk6evXj+Lgb6SsNPs+OdbNMm8mS9BVn7iAEsuOfNLwvocVsWotP5Cr66N4eHijrNbhmAgaIU22k47IwQt90LbiOde5O9Nt1CdxP0tHGTbeFfTd0oS4askASBIHDkE/NLhD24nSqsR+1pP5RtJpm/qlhXO4JPSTlmFJChe0EyXCj1Oe5qYn2VvNR6xyJJZ8FN2gfFe9DGA3KjeA86wnbL7QMr6gK09P13XyzcIhC/+3kNka5wAwGMk/4XN2SNdoB8rQonZPWjp3AlPXFXTs3MIIqC+TROUH8/EI+HixysMWWA4tk2wngkYrIFimUM2vSYKZTY8BabtHHPv6kN2lQ54EKkruRCoGNXtODaQDw+H4Lq46RPXx6HUqCJUOXmtOVh36h0oZ3kGqYzzXfd8swM4el/cVbRe6KWs30xo0BzU65We+Mm0nulMMNUa6MpeKhXAl5JrtOj+cY6EuXsuh8sOfOVbskg2Ozk3d2/W6wPKqiIVzQCGuVuXyoLJhzAeUYEpAZN2S8sSL1ndW/HA/nvvHFy2VUY/E6W/Wu23LVTEqeoDIoj7/p+5rMp8DJqfNWzNCSnP7NGSLg7aBipms4BKH1I9S3xLjoan97Qms4ISKrbHYRXmyDrqfDoWKeEfvt8CrpYEOLW5kBUxaoQrQYZRzCs0Dp0r2ZXqLe0zlcVjsZ0OodRgKNod/isQ7ayFthL8mpaN9gffqEpQBMoMMy81YXHE8Yp67ymCGZ5WB1dg6tUThcMtN9++i7JMb6vQjrCjjGIwudHzJIpiuOm2w3YUJ1SDV5nxxrESZrRMaBJO/LlGRzpBmSFZuCMbM1BjC5lfSWUGUQcW9cvlgsO2wom+wHcXg/ODTLTcyfUHz5H9f+LXt+CpnLUAuyZG1s3StRdKFknHI1Z+4tnArT8Xkhwv1tu3tQsL3en0WaMWnIYCgMyjnwd6H9cN1mIJRan+87gnSqdG37E9Zpb4DwtHU3X8n5cOqVb1vM0DIxS3fVy4L9AvGMbGcPQiI+YXerOVQdktMhSdcE9yAMGL7v0yEFZ5yqXOrmBQW2pwX/7C5Wd3X2Mo3QLd7jsf28VZMxSOT/o7urpclq+Tl5Nym87h/3L1UmJuEfGhuY19s5UV6oUgUAgCMRbyICn8cXUOY5EwIaET+5/xzmC+HJwD5R9cF6Qz2UKhyUg6Y88NBXnRwrrra6PB4BYlh3yLUWXfF4+NO/0ay8UPKOvMgfoCMqlHYD/6euA2JYeYfPHaOjdRxe9XVh+5kwQOEVnnATQwDkG/SlguiAH8cTzBMJ5Iul7kjsY2WiLEZEu5mT0m6jLMkAsu7HOsZXlWtGk7O77LglIdF9hWjYAsSyB+Fds5XZh0MmTxlou99FlSyp71K48Xopjva7sj/a32Ee/3l3+HixlVWRwwwWY4RT9laX7PzPBV2+lE0PZjJm/4QcsdKWRtWF1GDFUqyHFnI1Og7XyJKX5TVPDyqGZIR83yfX5OFDW1aD+e71nSjEQPM4bXlKS5HV5XyoXINzVX/KOcvDey8nLY8RYx5mqp1PlF3AbEMsSLdMirLkLHYkgERG4ryzV1tglM9Mp6zd2dD1PtR6CX0k1HvDW9BxiHvR0aLbfb7TB6Jrk1DOsLLchiUETL26rsu+hV5xFUTTraJemLymsXpiWruppvspMOYA1iqiQmzAaRiNDmCarntZV52uR1guq6PFJjR4hiAmoBtBOiVM0dkWfpKv1WFfWvEcFUdzGMcDX1IOVj8lmANmTXrRRpDkdnhdBI57SYFeVLy41AlU16cfXaL8wzQe0uw1IQllriBO9FufUCQKvMWbfHcKErxHGhCam/EdbdoTykyMFzVvN7OjBMKcSCFySh5sagg2pQKjU/fHpzTf9NGcQPxxBI0P9BT5eHWvFxdqQS6c096U4khWcF7bgvt54pIjMcFRWeZJ018txf3J69vuHLJfkaVDkoW1eur/54yb1Rg6Y8igQy3KkPBE3xW3xJZLVGgaP+4aHlLqh2CcUgh3pJU+Ii/dcTs2lrtWvslMel8fo6eGnbW2uYkQKPWzY86CkQ/vURkL552ptQn1Z6NJTOKQwlLUOJadX5l8S0jbXaa6t2jg/KSN3h1wkEQBxHSGf0yp5OIl2apdSS0fXLymO60AqrMS2Y56owuM8rlXiv2X0Nz0Tb5XsHhqpVkqjJtYNucQX4v6f6JwO+duSuYiOFRlkxn5o4+LCRBm5q7jgQiDMcSVDIWu60R+jFdsP4qIRDDqyozjA2rl9I9NRPUZPO5HzTYTMbNvDWzvVvr4H9zhdfkZ0bj54cMzJS0nft0H0GLx7Kwkq5wdr/MJmN0mAN9Gre9XTG62NBYEeAKMYtRxjISPWBLGa52mU7cJLH7lPhXcm4e3BvAFqfTnTo6X6gFVRbSZ5LzmQ57Sh5GfWEpzN+sb35lZwtf3axsW24428VXcyCCPvSdhzFykFZa0l49uH9Y71rbOxMxmSJ9mCe+15lrML/XF97IQK8VZmVn2vpo09XmDyUe6u5hD77b2ZMgRrNdjpg/DwG+1ET2OpU0gHJrgIts2P6k/Y5NZentsubDfJ6Q1GV5fRDV6wwdpKXI3ukTWFs/ynfwscDfGT81x8sD26YlNzc21sbKr2w6pzMuIuGnUXEdGaqbRJuFcSlkBwiYAkLIDgAsGzkgCZTUCmfo69fPYV3gUqbZ6IlAKWHDO7JhCAcJPGxx18a4PS+fJBeFR3MawEmkRwxEZqgZlPiEtUGmdE7N0mfQqvGiXsooK7CEjCPEidJ8whEC+/9FfAaNP3ahLHjhHEB3gKnGij1bDMSt6FgEMYJG39wayM46WB+G9Fx4mprIpN+TYB1kJnUKhKJojH4opm3mE31a4i8M36vryC57IJOqDgwwUumIl2VrfLH9LH+tbV1tKkjjQhw2zHVXJuxU1iNpS1H4E/WTfENz6lTeSRHHHr5pCsyM+pdfOI6MjfXtbHGN7IDVj4N8JRtkfEPvx5AY5061sVq7Hq/PdcbQC5DQdvzWSgfAoXtnYO4xC/XJV2YNsAoBWLwDYAQBh7CIhllcpAngcVoAEWFmy3+GPSAOTRWhRIXuenuuVkK27AARP7JWwoG/Ja8j3y686yMMkPK3MssSmEA3hHHNdbyqLkYAEbdH62Nqh2Vjog2yE5j86QmUfaOvyBeEvuReLrEqFkIiKsu1W5MdrZUNFg+IApPyNbLE8IXr08vriJTpoLv6AZoMC3YBK5KXYb+HLvxEkcFZpngx0/XDOsf0s/cHkP4YOw2PaKErMvuHfoAx+pLlvdhPA5h1pFUtMUTawbWr9t33bD3BIcnwDwclwtIcgS9bsCQInlHqQhjJFtHZ3YSNl2if96G15nYZ6Gu+mVlxEZ7DAr1p/em41lfb8zD8oes/AW+hZoawmFps/OhjEHmgbxuZqEzxnxq8MkeVffcPvAypaJtg3Rp9J5TQ1OkW7FKENshG/iPiY2amKP7zi6bx+aQ5GhLL936K4OnjVTTbzpAOUGGXBoooU9ateiFeR3RnyMjP1wQCaLNbhEuhVj1NYpzq4+eVsuDOD1PZBtmeCWcXqR6my7hf3JgppUHXzYVGWfrnKdXfT2CY6/eGYlDxtyKelJLnuV/uIALjYPqaR8sMO39hT/40k5DWUV+W0qizVk33VErkXhBGXGqyq03xuQDMotPWy3UdSk9zfNJcWwo9rpShnDN+5ml9UlKy45HP1nhbrHFVUNGidgfdeHxGVWUZZodzd7sa4eT9oyLi/VxyanIiweWKOl1voo3EMQaDaNIrv2e2YiMvna7UPdvLJ/zarfWnPv8LedZFWm3ePSaSNWgevna5VHqCGowsxd0EnewvxjIFkJI5bo2vQpfbf8bX1saIpzaHZ362tiin6KcYMcz2jrXzyEb6NQ2vAI3AiFMoKr78ZlyEAGh8RFAHIEZ+vGQYpxSATpBUSw6rI9kje2OPx+J1nVnvG4qI9vX33l2k7brLgsToKgCEnWvlm4cORW0whYM1V7Oct9hnfBzkv55GVMX4eTJTUltJcdjoGzAt2rCm3MZFfSoyQws47/qR8TKW7LM1voxz0RPYG39oPJbt+KYhPlIocPe8eAJw/Egi45LSi1lorjmb3rIf5Am/F+yqRGTP0p11DnVpVFpJzPZV7P7wWqJcTcHWLQAZiZYrGFSQKd4g7ITVgFzSPUafLp1BMhzIoi7HaJzqZQrJPBZesUigrbJBDLzhEgIqPFXED9yLRDHsJdUBahaSI/fTpNVtf8m6JQAYDuqbjSBFl1i6pdH2+SF9XTwaG4JTwrf85tVxr5sKv67ZEvNEiQsmJzFNRf+S/Tu+UZ9A9I/bR0aMExfr+OcFwdoZQl224LSGGMYDoQjQUUtJDUyhEl2o7uiPDHgp4ZTlVCLPl/rsngVZdFZbwvZMsZrNXeqj01FYhFibdEHE7vzF8Lg7L0TWWQTzcECo7wLssm0XZ9aP6NU1rW/1zOQV5dmCocaOvuev4tzg4bod5molbtugocMsO8dVWlfwV1qBs8U7MVOqiOwk1ywc6zLWhV1NP74SdUttvybewUZznzzz/LGVSGBgnbcg6IZZMyHICmb1x517vDD63Yc6TgJxp7sbgEQllO423cjMvIQutM1soVPT3CavFJBt7zyr7Rt9G+URyMu+TX3qJBjY3JDVGwn8avtxs85e+9/c/qxLd0xaN9I1NKWzc/HW04eVhvBw5V8zKz9/qXz8AKoSshWyTEmw8vNnfht7kjgwBomaI2SRBZqyxEF+UVs+XKzcEZME8rCwbjNazbSwwT79VjdvUrfXSLUeUbhugJdppEJnxTV1WGWYfA3UC1y2Og3lGlz7NP2RvRUF+pE71MZ7k9yUzz+8uchmCFuJPnlT0yrzrMSK/YurZTpHtKd9Ohgl+LaugzKXT3+dscr4/8Kw/FUqD5ii9GmxwbHaFarQyteoacfdnMt6c+/rgqOVURqCyft9Dy+D2ICP6I5vfleF19sl6abnNSTpIMZSt+Dfc7JswNUlHBJ3DZwycYt5Ro/p+GetMzQ9IFGqJf13uz3DbLZ31HtU15neZgdP2UwNnzycNvadJsGp+Cc/wdz6+KE62twb6+wWcG55cUmUoZxY6vp3L6ZSs45PydyYX8338IcdKyKgTiY3uv04eAfbedjR0Oc6lu6//rOis08Ri3SsCGVDtrkPx5SBa/xRRx9BBPIo9DHf04VuffpvLD1VCWLvqZJww6eDz3ecpDPgx25u8zSoHzcD/HD2Xdncg4EMsu1Mf0Mptad18JcI4uZQaeri2ccmPH6fRzwIjrHGewPikgW195qPTfYssej0npA1LVBDuXmR1IevJEmvQZO1P/J1aJpXBplUqsdnxydpKWDNYTXir26tq+3Yp4LoQcFEEvJI1t6+5Xp0knDvze+I6AMXCwhfQ6pwpoXsHPyKpRqYCV8GKxR5d5f6uL84/e6/Oao1YCwdz2QIs6+UDLFj+NX76cLB69hmvHECAnEMsSSMUfbOJswqkPux9AEap0qPRkGJnKAsH6BjPPTAb67jiJ2gdKgJPNnAP0vCp1x35ncD0psqTfbBpY/ibDpIRg9WyTL+W1t7ihebakKdx+ucW41MWzs/F3pr8VrKCL94l9Q3GDcDl5HSLnWoBzUPPAZ3VQVkB5BNu+wifId460X8otxf8Cuk2nQdGTxJw2T61sCZMd+WDxzNK6e448fsh2oak8eJnR4NNIccQne0q/VZ0jJsmo654v1rxz2VoVeSl58MDkWn3iPrA/3loXVIlJgncixV0UbvqvHPbrZQxbNFA9Ts0vyvtb9kirmFwxiluDxa7B4b+/065kTit3krjb/8ywp0S/5d6vq/bS8gpzf50tPTnG4pEb/Z3loW72kzJg1vhxl7+78D+tylO/04bjC43OJQ0eesIDVdog7vKXCaz0/psy15aOL0x4GD/W6QmmrUOzfvs+Zgwb8VmU3CaDOyxXVIa0h3wOWSmXSmzwU+nqrrtA8WMqo6ItYV3NDSEQlCjhpgmxEFZgDSE+ybzHw87Ehh9fRB9fgV85267VKerfsDCDe+wUKP6AoX/b1nH9jWWxoUlcRaSQpfzarOhM2FfzWs3RjtJFa5sp7RJO0dCGu2dwj+v2/Wrtyw8aHGadLewoXa2vgjSc38Rz6hUfYQgcAWPAjkAQV1+Tt0qs8fjycDeUbRB/xddyB8qJZfCMClj4DWBWAeDZVTaoFnX1kMXu1AiBWHawqJtLwPy9y8zV9j568u88s/kG7I77TSvljuMddnxCfJwQeZ1Fuj75klrx0xfZ7ryv3RgIBINHS3rWptZ6XV4ZQmwfg1qZB6YkGD2h2HevMPhWI9p/vvp2d5No75Ey4I3WGGyIU2FInyFw6QNtHYKrS3OyrAJNp/ZwGKrKm6yeliiNlLux53tngm6yCfoTkOy4KjZQjfZ6hrW/ZUPZ+Taod8DEx3e7yx5PFyyw11UCelqX3peWWiUtPPiDdhMWqeKwwfAKaNfCpuPCDFVyQo9+YbSblrJxzA+iC2w2FztcAG2569l9f2qwq9LXKK2jhop6lHl4J/daOBx9S0ZpCT63LPrcXSIBtNVsVAlSFnujpLw+JzqYLqrpeoBzRWDnCKJlpsN46Wxo0GjNRpoNNJQ2NNCHHtwLgNU/ToHga+U1imSibjX7fq0CEbSa6M5cMCyzeSqpsD7nLUxZ7XGJ2pJTN9M8FHPJwH+lT7DTHmb5eHNeKeh9Q+FjA8jHM5RxmYenCXnD8R478UBGgwmoJOdm806v+05FpUDzvJ6WrW3s9EaGsly9TF7t6or4mrVXXtqKCfLINg+/48doNMGPIXryxN4MDxN7SXDgAZsaPpPUusdIn3s2ie2holNLTj0t+/wr6pTI9OJxiTe8BRzMQn2AQkTdKvr9eCbSO+7Du7WKWMKwmjMdz18Xw30BAt9Iu5N11Tjj0d0jvtFTs0Z6Y0FEcGqu5d7TI1mpT7c/MveKvfLIqgrT36jBJ6fu5aMu/y1U1hpkd+zveK7CNE4mgr+iXiHDmsdRKShpnmFCr4NOXPHUKj2w67Jdol+LTfaIRGHLadoYHl76lDr8BJ4IZfnenVxjOT9ZtEOOFjrc1cn0qrW8z1VuKS14N16yj4IWkJ0oKGzJqDhUdZ3/WJ6hzqUqC8cI9EeTSjrC7Sep4ejBlLQzg0X9lnzfPgoOi7nYkmIn+nstOQ3sodP3AGjSOTr9HGl3wbdPAPysBpDASZXhJFCzqnaOdIJOO0FCwUyjp/gJuUDePawfSF+fwEvxBTVuQfjVnzM7RIzNj1a1HfuBt+wdoWZEsttVv8wNPo5CjGPRjNOHXr6K4y+xnxJr3iSemy2IGPbjy0Rxnbi30zHe+oSLBmtJ7U/lI0JThfiwxK4WvxgVdNoQOJid2zcevI4hR9jP0sLRg5J9Og4XNCAFw0wsc1gg/LFVwIUUf3lKfnZ/Sv+CCDv7iQ3+9CZ6Mt7YFsFJKkHDM6RcOigxRo3KDjoGbBfgVn9uiz9bZGKk7Y32GkPlSRimYzke8SV4/D+UGfL59F6LLR+27qYFjfa7G4ANfKDjiPCGHUj3qMb6NtaY6FLzrDpElSnjNzq57ct2C5ptjlpO14Z2Niu7oYtTa3d4e/rH5warOC16R1hUrgqLiOk/U1WDE3PKCPMXcKCw/Fku6x/4w9VPLR/Z8Bts006X5cLy/BlgjypgP9wWKQKxmF9BC8msHHFT8/rCMXJm+ZzX8z7MXO1Dbf1lGfTAQgj/7hMERstIAyuu8thsC2oaggrmeI/0Q1iqOf8UDd9bzEb+ibaLU9Fnoh0HBu2Nmcan4mU4d3SGV2Osvh9WaPoANWwI26N22UkGi1Fusq+1OesLgVpH7Wy1LjjMQLLsuvVbYMyKpFpMt9c7GFJDouJzp2Ngv0g1JS53ltWA7a/5sOTWOdaPZpZJ4jCnnzY9u6AaOkukJ1iE/fUGYajoR3oTkODeDefxGNjk3edWXNkxR8YyeNJPP4qrzDQD0ySV090jXppS6QS7oWdaZUf/1Kn/qhLwdMFBlW/5fDqGzuPzeO3znN+g3sRp2IZJbtIHTSZ9cCMm2bCV2x0LbMHEp2oCRlNNYAodD26JPbmpNEmjpjgijpdK83Cg5zd1x4Jb0AgWk9GKiQfc3dzECkxyIxu4KbDNCnE8KdALUm9tshR6rr11d3tbwjLq0oN3/nUOINx4MfXGvzubfkGQxV+Hb4NmY4fO+Wxb7vxp5MnM8VTB4OlDjdDYGS++HyJsM8c8pheOmdxvPUo63CUlPLYYIYGZhWC/IfqJ5gVu8/PmmloiT2HGa3rOGgCZcPLg+yNhmbblWSwofqoizfZ9K2moPiDHDqbZNYsv3fJB29713R+6aKBG8bi3Xq/n9r92Vgf+M3td0Zqt23vIdfm15wqeMVCZ7v4klLedBFOXQTehFtshSNc1feOue1EXYHkRDVqGVmE2mt4GtXbwUhn3K3cu2B3ckD99QKHLiN88hl5vEacjH7x2H7Ps9ywtvYkeHJ4CvU2zSRHsiHbzIRLQGe03pqx8sQXQ/QKrmmGRwYrzMQaZhepClGX60rHowvLJxHr52VBqzR3hkQtr1/ExecjO4vHT+g0m8o370fgz6emoKTS99go7nAiETNKXnkT0I/16R6G9Znu+Q9IZMI8zGyL55yDEJ9FH7idr/gXYjSFtWCSr3znbpsHWbWtgDx838JuJkBmcqXv419D7cZo9YO46qB+YRST5Ke9ERrp+cXZBz9liwPiavL7ysrBq5nUz69LApSq06gmWTBS0GCC+wpbTaWe4QdP1NMcfUyZTp+0t3Ce9sAcf2EtBZTR/l0XZtM370PCegc4UC2P+zIa77xq/Ylulnn7if9P8c/FzOhLU21j6BYywCIKLBDRhLQiuJUwUuB/fIcvbOVa7VM/KAhNBFDaFdPHbO4ZGOc5jsoe537BXNnYR1pWyqFfBotr6S370k/f0OK/XdjQeIK5P607uqyOagovbfFgiw3nyiU1PaycT5oZ4Pt4ju1YosGq+uyqgn0wn+KretvQeTsz7fPfQecsI7HEEY8FD3H3MYRDnLrgDc9NHYS++faEG9hzNV/2XIrbo8awtP8sC/DqJUDoiusz3GQ0Kxe2Sr1JfpdPNaU9Ye4vupL7W93Xqaqry+bPR5c/Co32//gqlz08W3EmUaDlhb0OcWoD01QU+vxJaMP/b1O/eFNfnEyRiGJZsN47wQu0ExRH0uSzSJNam5NCA0p8AgiYzgIAaauYlyTb5jZayKBAsKBtJU32SIf+vTTFXqNA0q0us/IkZDLFSrHRz8yH/kAZ2XFWkEfPVwmBKuqC3NoHSnFWUM8tA/55vq1KTiaDIUCVgAYjP2ShXZkdi2PLHhKQf6vOFPzYtQ7VA0PnbFHByiLjRPtMAMJaBdBFJ85zjAOZ6fTwKa8WiMP/dxJyoPbdUN3HdW9vmN20/9nCTdKS8iWnBRsIYTBjl4znxxxQ/DdGcLKH1cIh5gabLPypxn9ABWbTWTnumVSL8JRzcasGVlgI7XjPWLnD07N+iMIbE2oIx9bnB489UlHY1dLCJBxbQAeraAsRvZiq3i54JsVwkB9sXdXnUE8GZE4kU+8WeznJPvmjiK38vOLAeDPvchq34iadv/v5mTn/DRQoyfizrGQDW5ii1qAa+4YTF4HvL/mGFYJUh71J0yeuNDqU1f0kCBo2apsp/zUs4eo+Vzu9aQWCUoM2tfRL29J61FBX48OYZzAX5Wx1clWwdaHeEajUytPpZSvs7Zn59CvfdMsWE3qvgynbJZ8/c4ANzI9ofN41+MbOBx0ntbfolGhE3mUpemui/BO+ZyblSD+9mt7HozSZhIJh0Xh4MldLNAolB+OKhd5NXk3NHrjYt3ziiqDB8/WPZ8FXEUNWN/Yr/l2R9UvofrYxvq1STidRb2RmQkJfYkH2h2U8ki6FvfRm884nKt1dq4E8zRjwBPu4ZOIVOfUWNCQtOLmPTv+fZqzRkIiiuUwOADPKV2ZEoTvk44I8nDFW8jb+1BkP9krcqf3Q6J+7xlyqXJb7t2vXdU3xbTt+nGB8KeOquG+gPLgNOGvY2jexZE7nglEAKLSVR6Tn4uM7f5f+74dif17Tur74N/OjGlrdh5o6D+Gdx/0q68sXVIgQ/NZRXZC5H8H/7UzCR/0h3EY5W7TYwiim4+7G6E1wmyvz/e4Fez2ilQWsSMhpz/kc3l1k4qeFPUISH0AeDpbspeYMf0bkRjvjLlglm7WHM09hhl961l4g6xIl/hHhMf5rwPEGb98UMgQJ+vpXspPmVAuo3BMp5Pq0Nibe6SR/Ar3yhit5ozTOfjT1qcJJmO4yPjVJ3Goh/6R7wfCbQ8QoCTUcjPxa56VZrq5+rrDGWm7Z44Kb8oLyUNzOQ18x4vw1ohcPNHt9T4kxt3uDHdG6UI8UqJ5i1u3lCIj5FSlYmeSKCiPui/sUKZ438WnPegOHc3b2mV/kleW+oiy6KwJ8OBUlKrdcWiiYiQyVD80/0zz7R/9GJ2js6P//9qJjrJL9RegUeKS5mFKNRKHT7El+cryoqEAPvGZFKAYqKyZXiPxN1g8CXNDThtwLUgeX4xs/HDIZRQyzClAg5VHhJCZbLARAlcGShSSAeI4A9RDqUWyMeYkoEHBBeDMdwOQC8pARRpBSKqnTF0kKi6RSpQ2D1MEzzlJB0al6NYssMqxpRnd47i0IWEfT9c2f9VhSi+OZVNjaewEbBUWwCgYXqR7EI+FIUAoUl4LGonfb8V4Fb/DxDKBSE3fhS25sft65CNstGub83N0/GxWVSfKaQf6pQfCpXfHbrzQRAvEhCgAhc/CoqpZhjZnbGLI7oqtuaJz/dv//T6OeNe/nH9YCtmms95zzz855zPT0FQ0yv12MXD62/CztRd9QB3kjv0nV2Vexpbq4ZYvoTpoXppT2wVIw4wnKicl6OPK2/pyWnpl6yL8oMEulPed96+YUsYbf/27yfFCUyw6L9palT1IGvBflfAVGGD9yNcSk4d+h8+5w0ee5tR8GrZ7OsJ5vOs7zMXM5a/Ivee+R83T+LMf8uBlpP/r3iw0F9z8u9HmDbQuqSQqb/qf+OJHFmlQQ1b+ExdSuD6CIvHbXh2TFxYCy8zEX/X4/3blA3NFV29OK1O0Nxw9yXDBKa9NlDESm8a2BwgdRxmBWCiz2PuXFRl6ZUsSoPPmk4kTJj5BITtOSMdpRdLJNvhiL1PX0dUH76Is8JQgGf9FNGM9/dPQkC13vNANkZxfdyTKCurexZeQnKhgKutzqhbUI+X4j8wxwM2KGqMNXUVJhV5VozTV1rooFuHt8FgnE+L0EZzbDujPYOXDRgc4sYt3cqnjbiDn0yMCAm/HJTYV5U+DmZdL6d9u3M9GpY5TSWzaYS6dUPVBMbI7woc796L+qKa/2KhVz5gs1/CaLuWLl5Pe51y6qHsQUuxQC8xyz8Q9Alv21BnrsA8wNfI4u8zenuxy67UvaD/qq1KrGIR+YNr0+pWOiAyVtcXfzQgvHHyOIFqZVXvIjydxDgjlbgUrECZQ4mUcxqBf4O2Q9OtTYXEpRZANvohx+pcSAZ1YKcuyVduzYilmYUBl7Fn/btAgbvkx7Avz3Q9ooWQTTFeSihtgWB0vvIw+c2Q+TdzY7F47HoYhReo1Eza9lcHrsIjSHgMWgVMyFRl+DWtw7cbBzAFspuhuFx64cHvo/PYoslgKOHVcGgKodWl2p5qD1Rn323CwbHXbNWE9I44lUWnK+AujVmKVqnNatwlp9KfuZA/8xUAv+ZHf0LM3W6ZSSDXddMT03DsbMkLpgBsX2xA1pVMrRhL2VUCv+FvbQwFzswImPu6zMLrtfdx1ZHzyl+yITnSSdSW7UozkVRnUXI0lNaXcp4lSXNHzuFGgNSy9drQNNJt1lcEHgd8yIfEhEXWO7N6yDgNDjaYXoRR30Xq7jzja1OPJ6uQvR3NnoYFhQuxwEjKJu9D8H/SFM7gdZRQxWi3pEXCq1YlNGJb4M7V6/JMTkdqgKxQTxAHDYScrH1kuIFCSCUkLT4xTiFWlgGfyhxxDy7X9gka+IMBwqxXhTKr8EZG70oOM8ATWjsucwtsjU0ctlLQk2bZIrClQ5VrFwMNa/GPL1FTjV26Zk/fyugbquOnRtXIQRcPnvD+0yJSTSmBoVBAcXBbXHGg1e/qX+TAHOlq7SaYMEhxJkzyUOn95PXG2tM5asVitXlpUbmbazAgWMzykcfVar5fCNGhdlQC2a98kr7PUOa/JoMsFMziwK183Xtz+2oQBYMJ1MBS45H+8wM82GFIu4XvNJfeJ4wv1MZvK/oAdK3ixhEDpO+KN3fVM969jObbw30/Op2DtMVTEmYMwD2Oy+ItWBRTN4t1HxdShoQqflijQjI1OQPaebmURjmp83W+usYaaRPwY37y0HCxjU/Uf+NvQ2dI7YayniovDEBKPtVUQj5QiCgrgw6oERzo6DjQlkhWQYCO7CoPTrYh04XkqmGLY7o47SqfPfPvPCLzCU7898WouY4oQ6W5NnZzfc8pIBjJ7e2WqhkNfCNGLndycnG6T3zCgv4Bls71EW54smjjOJKxuc1IxnsQjM9OQ3HzpG4Sjmmr7HLYgTRu5jx5XgSGo0pZACcQhmVX9IQxjy0zV3rDpq4tShfhQ8zydIjiTQL2NuYvLKsVo6gy9TmAxZc3igM0FBLjaEFZMIHaP4nX8Jjpsw44ruO0WpV1YynwlyOU02UVD6m5OzeZMXkjedR4vevd8HWMU6cuChJbEXkF+g/fp0C/M4GLJoAThR+jQ1TdSq5jWG/U+JIK98hWPax9U+Uki0wKAy6TKXMEpLCAtwUXV5ZntlOz7GqYjdaBY9lwllzsi6V2yUhI5byMUio81CYEexh7WFsvOCrFOafBQx5N6za7gpMReVoHjBQ/jAZJC2HpZfTcfegtijtpJFl4+ij1UO1Ls9bA2Nvtea5ddEfru4qzPvVevTI2NLpZvJZeBwA3YTzBGLuoJj6H93jRTZ/o1bCuI+ACTKQh6z9Sfh/LPRtXVui0XdKquHXrD1/Zi6Cv4zAS4eRX8BkdUjkraKCq0wjYTEXqEbDWJHGNrLszXJW4UgltqiK3aDAYH7CAWoQ3Y/AgcVWs9PqwqZsumJDnlNYOA7/JZp1vEOr5oAlL9FGUsswrd+ZiksMwZJSBIZiM0SxV4rwagp0ZbxPqhE//8hugrSGzfjPxyHC2ZhMkKZiUQk4fNHsN8lWQ92rAH7NSx3lGzm2HOsAegUkmmdDerbVNNkUt+q1KcyYv+YJnmeap5HNwnwZ7xB6+NF1zx7i7HPWFlFvOAvewksizvKZUWvP4nzMtOAdsQk/lw6gvX9tGpofjNtdTVMehf3eYv2/kDkc+oeL9dLFqmLNdTElFilG4kG/IrNstmReNnAcQz0sfU4szIGyXMzgWrX2O7irWVmmbwTp/yB3UpNJ2uf9ya2z+nCj+WN4nIwPduPjQgquM9yEO1Bif4vACW3fM/fWNGssWa4dT+mZ1wLbMm1xFHdksY6FEW5o8xbsvbsMdzY+2omchb5YnoZzywVv0YR/sCvg+jE+veI4PQ9vI9vIv+2A16HjyhoCI8slNhPlCP2xCRy8UI1cZ7NP0UATjumDKcInibEE2Kq1mPQXLBxEgbQCc/0ryq92/irbs6N1OHJMHakjo5HRSB2pI6OROlJHpk/ZN4H9wSwC27LzhBtHn8MpAU+2ug8BAFD9KgACFNA67iM6JetKHUON8Pm+tTw8zs0hzShfZpERifyRPM712Fid6UK6QEfIPHDwSVdMfsCFnfzdgJWXSOmc3wabM22xP/fl1vaRI8Xj2c71bayduH6wee01v1ie0keUtjcPn3qQ5pM9cJzEfXmw0enbtTW3OytrsI7pldJOXunPDtwKWm6RWzmXzQ2uU3h1Lp2QHKQHamepZPYLWxzD7csy2jHILtsb0BdO45NCe6yeOMRxqmu5tNWqu34/LtW+JQ8q2MM7XLrGIOF5orr0Lq0rtwUDXaRMeJfqCnZFdSlSBg+CCZJk7HZxhWIzFMoexhxec8s1578h76w+4X7xdqhkN9MGfDk/lW8oY8yCof4sqgsZfUFf0BfUr98BYVM4oTv92oDfQ+v3S+f/B9uWR8KPn6LX42RPnMfW+ChbLwPXtcDgy0QJI4spMwuvzET0qWCE0azUI7pUWpTpnNVi0gyostBuwsyIKQ0KBg/yEcYaC1fXh16i4urE93IjUmwcc3qgkeWfD+3Zbf0Pq6bgz8/XHLk5UMCHgbD8WuFI8MBCbzwtAAAA4HxkhzwRAAAASHAEHQJNRKbCQg1ZHpaxW82PKvHfZ87lW29WRhHvTwt4dvzUspvrAItJrnJXosaVpPkJwQ6d5vvMErMG1GpjOR5Ldu+qxshVjYZVuF+Fz6PDdbgO1+E6XIcfDp8gGq7DxeRNztvrxMRpNkrvbm4r4jPUdXfQ2robUcN4pRUa9X4hRhDOtX49Y1gPN4ZyJCU+QH6v+3M2F4ozv2+ynkb0xuJ85HrsW1Pi62p441BVxPw6QkdEI3SEjtAROkJH6AgdoSN0RDRCR0Qj6oixWx19KsWvx/Vxto3PgP117XXU75cGvMZpxDKMK1EuaG6Z1TgiYzk0f9kqW9WNzm62OZh30wZhaxC8k+Z4qrjXwahv6hNP0l0KD3Hdaa8gTuLDiIqGOPVOxcUZyyGRhCximRojBAOiNHgQIn1+iyo2ypxguy7vmv7YXH9x6PLujt2g+TRURDT0SlRctmI2P1VjeImPV0B456A+/+S5Xa9BGtoNZ3t29R+OG1rH1XCsBWNG43ScjovG6bggbtzqVtWrx7cBNovUJvY/Gegsfu9gp9rWSGsj5VBx1u/cisol8zu388ZHmcsFdK6GtKadKlF0ok6MIo7p1cN1SF9G2UDf0cpMD2NVHaY+zHAIyAoAZHUPyIpGH9fHa+Px2OrOn3pRZ2h5MuDEx1zTF8P2d8f6PMLTk82NHPeSvPW55PPHbrltcwv47RO/rHcHHrQ+j0qpC2WJ1AZZeXZ2fXbdLBJ3+24BrT7xbaUIqBPkVkexpJckLptdlDtsdj19gE15ZfBLEfWKHVJxV4SzQ5NCGO01+nkKXbNZSSVeY3RlrzhvXjfI9hwxMCh2UUul7jciuL6Bz8WqMGyE+3LRe/zWtiDlYGqMAFT1rTN2WioFQSgKDBdKCC48cLvoX1Tmn1lJbIJsRCg+Xad8kLu5rJPY/bPKRsKTdK0T8/0gq/YpPjfk+nsjbI3wRsI9bLe8W8C9bivCWFSPx+va1KRza9yk66wFDnsk6/boT4vOrXMrsd8H42yVWQlpmqe40rm+V+D/M2ElzWJndeko6VP0WsnAIp/ZlQinzqM5WoqiIGOy4AssowJ82HbkQOYi48OaURjTa/UdRaNHF+B10FDSqPPgPkkZaIY89IXk4vyXvGbmXH9ixmSPRU2K+zGuDJ6bK2t3NWd8woxuHX9l6f60+vXDbXHX6gPG6e3ZdGPdGIyDtyNauANz4H4MGCvjaGOGipnQvUpEWfWwmMTqlBVYWb0XysJ/LxWLqfDQR1Qwl0ocfmqSsujEN9XsYa6RnIQYvdV6X5kqakwdpaN0lI4ClLoAlEpkx4Yh4DnDEFuSHdcs3R0yRl24I8l5lMdKOnHN1JQK3idD9uhKCIMz2/r9GP0k2qX2UZEPkG8WDJ0RIRAllMb4XZKUyDwYx9CcT85zT5M8CRhkAcTtHNNrOLYkf0Fx3VlijmgcPWVkYzcnIbOb6htkXnphs1TMyfHUXf43JT96aYbrqCWVv29z9NYsrOvwQUp8VaJK90WAig0L6I+ZTuXQoe6WeKnGzRvTa1YPqY3u2lolN4PKP9DtFI94xJ9XuDwzTe8QJRfn5vpr6pj3dNR+vQfOsUWgRBnV+73EXv7to0Kzydn43OeoHCcVQTAqhMFVtU9Ir4uYxJ0ujxKP43ojOsEnePf2Cd69gKDeAEG5AEEhoghBwim3dj0gJTfurl/dqsi/JWL+hOFISzSXl8ik5h9htUnXowwfb447fXiQGnX/wDj0ZvIfDlgauX/iZni650Jv2C0Wq9Iafely5eyc+TBnSs4FOlo0zN7gwmNqPQOjPGmAyJlHRS1NBYPczIY9G12HLtjIyZLtJ3b81Q6Dl6tcS0+CCtkPXXfaa8kQMkeL5okkmFQ9a1A/Y1irVyH9KnD1zeQx9P7vCny/Ab/WdXbrpT5HjizjCe2efGSzLCt7fFnVNWgO1pbP5Vo7nxPOkcb1AjH464lUi4uLx9q0Qs9+7w2aefyJ8NfwGLNOCH8i1wpXu5ytWLTL2QgL+wvxlP3PlUifsT4yBseAdd1fZFQ9EIFx4miM0XVCJEoRRJQ3iCgZX2Qu0DW5n3By6f2+chGEI+wJBv4ylMO5R5PKxaSnKb+PdQoK0kWJEsXPc/p5z8+joHVh7+SKSeVi0tOU7xQ8uH7UUUctxd9/d9ru7OlmUaDX60HqUDAilOtgmPE6P1s176Kb6+bR5pHmRvKlbHsxgrZBW2W7AHVhJ2jLR8aCYcqoTkFUEKWjolBRqChU2VOCnkHPkSfnmzfMwkfGgmHKAZ2CAcEAPUAPYBimCIm4HGoeIhSPZheGccgn18Ew49HnZ6vxXfR4PT46PjLeSL5UMO8MNzSmwKXPSRMrfc0I33bozYIfnpu23Hw1p7XkdD2E5CK3lR2TnsMOsU56ePS05earpQqlZ1ubatmr1BF2M/u4Y4Zu4TgnDzPdRnH9v0wVVLoxnTpUQWUWhaAKKp0yGThVfkZ50S4666UjPGQsUjyr1JF87HqWZmxENVALvarXXL+SHH+wuWfefGckHfGRQ2VGR+LB+CvxBkVH4sGk7U7RSXywkpVpTaIj8WB5i0566Ug+PLsUnSQfk1makRHVQC30qj6f6lVWz/1R71b8s7Ygf64ozny4iUKo79X0yODIYIiBm2jBkQx9pnPyY/v94mmAX8d6R7SD3G1/AbXm2xveNeIoIolfRmcTRSQAmeA0M0mEhTShCUUCrsn/12mKkghn0fbto4jknMLPitrQ1SsiiXCpGzpTKInYROoGKPeuH/FxgC/WfYrxbc+jJCJcrHW9bKKIJMLFWtNLUSTgYrUNEoqAXAxJEZEcWFj9ukGKIpJNhCuyZhWiBCJS2bg8Tv3YD5q/2vOOZDa4Hj79vTpJZ36Su4UfZoLnM5tF1dktK01zDOokNhapzv7votxmjaSLckrP/Ls/CgECBemhZ9FrM/D4ghRsC8i48LB65GNTRcBltNNSGCNB32wBofLIuX+tVfVFhbFqoNL+7T/N/z8t71zhXQHAj8hveos3owwF/Y1mLj8SFsBR5AzdOSpNUZpW6L7NeGDGCTPIXGvLOxuNn9qeAGcgD7fCPBFUmvzAZwweZctHWShzozVQK1J2S9+AJyXZnR5qeKgvUfDjOgvJEJwLD+4s12fAHaeuOnmE3t4J9TihlUdjb45Pv6n4+mOCgPeUGR4XA7NP/v6ELEvXjsV7tWfC19iDQ8AT3oDxB/0F/aewipHxNJjGSLeGccwMhc+ubp7WrQW1eQK/Qm5rNetP9l9s/llg63K+X2Qe/xNmctYlH2iR+QzVnH/pV1fZI6vtMiMzxzdzDPyYmqujpfbb/K9fB15labWzn9lvOfsw/4/BTubAP5rv3l1+Pymk93R55tfPvzd/zR/4kOf1vpDdrXh1zD+agT/N2Qw7yMCv6bv/O1j5Vj8XaZzuQTmf7SOofPT7+s937/D8TscKAOAE8MlxxWly7n5/8P+u/FCq5R9YY77zXRwCUK0OX1dRyF4AewvyQw/yA7ERii8Py7nA/+B/57gL9QnuRNefAOsS8gJQdmPofbt2OjuFpYUbJOoPynGmjRsd3HA2vurIE6IXGzoLQrgMdISF4aGj1mNaYo1JkUXPhZUfUgm3HOGdkQRPhbPlaD3DFh4RiE7/Sct8RrsWU3p5a6Rd7GbNeLZGWZ5pMAyrhKYoBcYzIDO8yKoNeLi6OyC51UBDY/ogBoOBvBle9E0CHgO+COAlA2rWXpvqnMFpA1efo3gZpBwq5DSRqwGQO3BT9GP3kLqzq+uRuXaGe7A9AW6ZImu8LpfoyQPZZLKbbZZ6YSTZs3AxCTmTlTaBbkCvk6IG6sUjjgf5yvg498+8TD9rXi1GPqDCNXNv1w7+p92afE6T40dg+xkFGpBiOcWn2dYikcv16wq0JCIgNwmKkZyMoFuh3aEnw6JZXb0uDBgrid1FLTsxFQRg495tNDWgJWEhwNQ1tZVwTONeEzdBO2BTzEpGB12xDrz1D2tQew6Z81rqSYVaB3Xjei2jNRiFUeTXkBWdHT229MgMZkagl9WEz8SJaar2ejI6C0LYnPshyx+PKHAJenEPjCCko2WvmWX1wMy6nDUzn6KkenORHSVTmllSHpyn71p2mxMnkBA2576//GiiwKXmxa1iaAZuTUAzQxj752BYSCKzurfdy6oAVIRIsDfrHAURq1ZiJSlGinbqBRjAKIwlYecp5C7ulSQXtUS5oGeNvSaQXoV98FzfaMFybHnYZt+redySM+mmSGBP3EsUGoE9Aq6D6+A6uI4jBFsCAjnT51swAPyIDHvIdK0lC29jqqIzcO2kmgP2jnJzoWux9uj1PDnDKWotmXsbUxWdgWsn1QywGyr1MBGDyZhna28mMd6Hy3fRlD0mSlqLYI29GV6SVRvwULpCbtnXCGapFZCBDGQWAshAvjwdfNYI2u0ycYMYrCHbHEukcWFBUA3mrG9vePB92mVCjxGdGlwAFwx4BA0B+YGrfdgWyTbdR5p0HyK+YjsfKxNoGXmK5z6FMHfd8yRRXzolfxR3OKI+ubGufudxzfnYTnNts/bPzu3ZTHtf7TI2fNGawNbWrXJnTu+E2ne7+psOgJC1a1u9f9dey69ghWK3RqRlJOM1ln5LAxS2r+031Wk6NXftRVp9mcbSb+UIQY1H2fmcU9KpWWo3euy1J24sKIxyJIWaxeTVFdjTImLbmjjmpgb1j1odTQHiL4I8eewUvTvUC0vDzlyCaka+1AeQD7oqgZ1jC7ysga/EPqzNBaNV+lU86s63/aebjR/RsignDeD1XE5qVSdiZzcnwKRrGfa+Ctg7+0XFO2YsizKQ5cmXerpfYrGyJDAFX4QvDYhnHlMav4JVCmzj/aQBPHA5q4Ojylm3d0S7B+iPW7nLBO4k7CVRErYIQj0pyqum2c/RzM8T4bTt7TJcZbJHPGik2iXfYSuJd9TqySJxHBoTmkl80MyIq66LA/8hqbjMw9SkdT/RWUuEJnHkix0A/q2idBz/RpC5bCmQqvoIO3cvO5niFgS7q9R3XtFEO7m3lXz1Q+pP1mrrdKdPI4WPwDg50pSMRxMd1g1/379/DjKz2mqJByRFfXXE7iNqOoZQerAQQAEKUIDCNQIoQAGKS3HkH3MqR3rmIimrMOfPlbUj5O15DWTkdE/PxZUy9BSwXVV1a70bABe1jtkuhO2Mt87I7w2HsAmHIdUd8pdcbdRAu1pjz2+exwWQn/iLTvlTkdq1KlNK2GdtdjtmkXYeZ4n0ICQQ8l/PEsCpos/gbJJnzrO5c1m2taMnKPrdWdUEiF2lc3jxx/WisVQdd9UGXwoQD3WF7DlU76V9p9M9dSyHX4U4C+pJ/dRY/unrxmOrb1QsIEZumg2YkV49qyP13sNOk2uLuAMWMDVUYW1vUEEAFjBhKKYJTPQFAVjA1FCF7JUkCMACRkPZ/DN57em24Wqk5UtOZyFvkjFezJpk45q+Wp6UgSRIUk8iiQVScNaJtqAdsOGYQpGQDISokEJhaQKreSIBbCimWMRSwFJZFgoLreSxeLSA6WHQAqaKRz6SgSEYgo/AEAyhfUWocvnuHLOzKFlhDWsSSYSFuZ1p+8/A1pNbdYlZk0giLMztZMrVmJr8AUvbhfQoSSXrHnZTWmOCkuQwI9mtINvPbpY7FVmTbIzweMBzJJ4WZpR2IbEOJcs94bf7m6Aoj5o7Sm4vzPDMRnr1GTV7Kln30EsZJcUj9Nm0gpg1yRo2K+HFiKQoAAHI0SAtikfhnrCn9szOUcZPc0fK7YlZWs1Qr2W8r4k2RgY9NWg4eJThyMYhsWAlCMDxJQsYH3M+NkICWAezuaCGdAQBlrIdYWGwo+AJ7zh4i+9yRKKUoMW1WSCpYXAV27FRXhV5hs26N9dw7wjysbzKWTAAG4E/ePR7woxCVBLUrhW3YFLQ1Zssp2Y/W00KYpsJA/Cqgz2O4HUlaHUneSS3wx/A7Zz2PfGLelvIHaCG7AiRgDsQuYKfnazHDPXaer7+53E8CHr3SzO9DOssJ0BilGU3390qr60vVnccBmDvmThSZrK0VOUmhu0yJGPos1YKMsIiE8nPEEM8IiIam/jSN1H0caEoxICuf5QjgPfKNcLNgurWaP8AJDgbnyngakZHLiOOlxlxM4/zNqIDsA+CX3V9BwMeD+3KfGYGrimrGoqX/7V9dliOHx1/tkDzgG8HMv874H/nIp5Z8RkjxUBBhjvXO3cRemIPAIt8nbXp4uuxgG5F3shzXkH15cVMCL8GMpd6pL16F5HY6QihEHLKRD6eN3M9JOrzuOkF8LdflqtfZ1t/CYD+84ANUJCeIFZN7PJo//pMAOjp/8f8IQaA7gNSUnD4LhaB5HshCWoG2eAL4F/sPwwkluPytYTM4J/Exe7duchkfZE+qDFqg8/fUcW/kgqV4bSYRz2Nj8QJR6Q6LtptxDZ9EfP/TPd5ly60xLE4hphev4dqwBJoAGor/2M1y//BnD54Ouz33yvEP/p9+YqQ/xi9sOIOqyqFx7qeMthvqXfqecb7vnAvJLPIGvi50GYvAqHIe/l5GORLVLP9CpyDroX3hH+tC71lSQIhQ/aeucEzY36SX2oMbtBqfpfR9M9ipLFEN4xh5iN/O2L41zPvhMqCUoDpL/xJT+ZbdR1rAzlWeVM0jD/YBeQLgaFjf3nFzoGrFVmyw7r1B+To1c1WX8Nl3L/aRgCU1zPvRDAzapngnp07n5A055l8MSATlAzNRo9ZJODQS6ycmND1tOaUC2sbWjCa0gwkV1YXq4uinQ6mAxEJPKe2zI2UlAfbu1Rd9C4KNrk8cQrKwpERxUooWb3eKkQ/XxpEiLcMm7EJJciAfSHqw4THpStjJw+jQtFlcMXSYzKysHwaADbW+cxwemjCfrhl6unazM18htg5NQW1cO8wJBUhvC81IQl981cTHfN8zhZ5BS3kytBz0cQUTg5NPB2bYrow472xZoOCYqdPmYM41Pk4m+QqmtApXNH+LKb/yb74tXRu5QPHV+3mwOy1Fg9GCH1eLmcBgjlI+GPk9m3SaHousNiN6TfT6Xe0NfJj5EyDWQCArnut/DFEsw70PHHeQXFqnnbgB71zWSR+nKvSaNOaETMRLnlfF065DdXrJ+DGASUxstDIeCnrMIzpkWO60Gir4oD8g/22El82zQOA97aBpy44egbu1utgm2vQrFZmrtmQQUSmNdVHwIGUrw2ZkYM1SKKFbMUDT3Q8RQTCwShGJOPQv4BW1moB4QI2kwEOcVOqM1RGDUpQNACFCXTEcFn+uDBqYrlHXZnkXs5S7CSVoa0dQqWCLRb5qQn0cS18IfRLOMk471TDcueE83MURFns3Awu8hm8AQ/U/EOA8F+ehTz/fZQDOSKihCInkVLFIaglbYFA3/rnUdBE3aadHiYEnbFMHoCK0oFqmc/9BiBr/hYZymhb0s5fjyS1KgIhO72WTbPga4w7bm45a318n+Li65h+2t7PBX+1PEjNWl4YQKP/nhm5QSBlpWBsAsHkoJE0SKmxjc1T+fcD0POp2GfyufWhEXmTHoe7TP4coXKI8yXZLoeY2KxS1YU9PFIAoT8x0MAQhI4/FoMUADRO+rNK7dc4Wk523BEh1qUvns4C7hYYBa78+7XkwLtSZxnEMKRWzzdJtMac+7UnmJrta5L5YFCE5uIIzZwZ+vuNZ6TyzOYhsd6h/m2Iwadxw2QMYTz+5XIuhzEvM3OTTLAwKe/Bbn1QRveYvC9PcFYGo1xsPlDYHHFPphkhE6CRvm+NXtayutX6wrV9oGv6UX6FEnkuumtwew8xa1ZDC92s5Xj2M0h3fEHC+UY2JDM44K2ZgYmF85AI+p3rfAE8aEdFn+x7XrUeNB1IObflhrCArowQUbyfOdNmNrYRLOXl97jIPYK1rKsTEAvBZ7vX9TSWIPL6PjS/LkbTEcgtv4s/gVSAjuzL9zIOGeUXR3Zk8+kMDAdJpXP3gKuscsOeI/wN0/iCRYHIetenwAYb6xpy2k13kIsFQYnVXYxIalMVKjwNhCCO6o8EKHf+8llRMXqWiVZ+QQUOHurmVo4hDDEfCAscEAUigNDcJMzm3dzBLs4IFyBWzzahQvoDh5Kzxjno5BAca7xAHrAbD4Q1UL03GixsyJgc3dzyfN0mXrUnXpaJH83VKUuLOHG09K/ws/KAK5DfMpa1RHC6z0/Rh41PuRDuL+/EQJfxoTsojmjtLwccLDQHHwWie7155FFk2uvIwoI4FquiU9bZHIx7J84JlyDkuWid00IRoDiJCR5QWKGRlrWDmXUyi/jE9WNertIzStC6oPefqsAZzGFeWZDBcI57ggHm3JNch6VZqLiCX+Vdyv9FOxcOn/2dX5PIp56+sy/XMj7PNz1MA1zFx160eEzPy8KV6bE2eAzakU1o0eUVfeyZh2v2cCx+Vdzs4fTPls1bDzh4mPD0b342P0HuZv9V1JP4/XrZmZ8SB23MUk6gtLtXh/OJ8+gjmzd2c8XhFYbNtmjtIvgqzKgQtjas1fjIaLOvyiF/Pjme7oqtUjJuLSpiwppkClvvJ2dl8BWzL4TdG3EOOMgzjksz8zDbox31S5nHPFgsKX9dyC2nL1TPqvOj5btlt7N1iMpUb2Z20CZRlWY2XIAOi1tMpecKr6O/Gd/x28yuLtx+JU9e0NMtdzwJemALTPqrlEHMY/NprQG0w/Yk8Zihcgw39d+d8HMBdSph2et7jTXDcRX03ABf+2LVfeVuVQard1M7h9w+GsOzgeJZ+Diz6uGo/3QOLti0t3+kIz96Su+Z+Atm3slwhiuHZ+O9Fzvc01vfwkXNvezywof/J+99642+33vnl7klvzT16U/q5r8e4PohG/JM3vzNITpUgzjJs122o93RencO7HCbIoQ9O3rEY3dv6E30g6+KmuLyLt5YtIjjvDjtm5uhFbfbLKhumXHLwfgGr1f/vYd6v2Ez3eOsk8t+t1yYucQMa6xph0ucMMxus1u6zXZZnde5nGocO3sT++Di7S9kmBayHr5x/A1CmvG/Eky5u5HSwtslhmF843P0gjDopEWKRMcB2A0zoAmI32Xw4sCdP3OtCOtEfyHO1aOIX7+urJyMPRm5EQRpJi1cI9dTC5g7H2Nsxz3aeYO+DfsHYZ6xnw+ywi8LUJqXUjBo8gyZzRIPcXRYloLjdtPbJcFfBt4UiHe5/Fl/IsAeecRrm9LHSlCko7XOGEhPwIF9JIKYFB2PAoOgTC2tkN7UfVjbQ17+jXEzN43sKR37AnTM2fPqZHBhzUBMY4xXaeGI0c4+AD06Hz5H/KBF150K6b1xVZc9MXLhBeJOo743+dKTql9pp7cknJ6YoEKw0+OeU9lNcbPO1iAk+qfsihBRdRONFSoOw8jikrijZi1nlydMcyOd6C6Z0ReYunDsA1SQ+ya7NEO2XALxy45XtFzn+ILl6lO3KJjRwVEjGA/OGCF3EVE6c8N2U07MLTAxfUiwWyBjB+O7o4sJ8AS6BMAqPz2MeJLg/hjwQ7VqP5COAL7hYeek4ft800bJFPBSVIlOUuRSCdk0JXmD4xJjj2/ldq7MSdwVmCKQ6LjkhGAALDNE4pSyb6hA31gQO3y5XewMDA/I6lYHDoLDGRqkGBUBwnu9PAHjwsjYOTQDGjysnxedtF1unUhACkteiARJw5LmC0AbKe8ZgYSO3KzUU75poLBLjI7l6I9qk7qnrBbWWDXDQPxkHd8HzlFbR0QeHDkiiNCcJUVaVWPwg0DDFJqcCw/HoHCt1Y9b/GVM8Lhs9cm4ap3F6p3+4JOwT9gX8eaJ3S9XdvZYNaxKOsrG62i0hM2BvfeHky13LF0G0CoGJLYDWZImgr+gWtmbJo17R8cjLuyFfbF5b6LE6Kt7j9nnC51t07LOiOAacQbuwhiU/I1n76m//G8uPvlrUiobMXXUmYOkDtud26GW/hgk2iLcFbIOP9BgLFPwRHNCsCFh1O0NoNMQ/zWBCRa1YkBwiOVa6wDfQNpc+dHQcgKkxvr62dyC/dO/jr8Aoof6ihkxKpR0FWXrBLSkZlbTJWo37By83dz7pCIkt07IZeqYJBbB5JoLOm436RIUunEO0mLWrYpgA6uOREMheK6DFKOXDhoEbePygosbFyuiBY08U3FxkNPPuyJg7NgMwb/Ab/okEQeD1HNbn2/sMsDpg0Pu2nUWHqDWRMjscasV++Ow6D5UNcZcmsclpjxnfCSLBCXap94Eh5A4UFcINvDDbFpd2/QBkrYTE0kLVfdINuxUVB2i6A5Zo5uOiUPiZ/1U1ZEBHzZn5fUNMyY52gUcQ+e86R/pq72AKteJ0MJPz+x8pGVyJZYNPw4OpexA/GoiQRd5ONCrxkmA1LbJjDh16hCB+7tHYj0NfYDSewYgYRPaAMeSBgwPEZL/2oKhkr5+ZJ3RbrC92s08qeaq/J0UiWzIadLADGJAOCCBkkAagFxThPS5MwDgOQCZnIgwJrf3EjcAjWyAgiOUOoMNQ02yezKIi36L+RS3hLi7nc/oBLIyeoAq8hfKUuX6IDFfpnzyfSXJmw/J7GA0UzJMebhMp+RmywKPxHQDgJIWJf7dliMlEqVUh7gmxVEaR1wxri8RwnxjpjTdGsRta59MxmA82EAQrs2ohEQ4wKHhZmJKGqY0G59o0ir3DasaoaYhy+Q2b6mQbjRIr25sCpvcs0yOnIbjuWHqy73Yh6koDjTahfeThQYxIMmfsTlIcmNBiyZ7wiIKGILcfZ6u0eUOERFpod1rJqVGyxlTtUIoogM4t3dTbmE3RImS4LTISOFESyRFwPtZvlJqwmnjSq1Dpf8QJdutqVm/pZtNVCLZyds7jD+uU+JaNkN47GTrSMKWo1vX2/h4F6TaSlTWOgTVMGAOiDZtSGcDMw/2snplJFK1axywa1BIhAhJGZTAvPa9avMQDCBQURkaTyp9d9nH9ExneJeuWALX9EG2uO9xvh+KjFGf4SyiAjIYJfUukoNB8URV9dtgHRKXANoJP6FVk2YpGOIiRYlpq3CJSFOYXrjZ2AqeT3uFtW0q2EWMUs43sCI85FbOXowF5XXDn/WmuxV8R8x4arYatNhzOThoZN3iOjCVvjrJkzAgiy3UpWkqGrW00DDQRUhMEyG1T6XaMdA6hQn1N/E6P+6SUC7ENdyn2vgevr8hzo7ul+cmAzMjlzZCA4IizFz/hUzSo1CQAZXisYby9YQ2/loBmQbK3cTUmjP5VyDTzQOCQdwXB5UMIeX8Opjs4v5NVTOoVuBvi8Y2Mg9m8Gk3RI2MQCI8OtBELpXM1068l+mtIyRqHsV2mYp+RQGAwsQQHlVg1ObE/QIRBZNUUHAhUPzWGjUY200SphYIRjNCB9C98I9EnBrScSAhTCS/WqBDx/Nb72j6xs8HI/2zS90ytNNIfJLGT+U+wNoLYeIGy/A+L0FCH7LDkDSw0/5g9dY7ajLw5/0CK7tKnCcI3EppYfNmmg8GsN32VpwYQuCStYxIglKANHR1OVHm2ArT4q1rGy5o6OUn2ByYqBe1iOgeY54gCq2jYrAy8aBt4sdRN7/Gf7EDsB77lAj4N1r+oTooro57SiCxNYNFur13A0L/UPAH/w0H+r1OaIokcZfbmbG1gbzrWgXSDI434Xa/+hP6yAcmOQO74A8y8fPA+3t/TjE5LO2y9M3Mef5eJCY6TlkOlgdKFmwlpWmxYVn5738VQUh4yVw/f0t9K5/7593l/scsO8eNbzia84IVZaGm/W3Gqj1XLMhZYuFTVuoyZ23snD/lnDQ5BUoi0LdDMbVYnQPb1KJfpJ5BpVAnUbXF71WJ7J4um67KfyFCFPK3A+rUXpj61hMmQOsUDGBiACnIYLhXoFc9kI3zckSKFKXKzEC1BxCyHdRNeCBPWq208DkZSYtzR4+S1pqGgQZRTz0FuvREtyo8rP6pJngldBjlysWsQSPWE5PgOSwipLsdF5izowRAPAZ9wvDMBUg7zrzGev/3V/FaLv5xaYN4ft3rt45lmwFYfCWfJ8yKUSxG1x2fa/suvfBNemgO67tiliWmx7LigpGZpjn8Qfzik8R6futBGdjvjyRUwxHVfNBW1YEXyaGS7WAQ3evkQesPR48L1x0YNVMRdizSVNUydZ0ddSQalSy7KVIdcQ8Ee79N1e6oqnAIqC/SDYrF84D6vbWMSnmQB3mQ5XlOOUzktOgFkZCDAXW6o9z7AbIBWKKjSNq5//OhlbVCufwYZ5120GFC1hKxiEhBRlBBNgHL3pDMAWsPTv+mslW3o2mCLEBFrObtzUP3gyWitPz9HZHw/8n2x5EBvd8k+8c59LIYTHAY76X6gDn2j82YVbZ6LGeOwaTrkeT6jqPzVTpMQVy5VIx2UhcuWtczlH/9NCpu15HT1yWXk7XCIT39cU8F0cxL/ZfemLvsLk1guglvImaPYKN1J3fIAZA1XfGSXJS4k0eH+LwjdQSv71UdORVkvLA0HKSjYAcWDF2YmFuhDFJq01zGR0bLddssbTg2TIZpUjlsNXSQ0USooBlu0K7LqTPz5dNuONrEy7gzgxkcmKxZN3Fjn5jYbeKYBe6XLy/PwiI4mwdIYQajtzWqd0VBoO3czlHhxtl3s125Z2KR6h0J5SPLNeHRkz1rlrTsSJf6ctihZo/2iKU+hxVnVEn9aZx5RMel+zeY2vuesseFIJnAHnPYsxsR5UiR8Oo8sQ5ADYlfzoFzEB8lHPBhuzg4H93ZpkGtsqkFX7xm4SDclR1tG+Uiv3F5wp4Kx7dsOYq+aCO9SyoLQS9HDuQvBxHBa9Os3ANJtsmJBbtKPl9xEP1xfv+ct5CZRrwznt9L/h/xr/eME6qQ57idawOgHET0yXjb2AapRHsVyVIUGSloieNxAe0lbNp9nAryMbghASxMMKqLJKGkLb+XRNb1nPUxAgR/u2bJwuR0xRFHikYn6qEPUvPKuc+swHzltLCZvbX3zUcBIXDxDpjgje16LUXgv2U1ZOhkRQ0mZysQd3I6zjb0Ih7ENyy8xyS/t+8Zv/TSH+tvkW6BfQOnr8JnzOtGYX0QcMM30r8jmzOq4meWfq0T5ZtW6KE3ubC13dnb/lvEB8LfyDd/xDe74g4xvu0bfjx5+dVfPL++UGrHGFDboxqAwu3hwgXosWGw+iT0gWLDFw916X5HHkKCXNjUzuwrex/6bvVps/DA6xkaO7Z8AXF+98eizRLMM4lPe+RYzKAXcB1ft/Tdh1e+YtQYXoHtjja1M3thP9z7Jtn2dRy/kp8ybnfSWZuV61fD19N/muwZeAGf4isOzAWZjxDqEUFndTruDwuBjG9kbOOlLPktbB34Nd3bvqDE9PTbDuAgNZjBWNd6KtORN3JpeixVxwyNQHTkc4Y0Z1AFcUW/s4rgJh1MEzx8nWcBf5YG9C19cDEAXNdSAjvcJSC529ulHU/TgckpFRznVrn0oUSkjoBT3mRNemZpEhOCIRrK6HMkPdIDkEQQ560U2nSPd0niuHXqXPVWEmVwwh/Wt86u77zdAALdQayAW/C4Sr8OhZAx76xkmAO2j7ZbQNjRoF6JsfX6zOY1qbO9Q8tPFSoKcItNg/nlxeSQuWUleMb6GlVG93lZlLQc/XFrDKW1PVTnQ+neT60RvLo39vZk8UQkKeqRqAyImRQZkw8VTGesKDcJDM1TP5x3Z/JFklCEdMTcmfMFdnRBxoTJiBZ38OExDMRpgAHB2xwmlyTnR0I25pWDIiBEkLnCBo+KfCKYN9wNoI1MxzopEB8UY4BxA7/sYoDYtSzleolDSuhCcVSGz2PnNCWGSvd6oaqIoexhYegl+lWkARE9qAN6upd0yBX6qtMi9UTIoCvQsXSAbV8WMn8ghjRQtWmevDQeeCvwt4UdJNioIX7JiLbNpcSuL+wYLUMcfPhbbZeIU8K4YQDVC+t91SpMjH2pDZsQ2g+F9SvPpcBov+tzDxx+ErZh813Sb6QbmnQqT3A276s5miHqE/JaOUMggHOwOu6k25o3dEbrMpMZtCYqZ5SgYZG05kmn7uGPLIl2LXkPnwS4UPWpRwfC0BlBWuxMikGf3Eco4YuWgBsHHPXaj6Qrc5lsy8N1iS0zl5oeAM4m9cDQ6pY0nOUwTmXGewRL3bYWx2xM3aZVAIRI3GfXTI0fcpkzhHjG7WauKQo6p7PH5+XKxjxEMiqsNjbhkqF9RUiMpGcZVh4AhyiT2BdPjioV7GadrW28FgG1Hf00/BRvR4lfiwIjqeaiTiC9EW8CchMTvFBjv8BKb0GV3xkHFBzk9qatLlLpcRsqk1NnS8kJSTHTXKm1B+z3k02JGz33AJ2Ddxv24/L1emYxvTBN1uzj6ZaCIyxILxFIT43v+WzKBqRd3JAuHkhpelcLzJVSZEf2unmUNKjyIqp4EHjt4PWA604OAihYAsyRT+KUFPVtVL1e4Mkn1w/mzVNsCsb4Hc2rUwt7U7+EF64e5y2UMy217RWfIaxJM9vOQ/f2GK63ch7YiEjJEYzRAAFP9pcMr7K+hSudV4rX+dO9OjPITkFVrGY3EpphgvGcFVJPQehg/TvnJ/97py2Nzcj564WVJPt2fGRcTVvoMmc4xHmIDLTpzmzfKQJjptk0kcnU6N/L57xshiE8h93IokLU1TbN4//n21+0v6c/LuzP7V/bf7b/Wv/nHeK38S18H6f498AS7+I/8JPmx3dufjT9I2P1rTfmZvrGfCFfoF1WXptPs0/TaSVKIu++ZHmstFzWXA5ZLlHvTXo5nJyJseMW0qf5kJbeLe+sPDc2PHzy0qMpMg4xtLWwzLsg5tIoDBAk7C2mrRmf07t+XFgkMu/qmBGbK6q2+fQ7vr9H+ZQ7wJpI9eTecj3z8+qU6OxnKUcccOR51mfrgsmztcUisXrt38fjvFurj/1rqTjy+3/c2W00pf8Fp0h+A2YtWLxkGOmy5Zv0N1ctWszAZGnQPtt0wA7yJ4OcimecwYB1slSnXCW5tIV5HyjlQwoPCFPRDT8ZlBofOWqRLQwd5EyVXqyDRYPQtWKBjB4rqFPFwOkEvpnvjdjGsqiFhCYQ3+I4y7wzuZu5ZpWtVD7l7+3C7/CD533OpjaSm4ytbG4e86DMyTzG5f8gsYm2dquYiXlk98K4BP2uQKsZMoCfwPVi2OciRsu92TFgTpWvWv09eC1s8DXy/fIaPjTyQ1u8tgNbb/x9A6q3NAAca4nulEEX6D4Z8q/PHLwtEnNWaWuJFJNLb4p4yhiJ+nK7UJHHSOVmYk0xVO7tp2GrzNzblOfN8s2nH6LHn24vCZFfPg4/u6oyzrj5pzPMo5pP1kJHo0M0Gb6NHJ0OxSKeI2ykW9wsSkPNSEeOTXlANx1L4cUHssTIOV+C9XrBD69OiWn7YSlVylQ9a/xhG7w20lYrQvZ/phshptnlgyEfjA+/5EOmUcp38yh2yppf1mwO97OWnRBznp19fVrgo2tFC9o1VbvzCujW2R++ah28FJKe8yJYhF53Dr6WMv/k/R/i7pcQcwRc3MlufpmBL7eFm76nuuEGBmHGgrdUeV4b8vP/ofx+CbsZlxcZPOFIE2lMLWzsXG5SyVX9CWy1Hg2p4BaAtFzA0NQ75ImcHwgIWspT7LF0FaWXdw+SlxPHubCJzezEruzWHu2lvflhzzW7torrNcoB4yg4Fh0vqtQlgJ0+DjG0pfAHW4KN/A/kT+K1Og/5K8HdhOCbyb3Rp9n0rOoX54b4BsCR3fxgT2d6ZpcvdR29y+83WloGH/k8quFwK66m3bIhSvr1m+ZagaJqN2sa7z8Czx3eAVaVCioVvEKu+P0mf6+4owlnbW8lx1Oqsx5YTujAVX77kNoNS7ufJi09Xv+W/qGjkFfW2vF4PPwrAZfQ9BrwpUAsgHBaFmT38HuKYIlwtlDgF2jRLwNypmcPHYR5+wMhWA20nyHehi8n3lBCLcq6NhHvpftLEk7FvtChUiKwS0dXYMOqiX+P3RCQrv0CTPp4tf216AKEJ/dZ6nzfFDpEOPE5BQAUDTCP91s+oSfdr1W1EDEnD1AS8Oer7+hB4Q6f+9iNYon7Q3zaPcfXAdb1mbPfCgRzrk+BAdU5YBYUAGDtC2c3yB734Y63bADCK1g3eT/4feLLVW0QvjLKdT6O1gCRWXJpl+A4kaToQuCEKFf0IiFL+ZGBTeJXLrIQAbf56Ktbdv+3AuCqdG3kr2WqA4meuOktQJF3VPKslwGJ62/O+oAF4brGBoCfYbrQ8XxSTqEAcuQiJMFGNGTJc5pCbYDzvBTwcUOmIEmLtPXZp+CQHisV2fzHUGNtXxuU/i7RF4a+YZoT4yykCPjA1xjLyhgWCcQIIt0RUYMiRIgUrhwQ4n0dxH23XunM3M+tIQfoFdbyihsOw5Henm/zX8+PJMz+B5apdRhVvq26jMtROZejiPtDGfVKThAR9MwbPXy7pp+9wnBNT/1f+SzBCCEgmAxiGbzl1jt0RTPbt2qqYqf1CNkNUTpCV3B1IYLMHyCIdWGgwmB61XzWgYQvRR4FgccUMWtTUBsrAwfKKloS7CNOSRi8YEiPkkv4tZDhzfI1Q3+tne6A5G8A4iKmKSRCW9q4YJjor4KGe6tPUCYKnctKfllfAUZ05SU2wSOa7Q59BeLkMIigMpqehu6UwNnWXU1aKYM0ZSqDxWgko9UoeUnZ2GQZ7AV5w7bqZGvskLLjPAziB37htdUL4iJDDIhGRWABSSkJCgg2N4EDI61kaDDgOVSyFmKLDrZFTpj++0VzsxvTxzQNz9Yy1piiwIqzC8aR2Ogv1RObKFtDiyh1hIzjkmObU3NXgiegopiBdAbDy/aRY/AVfqkCzMCDB//Am8Iwr/t8WTEGDoWlJORA38uUAJHoASRzgMeBA36N1ozQxqxfQCzh708FmUwnAK+mCm+83U1U+098VVak/CFBTV32eZ/OLZR0/CTvxdglBZzkqlirVgaB4VH3Ck7MQxoXy0YuQBblw4iSpMdTJaYHrcl1FGmPLdWMvkkhbRvKipvhVhNFk1lXFMPCOznuwCgB/QeUO+XvRJO8zYh7Uv59TkLH+Pnkni6K2j8IzkwBwQ+HRLAQ31cnWwcttVwcWiFGQ6cfSudCpCyMYW/nRHIqP0aLQsKEQFN42QsAy2XV2bO0yACgmeazGHcw4gk0AzeE0xlLlitK+t3e4skRq7EysRJiJFyJFiA0Qy3F04ptOQCnr0tzfR3Fl1yy7kr0aljFY7txGsB63vk9AbHu3TiRCbAZnAoCLuLdhz1PksEHQInW04T+ugv7jgAwxGAcV5DZCmYiXmEsMp4Tgkx11y6sr9rVMcIuPWHJKhTlYeRbJUpZeaF1aqxg8O7Uqe3XfW2PKifmuqF+yy84BID7fD/JIvOVpYX27yEjLQMA8n9n8jQAUPjzjO0l/18bxjEdAJQIAAAENf7/jYsMTw+Aczag1ZVzm5nFyPm5vhZ8Hr6BEHT9HgUAl1ThtI9S/jkq6f3aZeMHsF/g7PknOEe0vJe8fxBYyAfow0UwEC1n0UQFxxbkfyzqU4z/9M56YS7eW1Ab3YLq780ag78vWQoYdrsKHJKrHmHj1mEAuaWrArEeYeLW3ID5yMk4lNvdFt6zHiDSLIo46VWIjEUdXQIVV8i2w1TcXUVBvsJ0M6biilXOGApbT3cETHHHLznyDpBc3FOzhuGWVBr32BGIvKTIi3h8U1Ysd7nDz/rC3G47HTS0AXbXcCb0lNh6dft7YTLl3M6P0d/N2TzyzVH0d38XYFpM6t2d8SMfXt4YSOE0d70WkBeydFcbAD6q98mDktkjk8jCM86TcyKRVAyYp5nuwLE9MLGklpVxPCfuv/kyppnaqnbArOAmZfv2+4DLre8hSKi2YymLhSXMG6T+ri5oi7KIT5P6uLMCy+3xBWNPj+/niqGoY3+iTeyYvvD75uov8keOVHLyYpQ5IRE5SQm2R30hHzv4ASTp5DtSVHghETlJCbaqI+TYZyLG5eOeG0PkwAAG07ADX5cP5vbUzD2uGM1/buUJYsnZ3p1n3ETEu7kfn9PNM6C3sz5wc9Df7cOdhBxfUlcScSVO+nA9JBYn5HbPAxbjUftwb0COr8U1RFwtZc0BlLTZsqENlLRRVn+AEgYft+Oirjfe9TuuhDqhx0lYFCzzrA4pyxfYL/coxrpccw+hP0b+GhlxOo0d/PcP/8Lx3yEyJYZbThAuMJqyRypNxA5U8z7Eba9nkGaPyOP1tYql4ryqqFZv4MSnn4rzVyzeQ6Su+a0ywr2+mbt837LB5TIam+i3VKMdCEwrFdzDAPpexVQlR2qV09cojFu5q9FcaDIeIw81DOMCQczb//oS9sB1mq3+o+m4S9PhRetqp6uNJPCHvIlKZsZRCewDNVCba6GStRZzQA0cMokNgPdvE4C4qPoZYlWs+SsqvCpkGQJzVMNHDgUWs0McMrRXfuwZQ/iZoMys9Ra/kQN1scXQggFuoekKfNpkz9KoXNEGzfqsmcM7Sx49tlSK5QJA21EbCDrwwZVqc5J7sH2Nzgii3B0kAeCjbvWzI2btooX1RqtGE20/DrT0lbVQX6Oi4QGeA7epCTYyCBCE2xHsu1DrU5j4fa2hBIChA/3lENTS40MIjauHUAEWRbP6IRwHu8PWQ1xnakJNNMcD2rb8k8uHnDrKpHXubYikg/Rtnt/Brw9jSIgVUm+UrbwBa8uOnB+P50Zdpnl1m8GLHFCWKRXq8hexuqEI0G2toUQCSFoV1i1w1gX8qMUCyw9QOPKfTl9Ogx/iB8o/qqqSNXSB1NLbe0jaaOAybV6Id6FH+zdX3nL/ks01ep7W1aZ3X0k+s1g0xRmcOkNjU3N7ftTpMNtDXW2gPElTqoCwC/qHLcqqbtrE9ophjGyX1v71jTmoB5Us07WvQ9PiPqhEtT4NkfukRcw/6AIU6Nrf7+9Lf/U+GZLnIBR4BXCNf3Aq0/kUwe/6ut7nMk9EyF7JKmQgazNbqf5sHr/OwdTwCEriAA8coFrmAFfyzx0RfHwiipoMLEpsKqmULaFKXoWU/i7CBF0NAQGvIfAbaKgg0DVu/ee7/4m5qPc/gSfB/Vo0Cn5vfTwKfn8DMACVwYYk+LsiZAo8ngDTACqTTUmI96WaZjxgqQojZZltjrnmmS8FkCwu9EdsBTvGirGqrbHWOuttsNGmHHhXa2I87ciW1+xYIMOS9/rJjih/4Hj8yZ5/MiudXzf4Fnzb7jTFs8YFcqjj2FJP2SUFJpPfKUfGSUaIqXRmVnZO7jx584lQkpGiarphWrbjen4QRnGSZvmwGJVV3bTjyXQ2XyyhJiHhJmwJPKUX5HihAp7K+9qo6YZ5fzxf78/Xsh3X84MQchISdsJWw9Nlwf04i+EptOlFMZwgKZphOV4QJVlRNd0wLbs//uXF84MwipM0y4uyqpu264dxmpd12x+Op/PlersDYJh8WwTF8EnUXcZyvPDwyDeqJctvS9OyHdfzgzCKkzTLi7Kqm7aDklhGYa6ZH3Lbj8fzDJqvi0Bu59s7tEAgkA5ID2QAgoCMQCYgM5AFyApkA7IDOYggiQxRqDQ6NwXO35iWVtY2tnb2Do5AEBgChcERSBQag8XhCUQSmUKl0RlMdw9PL28fXxabw+XxBUKRWCKV5ezLK7VGqyO/WoyO2U5Wm92RX98eBIEhCfYCrtSZibJgKV9iT6Uc+yaVRj8cLZU6ufiCr9SxiEgCyXjYQqmil9KRQkAX1ijdz3WaQptKUAnuA0gU2mLqF4i5+9GKx/TcLDaHy+MLhChTfyrTp+qVax5NZsbOhmwGVfLUpd3/KH+RO3DUoRM4VoSSjBRV0w3Tsh3X84MwipM0y4fFqKzqph1PprP5Yrlab7a7/eEIQjCCYjhBUjTDcrwgSrKiarph3h/P1/vztWzH9fwgjOIkzfKirOqm7fphnOZl3fbjBEAIRlAMJ0iKZliOF0RJVlRNN0zLdlzPl7cgjOIkzfKirOqm7fphnOZl3faH4+l8ud7uAAjBCIrhBEnRDMvxgijJiqrphmnZjuv5QRjFSZrlRVnVTdv1wzjNy7rtx+N5Xq+7kqSXcYhattPl9vh3FOPaTX4EcOb+Tppb6db3RlD9Vex8PFgDtOAwLj7V3xc11/8uptO9/Wle7B+dT0epYdB39HFAo+Tjlc/F78FIIh4IIc38wZO/Q/U7Dfk5HyVmZeRPkhkU8Vctv682pGEsQfLirvgTu3hibFLOwmJCKT4aN2nWT3NisVs9CoR35cgfUC9LFVVcSaV3+C8lnFfNlKfFo2fnvLcDn3Q7daLSHX9c2Z5/tPc9sWR37xdoWiGMXhOySLKXJfGp+SvLmHOnaP6yWVUf08Gkflo1fxVJNlVtofpNLczYU8wzO86dVvwjafD6iB7X2EsE0GujCRZEgjA4N5YZA4hCVtUKPQRT5s59nSBenP+jECEXG42anHg12YlSgABLNk+AElaqpNJAxw5iwdyTQFrUTg3qyBKxg1ia1cbruBYVwoilWhHVkUXC4NyIzi4MRSQSiRy+C3/eJKug0kdcAkGgAAxe4qvtPyGqNKeNf6xYU+JzrTQpwQqI5jiK02S1zsdU+5z8YDnhsFRJpRXCKAR6H+t2Xp4xdF6oSQzW8NtR5FQJ0Wg8K7TBUfT9WrIOGeg6qf7qfWiwhEBNWCmoI0H0pP3bciRZyIaIos3XyFCBNzqkak0g26xtsABUVaobeHVvZMcOKpIYVrC1AobKDZKhGdiaFBvY2Q8cXUulhh9WcuOi4aHAjSFv7+icBC4IDIEKHhXIYO88uNu+1eGazKuEtZxeMFSOSKf4DOxgBACI1C77rNOEnSBBgzqQpnO9xCUmKlVcSaVAusuWldEMVJkhoVp6ZR8OaumtzsQMgtsCKGNQueyyEt7AUnnDOsCKVdGyvQwraJrn/LJUoWhLqvxHUan1GjmscY+w4LznpQfgefXJuKE8m2oWYdMyGyLRaaNxXfzkEpVJYNx7xyv0S+CibQd4KceBjiwljFtpOBU+yB7WJnZ0ZCmRIEyIUiTQi20EucAgQEvmH8SOjiu30nAqFrJpJwCf1aDzEgxBTGA88VwCRzrWt0FSTmgMEoUtb40ztgHR2ihUSYphg0obx8UMpSV0ld5YuIeZSjNsEYCWBlnhEiPomMKnLq+QqjpIKctTXzBpxWx2MNq2Z1yrmOFRBKrXRhMsEQnCgEnYhULBGCwAl1YlhmDyBNMcza152CnZ2YgLhgF85Xgq7KYtlrVnZ7aALnZaFPV4cJVhW6naohGPe271OMJw5kam90mw4pGwF8SCZigi+EeqNBLqkC0MLdc0hNVbmCPYMsH2GbqfU6WnCYt5qk1Tqtbd9Yk9l3wNs99dOR1hXfy1VK37eVaWKUFcsVhYx7VUbTz6vIRVrrw6MhNqpJN4fZGAM+4ny9YAissoKakfMaVp1m6GkJRrJdxUYN5VRvFvMOQfiQRhp4r2vKDahbL0MFOSETs6dncSSKeZYGMXcsJGVcGpDzQlWSJBEzoOXCK54YFQgDc6RGloapFiL7wmsrGFKQrlg8FtZa1XVSN5k00G66PjkRstXbF5bmsJRnTix/2ecVdUcQiFlPK0MpIaGTcam0ekcarC5BAbC13A7tagE1aqOIRYchZEgjButI4dBApMFB4J3fhgxK0PEwmwpGnpozIQEZTmL4/uhUQiQVip4hBiSVlLhQYptWxvt9oDhqq1Cujca5ADOq7ODGD+Fx0tdKl2Iw8teBVkky0OZp0PdwEeu+Q0hLBSgFiSZVFox1VzGCM+GgihxJM+bKHEIzvnwrl6llT3VM06u4z2YYSIbCw+ALVElbCXbzlxWk/zebU8wCMf2HpXx1Ik1orYqSLtwMP37IbRN3A4RN0nRdqN9M0Oijgp7UZXAEHgopuhxWRtwyT22GB9o1Rq/Ski1RskBGr30ZWq6phwT+Le9sVgku1REdHmES2i6msuOa+kepOVcJIPoj1ohGJxsu9lVS1rj0y0Amg+Lr4ObBOIQceUpF+Nq4ombTKYM30qDO536umPHYtbbbyOawlIWKxN4trKOoEsQXsO8GIVqX1YVAlVxr/v+FHDE97XVjYhcnpZ+sDBqqrSKJwzc/91evHWt+9rftL6X6Jxz+LLD+xW9QEJkXqZXbe973rIqSrQ0IG3vxj3+KOQgcN/sh6RmuD3HVtX4KTjNm9hKB+Qnt4I1wWLfxtVMjIEaxAV0SPUBiRLjICOyzPVsbumtxRTo2CtXdbFYqE1FDVi/aYU7Tm0rXsTg7pEm+VxxZuBK2EwApJGW0kmgwXnbimn04BDRYkFhj/SWnTmG7W8j5UfAEEncTovQZQUoBhtaP5zxbzD2uWi6u11DxcQCwzqLqJUsjhnhF1xttbiavjDnyfW/39aPuwd7k/z6uhJE5YxcllAKlFolxOywFiTAPLB6gvR2NPlyLeyFnpQgxrQToAggggCNFRDNVTBQhGKUOi6BF2CLkF1WwKWgCVA7+EarqF6ZoBwhCMINEEKSWVKcVeQCTEPL36Ntfv2/OCW+Nd2DJ0Yw7QdUyfmOirP5eJO6C52JEkdClJLGDeN5I6k24PBPNPU+7tdZoVklj3xw9NPEu9wPWXf4wTW/sQoUZZ/FTMrPzt/ssUm5EJPbn/4B52wA5NZtn9Yuxy0c+rknErsbkmts/Tlx7ytbluv+MX16fJj37b/PzkhAyZyVoscN9u2DmXUk/u8NvQsQFsvaZe0gnCcSm4wghEIyFBaAmLCJMIPZAYJicoANtv+uWoog15uS+8f27Bi8+/Ji4vzs2+2r/6Zzh6n11LBlKSgfdg7n09HLauNsv7M8VZusfdzt/TE41leG3MHy8w8CAIKxT/PjDOGRli0qbWpP5og40JSi7DMKkHYIA0ctBgnP9++LmZf7oRey4uo2r8UNOD4Mg75GGTmb7/bj+vO3mr100vTyepmZsncZ0mgZPZcvn2Xm8uxqSdncZYKSW3r0VWfn7nB/vhQ9Q/lN9qcW84D9MmulU+/nXucHOINF8+f4pF/HMDRpPLxcHoskmuP9J3PLSnCIrSuSc9jPW0RrOJEvkwnbs9AcNYDQChnYy5sQAUMFsM2MTRCIzQguCOB1JXBhY1+gEjiH7lWhUrfoUIKC0Udz7142DtMhOlry31Qs7WjHacv6u3vjvApHTEtYLQrvMDLS5H8fWHO6VKMSGK5NvIgYxrZFT/MfJNSefuKpehVxyVUdF1NUlQUZwisohBXcyiqEUvI6Oz7bCaF5aZb7j6bzXqbVTYvYlbvDvId57ANKyVN7//0weHNOa41zZ8Kuy+kq6fsk7I9xUISPhgWbfI1vg5T7CzmHFOg95nJIbhAwCCgADBwPzoPIECEBBkKVEAgnzsorycRruz23fbk7DRPivmPPig68dSQFJJtJNhWPl1Mndu5MY35IptmnqAAgwMXCBgGFh441EhMyboBQlJkcQt7i3+n17uiABexXxp8Hy+v2zHZvbi+wymRbaQtF18ZEMnFzWlPaIWJN5OMl8v7/3cXKaXVK/GBW+Mf0Lb05UsEImnWp8278/pYQiIxa28lJa8gCP4e60QIFGiLn1wOC6dfpRaC1oOKVaXX+V303naGrYmCCb1ciNAFffq5PObVKpE4KrMjI1EpVh3nev8Sh2CPXqxntznGvmxvdy8pESRgIBBw0ES6hFGSq1v8GYev4/S16ceObPJYLtREsKqTep22cwtDbU4b75IsmbaQS7HpmmgppRkUAIC6uDm2zzXe37mZTx/yB7JUAhxxEMYPe4cvABuYqIlbYwY3U+eNyDXp4cJ6a94qzAtNgoMjAl8zE11dKb9NsINbK8oogy94z++m2wc16XI+z7puhWe6/JSzvb0zGyD6/pVDa4O1Oo0m93VyfSFGo26bs1s6C70892/SH55l6ypVRBKEQUgxW4YlTk+cKKWNpKvvqunwati+iswCJVkDnbhFbrVkGVGx7Ci/TbCX7ZjVwoXOSj/vjEES1k2oCiJCwD5q48hluNkOF2GjQ0/Dl4St10IFvzE8ZUzG3Zsf+E5ORw2rT6b97Z7//awhYcYAKPwhRtF51mKuqgNvTRNDPk2FAwD5fJqdsZRF3DmX/BnmRrVKCB3Rf8eZ1hCrdl2oUHBTeJxez2ucquT0N+37rlUqxXK4QdzWWMxsTbhjVD4zSSKp304aoarla9QCMmtN+1Kj+hzRwekN/OLXxNRJ3qzKyHg0IpPH6bHuOVTKmW964yxNCfJa2bfGFnl4BUWwyoZ2vKKZqfLpEGELXP9HShZKoVe2MVUJE/0jj9WZeLRJ8TKb8adUjJg/1JGIB/D0qpGyq23YXzJ9Zfqp6WgQwD/T0fo2JvgDn3B1HCCPIB5gemL6if8Z7CZiA6MAAAA=",
    "plex-latin-500.woff2": "d09GMgABAAAAAE54ABEAAAAA1yQAAE4XAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAb8AIchAIGYACEUAhSCYJzERAKgpBYgfQOC4QQAAE2AiQDiBwEIAWDSAeIEQyEWhufxTVsm1YDg+4Agnj/KgdnI2qPMzYB8cyosHEANcy+suL/PyE5GUPGPWxqlr9BTBC1HdJIZRSsUH0UaoYh48q1UEhcSI97PnQHEfH1Yz3FssGiueIW9DcG8YGxQ2aFHjqvohYVXlb4YTpMB8VTiY3rWkWto1jIMNpUcBQWDrmNIk43/zPdcc9g3KLvMrOI+FHDB52IdYjY8qcvxDrSvA+5yfq+RWDjMkaycvLy/ONcfOe+TJt+4EUA4QhArdRAcoVCsMiTn+e3+ee+90CijCIfZdMGYhS6NHJgDmfmOlx0sWau3E9X7SLS+L+lYj/4zd4rYjcWq2AxJEGD8DEFUzCU+nw+dfpP0t0hdYqAo1jlLKpskVYhvc32e3m7/fYUhs0Mmxk2MyadYYOX2U4ybHjYmNKpr3bTX7cgguAapczTHGQjSBbWLhg4b+n/nFpF11+fiyZXd+3WIWvXWU68tdJhRYwTkpFEiEMahg9M4gjPmpVm4wau0tyDHKC59S8bQwcqIowxbiyLrWF9K7Zm7FbBoEeamKBgVGP1v2Dltx9txxfil4KE6pIrzqUC5kubflp2FcB/APiP6qpnWRLyN8jf8GEYL+uNofLlooaGor4QN1UTum7Y+q5oaIrryAFVuDgNVO9Xqd+n/rsZBRvulXgV5BZTVNCFXNl5dkfhZ5nzODxykNpVS8yBB/173uNfOluyDOhBwZZM7EkF+gSH9CfWeAUvJHQbcPSCaTjByEv9bgUAeFXT6tvpdp+tnQPXwAJr2TtHy18A+h6/gUrVpemuTpXlsWah1auxZ7hH1q5lrQdYlmdOLXkuBth7wAsA1sCdvch833sRfO93n+c9v4jvz8HTe6I291sq9QWOS/YDNrTBdZXgUGo4EFxnkEMqGfX/U9dXqvsKIX7WGtGHdDg1bm0Q035D41If5PD0QFMqihrDWMZ51psWBbM00jrLrHdB5lyWuiCI10YtqwuiJLcdLBGxZ6/Ha3fD/msS+a8ze/ZROuJKN7hBgoQgIhLc47Ylzk7MIMYTadLbsl/2rdM9zr8y86zz0KKigBBJxHDssbZikKsmtG/Fahj5b/mIFGAzAIWGwIZwGSFLLYVZ5gDkkLOQDtchN92F/KMfGgRsFCQJftkVQ7PA7bPJVgxuD1tLHbghAKO/gMDuv7OpDtx+mRHgxB0E4HdblR4VAQQNKn42QfkflvAWZHamZnxGpiFVKUlhLMnI0CQlNqYERx2/LIgswniEFwYi4H9/+uGTN5554LY/XdXpagz4yWnH2e2xLQI2WNVsSywxz0yT4xnrqhao9NUOJbraoSqL2F0lFEt4XcCMDtmRUUE5FQtcJ5xspPijY0SsnBYC6eG1u1alQAlaQjBhZUAMmnr4FB1YBAS5667HAW+M5QUoP6eqW15NM+mLG2AXH3BteGwYLqIDM4T2YBhYcDyeqLwZcayxltrmRmsHnX30DtTgjLOCdQh1VZjre9qH3YgC7HE4CJTn6iPUr1mr4946ziSmAge2909AgP3e+aNBbSBwx7JuIRKsJ3GZp6t22kZCLMUiUZJLOrsrRt2Wq08v2Es2hip6sIuRheR2bKn39S6v2zEZ5mtzdwImc1ZmkkBvGJRdLoEFhNLDZsOzjMpPt1txYXNblKg0upGa2peKSXiN6A5pYLmc+1hNRZwUJVRYFiEOJJomKGQ4qQypbT+yomslbOw+CslQKdZ3VZG0dtmSLJXwPRghwxjmDaErkKWQaUzZsnQabBHhly00uoy81FTT8NhzmdxDTc3yqDe+jlrzdhdY5REid0n3Fkc90FCnQEvuqaeU7k2GExjoEolM14Nv1LEyQsqqhGjyBIBLhdYPII4N3LySr9TMqFV991QICEYi1Rm1BehnHShcQjXOKuxDyfolRzDaED6Fq9iXvEAm6wAIPQiFsux27JoZCZtJRdDs8f/olNPB1IydzpS2C/31oH+gKe1Ezc0zJqyl2BNPecORfC6gi9hYR0etLuEEkVG+AaAZHNgzZsz5Stqtr/geTR8mDVGx4n4USLgipCiWu2larFHjF/ivYbzLQxLz0MRcQtD7p4GjZexI5jIwJoQqDjmYAAXXvc4eaZdW1XVpI9CF1hlCmBHWLnYqNTs3C9ibeuol8dgL799ds6cklJrX4/YoSd6CyCO3EGDYyojaB7PRSo+5J/fEa1bGkZOREhDNz4gNLO9v5SqPwhYoEPUwaTpMzxJEvlbJcGiwZ3Ov410HaiCNDROfxfsyizW5YUaAgzT3sKtGWFPQrw4SqCmXrajynmdlu8Y2D/ZWh5HWHcmXdRCUYHBomdUZfJCqA4OU/9HNMnU1Vg2H4lGrPRmEfh+Ar9CkIpAyY8tSozSJ2APkwsuslgRgVVNGVv5eRsorMZFjdreTrCfTkf08DETjUwMA/g9jSBp90NkAK9KcxVseM/2At7Ha66CK15OOwgGBp9m53cN8nE9GBzES3wMJWhZ2uKQMfS4RGVnjnAonehi1T2vlvKMNriTgUfX4ff3t4eH+6QFWwRghBsgJoKUE0CU+GzhuodI1fW9vwFTa/OUJEACagzi7YK6UGVpDqVMWzpIpNPoQZ+VKsLZ8bdNcAZScqxr7O7Oxmy6Tg2pqjUIRjCbHYCOAzRKlvkxsWJWZZ0QXw95I8noiyWRI+BmbIM+4gKEsKzrtznCNUpaFYQOZDdUF1s0iU5+hlkYag1DdhGasZNw4NrpEZUg7nJWP2CaN6s1OENOnGkCASBrWmDD2Aon9Dl0M8iiPlaOJeKOphoaRAgy7TmJGZ6TyWmO3CRwyYXPPmsv7h92WzqI60qe/9USadNNsNM1lnoLCidVsd9CFbkyTNDxlp6BFIhrAUMLAnICbrvbIU7CCljMugdeIGThDtT2+PkKgZRuWoWsU92IjnlWguYhjQeevZGq93u8Njyv7zw/81CuxPjdieYnA8szuwH+5hWfj6tLhVkO107s90HDR14ePgYNtdl1YmAIpX9NixlO+Mf26MQnDHwSbcxiqYrtYibFIsec5rEe+xUrHBYMhvUhgJzJQwiYKguUoMdVGVhM+XPmhN6+FqqEzFg/0aqe3wOSHLslFsBal+snX04zkU0LnlspkmWLOb8Yq7c/SYWgrZoy4vFP5mV9X156u9xPhpYgPE+APqTaoHJ7sC2Uxd3Su0KUdBZht3vUf/+Y1aU+Dy4cSjCtGXfrptdb2aisDRuznxvpNd6TLE3xscdjOxSFHGY4ZHaBpF5ayi1ubd+VqUoxpzMk4vqfr7hofm4FwGNftx1NN0TuabnXA1ggO0a7EyNCUiMXpKhhozGcwVCSSKjJCL6Y/dVvYyRM5sAL1SeEWA3i4972DV3Qmg4dMUFLSRlxIWh38BirWDadgL7EVDv605NbWq+qO3t4PxJ/BSa+TCw2YD2QwJEJyaSbFUgC0BE9RjBi/G3pxtUinsQhCUcqtyfWtm20fT3Jm6qgSScIKpq2xejw3LIVfSF8/Lb7cqIrKaNPLcJ5l2L28BQRCp0uET8ydyWLawV1MXtSE6lgQJvBGvWBDoQReobEK1x4ApAND7p20Q0JFAS6+ftxl4dnsM02KLg1No+v0vkQBYNM7CWvWwQV1wI/dG4JtdlgpvgbmIs0lMSdMcJBDR4jkGSfn7ku5iyXKVfgAc6++5utQCjZ6IgCPUQ0b7zruV41qGPPzZKNH5/2lLHhW6xbEvb/nHok8t2O1bowEbURR/uvaIu6BqxEbHrprFroa69nn9QwXvTZVRTNMcLWaSD2dI1WnO6u/baZzRyf8H3ZhlEqpPDGQffrHImvQLDKBhTecgIA7EQkPUnLelJSEfAUQUVGR0jCQCRHCVxgjP6kyBMhSQq1atRi1asVq1CTORBMlWOoAM7uzhuvQqd5F1412012TIIR3oiQJFSKUTpgwSUyiJYlnZhZKJoRZLIUYiBKfDz1f4FzALXEqIwB57pc3lLP5SYDxJxAgECT2JxX0QXAqTEShhqOhBZZygsUBghfnlwAH4XmQyalc1n4oviROcM56sqgPLheHLmYmjIY0WF4HXAg+6/TdegTQTt0mOLcLuPTWDjDAujBcjs5gstgcLk9eQVGJr6yiSiCoPxQqQEMx7DHyQ+QkYVFwmoYE4AGZxCFgiCNWUxeQXeJNGwKpIVooJscZ5OaLAAm2gEnidHSBpZhaGlWMTAOANT/zuaOgzatDQ43Kor27cPoHcjnWe2oABYH82ovxshIIyEGrbh1oLF8GhOcuprxeRgO7aR17Lz0Faz+/YRjZUVs75hgLOz3RNQ33PXby9TptLWhXWm9/AboAP6cdBLaaBadNh4DripvBHCTXC0xIvZey7U5VPBDbmsB3qWTIN/sAC0V8kQisGeEkFpxjrq9tAuAYvAUr8BXD83VAAxBqyO2Txc27O3YYUcdXoLGanDv/AIkxXR425czlxaQpufC0bWadrzf6K2ycW2eDZqEQn704I7ZiZ54o91kRch1lnp2LFmkOAj+MRaHJLhZ7wnYrHxjc1GZFsCXIB8v8W2+dHPQ1Wn/gJGz63pNMew6JUyhWiMSbC5fz1tQPnWzXO15nFrZpM8SQxHSW178t8tyfiGiKDWbwUZNKMhg7An8fPC91ycyx0CQS2JvdTz8L2xewo5vvz72EffCFgfdwYLypp7rdyPMojuy3lhPcUDga76cM111WnhAYZohTvto3jBJ113vsevLrdUStwEAsi88Wi+VpXpDTyrt25gnb6GMiL1v+e32P1FDd9byaecj9bGM+Jl4Z2xVH8yY45PRJ6JFB6xys7qyFA4AaPlvnHBSk2kwqLRoGwNXyC7cbvq0d2Du4ZXMuzpjytjpNhTVxqYpZpZHBHZrsak3WlKZY4+Kc1V32QI0tf8nWE5jhGBgoXWh+v3w3myOR2GmsOtehcZCtumVbkrDjJrAmPXdswBKyM7c9NyI7+3arlt73ivihUrocN+1GfonQzSWtBiXcx0f+smk6KzFJTMuzqkhsGC0/ybYVPrAOBT+OlZMzF2xX8qFmqsCmOwvboEm3ZPH3cIIJxwWtqG9xHe13NbbKbR11c48tQzgvkK9UDqlKWSrlO7KZrV5l8h1KcNeVYWoAiCCi7mldrl0Io/mZDIc5WIAB+C1HeUfdHh73xAP4fpsekmEDhr78jomqIwo12x8AEiM8rVUZeAk1q9SN6ITzqqCaFdnrAGWc4Ye1y4XWIWRir/spuMGt4JREW3vnpjRzcRmRnUlHrRLm3HPUYb9LIDTckJkTlouNKt+rqAgMYxpjipyyiKzMRZjFdAnskpHwN+Pw5mdHTasmbBj3U3fhp1EBj5XkpUzLQ0+9V/hWW0fXz371m9998MWVa//638DQyNjE1MzcwtLK2sbWzt7B0clZkohJRCAgVFQ4J0617wzfdF1/DEwUbGxSHByeeHgknLnw4soVzp07bDkQnp1QeXV04m24ACASYhAaCaGTEj4l4fMlDH6ESUX4NIRPRwT0hMVASCHEVRhhM6LQLwCOm40rB0RkGOGyrFLEKhdPHnGWT1wUEGeFq3RRZDguG3FTTMRGEDclKHYcVDnwKFZJWGYNZC3BrVslZr1NcJtX6WWL7aR2EE87V+lllwNwBy8t4ZCjvB1znIcTzqA76yy+X3Vi+BfAd+8g3QVhu1deBuNLSBCSYBQEpyaEYEIRSqiSiZMUQpNJ6EoJQzlhqiAslYStnnA0E19jCNdY5HG1nd0AcdFFXN0nbh4Qdw+Jh0fE02Pi5Qnx9pTwPSMCz4nQCyLykoi9IhKvCekNkXpLZN4RufdE4QNR+vjyfWCMCOABZgTK/r2LcRl3Lesq3J4igCBwrLPVNhgqPT1MiBC4MGGQfPkIhQoR7roLwRppI1uVYLbRGNDFIYCrnzqWnIVwOtB3dXVXdHH36i7zKndu2+bp09/tW9swLeqKaeY0eiqcLNPgT8OaJ9MUPPlMPBuWQSGI/+vsvutX8PfaXBZf6efp1/K0aMXCX7Tr7XCb14pbZP2fu2pHTa+cii2fItCDODI1+QmA8bQmn1cQqUPFbJxMCUFxbih8+aNS0aDTM2L1C3TFVHd5CnloBPhOJYEuUNxBUCIjShWB8t8EjgqVgvLmuMbfDXdpdPkoBAtfsoW0QooGvq2y3trktoVdak9wgCOe+iwdAwc4XAFF/ITWoLLBWUSlChQILNzYall3pA05hMCUxEeJcpRQTloFpIqMB0NRCEEIkOSsQQqoQgfcLp1A61svOTEVf22HQQpS68RYXo5XDUc4hwyBj43PfYuCiDOxj9UrXlXct8upxQGx45jFOmKjjGAjasfKYXkWdTOpQuFbd7g1EndcmNTElGAG89CiARHCjj8DQPxEzBUWsHQTUl5XtC+syA8R585jg6VhaZSaDE0zs4k5bbG0TAv54prHOdnzBfRmpPOBFoACpjCHBSwZKVwobmdRvr82wSAFQSemRGvAQLkQMIdlts5ROWMhfCStyuzERBitmAkVLVZjECCVeQnBxtSOlXr/uozTqvblXnxDB+n+7UPNddBPN2CNWBM0K5GPCZWm8VFVGRfm9+YROZXuy2KKiO65X1m/BVcz1z03E7exQWQYGUXGkUlsGplF5lOLyDKy0rTmbYgtbye3Jw7EUeREnIlA4a1A4alAQRgF9uEPd17oee2rppBC4qSnnn/bEyXLVKQIFCGhO7meXL9/BPr9xxIkq69FFB37lvgPCXVXmhXJJARAmwpq0Cz8mcgi2hMdnXOX+E3gGhu0KCIwAoWy6yGQwscBnBq3Qba049zJtKceU+681A95TMqKWy0Ge2G074r5Hp964g/iw4kr5NrL58zhvHa+Iv3ODbAhNhIbY1NsTiyQpflBtec2dGm2R3ZP7Y8dqo51p1fOB4JVh8Ii11a/L3IS0apQJH1boN3SCbp//PDSNRf4AGWwQDaZhP4pMovNGU7gYA5LWMIDvIEZfAUEt+oy1RbosRH0hBOiKNxk0LOS19pNHWEGmNtvIn9IfDjkN5Yi2l4b0IZCI8qYgq+4/NaSsrqybtp8sf1s99z+s8MxN9BV09oa0FcNFYSFke7vPkxcLZodGJScYdq9WD/iHVKjUGFjxt1XwqESofRpg/avcDqx1sgVUUgXFRgsdbDAlb7AynD0AQcOmBKcZUa7Sqy778MaciifdzFERtiYmGiZysxIhy0lgXnEVWTdsxlvycjukz3BgY2FxKnjbD1443/vK3jBagg2GmjZHwNce0BJQPE8BByBkiqZXioF9fbbaxsg6auuvhZi/2fn5xuMj8pyG+gf9SNqIOi3tbYJfIA8lYhAAnUMpNT5AxvC86cu2+RLEUvG7dGQNMhojNhbi2HBMW22A4JjYOM8mPms3fDLaLcRFSg+GHCIC0QNBFhgkBc+Ag0ihLhkkC7PIdmNPFoWYq5UolFSMeHiwRRVzUDwkS43JP6gJmFD2XS+SO2ZElHgzMuJpKhZAgnEO6ATZHOSaw/Q2CDUXADr9I9+C3EbqtrSAwVQV2UBrv3HAXKT5IwLwphUnILhgLXJ4HbgGABc/ZpMog5wyAsRtbaB1T1lPQjQxYBasHbgIE5AAQ3YDQ4BuyEqErhELAoM2EIjXKxc5caaqB/pklmn67d6UI8awgmcRu5G8kkxKSN9SBNpJvcdLJMuPnjpIS4y9/4OtiBpmcTJU2GcTemSUaeICOBt2V2kFylc93DMOiE3+Br3z22A0QDW56+1a9HaHfz/1/+/f6UE8NXPM+5/2n/2v/tPLU8jT8NPWp+EAQFcAFwH3AE8ZzLIeQDIGQFPOTKev9hNmVyTLNYsmVWlKhNNNUyqLPVyWMw2yxwVUlRrUGOyTL0IlD3p/35qtagzJSqUWmCR+ZZoNVK30cYZYZ40Y/wwwXQPPNTjnlHa/O2+8Up89skX5dqd4HDaSaeccdYvzvvJzzr96je/63DBFRddcs1lM1x1x0233HbXDQettMxyq62wyhprbbLeBhttt8VW26yz01677LbfHjPtc9Qhhx1xjN1x1x3QD2t58hUpcKIjYlBsKrgpOAQZNLLgo5kfLanVFLXaVIswUkkJ+gD8WppJBkE6aYR0hQZeaQeW8sorwyHzC8C9NwfQX1oOIbLA6kDrbsD8fRIdbKdQ5YBSHJlYabajXZUDlp6AeniVA57ikux4YsiwyK1k20Hp6pI28hKywlZiJ5IQ2C9Q2mbVkHaZd+VzyKxbar/IKvjKcKVWq0nlQJCpBB2hsjNZRaNWBS51/2ODklpwI7SW05JusU82C+wXma0CqZRMtHc4LfYOnUBqtaocqHwDFJtQ6cUcnLpTe5cQjcp0z2bspS/rX1usRi61vzL3F6RD2+jsHDo+NjXQRhEH2lQ80TvQOO0nmGNYgkBX1NqyCqRWs8qBnloyLYnmiE73B5WTRLPYaDv6uA3SAbUVZD+wa7z3XnuIuoHLOAUoJdfqpv3A32qte2Tl5wtolSFp3IIl81eChU4ZrdzZwS9pUQObVJRlZk8VZq/ytTJKpyGP8Tqzx9lIfNLcjcy07IznVFeOQeSp13iSkENm4ZU0hfbiWq1ml+OUY+/SZx4foK+QG0SzVwXmfWC8V9Q2udiZ1byydgjW2837AmWKReVsW6G9pyu7urpsUvn1jeN3M5oVcUZf+eGB46cBzYg44H10P466LIwZL2qUkqgw1DsctF7XdKW3CKzO+Zu8KKquqFDrdHIeCx97rlvPoQaR85Qmv0rljJ2+3p2UqnN07s3rDbnpjEG3v8kx4a9TbJ3rMLWdR9/fc3yp0LSIFUadGFu95HtVhc340N6h79tIBemGtMMSdfKXYBPCk4pNGqROaTxF66JVg3MGFGVn1jBFAkbxGTO+tF75yW0BwCv0o6h1EDBmXuxZKpmlvduv3U7jL2k0UqI12NArvGKNvXVENhNngchCFweo9oW11kMmtJVYwQZwpA8Dpcu2QJyT4Uqv3i9swSa5Vy+aiVeo3Zjo3tE/Dn3o+tmpeUYHcpBzhph8OD4AY1uFtuYEplMcT1Gw3VTOr0XAq2zelwzZj7kNaANBIZ/MdulMbG8mw2MRI5z1NTqCRUzdYRgRDuUbjOTsudNaRBMwpbGSBYWl9H7YyntB78qNVir8M8Mg+zyDG40ozbShSyOpmM0zSrS3iaFvLJmA1tnp9pXHqyj3KysM1Iy4OTPVk7FJ6jnLiQWcCXvYDCfrCSDXfaZDUVsUiR0xh3I2YsoUD0cZ8ICJ/WO3Jmc2mus1WrF8GsQNhqBUj7XN62536yBGmJVI31EHSUNzlfZ+wKRz4Tb9PLTnnLqstJajtSxiZdjk+uVouFnPDp2+wFbJsyHRDiIF4ZUz2cxDIbMi7bqdcDqkvYWAF+0+OgNCzyCH8d4yEjKWtVRyYTzokV1dh81QWe2I7HzMVZnh+ipDyazW4BSVJbQWFJRVNqIkTw3lj6au1j3I2qUJykJqv7kULFnUcjOs6SKKfbtlL3J5zwofNQcFgoGF5V+gsqj9nYFlPapGlqtiXgkzzTm/Y9o7hHAmMRuMaNHBZ/VlO6kT/inOQBiZuYS06D46bq+xJMArsemLnZzLpwIldCGbmf56mdBPEKnIBVqlN26DD+uii7Bm8Y6jQd9pEmuYX/fMFsdlSBoYNqdzh4iz1BHuELRF7KGELGLR6S4q9d8PsnaayupMefEskPNWimQkJdlnj5bz/Vv1UFM8kiNzjGWeFgzKGD0uFfiBmXPDErogWmulS2YUyA5zrCprCLqNvMlf2ZCezYjZbZCX1UZlx58v+d9YI+gNNyspMLF2uigdXdSfrvRwimItzsmP31cwAdZLAmPq17iyD6N02bnyhEoOp1NKJSfxD6CzAZvw1quyS4uPsKbzBhdmjmY+rZbKpzQO/w9SV9mRaklvxT9Qv2bKRqakcOJRhCeqKXXTNjxMS6GlTc+aoLFN/6UqBTUVMhWnySr/mbjo+N+8FIrIJwC1mhrzxR04u2FzfQ7fltqi6X8TL/NIfjJAF7KE/2cqPQHpGSKNhaDp/q/uYYOwE045UftZy+VKnKpNiNaFM62UgH/aAr5hJPq7+WOC4aTtOdIYWSUiU/qC4YA+h0+XYF0UT2H/G6WByCixfCJmo14jS40oogVdYpCxrquSYiuV1lp6XVyIENghSZVFZDiLEYG+Gg4NYW+g9DnL8ziTM+s/nMOVU27kLqXoWfPn6rOvOLcJdYu89Iu6UT1YcCrzIIdBe7ayYflQO6U0Nq4g1Y1HepUpgtjhMJWGfSWKSGL6v5bsmYviUV//Gslgl3CHmP4XPo2oZhjt6hJ6VyVwjkO0R3jyiEPuJgDanc1dAHonJL9NoNoGBkhNdDw2nVMuZz4B6tE5BbAHyr5GkjhOuhhnVr5Wd/gsp5hCw+28Zfs23ooVL6PzdkcucNWRXv4ffb3J3dxlErHmrMFhLfxcL9WHlASJ90QGE56PorsSVqIk1h2Yq79FH2aoyT8T79vNecEGitPh3uqXnUxQiNYCOG9aJMqj2VmYRiIxO/TZGo32KRcGE5Jv+GZoJJpGJ4cE34xQLj3axVAlM9QIdVUBjzh35VFIf+rGBcIcRyycQX2OEUGWSL4CrIrGO46aKfdh8845+rsexgT4hBLJ7jVqHAcQTDG3wr5JNDliiYNQCBzcRIxeqpjYcaOR1onnYnGAwaH804HWQXAR0Dts2aGJPdshhQeeC+PJVXWBMSJzDPU/G4Kzt/Z8XZAuk25SsfJNUosStgoOdtjjkeCHLBwsNdaDvVsqRnErI3OgUtk+1kF3dFu2PCqN7LDhVPFMn0uiPwFG9EorrbMhqQ224W9hU2fcDC9X0zNW7+v2JtgW1uILM2iE1B4xiFbKt439Vko12YlEYbChKenGTHd+FIFeY2wTJIEP8N8tmT6AF4b6sXbYD3OA+NClUZF0kU/Ag0itk1q29T+jNbs7D6xjV8Z7iK8n54aQfvLPyPd3b8fYtL4TfSWo2IALmhE8H2n2Sq+6QG7elaFvverQKM6hYrAQjnQw4B7dFqmSCgzgzBitd4gz55sA2RHElPeT9VVLnFbu3XX1StZ1YOlwzrk7evNO+hl69tA1WP3JPp3s06q11eYTL9URm/CP1AGOzjbbt439voWxRDE9z3BL7MSy77NXs2StzjfBwxWYnhrz3ZeG9/bMsr7VgNXaHQzS8OSUeNAu7PNttAkoxfKxv0pssvTsufVJDqRnL1breiPwicC0YwXtDeV0hq/Gxc4ZYFgtjPVDqTYa5isTf1xr1tjMs66QP7cJokLZ8u5BWfTPYlaSPoU+jV67NTYvpU1zypap5agIt9KTqZ+poqxqVHFIV83/a/Md/5ooW0yZiSD2y6ShRFMRhX20H6kF2TJ5gVWxgKnKzHTzqO13c2nQslL/OIxicHR5EYvyhanW4OZs9F+WzdtvTNQKVfKuWOUrbThwwMGZZ/aypbNtyKcjt4Nx5Xo8zOfBSBDMslaXFWnq2CeQqKUZK2VteaYUwMY4pt926XEScq/ukD4NbcJU2mzS9pKpmJ/QR4lWwWwNC1jXS0RsHllVa4frt96wfF04IT2bVgnwNrg+Q3o8L11xE/qK/kr5dTCeU5APkPsJ74gN9yPh7AP1kJkd/5Fet1Xy1DznwdN11gVHCTi7q591w/ku9/z96LNaKneIF6pulE/Rw6YHuz3sjbbfV8knWbDJKvNw5kQzaBLYjg0Mn3T3qjVylynv2VS+Fpzbw3ZiaGO6ef4NTNJvQibptkEmpVfkXQqXuTrTbH3X9q7kEvO6Hn7HUSxzQW6jvcWWirB4AglnlVJdsi4stVY1hH1wiT/fINCwKJZQq2EU8V6/7X6KDx9u5QsrGxZ2dro2K4VWQRYcSt1zyUCTPCCfVirjgzzaEVqrnXlIqZdcaihKKpWgRINTktor9XV++rZ6tlxuloe9l8pbmF7O3FQDgss98CyrIPXR+cPh/NSD1FhXphX801RNQadPFAYcdZYCbhIZRJUZCsNielW23GDV8jT0yndfpaSmTwvvp2VjEX8w5ArTitoDDr8DUmkMWsifmpHCffNgqjmX55rkmq/2jVy0Act8vRq5VUEL+GDf8+wiZ308KWkeTkwnOn31uRSyie1oiCUpP4p/Gp3rIk6PeaxVdswi8SEhFUdR6KZt7eaZ2aPZZh6X5wwtpdcVPZxDQ7yS17DTUXZUkO3GSIOTZrxKa+JvFP+DXzXAxR6qk8idvtq4OaWYmMidO4D3CKeqZiYJr9HZ6NcEwu3V9/S2L5TKSFltiJRdLtdrVX6X+NtItxJku5+6AjeGJs+fdvzaZ8qu5YNG255U5WlprWBCap7JL7JnpCB4e+WwL7Eil4Cc9qtDobJ7Tpwsv8HPDVzOnpIUE6Oj679nXJdkLO06yDva8AxVoZFiH1lhwCeVSkeJBrnEyqFEfimo0/v03xVSfn9AGyIFdTMFux7ojD2nDEpdXw/0I9WekUrCd+pLlUAdU6Oj060VfyDNlQKbXnXBQOHyHuDRQ2YOOIYGTCZKP82QyzT4mBStSqImMNjbAGx45YAn025WUT4PWlANt2RrxUqXn4UxYoKJhSl/CqryR2Z7YIlKxgicy1cTt6QUE5O5HQ/xqAZpJX72EKLR/kJ4PP3r73Tni9ojCB0aUS/8mXMpTXRJ+XNC9bP4Uhr7kujnqnmISeAL+pIhtCW6FxPGjf4o/fAHE1uOpY0/Nubwe1dp6vhTaZNPVc1H1P3SNCf5qB+r8vsA7ylsqqYYaIHjWnwkXx403L+ooiBA8BuHKU/B5afaX/YtfNkndMGTgi/HevpE3kS8nAqNOqRJV+M/usFiFJQNaLDUipbYBRbAJDAB1oXIQcYvNBztF8bB1iByzroTh3zUbkuwkaMLdjgItogg21yicAVT8fp4MOVS2dWEgJhgmeIBPX2DYCPTCtG7vF56lxVqZIKDbyrt0Xi0JRqN23v+sED9Z5P2C9wk93N70gv1H0uCF4qSRTxbXh1sa0zrVNZxrAFGj8/L7HEEmzn6SGc5sSwo4rnlavcByJlxO7tu/KFzm/HixfH/x1ROHsKV81r7WylyynQ1r5WGokOiIV4oNiQWspzr+48jKkvaC3nB2liWrSZvPpHD9sqWPoioKPpo6qdzbSRglVNP3pv5lsxaNrsSCluDCpOihly4uGV1Xqc6FDyvsb+nP5F+HXZ6f2Nrdqd1WVq8y9T7fP14JVLXxLFrbfocJRrk0inbAJM0LeYB2sJr4qEtD+4z0eiaV4qhQaifFa9rjcXc92f8ZN7EY8z/GFrGf8yjNcP2VZY2CES9YZHGT5zqPMWnf33nsaZRpobenRcwfLW1nx1paIlbdAltzkry1HnoeUcjJ7or3rpHQfo6VMdtJquPLQPBUgH9fcSoGlUVreAQzPf8GKmjXTzDrt9qo5fINVwOKzD3Rm1OLFpRjHeopWFsg88DtULXk9lJxbm+A37QX14uBf0HmtfbMM0KU4JoapRo8DCxrTcMPugb2+TT/gED/2jytT3u053e3tducPAep0kelzumuhziR2n8RyZH896+ab5awbdDhN8GasfVd+/KTevNnXI3+XNF98a0IZvTpvzqrvo352tv525x2i7x5N+35wYY8KqO32qSj55t9RiZSE2UpwgC3ZAH6BEqdTRdHaf37nWtdEZJrIEsM6eDM80ywFLI/llM8EUuDcvYsk+nOHxuX2hPxA/80njrikMK8bIEnwiBzf8boQR5c2iTHSMSubE9gIXNQBtvfwJsmx/zwtdqfmAieEcEfD1rvFn9ZmIEHMUqdqPO4LUMvN40dAf8e3NHPYVDNKtFwUJpcdnorn2D5epLF0wvsWpQLkaIjRKtORavma2LF1xf/nPUH51tv/OgDVHzr1ec/QZxbDHqFJZtBWYVOQVCnPddiFDKNY5OzB90qS8dln0BKLWgPFOuBZVsFymUiZ45v4uNLAmQlQZ8pcrK7jY2+6B9K/eEHXo3J3w1vv1SQxGeZQZqsY5iEQH6P0AQBxWgWjVcBaoV/FUV2/tfKKMzfuvnxIDXxUQqQtiHuDKmwVpxJ6Nc7ZLTsJqNHrRYrOZGrqTJ4wtannHHWmFg4soehrDygEonE44W6mQqb2SloeQ8L5t3vuRx9/ai49ptpnfvqHa+kOD930+QFmXyA6u1HCrKRE4b17tihZPThKc2NUx6++vnpBbS57++Jb38XQY2BPqOIdau05XsObwPvjn4id4e/XX/ZLaBhGQs4ccLI3ESumyc3VvsRC/CahnEqbu201a0WIKfe4fWyNR0cgZlDj/ANVvU7bV8U7Erb83fpFCdZQ9MgzTbS2gEzTs/WryyvNWp+NxI5Ss0xWwEU8dSG4LtifGySM6cRUtDUGhC/ZcsxDfMmrPvRnZmbFBT+Rwzxg0YmTyC/bEfkCxxtLhUL7UUnkwtESAFaomMCM0KZeY7u+JxJlLqxd/AecVifKOi0gs5V2hYYYvSSDGtjvN99SwTRlNoYHAI1kderNAnHxCwBQPy19s2uB72T2Ps809iz96PczCRpf6CW68pcqP1JUKtMAkMbVBDQxtkEMhNasRNo1VOeX3LX1DiUb5kZbNeKsnqFWjpXOpw6lzp/m5jNkh8Ou0gsmnXXx7RJ4bPrRmvaWI3MKPQQCfXN5G+GsJ2cYn7Cw1oJg3MRe0iEsatr747a+m3Ixz5K0K64ZZns5fNftFEKiBmFKTdXXmCnEE8LgQY/07Y/VHFfXYWTyO9tm3C7cCikmSDeGUoJFlT3bRUEbDN5lRFShfEJLkhFgiS2YIWCfzJQQ6h/xLaKRajnZf6CRz5QbjOS8DPQTNYkIuqYdU6TCmq2jiGV17BHqPnG1htrvI2tvHWoyuMm6QJuF8YnDfsZPabfsXb5tzmXOIHESKCuiu/LAwcjAyMvBhJFgMjADGZ3lSExXPJIuzIYmH9Jdf7h3vLl+aPxIoYto9ZcRZ27ndkYmF2/v0lCpft1dxly9tQowqJlMUvKTlABt+sxP5u0tblnR8OyGHMW1sHuKs9tTXxVVOkn77gEs3mz/bolh5wXrIDh6/iGHwC42opj0ICsgEShdr8SVcfYtyRSfO/9f+hVQ2eLnZg2gATi4014N/l5tducqZBcvlwThuX37cvQl5ID5UVFMnjtqje/UvUHLzsJuU/oj8oAaW4rKCb264OR2u6NWF2XX6rzCnLb2XXaSIza6LqMLe9oDt3ZNhtzNRE3hXunq9nTtfHLs8dj4v+alBsh/zZHNod+h1WIyPMaGS2s0yLuNzP859uFYPDQPHWp/nP3S7NikEa3FWmwoIPwFN+qdg9zC1eqniS0ldmuydF3K6EUtrazbd9vsE+8vH7fVX3uhKZy5OMx0W6hPpOrbFGWmN8nkrR7AjtHO6c0xXuyu1clgwnQwDu8sBtBPVGvSWPwwsXuqT6np8oxbNJBPhLXU55ns7J5YiMEDKPpmFTbvjNuZziMCYh03V/QuOtJOPh/5tHlaP0Dh5HbPIMo9C06q+J15vAUa1/tc04hCXebgaz76dzax1/ogNMuFqsmcl0Zi2GYoQrtP/6/61Dq/KeYabJxYGQoNvtbpRokMukbNUoL03QDAZqXKaWfdM13cpZKq+rjXqjqXDYteOVl4mYZspuZRF1MdXYzgqu5ecyCt0q7XtOZ5iwXqyZxWqml70MVcG1+HGzq3AFRdWzx+GvS1cXFeCqHno0wddRohBA29M5DinFCHjQeSPy0JTSTY0bHzuFd4SOxy0Ys3IiXDHRgClpgXlhjpWOlTCYt6Wjw8PGBLCwvW6WsJcnsQksGlSZAX/y2Nt/DXSZ1qpV91I+8pnZmajvMPgsgLHjS4cdikOQSvvnyDYldQNTzdxAZa1En0Up/7wu0FAoMtjrfyhKdYGM8h4kG3Mo81eb8q2gRVg3YyO7EFpdmr492ui7BoA2sXfo7tDhedieMxtxZ2zqjinrLNxtlKdgxfkMZCGA3Ru19avfFPUy4DsYLsanTcn2sghb7pK7Rp4Gi1Ds5kb6Jq5sxLJ/lL+d8J+4kvgqQNXC/N/4Uf/0nojsvkQf7BPo3p2hzMyXK9a+W7mum++o2xNikwx88gvtQ9TS40MaNyl1ptRWaZuL3b/+/rvN0uhA+ar/WxhHEIyjLYRozWQiArMlDtzmQTh0mwEB+QDE4E4j9/PtZPy7p+gi9NN3eKXkovAVmtw+28cL/E9GokStdF3OkljsRiIxaLcP3s0bgbkkzk8PGkhzi2/Ilx43xNzfcNOetdYHhlfOa26pnBfIqvfW/uhQOVysUzsfVcOHvrZxnRXqR7W7THyG8WRiL9MgWBJAgg0cS4jW7fXSui3BBi4YStky3VKHWSQBIUeW9i/b39Dftr+ydJANlNlkCXfJi+29lrydlvZOooGBHI2uDOrm/0NU46w/eAGpvbFUWl6yQkvllqqVyqJvJl4PHsGNknCs59KjiWaYC7LAaxQhk+ahiT1wpyEvGrI668KBoV6PdyAiYJXJQ1d6v9hnI2YGqK7ahhjSF0NTDh24jvCOqmQMY595o+jnPsyb3zp/n21fxT7blKOq6RvpsDX0jiOqyV6ODsdFqSjDvGY5GlD/KW9BPG75UD+K+IDJ07Io9ojR5RESuz8q595NriG69v+v6qV6qjaHm55I11y5rRnNcPg8eke7qz5C5QnEvB6lWrbzc9qkYkuiJb31j882E6VuqtSAcascISbr+6LK2cO5viZFtDrYAuJWEAlMJ6JUsN35bMvpTfPuoHIWjMj8aHtXpjacWbWgbSeo7Xj/WQv/Q5mTEUE1KMoI9crkjiGIZD6SUoeLlsqAkETjIBUL9QJ2+TFV7FO3KFbGKzBydTt/+u6FWzJ2h0xn0iq1OpOMn89me0YqgzukyTXe5TGaaLG2PIGCxDsP38mxW152CnTH870in0tA140+KjddGSfTmQwVGOjTt8/LFhZ6Ph0s1LHZb0LbXBMT59+t2GdyRqkpIpGmm0MitZPjtJVBXkt6KCzUiivIpSA2UuKUKtbdf+qlzydtpB34V4diKH20HzSqv/WUY0TgG//jq2/wWrwGspoRsDlTp8zJTh10+B2w+kkTU6KKor6iCqFVIJ1CwlnoP2lGKsG1e3Hj7igZc/fJX4In28J9QxH4M3R2pGetZJ90TTCG5o8gvGlshSetQX29x/ZnbNaM41vdAkdG3K+yQTaSG+CCneuCum4sq0RGQabUZeSowyzK9AqUm9HvZf/DjWlGLjyvooOFA+ihvCZVO5seLVen44ytbEeQ0e0fo0SDIYw4TfqxvvK2xfMBO1a9WNkLxKONsabYd9s7oP7WnpM8M2AosHG5BTYDD+CdXPwnBv/qBbar13dwzhoES7j/OYjRNMNG1HdO7gftpkQw6KRdGNmmJp9hGphnyOzvBlBoUlb/lW6F0JGGsYKgUlNiQhkmRIc+RsPyH6OxN8fp0N+DYqVaryhGDR6O2J3S8+7VFPxgNjH6aUHBrAcsy++CGLOQTfz0rzTyvxS9s0RXqqEz9/7QiMNh8uEoD56qnnTZZDyqXf848UooFxotOHjjhrYoY/zxjPHwPhVJaJBLZTaTSaamY9Z9H8bh3hdyzPuy+vpsNSLr+m89R7VGix2konUd7E0pI7ei/DhvWyeFD8pFMqdRW4plARkAC0sushcyzSnuBsEuFDiTrfhYa7TKOcRTNNgnZTimXqTRyNBMXNknMNopIicf2XALeJybkfsYoKsv3FY0NA+ZN7ToumoH2dR83Vz2opSR6y4/rt7eShFoFCKZwwgaLfaldVg2gADYWNJCtB9e2Z3OMvUBzOYsKHrFUrZ5n+RvmDfzXGHTPpbDTC02LLjHCxsA7i2p2Umx2+qdyob1oM1ZT26aLVN5cP9nwc9gft7UrZSbN25wv7geVAQrgb+csRG0ClHPGpm94cWMRwQynObYNZ+Q3CTV1TjhNGoU6jSB8/aqWjWJ9SAucDTCZu158aRrujU0K08wbPyKjnFjutlB393JlGD+wEdjMEr8H5inenslokKR5PMHUM0yA7+is2gk00p9clZdOSsHif5VxQZMQy9PwEqvcyz7l5xDyKmUjXQJprHe41GV8HwrzKL1HrIsqSZzRgbhy0ePLwmct1c1yCh+ARblv49l2NFlD6VFFuXQbhPHtXdzIrZLy7w5Uvzb115C170vFXCXyoVRIRU4QhZwpKzcgS5rQYJT+BxbBCNzCo/DDis4rX4D5PU898nv+boo2oqwdZunFEfxfzVDI6gjEMCs56OX+9ztXv/Bd2jZ8xP3uZvetvlH1zMCYOwbu7fey6Vw/LO6Pn5A97nbvXzHO3t+5z5303uLxHoD3SF5CSY2YWTclAbfGc7VeMkpH3Q0YQSOb2LbmDACJ+iAcKgSMzJhZBzAkFggE0bgd1h1OgrgfQt0asz2Va/6k5Ta0OlNvdpDrRBf3jp9X7+v/dC6tR611zhvpVf/9wEJbHvvbfL5r/9fALaSAFzgr2SmwsBLGhXmyrjEq7nR3Z+gcEqOtNYrCd3JZWrfv6c5VF8o7j/ts5Yyd5/nIwOUr6c75CBPVDu/S4qGC27FjMlhT5JaKHkhEBCHYgYdMnBgMkgX33j0n94Y/a/EUSU/BXgXUuS/ZBpdowM9PQTKyiBf+vitmEFhhGrWMCKDhh6gXmnnQbPnmgnaIzIb2/9MtcsRu5c4avbwTHSNIPcApOJl9atAHufIHw/7RJst7JJaHPKbZs81M5DZMkS+cNTs4ZkYZ4K6iXUc2qnVjnAucK+eo6tjpFWRw3sx6muUpbs4iqrY1j0ZnZVk6hGMXVmScvXqHJejf1wPPIClL3Dv/gLZlwDx834hC1QEB5A/ykfU3rpxfdaX4pwEatJGJF8n1VMEQQs+SoUzdvhkIWGaBBkX6haEz2bpTN9jLqE0fQtTmvWr6untpNeEf/EY8LNSgc3yUeD9D9jxX+ciMfLEE/QACcmeFFGmMrlPvuWNfKtWMzWW8YnK+xFTZDf6gEDowkV2vxXpBItUhJxcJ5wixaCF8Ig48YnHhpA1THgrDMFrItK2zo+HfoQkPcr7tsbW3/6RNaserUhy3/+f2Eoc68VCfH+I0RYyNWRdOMn9Wp7PIxOD7QJaooOUXI3LzyShpJWAgkimWnsL5zAOuvbcC9Tz93PjP6lC9WBN7ICp/57vIyaiXQ31Iz/Ro2B4f/1eeZAbKF/pczB+9R7lI84R7Q1c/gPb1k02U4cZ5liWFNktd3Xs60SdfkJvzIx0+sxDj9j4EzyYm4bfJVBb3wYloSTP1Xf9yQX3Wp/Up3jPekbRyh4jRpzLwooVK2LEQ4kfuO3it21dK9pHZZXnqZ6pHCzJDTiFhpL3Sz8rKCYpYWMsLEpb6RIDaKHaqKjCJJqAoJqZATllvWahpEFbw/3TnMOFQcIJzrA6FLbDmAwZRuDoEPpeNHAz70s642payGVeAgJ2litGor7d/5bINyMi26uDDziv+SeCZsxBs77DhMfYkkkhEmp41R50iPusqSCpQUXQBCIBlIop504+sphsXIBmob9rhUBn0y5yhe2bwEIXULJyDnym9Q8WpNvo3DlbdPr6a2so/iY4l2cq2ZvMcg4546eV1NbIVDWpJKFKB8wgeSALKPE+8CEfHpXf0WqSE+pUiR/cu+IwrjMDSIj7CKwSAFIJgS+4SlAKKraLjg6DB5IkJ+EPxBsmeMMYTMvBo0EG06eKCudFVHW3sN/fx+YYh8MRQdrs3btcWCTamHZkt21H0II+pwDD2sOAEkgkOtRG/fCKSU81kMOwuk73waUL4hJ2Ue0Tb8JhQ6k7yJD5YaSYldIe1Cwoh/5iYs4IyOpbjhVFRGhpTMf/8oSaUkohtO/oYeP/3AL797FUQFjYeYh2ddKgYuP25rUPTrpEcTmlc482QkGnDFdN2wc0beyIpuulZRp9HvHrAUneRWa4hmHG5Ad8WUp8RW/Nxq/0m3XmBALOO9bVoJMW8/RG+hvYYMp/b9zr6BI2RqegK13F1dKe43AbFiO0XoKh813mtmNW1MlkCTbFwl+DxYYM7mIVpVVJqNioJjRqRN6uHpIrYbl+RpHLScXL7yD2EBBFmkjzkThZRF9zPUCAM5mTa7IziGkF9FO+Pyeh1wY5Nk9/ZT5WA9i6G0Vm0FA4TcgkXYKkIr8GhuFOxaPJ7DxLtjZQpk5erqomlocLIAE9Z0uKnUxKBHk2UNR2lwTukD5CFi1BC5Snt3oaCyErjNJOI2Mnmzja85Xhld7cT1VxaJRKY8cH/+m2UidlnJtMtwbOoE0ixcFIQomH63XXHIjFbVVrIvvzSnpVIkGig5RIE5JAgaYVpx+UkfLbl4881edsS4f/OH0PrcqxNh4QlurRNS8lIil9Y95Lfs9Tog+FGc1N/wTGmNCUhyDEgA82Dvy7qvA6GwzI77TyJOesjqXsWth2q1tLooCRvbC8mlBZVwbJEEGS8dZFb8fKs8vNR9ocAqrvGuq1BBZK5YMm/De5euf0VXXloRmKa4OjAS0RraFBurlEhAwwY/JVgMpVNn6h4kmSTcnGd9Q3FXcqOGUt7XNIkgRdMNqKPtePaValeBw1uhoyxg6VCGfLtDbgpuGFxjNvj/NTcl8mZjdODEQnrrpWdaBE0rl19smRNC/JJo/Oy7TQo1vApc458Ki4TsruVYGOeD3Xz+QbcifkQITZCufsJB9wkKDKvPGgL6Xb/ht5F3v3LQzgs8CjNaJZatT9oi/l7MpNKFXG5Iasa5ua8VVsKNuWnX0eY2xdMYRldR6lnvLwiLpmqbZQlG+DziBL4t6glw5P+f9mj+YKl89uGs7XYbb8I/UpPU2qVv1IXnz3o0wh+sZAd7FG5CGdNNxLm9iaN2qEpKOuvsNroyNboRXHvNSnVxT4XW3uJ3RrU9/ulIeMD4548XpSyLVcDGKbHoLSVXJBKvB+0qZ+2n+kDTaHJQ8AITQ/1ZipyTUW6cIW7kj4T9o0tkYfGJPlfbYN6dP7hD26jyqz51u7qu7p0pbUjOM45eG18GEwhCrZrWun8ryaTGV0SAIl6FpMiSW0OY07VXjj0qaElv2LNh+xXEKYuRYi7t0isx5JjLP8UWTQdg7dSW2+g+sakCdVYCal3ShwNVAsbX2bgDte6ODt7RK5aWrGSd/MrroWj7hX2Yp15n14j3vnvTQx0tzouJeXd5BGKdq8WNudzxjiLfPgLJXYUuQO4Eftuqfr9ied1p3KmCGPEb2+boApfEbvvgfxfbytMGprIxK6R/dGI4+H99+pAVsohH3b03+m4tqD+zhkCB2dN/SL6NfBZgtsNFZnS3XWuxjchwevRv/w1jv8uJ9MvGI1qsrNBCIpykd8ww/97h4MNaK25bm38PUL0eXjxdHF7wteN8M1EQIeTNi/p/9ljn4BfnBoTp+5v9hNHP2D1y7Lu6GM3Ir3ARpaxqO/F1CvH+G7cexYDRCTIyRhHshm6O74yhZ+anMbYY8RwMN63x+gy1EiQ/aU+Fdnl4y2N+xQghbAfknwhu/MXtECl7uf5efHEielyKlRUpsArGSkhxVszf4cYAPqTMKEHwGshr1iSjq1ThiMc7DzML4YFz4dxaRoONADGqaDEjjlDkzTqO7o1v0FC3hdoOpWVJciyTZpy/0IqZJeXOzEf6aZpyhugCEEaxavQzFmTBm+rV7dAhpt45h8LN63Sr1oGi0W1DYmkOezd8XTVpSDBclrrgkkKsUSz9vEbesz1/1M6LBNuY6cLhTcBYJjDIzLhHioe3B3siF+rWapJxe0xFiYrB4WJWO/bg2ZZi7ZXoZh3nUHO4W5uQu1y/AriuvMM8+R0c+Z2DasbLAxHR6jPay48QiuC/j6oZjlP/foVuYW/iir/1LBY3l/AQfIV21aUUFSHru+eJfPywwPAu6BrylSwGe8XxlGp6KFNROhuHNfzrW1dz29F93XM96Hgql8FDNe+rOBg0cHgQF6cTpIN+zLagLs6oN5FrubmhFR1H/VkVvuhVD3ahnsOR9vnt0pCe6lorv3X6FvNJbNGaG0EL5T3vtyjGOGifqgP7qpj4/qpX5q6NLyLni+uboi1K5WmRdixDZmUC1LnZxpQlBIB6jVJYfH5ARjq/f75kbTNEgmaqjhgGLtNPOVCnrYo8+zvpVlVAFbC4lCHwk5vkj80/I5x5LjP4e6p2nIkdYr5Sji7FLBgxPjkL2Amvr1KJI8KGNqJRjnoTUQyAjQLzoAjIB9Cjbkgzl7kiwU1Rc2kbaoAXLhVBxtFHWYZqxSbgyKvhv/C7pogCJf45mvOsnHVxNNCVtasKhOMEpLEcp/vR1Q2g05cBkoe/T8oCbIMU8hwAqD0ZXlUDOJq5Id11wL12QoLR1mmZly0oQcEPf7YLkzWCIPkxvABjgzFU2LxyyqWN4NAIsNqlQwp1gTZRsBSXvYk7eXlTm4imTufIC74DTh7M40Mm7CJcCLcHc2ShVa+Dy3rZAm0y/VbHzgb4ODXpKTh5mptofpBrqKWICuappctWcN+LCCyi6/AThJLnCi/CgxvwnDTRJijOZJbr/aLoFg5MwH2CGDGQOloo5TB57Qhs1/ePnXyFH5YRQMtjXQO0bSZsIv6UllraH2kjXzEdRQI4YCOIWFlAVDYzMRRI1QmCpVjpufiCKdGSB/IB/Tw6kSVeyT7qIyqxQeUVGVRYGUGLK8Eg6P15Tj7agyTDiC/uz4pv6ibqNy/b0aZjGkLB8Y6KlujV0glwK63D6iEQDBZDS5dY/9VpRMzzonQ7A5Td0WMcuvaeQ+HCDl1YdfIJlX89nhAIc4wm8s8A8rrO/2OmdbPnv47/KrdgH7gDFAreoA4AFCwACgdd0JYAqYAeaAJeA/4BTgbWzoj2jY5xorJphihvmUxZkoooY/AXfqchTLEdfLz/KiFVy4cAWj24deoI0MQXw82ZpvmMAhw7DUxnl2j+czogNe2Hu6h4kj4DcW+IcV1pZPxCFpwtBZYqBhhI1RYlbQ0VdCfOMDrpwPNUKh8kk4g0h0Rl1HESEFjwnKSXqIjJ3AFOQw9iA1Aq7M5aSReIJS6tMmuXm9LrVo12tkJvwMsH0XiaTtyLlNtfvSq/z+XgRfqktvem9E9H3wO237NyIFdW+YqtHhPKaDacA5jGB2Sm8IeMZ2PGlzBwAWfK9ciZl9EPs5zpshclXvX3r/mzWeKpcnM+bq8oVztkV8nNQC/9IPXXG1MYsebz2ud0kVhscOH6yKCJ12zUP3gbd1pbXV9C66hK2aFu1M2kvqE3Zb7D0txTn1iMphiAH+EMuLtqaY9H2ipTHxUNTW7I+ndZmbJlEyu4swrESb0OYugCQEvS3b826E/bdJBWyRmxYNqM5cdKr7U3F11I2yriZahHZ0db3oKpf4d975dbC79rCSenDHXQxgGJKa9prdMWqietzgWWxmAL6R3Yl8dh67d0ZKC65z+3l+cqKKao54o9p2BEU177P0pXL12bSpBXrvu/u40PjpK9x8JHd9wdYw2qtzc0gCd1LB2veiHFAn7nwlLyi8gnvEKmcDNL49zKk+uf9Cjfnp/38p515nYdz5yPEhJhnxxjyZoVgXq7G4URBEEctBWArcbK8p57K3Sxlcoqn1IghSVm/XFqjoSe8JSXtrx5OHAY7NyUOiFHaTKzas6GT9vUB4ypQSSmRNaHjhXyd47WdqnIM5CMgoo5f8rLxbhbjL+Go2H4Zmu3HlHm7Ndk/cDIXTBBfqkn56VJDRsHvPgz37qBgRWEX08aGvAtAZV9sPndt+Tgr1tvsfqx4RUHCzq3B4CUhcTqaT4qThCmBrEUx1rr7u2hy7ihawCjf2cF2DlQNu3pT1AKzgMVNzk1AZiPKvxSRlfLEbcGfrZ/VZLFiUda1KsVihytq4h2APoE5yAk2zUiPOxkkpMmTU8DdgXAK6iJoBVmXTWhJZhEhR1tGqHsV1qqEZvLsv9CJy0Eqtoa/l7a3t2W7qRX5plNqqYaXuuk7TYsezMx1j5cxTxsXljdF6dqHrn8Mq79L1bTiioF8AuoFKkrP5qCl8ukcFSRrYlypHJhKLiHD5QROmVTBPTTt1sAXcYRsJVZxKrg4MDOzSJoPJUc9qijcmmooOMuEFfi8ozjrWg4olpTllDgHC/8ntwGez2TqSNPMlWk7aHVBKgU9A8w0cixmqTbdsHbTqYV+pyVj7IkowyRb2VqWNEZCvX9Ers0c+0YBiPMuJpkorbHhEjw3OTxwbnKc4NrhYcWzw/yV+OTY4R3FcRmPduOXcYVQApzItAIWWAAVVVDWaoITuCYW3MWooHBtcqAhKfv67dWaoWrNB1bDFy2FHJKJ05/Dw2OAcRZERCJ80VS523fJBnTzJqzz7+EaAXqKm7vMVzmyJ69v9/rWZeKfSpf05lZPfYklvyabuDqizvefWLKXjxYSxlQ8C1Et9r6GpUp8pXlmKmkguGuAw8KhyC5QhuJptgHSAoOLtbNAtfqKodpjyLtYmz+1Ve6JmEhrB38FWuWoN2BDUFCtuZ+oF41VoHbum4WoNSflBhv9cXUVa+1QtJdNQr9pKiLbpTLX2PfbxHS3hf6fchqPS79KC7x/fim9dYlXh8gV8Gd+Q7wXfDt8e32e+g9JhKWtpNagUOwK0lc5r+DAAyF01pb9/MwuA4q5BiwtPyn+f36K9Q4foq/9yjCgElPFgNQraI3bGEtusrbYZ1FjNPwLOqujvGNIobbvNl+75qjHpqXZ2g5JaimwUz3y1xSqB4G0ICMjen4YvNauKuJG/0+j4O8DX31uPAODbj5M/rYn/d2DfE1HABhhAQOG/j777AX8VpXNWQM6Vp6MupNB3XwrW4fyWJqX/CaQyzYIKlIU/b7JJsFKzlOhgfr/+/0ouJVHpafLNjMEPrZTH3ZtUKP8FWS1+8qABbG2S4Oy7cBsGrLyl2AoeWypnY4VtL4l0CBPE+VC5WKBNjHMl2LJkaQQ5R82S3ddZks03WNh+Dr/F8doBGWvhcjYE7U3ivkrMSqWchcaBCsKBBDnEghFiQA8hEArRkKgFaFGQgCYY+LOYMxmLtlj0SjaU4rDanY44mYEnxcBCZUD4UrLOf1L6WYhQgu1fL6DHFVPUBxJC6TfMjXJZQwGGtvaUtLdcSxPTyo0miXKSjRVzqwT2Zk5YxtfKK1fVjojIZur1tjixWynwcMBQF8VaidomsA0CuitiGMi2g59AYMpOgOyciDUcRqhEcWskiXlJanDLWdCahS2ZbsMEro5wVnwVEYLYObZcWddFC6rAndEByeYezKsAFP8fVvB+Ez5eO6uxwqYp8OogzDBgscpC8PjZDlPe4iA2vFK6HFHfCJBC5Y0hBPPzRJGswCoy2P5ZyiApjaTIxqNcwqy4yeXacJLKSRvCuwaKyoizk04Gj5MqK4/CbTmuLjKLcbAG2qAb9sIE2AM/4I3/EhhpUA9F0CknE+Sc8/ga9AkISMeG8LCFEwSwERTiEzgELMruo6zoAK6LdiyPhLq5PIbjl+VxSSZmE5nLU/CVLE+lFSw44oJ7tHR/AxNNoWYjNKnUoEWJWrOooXtDvSblNFIlGWqQeMnS1Cg1WiabOs3iNLEpVmkElWSlSlRqVStHqSbCl1qvDklHTUdL972MoEYSxmMRyBDlEDWliiYygyRMHl7yWCeZmqBegzESYLk0DknPrzocebBc0WSoJhQ1PZt8hs0xUUpQiiNLvEpqGICxX7Kd79/I0gEkGODMEiUZYKBBBofDEEMlS5EqTboMmbJkyzGMhVWuPPkKKHwBmUKl0RlMFpvD5RXzBUKRWCKVlZTKFWcy+F8uoMAnIIxAFERFToiG6IiBmIiF2EAnx4sDhx0Rz9leIlxiDBTHnXDUMb/41Vnn7LbHVoQtZJhYosUqNJyLGKfjAk2Rd2aaba4286y3wTRsVHFsOL5a6hsHkoTUz2bZ5ozp8czgZIUOlarVqFKn1ib1PmjQpFmje1qMNEprzkYbY5zxxtpsgkPm+GKiyaaY5JN2F/yu2H4jHLBISS7eK9Xpoksuu+Kqa8pcd0O5WxY7yO6z2+6ocNdHK3P13Q/dcYt7POIZr3iHH0GEEUUcSchII4tcj159UUTpvgcWmC9Bl8f5xNeT/OKfgAQmKKqoo4k2uuhj6K0PVWq1WrNT+Qm2mhatnn2IJezsRo4hLiMunlX/UKlsoZan65FzVCTdniz2lSSMzSa+d2TirTXfO1q/hyYG1Q/FxHjbWt29dVxDJS5Ag/R6XQhx5aNMtlKt3hBGNd8esbVEiGnDtFQL1kK0UC1MMxaHv8Oo1XSaXjNowVqIFqqFaUY1vIsuXMdrN6aPjwc1oYtBa9CCNaOmq69ltNxbU1J63wy/ml1yb+lx1emqWobt9tYWfy/jTibyTy/30Iy6HU62rrTo1yShi8EqbEvrAMdqh3jAjs26oycMzl0agwBSnjjAcuy7vETR8yXkrD4d5yADRVCTcw97yJh4oQJgfrgEYQJJOJP5EfIMZuLPm4xJkSScivB1TKpIekoCcJ2kirOYnCtIWk5LvOZHN1gkDRk3SGaokytpWIphfkxtGlnE8CHzY/FD8uKMQebHZjVIOH8CMjsOo1Y2l04SEp64MCZPICURd2+tzkIEkvKWLkmNiB+XqzAq8rW6iaDjQ3DI7pLFMNSt62GYAeb48oR5aueNxunY18AlcAzVLoYIeoK0Bm2TFlvEU57UYsuGkyiPQz2PxAG4DGQMaPXaRieNNLLUgsoD",
    "plex-arabic-600.woff2": "d09GMgABAAAAALJ4ABEAAAACTbAAALITAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoQIG4GACByrbAZgAI8+CFYJgnMREAqGiRSFwysLlCgAATYCJAOoTAQgBYNUB4GFOQyFBlt2H5ICMsd+QTGb2cqu4e2qeUWCNvgN5NyPzFS6DUHcckRl6S8pYdu0iHc7+MT95ujZ/////78jwfuEeD9Z7+Wu3awb6AYAKER64RgaSSpmNmgKh8cvjmJvUgeqIzc9dUR6j0tSc1GdKDKv2vsOp7EvpNfZwu2d6d3Czkwwbu9Nf2iOyIimjtIr/rE2NycuiUbBn9HNrbVdhgsbJgR7wYbpH865Uk/os0TzIjFUHNS2Pz0e5mnm8Tr0rb3Zvy/Lssj80fDNq3Tp/jBdJjwo8jk9uy+dGMxdKg4shQWDoCBMcFnXtUZ9tYO/ejz2mggOGjkWDsFAK98FP7+S+sPCjigoDaTZ4Z8MbZ/8/6Wxl4A4br2AEtGipy3bMa7nO5/OekeWLI2kQWmEYIsMMtCud31/jwPMfZomJWBTAhXtvT5Up0qG/23+n1VgJBIpoVcQBLEQJmIx3HxsQ+9clNtulHuZf//38+NBxfNTnd17X3KA7UbGuGCpwAhuCkhJEZwCutZ/PP9xH3oC9jLBTDz7y0bdqVQq7UKLSJFasTt+BT9UdOIGHiOhCKZYfMGSt+qzc9AAOKI5/2f37pKQXIIF2o9Y86Am1BxeqRitP0lFeaV1+C2WWsADaTC1ChXwFqsZosEqGSC3NUrchWMmiWOibc0zJXmliWs3vJaTFBwZLbTP3LhLOtMKXJsiLVFyDRyVC2lQr9m7Fg6IYr8H3d17AUZFNjKT8WHF1GqSlsGowPi2juj/o57+ns8+c7fCAQ1pQBcwFZMIRywiKf+E+98d4OfW56hFvW1vXawYMGprxqJgRQ4G22SA0EILNuopmCeK9jnve572VXxP+7zQC73I8uvXVKhMNopI579IGUncVvbOyGpABYiKeBsAQkq3275TbgqjyILASOQSnEMoBaq0MFfrMR1i27L5fonnME3v0aKkUlpI8qGo36wRzo+H1tzVuLqBv4p2QizM4n/7b87J55OT+Hzls9NJT+I9ioiIhBsiIq1I63rFDQkREQlX3BCvL6Q9G67bEzfE+xPpuhLiikR4f9L9i4X0Q0IiXJ8bEq1ESIS0ERH2wQ0XNoffNKhB2SZtjor/ML6EKWCgyrgCpMzRDSugEpTyQ9MfnNMBCnWgZMDdRwCNGOFJIQ9I2dzlbtp84JzIJzsYLyNeiaQbJYP1+JTUJD9Ef+/zA/gfmGfrDyEwTdLvCVGAsAkDpj4yBoIgBP7/b666d8bvTSFnEkdGgrdCuzPtT0hqmxAyLDsqwErq99UvsATpMTxtIiHVgAANArsLYA/w/LuZ8LolVbXxzDv61Lld2xXRU0RDxJC4/4CpK1K8e9KREp74GcfwJ7yA16JZzW538ex0TCq5+4VCCHeb4Z3izaiddnsKiRASi3EIjXGS+S+d1fV/FaKliVJHJsNEPHHzmWC7Q0jX3VtIVb+q+Pr1VRSUwARBmwYHQvPaQo5g2pSqCkmlgCVwD+AwAXdikidlUifsTrhThAkp0L0xhJPfnJi9nOZ225wOl8ve93Be+P/etJb2mTuflWZwn8Y0eOFnFnyQCOsqJ8mlr9Zqnt7+sfjGOWGMW9c4l1LkkCQbLhNuRBERhMQZ/r97nf3pmj/dOed1/F5W4hzOdcyE2TWYqv2qw6HQliIcEomR8BDs5/Lf24ali7Q2qwmx2zwhWolLiEgkZepSpIMqnO8WYCyg/v9ULVsAg88kcm+51KWgDSen9HoM4aA9J14oXd7rXYIzf/Algp+6pYhLEI+XshwDB7gAUPJ7khxCrF2F2LlzWRr+P/c2m+wudGtKl6xw3yhK7hxF6+NRCM/NCy3rQOLwv0zt35Tn3ukh/vfzQX6kQo1skoHk1nvp6pUqN0kE9NxBb0/Pnd7lYvfXiuSjjF89WctBg+QA4DN+5Sq3mSJFCuLQeMTBgXx4DsiLg17/9EsKH+YzvL5UpjCmSXH+46wUT7+ec9ntzbjVc5a1jG3t/6TdJE/TS+0NQ7h/z1FQwgpJMSg8yy8zP5hIOa6OSsFdCoMZmfTe37sb+h8qZ2+tvlXECxJCkCAiItK3xu99+O/CL/g9t97vvyKI0kqr11prERFjjDHGWtO7HCPZ/9/rvl8bpvYzswQTJBiQEEhpam5pn69eF/Mq0vmgYmDweB80jKnWVZv+dOfHNSrnBg9GPCigdvP7WdWjZkO6u689uybZobQUQQRFRYJE0Zk8GBqouAXzGfCC9L8UIAEAAQAAACY+YRskMZgkGCahGIlFkLhcEl9AEkm5O8KAUIhw4RCRHkHUaYBo1ATTrBmi1QeIT/ogBgxDjJJDjA8JkpFaIAk8BNJCQ0C6IgGka1JA8jEDJF8LQUq0FKRUP4JUbhNIVfaD1OgQSK0ugzRmJMhGGYE8t3CQbYoF2aVEkD2jgxxfMcjJtYP8pC6Qn9UDsq68iAQVg2CBik2oTKXKNDtn2eSGwYmN4dlNYzOR2wt3OS+4clvw4LkgIV2QCVoIEb4QKWohWvQkRsxCnLiFBJkL2XIW8pUslKlcqFa78EjdwjPPJs81LDRrWWjVOmnTudCte+GNdwsffF746utCj6GFESMLcmML48YnEyYWpkwt/PyAGJjiQESB4ZmTTYnrB9OgdZveMEHr7q1OQSspQM5EQHHi/ZcpqO/Rygh07bFOItyFD2BIKIAAgSEABFBZ9OUFl29buXLrKIIHAwSCBYoJ64BcB83e5JJLGtOYgQENWi5r9s0pfzjhF+P8vssWG2VaY5kFt3O+1KlMpRTvyf5mnDHeN9JQA73hFT11FucZrbXwhIc00EAt1VUS3n+VROSyp/itNvHvDOv12VsdWrzwWJUSeTIkiYHo7D1IC4oFkRABxMuegOjaLghxViAyEgPEybC+Q/Q7++jXIz44lxbv4xnNl82ypER210tpMYzq6Xylm136kz6PEDOmY0zvDOM6zFvto1N2lKS12h9PP196z5snO21PumcGdE6f97PIuXZISR4E7YsjtLZHPLsKeY+MHh/5ab93rXpAdL4p1EBEr7BcYQ2G5SfHnKVDuMnOp29EbSS8pe+muX1T2lPfq7A07R4xNx4kfMj4CRAkuKW49raPESdBkhSp0qTLkClbrgLFKlSqUq1GrUeeeO6Feg2atXnplXYdupuGa+6PPpFvbbReffoNGDTEG2/CpCk//PTLb4qColOkDYqiGBSTYlFKFJsS0AseAxZc/WNfhomCnuWdcxAPLqxMBiMaVIwiQwwBDn0ev9EC7c/7tKwJjVyn70l1F9ijRIHP5MiSJE6USG4ZQgQgcX8Tp8KOz5/5xEc+8IoX7jGky6IaKKdhi213WR3LNcMWdyV1FezyU+6K1uAg/ytndAALoxeAFA/EO4u4xSze7acJcgIbZibQo0X9FeWYFj6u6FrziyE8LsS/WfpDYfqmDpKjCNCNf7ImD40KeJBcKqAnBMaEQvwfxk4kTdxWQlf7P+xJK911nzNXnrxJ+QoTJVGyHHnyFSpSolSZco/VadHprc+ArRYE4AAwX/VrKFEgF7IkiYQZxlAiRRT4WQTNszfmvYczyiz96SAIjtiJ3aNd/a5w28wnBHTguR6YAcD0+DieQTKP8P8SeUWaGdTnnf7X73/L617x7fsPuRNr7XDlFd6y1F4sMM9sM0y1xeIh+udSPWujtZZb6GpXmvQhFsMNHMpVWw3VdKRt0wp/nGx7eztV79WIzwftLeW6TMuZOSGTl2USQ7Nv6Z5xf2XWK+nl96K9NKQ7fHT4d7+InMzVD+lN/tbL/LWne5w/9HAfAuULMxoakSI4wkAoyFKaUi8hV/6bk9Q5a9pKPrkhQLf+0RRLOKQIojE1uWKLad79qixSxg9k/bbtqUdW3TJvzpSLRpzTq9NJ9Y4pc268uBr5uCep/K0jy0KV+ZMLmtQos8EqKyR5RhASFzZMaFCwIkVgTEplUN3URslQkS2RhC0xxOuiVZ6sPKhAtiQxiBKaGrnwfO9xMSkwkw5jVSQVQ6cusQTgnQnAOZbh12OVCqNIIqTfZ12aVCmQJsaxApveekHciNjo1MDHqlIBDhKUtPUq/p4cBvoWBofcQ52FhYUg/bqcwnGpR+COv2tMXapXiajj84dCgQCAHliD46dfpLSL9D99Qlb3/BYowmrBIGRxIwgUjxUMTAo2fp5530HtJIEwVviNOQ6JFfetvhUu9FgNG9eMEuiNAaoBBDFQhvcNfRVLDIh7M7GUAGGxgWSxIjYcwAZMtpBMh4IBv+YGgOW3BgIjgi9eqdAADA43/0JCDTAs+PAVCmf7wpVXJJQCSI29/KlLzCwEQhzAXkePVntZAPZH+IL7PwJgZ2H3df4ASI0zZ1/EVq2uEP7R1hkCa68a8K39qjXG/IQJO0D6dhBrTgLpP6prguEXuHLQrFgtQyFYrCXDHgGRwF0R4DSVYB4sgaNmZ4jAuWt2s4CZASjW9pZ1pluwGYIJWxfYcsG4rSZ8VKDSjcN9VI2aMolcpuf7k8Xvb8CpApR9TdEEjPCZY3/FXs57d+dRhOZCBUZFaCiJQKsINS6WUqorBGKBTG8faUjhV+K8eFgBQXSLbfkEES26Nf0200PB1pIi6Ljoa0Vw5apbiuDMUz6W+hqu+IBtN8A+u88SdrzsdRQ8Qnx0Vp1xdrmlFu+mWUckGg0zj6i9DmMhuw64fnvsqzP2IVPgBpnJ8YRoUruY402YtJwwQJ8la9wxjxAKY4Ac7UMfXVskL/QxCCqB/2f/ojxKmAVgZmbHFAIBMK75kHsGwNjmdR7nLcY0W+nNC4xuHmcjmxgC4I+mch4YOVHPpaxgmACZ0ZJuIDUAqWEgMCwin7JHq2CQmXKZzhWQtsN9vMeDqVZRehz46lcpLEzXYvomdkOHFMtBDYw15siBti7x23h1mughANIRAfEX46bAAgTmchCAYV5+F7s4E+547AN+DYa2vcaYqjJIDHNVQNSKoUohdsET+rsnOsAxethXYYGxwP5P3zO8AwHXyGv7pB5AB1t8CcbgFY+DMnjG6/pdXYHa7SUeV6Dz2OdSSSexw63pPyRbVCNDEHbjDTbbYqQRE00Y5CIAieVYwLK6FH4cYTFdC/igJdw1whqcQoqsBWk3o+ZrX+nKocmQc1UM6UMFECHvXlLGIOWgBLDOmNBY8AeHhkftG8RoZ/WBNwijtw4bvVd3pdPQgRFa1yWhx6qJ2oGOfAUFNGuftaeAw9q6Vg+o1D4qbyavjo1aVFl8rSX0zHlXe6HF9O8SCsmaWyHEaj65tuHatLxEkyHIMi47PMUoTdVRtNKPlG+E8lEloWIUFzUeKvQVFIAPdMWuC6cOdCze+8QHwReBndhn+tTFvH48m+jy99YxHHN3aTbgvffnluO8d2aZz4g/lwHxtcMCiHlb7foRA6yBBBh2R50OH/iviPgNAKu/KuNmLAy4Z6iZhG+6gAfTc+/mxQNp6VLDeMxjwodZvFgqbpzY31NK2XVYkQIjJtAjd8YZQ8n+2XgcpkYBUiSoF5wHkOs/f0P2z/v1AkEkkYS9p5SxmjfuIRxWcOBianCG77cHwDyow8R4GGxkYNBY7GBWFMNgmBqNJ8dSIMIPz+3eCXrXLwiy9KboqZ3DxTnkuwMzyDCHeufXR732o1E/O13q5GkL/PScB02ZlXNEuOFUi7ju7JYr5k9R/5JpqYkoeiC0VMcCjhDphQgknTIvfOYECuTu6ck3dFce7Lu6X67OK6/mxYs86EcR2cyz7mR8lg0E0eO+kQOQLRzp0z48IN1xEOuGHxJszRULMKHg+qFr9pipqLlT4Rr635O9yIGUu2fm78WAAEi3AYiCoaMirpirEt0S7gg7qM/mRMfjzDZ7kGdFz2V46DkNBzU+10LPXhipjXC1Ba6cqyQXRCROO8Swz3BSwRt9AoXLjlQuXWta8/zd5UU7kHaf/h5EyGBGX5Yu7Nkx3GrqhdSQTnKrSGtIG8lHkRoOIOIRNvfQw4iLIVm/+KYzefG77rv4RN+ITLxEhB5TQ5ClWvzh/12JAVS0WN8H2HjolW0m3ISxo7tHU4T9Ci65Rvrz3Dr75zr+VzpBHX9ch6njjdsByDBunghC38MSwboPJm5s1DVKpm9AI9exyN8Dp2WK8q77pDzkVa3LGxmg48CYOZvTs/inqvexTerXmJOtP02W3R+iluIf9xuRB/1oDxc9JQ6XBtSr4rro6YlBu9kmwwjo1i1REyqNIksFYhHCHaXs49JFnQOLnI7auixap3Y1gz5HXdwN1dVW1VrVSHD23lzaG7uwP6NcfzaUlOlPKh6iqTkkE54piOSQ2oFtLVIJpM9AIJA17kYbytSD5cTetkw6iUZkU4+EDK3xfdTRSIca20qOnCPliADo4nM409nbIIgppphtRHOUxaEu93tqXhi6HgE72Vdf6IizpzpPviPpQBUrk3PRZ7Tzzlf88t9HvetfCTtK9y9pMbxICksJTxeEc1Bt/7YWroRZ9+L+RdO13IGKsrk56xOgb2snnUQjsrpHQor2yD4UHpJO7H1DkiHhEG8Im2KJAW0KR1vYQ2Ue3sJupSudt083HeuQ2qhrrSXY/rv7bmldX4vVVBlJb7RcpH49lhh8TbF9H/m699m7AEzNaw5f9kSfoXS9U7JqEmPWsQdklQbVV4/WZzJMjMmAEF7KMJS+TC9EXQWpDw12VntdrpbU7G+UnVXvr2pvRylvNIdqgnosrM8516Od3ag/mFnJMVDiRJM8AqEcKESuzaT286TXnzs4sfc7/9iyTAD7aoNpXGNSfhN5ti3dpPyGogEHdPz+Gxz5gxxnL2JmZCsoP6x1i4aP3kvXurCzvU6cn+UoYQdLlcxOfbk8Ztxwb23HoORisV+N/NV+fF3tnVaUnlrSol4Q9mAl+6mj9izyMu0Oy7ZOST2zJqSXVmopGHGJspA6avMQBssZlmmdknrwwAMUt/dOvNo491O4SoUfo0PVtK9dPRRbv3jievOE9leK1SfbM/PNDZk0XL5MkVqYiT1XFEssfzYXgInzQ/U58MmzR5MrUU5NqyZlROeaCE1CqkQzOiBDYhHghpJQnwjod6IOgEV2p7/dviS3UuPK76drPg1Tvb/a3jNKceMp2GfS5jnIkkm0kxHxGH0iFpIkDwDJTKLtjnA29scimWRg3MeKqGTLXVp3kSQt+WyO2GKCTCnqtHWHxPuHo+t6ay7uM3SiIw68YrF87+RifUfeKxY/3u+mK5WJlPYlsUgl9dCL2hRuB82DWkvT+O/ZRV5N48i2Qub2REX6RKO91SYFI1kCwob3E4ZYMDKNAn5X68N1e13BeT5Fx/2Hqq3tVz6Xzbtoi3X/iq8yXkbKbzY/VuuwGJv2r+44L1e0xbqnWEnwPmiNXc+uhcl8ntvcR9tTyMVUtopJGffYfL3rvpDJsX7uIJJmmksFwNQoMhcXTlDiLFR90J1KA/o7qF1cbkxoMaBsjobqVH2PpjQ2+OrCtvszk6jJjSzKrCWLJj6iFJH0dDyUJjQCapObZnA3zmEHS2kaBo0zFpX98lLaL4JfcvrZMM9C+il93cW+e13rQmec7KrrSAeqqOw7qFjkT+0f+zutKK0lLbZfoLCC8mtWXk3n/Pi64fPbE93RbSM6ujlP4PrFtYXrcTUodmV9BEkkhJexCjZnLZmhNVq0l8OuFr4V7eE2ttuj29Xr2nk7BdWxDqmV+223f6t/PXydpD5f/xarUW315UtstDcal7eySbUEiumZFtrzWzEX1XEy+XTw3I9ztSlao44Ctv6GrflTeNcB44f3Sw+KUqYs8dT4pdME/krKrBl4cCO8MMp+MLp7TNxrJoBlWfYffexeTPTeWROTS+9Swt06gL5jJjHLzX4Uv/INcPa1D3p0dDglynGbz541cm+nxcD65tsnVicoJXfo2LF0WPH2tq0V0bdpjat+Rkc+vGss6kSzMPozAwkW6+NgUH4/e3Vg34uDJ/WTLwNZI4z+iCqjsuTS2aJJdKyu3n7oQx++oA8sTKIXfehh+E2qt6sXdukdFvWsIEPBlXUBa99/R9Rk74l5fp69CmZIyluKmdwKLLqjFc52YJgW9tq0FG3GZmuWBNYR0ZVfn0Ua9nUYjZR2d/e0A0pp/Forv+09u25vVuQ5HmVSqG/u5kQFJKhQKz/+r4WhZSoV2MAGN2ADmzy6tLiIMmIQ4Ycj8EdHThxIyedGkFWnayuLoXa4UFpcIg65dymjz+ETf4n5HYui6gI0Qg+0P439YnN6FWqa0oALAR9yRa039piAHfgHAUFN4B8yDgKCml1l3Cn/XHCv0nazvJ3F9FkAkhU8fabjPKxgxdMAxyyg3ESOi8r/zrY5bgEiYMTPE5W+6qsgA7P32XOqNlRL/7q4w7aziwKD2Um3kzfep55/y5Z1v37ti4n12wk1//V7kw1GB2fSbIpzzrSWg/UxVIfgAVM8icuqSm3w1GfnTk3hlrLWzJkGU22lGbLnTG0bQGx3BYvfBjUAv1WU2EzkgRLQoKiz5dg5THkv9Xs3OV5uZPr6tWOOr02/xeVD4LK+5Yp4hQI2E+f6M4db5sf65zjJkTZGKUr763TrGd0HOY4AVBseZS8xyCKLZwF1RJKY2lPoRAc6XDTZ4ly7Attymn2QhaOa107x7mx5tlJ7f5In2VRkcUvY2XxwFx06MVScSouwi4Xmn4PDSG0Luw53Oi0n1oYXFruyRb2xqXsepc65MXXHbEGQX68nNnQWRGN9blZ8/FPXHngBSsJDB7CtXzAW9Ad9QV8wHowd6atmt1o/Qf9RUDERjfXm3nPlziHOWetn+bRetsJY2lN5wZ7OY0YnTTCSgx0245HGGeu6hdvXHlqX1fq9dhpZAbhuMGPtoVrEnO69pZ2lN704ozs5o3FGZgB1CmYUzkMN5MGRrhs6D3ZMMi3MiocsXg7RWE9GWT2QxSynMnNhLqZICDdiZjg9UiysQFmprNpqc5NVAeXh0ZgF3pa0HiraHtPynLgcdm0SaU6teEYQ/3JQo+9aWUDDNLdNxysuWR/Y8r5pGf2BHTGnYYkP6T2+FcCw8GlcWm4CBcjga2FUQAYf9tdMGaCNAxjeqQw94Q2yLYQ3vcaoDE02jZvTY8wK4QhFuI53RRiM+Zsyg09OBp3hJxoLZvxTybw2lLAwKAEDI2ZwfYXRFUz6XWzOnp5REbpqTwrbEkjEuhr1ts3E5wdT7KMWBSjqQBGFKER7dFflE0FWRFpENMOqKsrywSEStfL092wWTsWKULYA80YYwbIjy+pI850jz4uupceBbJbWpPRljSrLg/uFeXw8o1Pm1rVG1iL25kDdPaIQNdow2AdanUjbD51up5NOhzoczlErQAHR6no6LVGOddjnhRMhi6ADoPMzTO9rkLg3t7UpG2s3p7Q53MJm4aFbUHzc3fFegFn0GVQtIJAYlLDRVHiRZN4HUEqVea5Nh/i6CKMY5ehMF4YyjLGMJ5UQS6icvVy/dEE+uqoo3dNzUeFguKk+f/qkiZr8fKl4nyPVt0+Q3r5zHirSgOLm71KmrV6J8suVFFHhx9nmJuH4qx65HBX/BytuQoRi394FENjCxdZYbRIz+vbK9DRAhYpRZIghDN/1agAU442OVXQ30WYa/J7oMSi1SdRtPp5jSQMbqaU0aXh9RG1fKdOwypvsWUl4nAKfyVk2cjVJ4kQ90ruGEAEjlb1xfxPnt9kVqV8okCJiPnBgQuuKl70XhzFWER+sNQxYtWVnY+9DjCHRP49IfLYmnTmDwuAEBWVaGp+qaab1kZoDfQOeo8Q+T0v2wzQ8wfmz6989jMEdOlAA32gIX4SgAu6vkC8LpTt2AsRMm4F/j7Z6peZ9SoogRkJ9GSB3dNX2Y3hAS+UW+EubItR5017GnvXtjdX6hXu5nRu5mkt754MctYj0jgU5kMnIZzTWkP5ddX7dwq49J8BbWijZGNZl9Xxj25duZBzxJ0vbooIpczIzM1hXRJOxDC/SpsreNR3929XvZ/0M0ueuPv8mH3+nh6i9EF7kaR61B4W7uZXrI7xd+fFcaAvawpdpCJctUpRejBNTYw9ciklFRCqDYWUoeFM3kPqVkP5EL9yXmFwryoYpBnQLOQ2QA18kvS2SLopxn3MkqgQozgVi2OtaVmcH4OynO7JV5PrBHBBAAOGIKLAuqFlFPdwsvSaLIZYVvvx2rgpDq5cj9Ktr+FZJbdDbjY15myKs5efbYftvgTG4B/B8hXpUqCfoOfjp5f1A1ZlVTohQcRIkSZWuukxZctXTUL4Q0WLFafb3ScJ/YJQg07HDoC/wwFoDBXhXa6BQBuA1VlwTsDtzrgswM+looMOsAOzFmsKok59GtW8DcMINAdx0QwA77xUzow6HNnzsLSxSTFhRB/ZMAI0JUZXQqEb4TJ0MmeWYI+/YGrX/MGRHHu1QHEX0wnDOoR9eE8X6mE8Awju4qUhEaEfM1UhwLbK5HjnciGwcBis6crLbRDZ3IxtxZOMR2Ugjh8DIIcTJqUSLfi+tf7wCV+ep4NrgoFA27wws7wg348HcV2KpYPhRBc91Q459Vs97wnUoKEU0b4IJRvlAhCGiNoQZhGjIjISQkJCQkEiRQkKgacEVvpKAD/EgbKUjALPucbNhzEMn/zkxm4cAXBmAswNwfgAODsDVAbgwAOf1A23/DoJHpHglC/dxyaMwSqM8Bwc5WqN9fAbDwJZNt4i5GTH2jrMvJJRSd26NP4go0WOxrlcQultB2rOCCn4FIzQrmDGtghV6FUphUMEOowpOzNiCfkXeuSUySpv50eMeZ3MoEZH39YSAFwExm/LgWLqOF1sksB/sOuHC4Zzyt10QKnBRR5PpaJd/u3C50SuOEfPAHXapu0OO3Gl8HqUd+3BcCJR27u1o5jN9eghfsrOY4crRrZNglKgkJStljjLCxeOOJ6VEJSlZKXOUlFoqS3E7skmbcyKrM5z2hdM2d3EJgP0sJeVdPN5ijEAbPLt8L+yFADKrRe8g6ycBKLPC2/GZ272++/5Y/tpuj73Z9o6bKmZv5tGBdbvvtd3urPgflB1YvO/uu+zEXIpApOTIYIaAlOAie8eZcFv/OOH+CRHjrMYgL9sJY19yyi4rmI0OCKXXePu3oawOeAxz9tg6kEHiMa97EwCML8cKAkIE/gubDAdkqJUlW41MDz2aqWae1NxRxxJ4y9veuZliGSrJiuq3P7i0rLyiUqtz1Du5cevOvQdLK2sbWzt7h/j4Y8jwZ+qI4iTN8qKs6tm8abt+WCxX63Gz3e0Pl9PxHMcDo0GoULAoB9spbilK9CFKNlYwUwYiYS2+AZUadWBr/pEFR/VZ0GoeAa5HvQLP47csVLwxjaiG4ZijFl7jj1HMxwKLYymWMI2VtBeWJglyOuYYKHHfQd5K4e0qC3wIMAL4ICwAAg7gx5vNWja7RszDHW8+C1nEatZhhXdrMWXnwxF+5FHUDbN10y33OKtDgFADscPC4RuS2qGdV7wasM+Hw4IJZnG1fAv17GqwRSJT5hrdKH9XcWuUUVZvuOyWqD4Is1Vlg/aGe4SMlXMOVpyfKKbHYiwyM5ZjmVlJ9QCYDQEgjBjEeC0MGah1+v/S7ncIDF0+vhCdHJbpZpptzt5qyOr/g5Z/Me09LZ8QYVaQZhKEUXHkybP/+/Ir+Gy+Qj/KeP11UqsQF5NS4Iuv/1UXIqdoYufGXBiDOVhL9VVVEFR6ju1Dz0yQ7BUtVWPCZzWieLuIfNT9REjB/jSUGW8nJd5Mcnant80In0CR9PwNnrdECeKvBYXI8fz5M0bBjbIFyZLZKMOAv2Ze+6P0mzbV6D99fvuFf4wg48O2w3qRYNJsBOgxHbUgGw89KN3vj++cp+RcjbxzJXLPNtn41lmyKWNGjWhQr66VsHXWWG2VhLhYK+3WmjVjpTZRrVoWsrFOOWGmyFOkKSLwNya1aa40a5oh7ij2W0v22VsQgh34YAUQzMBsMgI3AwjsPjbQXzeeYLheRM+55KILZwMAQm6cB51z9hrNs844/drjQc845bFGJz3tfx5tdMJTUo53H6mz6VT6XZk4TzrmqCPXtOcddqh3sGp7B7Y9Qa56fDXFm+LinNcoZEVLGWEU7GJgYaBhoqPeUVs8XJwc5GQKSO8gc7OzqSYhJmpFKCTAr1aJYkWtqAXV8PEqpKKk6FRefdsIK24Y7xCns0xHysoioGcTOJtwcwmfwxYf+XFmSxrFhxG97a3SvVGWkQUAC/MetPC8S/amNxigICHeB5fhA697zR16MFD578sz3veq227RyZUjuzWI99x0w3VaWQjAHiKtCZvUrUsndEKB7dqxvdqAw7QaM0eM5ELwffNxcHVo15ZWdD9ToGy+b4PFhFYtPrE0Yc1qb6V7d6q6ApdzmHLuLGYz7/CNrO13bbP9DhE6wcp/LrB20SVXXHWNjSJiiEe/tU8989wL9av1rUwbkk8hxdQyzSzLEzVfOMMflP8HlxJopIY6fEwwwBAjZiDgD4zJkStPvgKFihQrUapMuQqVqlR7olOXbq+98da77UEkohADMRELKSE24iAacREPKSMVZZVTXgUVVVJZFVVV84DqIjyohoAWntJSK9Ge1lqM/2jjBW3FesaznvO8ZKON8bH/+sRYnxpnvAkmmmSyKULm+tI8833la99Ik26BFVZaZbU1frLFVtscd0Kuk/L85nd/uK0d7T6qjGU7nFy4jxfEgqJWNP3WtGzH9fwgjNJsnOblT3A90ZfCqO36YZzmZd32AycoJk7SLC/Kqm7arh/GaV7WA+jNmALG2stL6BLK/SEh5deDebDLcCBNUmqBadL9j8eHW5vm8XVo1UGX9z6YcSuN+YOZDxf7RcD0pIbZADeOdIhNO+IJdi5EfFguLgj3NT5i/yj4OL7EIDzR+ILTK8THhYUGgTVLFpf30ceV5QbhVT+b6ydH7hsbeP+x2WdHuLklLeOwVW3hlEZIxGmlg0tGGeGecYfxyD1fvAsOT3DhhRNaZFGEFVsskcsTwqiOKcT1IoiES1E0aalCmNxYR1qfjiwKavVReInKXVQnUzz70vqaoKx5L/G8OQYa4dV0l37Zataw0y677W3WqjnM7XTBsLuLWcI+pixlGctZwUpWsWcXT6P+7mqvg4466ayLrrrproeeeumtj5fY74CDDjnsiKP+8rd//Lta62T41ne222GnXf70l7/9zymn/SM/GGZiFlbCbMzBNFZNLhnMw8p4aehOZ90/mXUy84AsOpVlVmGyybbQCD3sUeSiyyirzN5EYx5rWcd6Nthok83MmPvTFha22sHSNtsPfCQJFsEkOAQNCC/NWrV56ZV2HT745KtvvuvRq8+AQUOGjZIbN2HSlB9++uU3hUBC+LTtbamrnvoaaKiRKI018ZBHPOoxj3tCimmmm2GW2T7zuTlSfWGhxZZYejsXWd6Swca2tl/86ogTdcW1K1/Tuja0KYG2jEw7HbKNM+kQx1Q88swr73y61OWudDXfKuNaZWR3Gteq40uoqWmqva566qs/TgMNNtRwn/vS10Ybb6JFLyXqZfwdHs3H1LFZRZeYjqum/nwVGtxznx9/AYL6edV1Nzr9/xBsx14Ih0u3UETuNCnwMuwHrVf1FfSa173hTW/pp78BBhpksHhvI3TMcSecdMppZ5x1zvkxfW+9DX6w2x577XPG/511znktaFF/Z4r/e0rVlFJOJUQHU+tA6mGzzyHHnDvT2c51vgtdDJddTrnkGrGwYnrcvz0pu/ye9bwcbIg5c+HKjTsPnrxIePMh5SvYAzIIV43VgyumBcHIYzdnIw7cwv0xKDU4YsFvvTo8lsfDLeccJEfXiYIj/Xu2Cb+m++sH7ko17hLF7hwKd7af3shTfh7rnvJSbvaYX3nbaDnZVrRoxSFtAyO9jGNru792+oobdmQE3X9A3namBpbbW2ixl7eIUdBXBL+SxNKprdzht4wQJLLhPCUd3SBTfV2uUJtDiB3Fe6cAJWh4TEOLMBFafNRvxNg01fawoRJNNdMiy2y0WY7DrlgzVBE9LamCSuqou15I++UJBfhUMdsXWO36aksOD7hYGHOYBIUJwCHCIMhma3k7rfJzjV41AeVXsjqDQNo5r7tBywDg4bgIoBcmgAECoBUChJusJv3D4FEiDNYAjMKAiG97GCRD+8KrFwZc+OrCuQs3KrvMDS96dHH+xWUX11680zs97X8vhkBhcAQShcZgcbjrPmeu3Hny4StQqHCRYiVKla6SwxOIpHKl3n8ofYwPA1AqUskUnpJTVFHX1J170vx6lt9lqGy2fNmkOUvW/mPzz2az3P//OcPkUIj9fmU9ttbhkHn1pR0TBL5m+N/bFI5EY/FEMpXOZPt6SokH/AW74yUfPVPLzNW+Q/HRP/RjU1CrYAhLyM4rqWroyi3PZF8lp6FnRy+++OvNXHj5P5AzWO79dufKf+Wv0r4/fDag+c0Ctgr479bx7zYGep6br1dLd/jPZVZc5IqKwemhZynHLbbvdl8BVFeoV31T+fIgXxidElTdnxwJfJ7aMILzZNsv4A5B9dWxOWp9kVOleKoyBg6M8h7LAxGD6246lmpT6/jdAtkReD94/kcB/Len/DtwiiEYBJvgEWrhI0WL9X8LRXk898pnghFHtnrx8tjIOeAKvvMUKlLWPnVUPt533Q002nTiPJKO+AooYqRtmV7tYvo06bZcj498/CiKRTFJ+adEvlCgTyGhBpF7dy1pDwY0XQzXz+DQVyLD5NMS6SFDJBAqfBQzLLTUjzbZ75CJxKWBjrz2wNCokRmhbcP5UGz0vr0bolSaUCLbVzmmBMmsJjjKoHrp/9WZuWtArU6nhNVp2c/Wd2Cd1BijldWouLa6xomNNzgRGDVg0pCrFn0NNN5MhPvIO0YZYaR3JXmPSFHSRIsRK068BGQ0G9ebj+WgS1rXqja1Zq20c8+t4Iw73KEuhe9qV/LtstidffLeZz2+uL2Dn/Gtw3Tlnld9tZd26ZdxmRd/WbcP7lf34hKu/Tpu8Ib8c5s/NsUh330kxSD9Pkw6GLdLiG5vPoLMMOyZ5xo42iecv7fPfrfI96W+1g3vN2/xzXnSN/Emd5f8uaLZlLeJZkmRfvBH3MptCsDt2r3bl66bHpHVyZdi1bd47p7k5j3Ve+FNnmAf22ZGndG96NRTcVm/x54YUuceN5/c5+qzar3KjAhVIf+V60+UnAbD/8RK0fOUYX9mE4IlcM1swblhrhSxs1hK2FsiBW5ZpF3cljgG3J4EWu91nUR7TUdPeVU7LfXVPrAzmeUXLsuCcs22wFyyKbf8snrV8zQYfXIit4k5k/HlQ0rCWzQPngKNGzvT853hvt65rMKBzOFPdjrL8VaEFlZOue/a7vATm7tXe/LGrOnFavrVb+u6Uh1EYnJ913tuY3dqvte4JI/c1Bu1tTVbjpyNNNp4E0kTFq4xb75q87eyO93rfktT1FL7ZqIrtYoaNGzMiAGjXohJTkaRpXJjk9/ikHmxyB/RZHAqWEYJLYyYhoFLYsJD3b19w9k6aNTonwxcNctJpTEyWWzNZ2zy3LRQ2lp4RZyaAl72ooe1NUAPQyVLNJowOSLkLlUIof3LNI8TDq3ICpnWWma1Db610U92226zrfbaKcdxZ/zpsJPO+tsV7VghMWyYXmrJ4DkdCZspLTrVsSoiUjE95OP2wj2r/TRK2WVUEKOOuHXHQ2ztaoZbWqmd8YPsZuxQlFITRBvIOpdigmJJzLVPNtx4NELLifAZe2MNgxgcmVdAaysMXYFhNtAugvZHaB+DxgCBMftqhCHMbfzL1JmbEGY+oZ/QxR9CBruxJUVgagAIj0KYufUcBJaGwFRBisDWgAhm90UKtBiBee98le4cRMCw1cWcvjX3cJTeHJ0CTPHLaK5Z+gLx0uhg166HkIMicDgYDltkpRyMycyYeyH/T1RyNUl5M0Q9R+dp/Lb8AV46hA4gBGG8XXtjvF2+EyJEEXgiOat9Hu3KhfxSnurFK2DwFJvH97IE9Hfu1IkhPnot65zPiNzBCNsPhyjsS/sIbMHsvjBhHr32vz1HIx0Y9ifbPwTRAUQhiiDUJIt0OHQAIaJQA4KABRsVmFnBGACKCQAMrwO+EFjofmCFP8AiSwOTZgeO+gEGANAvR1YIo6BS0BorfT8F27BrH+mqcBwkpymAk88aJEYnE0tB4G9mMHiyxNJxAPumkkshlNlkkouomIS3g1BQMFJOgjEUTWs9pBaVcIoc9vAm4ZJ0oz44TsxbPOitcb50om4fhrL6LWlYpnFE7ATqyzcD9KTKBNV9RdD+iV+ZNp4NnO9MoozwhUF0E3KdGW8hhWx68xnCOHMIXR0SwB3GfN1gVvMF2rPcuWyXUff4YZ1bwk/uGTeUXFFK1e12oVqWMJgK9Gv4CV4vw/aMGGPj1qb7EgnUPo47WHZQ75Kg/0+ghCaq0JBwZlZEYmsT6RES4pcVbuElAdYsTZ7ANr9Sr6Tvr47kbHphntDYaU4wW+y2IC3YUCrhEIMgK6RovimvG5AS+YaMCBopWEHYFSUhqPwxKnIJIYeNk8zsYqzXoHAXyL7WokC+EMSrUeRnaIawkwgrKLqKa5kM6mxX0LN+p7ZHK6Qss0PzsqWkuExV6mqFvQj7SV2lf67bsg4aVI7o/jbQA+1oSi2azDKbGpes0cFZXUzqQZpwjmv8y/sW7vDcRKJ168AeNlf0hBZAPUoqmOlCp8w3hwWPMUowSgsem2ZimhEOTB9jFJgI5jgz96dHlFc98qwv185Q1Viplag6Xa+nT2/ZoBu6pXOSt3R9Ov+1XT0tgKqKgIfw0kdxrcRIWa7rQBS3nnGmQ8hxFnozhYiYhIeqkJf8y+knRnBHzJQil92xAbUGJh8ICbGjCybkulDMHydUyU1C0Hc/uOnsWaZ8AYXP1Es2Kj9fYDb/Va5OoXmWdzJNzCBCMmsviEtyCBW4x7bRVII6hhjSIIR8HSrIgCsTxojiOFlSjGxCYkewjbg6chSFoQ2FmeONrXM/iuqJaZsEbeBLGG/f1CwKigrl5Ci2qEiSC0x85YIPhCC7KLJMMTWsfs0s/PBAGi2QJo3oZNhNQVlHvxtj9cSVesoUqicD+ZW20pJbKhZaiulVmkOzy+hErj9mdzhfDFtkkqDFDL4Uv0WWcfFtfitrMkP9loOLOW/yG1l5Y6u441q3c2gWdgbs1ho2zPqMBPwMpJrww8jCVOqN+zGBAkljzR5DJ1I3e/R1JO6+Yn8Ook1faDcKOiqzKzNQItZHxK5/uKpAPKkyleQdwotUkFoVZEpSKU05Xkoh3BXthVqKiVKkGSpEX7YwqiXgBZkx+uPWUl9VKwGEZ5+YyscOHWHn5MfjH/0JkSIEMM3UR9eyfqU2v8lvMFD1U4TKRkoxohxDuQB5kiM20FmvUlqODeEbRc1H98Fosrfx44lQ/RknEh40be3pyq8rnn7KI0KJp2SZUdTsSoJzqBxWF6w/m108AuMilKpnBMlCndV/H1dKFPXPI20xrtUjLpJXlIeuQBhC/1iTYyM59AX5OhcdT7eWLqYaTlek7c/vQ/OkUBeAcit1x+pEBuIH608NH6YUiwFGjUMNzd0ICI1FJxQzNZoa6hFgE7HjaeZU7u7cKXZNlsk4MJKT1rlz9MAtVk7UGhxNSzRxizwC4ENmt3HdYyd334E3YlHxgDfpS8b6T6IQRsijS1YACwqnptlgIPOs+CZTXA33dulDXw8VizdF5LqYP21cXGahT394WHQ/fyXRtfappLmYhEtQ9PB52wwoh9tRIkBBDBMOJcHjLgb6mRWNZo8mQZ+PQ9qFwpYj0xWgNXYCxfYyDaJQeHICUoiFofbKF4XCAh5YJI2FNpVfmeRkoTDDRzUsEvZcSt78lFQd5eIQ+mEK5BodIh1IWSI6wtYazi+F7/DyZKz+BNOqNaQaCAr1dltDVkrOiW1u5gNzc9kWsNyebbGIKHV3Qe5BEoS/5e2RkicrxSF8rUhLJZwtSvvS/d0EW7DtPM9b3YpKvbCDtujERI08O2RfRNyv6guTCOOAXlE8JTYuIgO7NjruAaXl1dzJ8aHItoznUFEvOwam5xo6DirakhjTZyZM8JrlS+kqP3hBsM/n8kCbY4JxynKPlY3HYZ0xRmOdc6zS5eiO5BzLOwL6Sn85oDv0oak/iirHb3tHH7u2bL2vUPgx55uANpEBD65cFgEs+bDavTZO45Py2eon5BNDs0CKOINbzYQHDhadOFE63xIgW6UBG7nlbf8bQXn9MkAHrHxRAgVhjHKVS+ESbkoUmx+GtkgUit1Iwu88XPBicaxOptt1djiupSgUbs1ChqG/7GYJSiK3uyqFlys0wauJT5TmrZ3Kl9qNF5pXCFC4/putdtl6OYNOnUwxjpZoQhHchxTvo30Oc+RKfWBGXbrqAqxqy/VT6sgIPY7UOzx7waWVOied6UH0LTaHd12mribWL0fz2Jw2ob9cMk1TqIOz2Apdg6Uvl3FFUq1/BejHHjp9Ys3tdcHwBURlXiTZ/yaLgRNJOBHQtN96VK0BRN2H0Fd+uuenK8Ni7hC7ixH5CXCxXCBKyX5eRQehTFveBnT1jG3rIP2DnczqvRtFoFm3xFkhptM8uCaSkngRVkLNxKeazOj4VKPCDHSAnEldPGuo6h+9WtfoohHHGGLvioobLrZu/nlW1eXi0ZKMl0ypO4RE2TyGE+61ynaVPaaxDJA5Ibx9I0v/vyFBIQFi1osY8BNoaOiqakwmfUoL0r2J2ISsvSSMgatbN5I2tnap2A6bK9Tv3nPH4kiQz0SnRyFavbLe7eetmuWYWf/+BX7okn5sXgqeRqTRP2BkZ/2sxAVJNbmJukEMnfG9oMELCJDOmjDVjp4eV85x7Wo94sZsgYSS+ul3KmR5NRxs4gtX3ZjK7aCTX7fO9/iK5uZELkyKHjTRYhJdm207XRtRPOhI9Ylj+WMe0vPEggh35gyhJ2/8IW1oCAw36hE1P2Ug+zqhsqOJBHKlQOViTSxpYaOoFrFs6pe3jD7snBUJ85D3sqSnJ+pI4ArsdY+Grh+v3rnjyIlLY+x+qSlfClc1UwqZ6gqh9HOP3d7ixSRrB/Fux8+TP14t+wn/ReQHkrQdg7SZNP5m1BF7J2lTv+Y2L/DBvNDzXpe/+ssKcwyatDvapMl0RcLKWeMJUeRoCzo5TUmc0vBpTRiCsWzptfjnLhE7fSkMw45Rd4nI7EebS2YgiP+xhyi0W8Q0Tj0yAevVFLajpWGLITzvsRtQR+Och22wcDx0CRhOw0Y0atpem6p3Xm/QdMy2pWRbb6ltlXdvsttGSQZAbMQU8rR0I68Ywp7WE7hyoUIsm8ohIpzeWfOCYFB9pgp38gDIZleIC3YdnktBmj7mwkRnM0no3YJyYZa4LGm2oF41ZbA3YKm+8VUYNR/J5KdAK66V9aNjIK15gXxaBNgHGLqgGLFKKUEZb1wndeK8ffxvfHNEFeZ4gCq2CF9jiHOKgqboSbbhEBnIplYYinNJCSDuUiVyrK5qUcysZ4TEg5ChF/5YN4sad9fV0eDNycVC6K6uiNHVuKr5WJtM9YIGzKXXRDw9WQkRq0SOqkz6LvJF9YaaS2nVsvhxpmQEgx6OaP3CyDguhEL004cJJ+ZFNt440B2Y27N5MUnizy7dak9WN027p3uB3UR+y76tOVvnldUKb9qpqeMq27dgveEzNckkS/49G2FBG2HZ8hEQxRCMNggW92dIbSlVyJyP5JLX3GZ1uEyM84rhLcOUHSwXp9xLg13XVS3eMMtmqHW5EgNkn6PNL2ws3l+XTkkRjq6QTBZmdo5qlgvnSyqdjUy+gGZpGEzhWBSbLAx/JYfhU3gfi8uJ6zvktHJU2U5miaYctoEmzdTO9p1bCGiW6bH5EE1kaIcPnCeE9IViOe3Fab5XrCp6Xpuy8SSHbDJVeJC3Wj4pZCSoCl97NKNeCfoPeAzFm7M3WkkfWt335kcJi9o5wTan+BAlqY26r7I1ZYKSbqWua7GUdKHhnR5AsplIrgZprFMHfxNfYKHeeFAHHgrlylXJ4RrspHkdXS4Uxt7hPG8vXvLN5Gue/aKwaGXchUWmfM5q1BP82bPMO1TG2Th9u4mdbMWEvk9lOZ5zX1FZ6enNiBjuHwZKEDtamtPPiuoeVPvtnreXXxTEXTGbt8zN7U/OSBssIlOe50h67WmgJy8WD/DTOYncHZrHS37J/6JM40b/M4WK8qfyf5+IgszfFW8G705wOx9im4HadHnoat5br6WIzNTYvefnai7p+2o8urRDy68tMuVri7euO01ecaIu481BxDoxoBR63TdCzeo7a9P4vh3mJG6BVQfljV0j7KtxHybiFskRMh5E32TJmbODGjG0nbRf6GPaHsczFx5cDgsXg/8JXOfNQud1ImOKDy6cn+mOLF47W4m6o+MNjzfLAgXRM7Kcvrv3ND7KgtIbiERDR8mjJRXjqG+daNGdPcY3nJ7J+Ll7VIY73AchynLUev71j63kzMUauREhKyaHGMm/1JZ+H7uRKPHqMLFHm+rKZYM6txN2sbQoU7+2jueVOe9LRZUCliF4U5CxxbP4Is57olLqx5uUxfO1pP5Zsbk5uBKDwi8j1owYlx8vz6APnY307bpco9NZKqEDLOgAlm4XkKKuGuJPcYPTDsCv/Bb1umNID57ekRgvZ7QLIMOBp9QnK7ZlmFyjYi/x9ErJl2jLb42TgY1v4/bgI6Lvx8XfpU1AF8QXNBSoR1unvSVZMs8cJfCbEtqyjP4gtVJv9k4NTs9apf/5u14Box25EBcq4w6LWbo/DM8nUDNodjzp7jHz+EL1tXCVC00YB0jv1Gig6ipzaxH+L06NxPRpz/N0psqiB0lzB5xNnXRElfQ629jRJ5aEudLGIopCCTsJQ/kHk/U/zYn+bTMT3mQk04anBHrzpD698/FbP5v+2/fRb32XBH6r3UEZrS/XCq9/y94IdWdNFNHTPop/82NeskcvFr2P0b+l8v/P4r/ZbwwG6jNK1AdlUS51UxBhiUlXEaOREWZno833uVIGSuW+IHJUh8BV4rfAZ0LWXsnn6zTLHJpBmkcjkm+LTmF1KzJJwrrBgix5QcI/aG+py8hfbm017BtWrI213XPbpThTPBO1kkWhtNNAw3Y9JaIAUsA9a8/CwmiA2mvZaBK0JBmXDQEdvuHO7QX0olgErv+Z3U6fx8OdtXL8MsGd9GYqOxQD9RgsSoRXzRJvkGYsWIeiVIiwTqbQtV+6CQuaPb6I/vo9P4wCXkUFlxsi6SGCxGwr2vfgctRzEGL+Qu36yXAoSPpC0R2tGOcAmvgDeqRQJXPdnePZRtaSQQogoQhVF2tUJCBj+uZq4+4mx9jUbYlfaXqL1dcobDj42UF6mw98hvu+ntlpJ6BWhW0DUuU1zQ45jJ/IDOccJZVTxW/9L3PyzMWGla05eHcLSChBjfdeoePtXZ238/lYG1joHPQho5Zrx3yk2Wat801Zg0rQh0gJC314keHnt9L2897JvfSMMSo4NM0iLKmep+xCus1TmNsqmnMCZ0+F0p/D7eGReF30Ys6sanltb7PQI4XORlcHwgFjMrgTEsrZwicLcBfUjsYPnqOOF69F6g6c9lWviwVF7mp2jx6mXWa3UFqsXf90noG+Uv3TIXkv0dRNisRiURRsowYB8uP2rRoVfhmFKHsxQ8weTOKv6egOSLQ8WdF2MkvlBD+ZQI3t/KNJJl6rHvJutQnLukWz/srYwt+ExOCHACQNPIheK9pGfnn77GHYofOX686r6OzdnoMQ0xfi41x/P9hjDwy21TVEXAxunqSWxCnVylQ0+i6SI0PFxOzXw5ldFCD137wS29pPAKNXDKd2U3eZ4vyK2PYHIsKdgWymXg3ONhyjmWBNHTxW2M7la+RHO8aTQcgS2zHSIIzq37VSiQYEqaFjssju5+JC6SkxFKMzPiRPg7YG8Ut0lGauCUW80UN8DNLmeg3Pe5gWTY+U7nkH0ABfG1Hz531Qz6af8Fc4okIA1sCDVNdriHw6KAxhE8XYPbd8dEc/d+YOZuevR87PXFnxskCP7Ubzl4SbaLq2/c1wtsWmaXqktq3Dc16oZG8r038mgMevBLELKto6vxWJKPCK8VndqniuVYvDBsoUtCUDdYmvAj4+QLuitxnXwrlb266gbILeC1OejOxYsAOTSPBysTe16KN/nI0wrB9JTxSABaV4bV9heLKlkU2JpbubdyCV9nygHLHoCdmmwFxunMk6MofHG6QVjRIlQqKBJV3RWDO72oa7cPZG3wVykOmDarP8/7klRP2EvLFzvXoYYTteq+5qr86oBHEmCeleRxxqIrdDVY9Hx63uidGBCXYbdRungTKUuQG8jyMZ5dWJKrZQRUlMdblYX7hHqdrqr43AB9itiM54q2r3qbNlRz8CWZDkN7LxhD2yiSGqWKRxbQNVREjxOGJqKfDSoaCIVjotRMuD02cIW2StFTCa++1q4e4zGQCpRDmlbaK0/a7ZR5KS/wpcJPIXzlbNGGmUO4lt2ujYdSgo0cOZ/c91lXsWUUGPKF4qVlys33mb/hI1gVeYybulzdG0CAO2C6YNft7weanm+ynaFG5bvjDBwDCWCUVh/zEYEm/bLVzGwJC/OOJuqUc9OPfxeTKGEVY9TgxX9G9KKZjRQ/rcUz05pw7qmdGUon9TuDy6nUbs02Lz3qUw1199hVvol16q8/46TyKXEal3NeumVtpA7UfJj5OytK83BGO8JCh2SumJlNqyLNmRZMHePEA+2Z8NaX5fwxPJRxlfcukJwZnW9GhaQwAYnHqHX1ovyOTShUek5KrM63Eq2gPjWKq8H/eS4im6z77QumC38xIpp7fsPQhMb9AYvADAemMR7H2QBzIOdJfMZUQmAK/w+hUamPegd18Y/JrB/BpEeweTEb0qNQIVT3gbh3ubQPjytulfbqNVQE2UGHvBxzfGG8BbG0jx1IZCz1ZkRFK5gckzd7jEezR12+dI8RRUei+D7w0Ihb6npyiSIYWx1Sg9xkBQ70qTrcmKm3q1q+hENkS/UR7HTGZPTUqp545P3HRiKrZiDovHbeL1HG7MXQq8UMd4eLYF0Tone3m3yVL5LBJ44Cwf+jmJImrj4ZN4u42dSLlqy97Lhur1Gl0TDsZl367GJrE2r+10Dk0grHu6egWbVH0leWWTGC+xExAzkqj2Vhur50nxFNHi4KF0CWS4BQkP6yE6Qize3FeooAKw1xIW1fjmF8p+CKDcmABtDri6TzOe+tq6vjUcNGxJwjixAghRSPSF0KZtD9AVc5WiaZYmHuNdlXrjdJR18iPeQJqPGHAAkxEkIjiV46Ub6d0GT0xiEShgMFhkVqzelLNgL4ZLPHZP+1BrfS40j7/BAgnOapbf/PRpaRfJX+WvLYS5r2lad6WnSaIjC3IsTkmfXg0kPxCtFDcmUoZ2flBf2ciqEFgBGPCAIV+MYVGdrHL6xd6gS1V4Kcj6O6imG2hIpPTtnOCDAKuEbAVuykLNfn+gobaWVf/lpYlfrRR1AjvcgoQH+7IdTB1j+Y0Kd41eoZtsZorHGFMTWwpEtHKZzNiINFHnn9eOeLEKBafq2Yd7Y3Nh6xMpQwPF5cV8zKbxeZn4VqwgxVMCwQcccgc57ok0pxnVOBiXc9uG7bjSvBfe00T+eS7Yajgk25WO7hXVlUO7znwIdhXEbcud0PSOLLA9Qz5S+PeNNvmtQsWywrek4722KOhNpHQtye61lh9Ilf3aku/WbpqbkoJdtX6ikBBimdw2i000K0ZWFc51zB3ftCSXHpeC8Pvx7QR9Fr7Ndlys+O8/0vsQ8bexnkVLXyLViBqdG7DzL/7nfbwzQuRvT+QMOJZk3inP/oXdG6ZdNX7wdgdY5gaH19ZQ6/ET86pWYMLNGHRoLM/L2LdtgU71mkaFl9pbbUB8VQI+aDa2tRP7lllIJT3XITaGTbTfGapPQTvn8XWFfH+lAGjQ+kEAqyfR1q0IQXUbjXXZUx0AUhdD9R8703UTtFxvg2wvVkIFnz8pyTdW6rbazEGytZDuKUEdq4hk18u7Sb7MY2SZ+jpK7nk21t+T8GKrPN8t7C7H8gDzgl1uPyljuLqqG9etOsFHtw1UAt75knqeo9jE6jhOB2g02tuMeoteWgU8axsHX6LvsYei+60faVNVn61zEkZhh4/+DdvuK4PrsoeiNnof3P9kHPd1sOnR78zYzPO029+QH3fItu6fX922dmG36hUDJJpXHbMbqyodWbOEy59bdJgwZ2w7B+Vo9fSax5RIU+zBfl0FuOcnKHDDtRHIgONkynEAidtNIe/GuQaAncGzq58L2EWm7AQkXEEJDuEdFHKSV0qztuBl3DEK9RgOoR1UyheFj+MeoVAewSH6vHH8NsGtrMJ3KalcTck/n3fCqACFXTX/HUB+VktAlAo8pIyqGORKdq9Iu2XYxithMOI/ZX49n9pxsDjQzBb1sqWviTZX6TPMhCEoVINCkcaWhgFqd9djf925BC+2MUrmsoidANpCp5IohXQyFoXJ3fcRu0E3CwBm2aa95XGPrt32DbfJ012alM0bY81btRXguN1pH5OHiwxX2rc7XcmRCOmJVDDNU9MkaCQrnKwIcpg1qycOcwp/p+mJi4zD34VsT4Spocy3ePhweGibb//gYFiPk4s/wA6RSENYBHYNibQGuxpIlQHwH4EFXUCcSIrXb8hhEnEYOEyKp8oK/ZlOmIv4aTVkD+OY0N3uHO3J+d74pvmW+moAyseusjL8wdmV5jbm2LbohO3KOmJtjiywQIWicPu5l5kQZqiNilos11caLDHToghJIct0a9pa65oDYfa/77zKCjdFQwLqf9eOddtFXlWmA3rRzSVhQ3ICPaku9hF+A6yTsEDoQ/3h//ZstNFOJ0euYKiJFG/syYKf5Pn6yzov9QaD54F+vi5ZCDvU+GtPdbKpHy7bApuRTjdk5HOVNG9sw8CGHYsbJyVgq88PCgh2hrnJ4bd57SY7IU+/HuWKYEibvAUR0bz2p9KXqXDwGSaywdUfQfRVFIIvJ4uKNKdghXvzdZQsds6y93YWPbllW4qKpj2NmBz9+a0w5a3VE0BGYdhZ7XerAwRFT99IV+9YbCY6CfqhBaQvVM1RKR7S0iT63MS7rSIdNwQQc7ht+xT68d+B5FtUFHIixXls20e1qGKyLIcs36x5aTnT/YAdFxMbW42KW1J3ZbXfXRiUbiyCVfd4L5yc0MbDcd6lQbfcuQE5RO9obJZg+qFNeFeXZM+En5d1MKADvskVquqbYS49to6bDehrzBAz5dLs0YxUvjVn4S+kVCIlSwbOHHfJUYSZ/p4O7I8FN9bKNi+tGfc0TkUkkGHrUAHNu8/LUZlbyj8K17TuExXdkRW6FTalEeqBY4dnCHvJW5tdCHOHudk8q5SZYt8e0jWjn18Mrunuma28yo3Tvdz/ItFcLFu7rb+LRfnKXfna7IG1v3aChW8eKCsK6fmTU4/IoonSAMP6aw7r779q/pvQomgubaroVt4yxfZt091cmljIr80h0FMG2m9H54lMPnMSbSYQTGg4upZA8KP1LT/9tWhYjE6hv6ig8x2AFE/NA11reN1G8rF+w+GMdYkUSRkDH364EVQ27JSuXnwDPvtDH4xGWxoG/41BE2QDtVokZ/gedbEKbJGyX8I1rSf5Ja9KC4PldmJgqB5kDG4SXfeg6vJ6Mh1OJPAotHPbLO03hNsdXblmQg5dlE11tHnDNXYl1e+qYoubli1trucPxo1nSOPVAv6fVp1RIXbz6FdFPsqc712oALZzggVisgO0MMRiCwMkO8QF7OB2YCSRgqlbSbeeP8G5u19SZJBIV4lholVSidowTSHFU0NINsHeZoYgg+OCqqMdb7WS1LqsbRL1wQkVf6MuMozP6mMmg76yfD3qIXmAvg6ucmjCIxM9X+0QlYmy3zDwFOWyd63LOva+zQHK8jJ9HbHyXUjZgdG+MsYlkavj8/1H5xbkv34vczTZSt0IRpQrzabWtXnD9TVKqt9tZYtl1UKlm9RfXceZ9Lim2bKkUPBlqd4kF3t5jGuieirtm5pEz015Q/U+fFD1B6OhtvmsWWUiRd1cEHQV9xElxxhPiiayDFqnSqxvFM18IB+SIjoQ3Y2Jtg9ek+yy4uzVJvqGR34Bh4x4p6WcLdzWoY4tSL+wKZQtryDgO/BOV6g9ZKjGSl8OP1ZCaTG7kZf4WWWM5J5dIMVTjcL3cYjfAwMD3756ZMWh7ZCff7n/941rCYkUu0EWIE4a5NhSo72sY5xKm2AXDyBikz/vS3x98wvWHueGSdRH9Jb65rYdQSpmhok3VWtd8h/e/WLi5PXsjMnBiTUsz4ikxfPwyqsashpqUbBwFsFvW9mHtFKRu1m+B6inth/aFevCUf8USHw4LIMt01TlBw9NG4bLzM2YkpJNSp9Aw8c4D/JAeyJ6jK4R7gn8KLgxwlu3n7v5NqUjUXOGqORfXKnXObZc9mFjRSaa0hjq++7wO0PRnmVvpesNdlWB441G/pJYv+JHerR3+1x/ITUc2079eVkx+E4lPOD+r/JgcMBx441cJjmRKjdx1ntce4yuCpXoqcKNvxWeUnCcHZ98onSs0+zysz331wPuI6o3Mxue27/Rdwbn/w2ZsARUpFxiU/i506TV7HWle8y0niNb+0uW68GiRIpHfp5sfuaXHX52sP6hKXbN+L3LN8pxhhKrnH3uxWUf50eWxeo0mqHjK1a2nVPEK1sSvf6ZggATl/6bJyc940kSs77ACIN9Vpfmcbtys799QWOx2sz2QItH2FlctMzB/IJLT6gXy75gTnsFYQKNzBuCHYf3c6vnsdwTH5l2Tea+Tk+kQOkX6XyvX8RzXYE8VoZisqw439XVVMUOtC+RquqE15Piqdlii1GCb7vkcgr4LlPO9N0w4B9qwD7KYH5NGCTFU8OAWRsUgNb/31F+s+jZ6DEWesDmUsAz0q2OglevtoJ97cz8qTQI5HwRVMSXC5SGD5bIfHjQrAXO55qLG1/cemKtRRcQENHBnjxeR1HrqEvY5EcC4uyWPvSfijKbIIKJCHsrDB9mByw64AIsmZYgG6p9+S3+RiseUO14rK2i81TbHT9VWDgtIKz/ARtEAQkbbH1opkDBvdT3teKuV+rvCYqUiEhHM7JzBbGuOljFqyL+Rvnbhis6TwG/vkyXEb8En3qLg8maH5m1/4jtw+KG2QYJrUrVYlvHtvqafdUySyJFpsfrO28NFvptMgXLxBQvUaq7UaKLAuOhVtWTEst6CBO2VcbFRpqHLzwmqyqyf13nbSdD4lqOEu5jmGmbPa3TMD3c5CZm3zdIFL3+lTUt2zNXK5ypqR+X+apv9GW5iHqzUqwHT0qwt9FAGIPWWdE+oDEMSzJ8t1EUjs9nzCoSKRax78D4OlPbScY10ThUq61WibyNMQffSKULJOqeDhPfWcTp9o0KrowthHiQ3CxcgU1JvPQcZjsGvR0DrEZjVj9E53l9qsMu6mK+McmO950gFAvxIDlZJwa2fkU/WnTxr3zWoHIhb3xw41WpXqLxryiWcf7rK56tULmR9x+0wfnPdln3d64Rtt8kadUuT36bJ+mI2LrHLZUPk+tQdT6rkttm8IaVheWhsrMNNVAzj/STvgGkukenwfC1EqMi0Vi1lrsMAAAYqpb5rxe9OCBGZz6mCbnXCUi7ncovJ68sx65YtUy4F71/bm4ae4Xan8a3Vu2b2jSokn3CWjWC+bw+l6P5xKzobLSt5Y0qZwaoiwoAe3j2NWF89xf1OZsfmpuX9NeHxeedAbe10tNcI5jVlsQ0vAzffrfvbSTmPbZ91gqDrftOsl5mamqK+ycST7Ty9rEkqlnlmUJPF/pfoQ5wg3cVjGSKGdyJlIAUTyV9aZITgHv63RzZylMHv/vO6f7pp3UsyV8df9E2lxJWP6E6kLYNlkRJv0Mp/vqLntbMe90wIGKb7ZhdcQqdv2zm8YPfo7NGzeEC785sXuQQ3/1yHON6uuyrcwc5ezrwi/arb0jz17VisuEevf/Z94usMFMQyep0niPwTCptEr9Dsa2xrLOg3r1auEtUrIGfLFgvkcYUxqhRejmILvoZhKcfeCDoyWR1mi2c1rgaXibDGundek9UYpRFKRjyMGyXvB2YpPPF1nUxPWZ/Ws1pHiCuEh18XJG1Ci7Wfglad7mnQVLB0lPsUKkw/dstiXYrrpAfm10T5SU7yV6E1VxVLIxa7S3SYntai5Ne0/G7gVuFXTcj/Fqco79erDFVUa0jlJti2vyti3hC/eVxfPWDIq2itdG4lv0yABRvgWmsVoorjGiX0Q6+l59oQJ7vHKKozd4m1VSn1ZsptQ2wfm6D3Ffqvfm67Bz9U28CQG2uoni2wF1hc/Z4e50KL4rKl+apSQ823CXXruBCwj6aRBxkmqWHHu+F+XkujKVtL3XTk3ub1FAUQKjSvbAS4Z6M+9j2c72FIWrUE9NHRHYIq5vIDBkcdVtrqXK0OGDQoQ6J9+klxKM+7frwY/1Ie/sJ99I23QcArTQ0U+xVoim3U7eyBy9+w4pO3X3iE3GpoqFRv5aloTtLjpfUfyOeSJQo0Y0H9saWWo5t2d/gx0aE/9BFj/SMAAAwLOGRYofC2zjEF/6F11Ee/H3DN0glG6UqtP6G6ntq8klyWJbZFumQou86vrPrOJALSLwTh9/2khNBIup0KY4a5LJm4E0WsjfbONlme4NUBeI/BmtZ9Q+rYhexpERKtO8u12xmhf94uUHte/aRukh0Ewss7Ythd0q0bIjv5llcvKYiuZsVPseH1W4KSefDGXQnAGxvuclQ6zGyv3W7ZFxET6RyvT5drm03CM+Dbq+JbQM+Tntxdd8mpSnC2wzGOwQ04R0G423CgVQ0P4k+GK1YvJpwjc64plnvYNCTelHM86k8Rfh8+up/cEm9KsQRRJz50Z6nssaf0rXNCOW/i9RhxZEaR4aHfBEGG8Ng6f878NJuIJEpv9sRRxUS/F6m5Nkg5wSxlpJ3luWcJL9+J7nm8+pybQ+DIvze7duWNn/UwK0pCR0Sxqi+Epj0EhtgX5JKL/pbe5HwWicv0im78Ei4bAsnN60qEowCeyfIzU2RZV4MNxvUXrlYxBCWR8ulQRJc7MhNt/YhJl6apF7eOYCbhIwkpFCoP+FGIdDlfT5XhddozYBcLbLS0k0BVwjYzAInUuxz2TjiBeHalcfk2cySsaIagkid5Hay49mHKTqzXsOMDwcYjMBwnKmx6J0r+6dWD5dzYjpHSFRYGBbpHZxY+fD0aoWLep84m12iV1fSvtKEdzwZWT/7Yebsh2OmlyInO7LWSSG0+vhibHdE7YlNueOEls6Vfj4/b6zcrBR5IG99+NIaG/aNtWh6+87tLLlDurvGecZMJL5FJL4jnJxsQeUr9FeLgX359K9+GHNG3FL3/0BHyQwnGG98PiTDOhP7uFqTPt+UnWP5LmdW4zdGjZIVVOqnIq19laUqLeeeUlPFtEYhHsDTag3dXMh/C26mElJtIQdTZm6p+DBc27okkldxRTpxCfXP31042uA062sjXS80G1ryta8/Wj75Ao4VYXKfiukkUcKfkGNghLMAFYUZGPK9I56WurQHD3xynoRhhCVvf+BRmahyukGkoDuPeqkqhYM0N3x9sPR/zxUVXBKqQ4XRjMWir0UhBtEr2qr8bq8t21BQuxFVd7IyZLFUhk+iQrUbC8baa9Yj/EuVIbO5MrSECPjWDz67lWkDiTamjGkjgjZm+MaGsUHfekQAwOPHq+1jZEAIhkEI1KXRtaLUPRMbOHBObbRrXmrN96feXoCD5yEPjtiR+r4kir0evgApfN4g+nTvvn/l0sBhd87ypYMdNcNLLuxME/ZMe0bgs6cOOkK3zv48lSjg/V0P0gc3iZ7yoOoDDj9WX+K0PGdAlB38CFBZcTzys3qCXLD31M+XF1oswQPKnS6eH6OqtRiC8JUMvtcv5Ng1ThHw4ulvNIYcU5nBFZt/3QFw8SOzFbpn5/zLK2Uzr4QJsY2nE/hLs/mLdbxpCn/VmgQq0R3CVmNrdk3V86UephPmL6apTxmU+jvEEgfpfayOO5reHitbFGhflz22pmAtYrUr9uYz8DWRMA32+A/tWeyvVwv7x8aYuNTVOBqRQM6WNWsKaL6VLEfFh/drWfpwUbvlNtI2nAeBXTGDr0H086pUdIMEkp/F0MlMVBtCkuiL1ofmIpN1ayVXnIHxn3kXdO/0v+gHivl+M0hliCvndMJ/vYGADWKRgp1j2lDEpTJFb/sYdDn1oKXWGajhQ2yihEc/SvWHEPh5+3oOf8UXNINNGVzo3+OcrdIJ6mPz6bPnqp2islUg/VBHi/bc9w13/D3Z6YZKj7IMEQgL7VIubuYxrojS/l/7hsH4BkT/uFMbKm6Lx2/9sR0rYzajdKHwGkMm8dv0zbxCR1pkVgWG9ELhwvE9BZKrf6pEY7ZQqpfBvhXR9t+8CCKHLNZnNtgr+hbR0J6+rmYm0nTfjd3+Dr4haSKv232TezJ+shTfWGJo5HySg79IoV7Eo21uKvUCfgp3IfsiDoN75VfSZVxzP5NO4PLoSIYKnGhAoSMIJ6cn2beC5UvJXg98zu6ON6ODdCZ4GswhmhD6evQOixfr9boO+Q+Kd207T/DjFaIuR9GNkXpFHDLqa2X3xrzxnls+ITehyoS2cNGuhRj2zQ0/v25/5PRIvohHDdZzotlPtfAXZh/J311aKilaP0DasmUh+9bdm3shL6Qdu/ddX5rVNX1z9VyGQOC0z7XO2R0Ch/PNjjdvX/WEyt6D3NKX+z/uOPUvTfuD23qX5/pPfb9209wksiGvsKC+pt4jcdDg022fKfvryCHOntIpVu8N+SqFIYuMowJXbP0LbwIml63KJtxKu3XJlnGEcxImnTC2oeTbeAY1unGg/v3vt09rdNRCFHNV8pm/QzqcQAfwKiE0UJRVHgBFcZHQL/K3Sjfqqk4x5Rkn5OldeuoffFtlER4g8oxaIQUPkil3bw8mMarLIjDfkpXtj76aVwJjOdEbwfsMxn0QQ9D1MkIgJWr+DM2xzxOQuce2IlBmNILxb7by3TRWqFVocra4nmu/dLpCOlo3JsOsUAD75CAzBw/ZxOsReP1Cge/p5dSPP6BdHZnMWluBYj/+vhEkYuxIc8JTU/QOBKLfqIh9oAJs/hly5FLXfSe2/APh9MIfn8+zxsaQL+BJq9nDsxfeJ3XpiepKbHK+fZUt5NTg56l3+Gz1flv+B2IEgw41T5K92B0Fb0aoNoa4Sq9sZJjycoSQs6yNLF1MW7mnKOcH45u1t9TX/FA+do/4ti/H+dej+Y4Cdu34W2lrVcIDHN1/lQcDA44bL4NMqfe/S7wt9ekifRpimPlHHjXr7DDfyjq7u+xWNlT3p4Utb/v8c8Wsn+V5ACgc/bMDRld56Mc2NwbX0YGtTlf40qp1+vA+uAOCjuxnO4XTOvnN3kCNlXqX4cHqJiAhfJVDTpLj3pZIop0fNFQ2sCoEM7pZfsQD5EIENXlsim3LfrvH2K8nP06u6usqJW98mEbQJTGC9M3Fuo/+viz9MDhdHg0r1/mpX2pZ1qcftI+NdU9EyK/Ksn/5uj6tHTJaYGpHxUNvwqifvl8M7rI1gLQE02jdf0aXjiXxjJVCCp5IRvRGtfXLJ+RVQXICJT/mdPBPc66X4wzFq1n39nB6w7fdJ77tuoIhGOyBE4b0nmcpeTGNXEHHVyAL00BtyuZD3wUxhH9uIKCSkDTdad0/WWvFqDuEJ/M6ljCLaAh3SCDS8vGcnmiW6jkSjJdOP1bzYjgXTiz2aam/g+hFTP+uJhyKAaoFPb7RkosVIqoN+cpYRGblhvvfRQCnEEv9kl3CzL53adwgV/jGwhhFv4Q6juw3G8wHCIgtKBI3ZXgUuIkpzcy8giaSvpsHBTr4wJb9eNIZNHiXB9ZKsdU+UOi8vIAX3W/LMiz5Llrc0sc3jpHbKlC/G39HNKFZHDZYAeLXBMg2ubq8XKfRGeTaBTfMkNkqY/Me6s1sRb4cw4dQpprg06LV5Zl9X1G5QY7o5/4xin4Hm4fDVgLhyjCbh+exnzU+Ozgg/2/f6HO/uLlH/xIvN2uxUPCugPj3fh9eWeQy14SbQwP5qocu9G672PPRccOfBkQmBPY1I6OMfJt3Pz+Qm8PMQcBhiB8fRLm50Gwh4Rc+PUclREpQGdILkBXFpuGiOxCeBsS/R0Lh3x+q3OTKfOV5BB4n5JHy83KRHB6Yl5sPzdUL6kYA8nI8QirJqMA8PyA377rmQVGtNntJHnkKT63LrND2IXA4EY88ezaCyyPqBliOgZCAyVHDmeV/KZAqAFAhYX4FnAExiGIDOQcbhXAPIzeJaBqoZqGjGwb9HaejC6El8x3LobDfTAoDzuDDfoZHL4fDg4iNL568eXPr95A/W0cZ3x4//mYkRq78gVx2Xy6/L/u27L/WSwAEfuxyuz16d3cYPKxwrL051DO8c+dwz3O9pPnWGLFN+V3XE861a51PdHXd2E/ssuqS1cGHFmV+qHKMTEhFthcnEkU7I5GincautBHB1vL8OfDdWf396muCs+3HFvGJiRetO6Q6seSrzE+THgFDkPR8mvmVRCzV7bC+OHGC3PsRP+vDLITunqOuXkJauf/KqZWSxifuNPH/f3KYcSlyheGiZ7C/yr/Qtx6+9uhfOyb/3tFnTv3a+VafvnPKWRHkguCWeJ39Tf1HsvQY/UPhSX0pjfSumYraumzw7zmejiDBirz5f7PPR7bGPWhD9P5i+LyY8V2tX6cd5F2LfqBTjflMHhuyXvNmJ4GtTDCl0ceEKNOs10MvWn+TpgdcaPwA9URC/p38PAnYcyMXBHNv9BCMwE7gBh7zEyfaA36NykqdXHaxVgbzuFUiX+K2rrUM7HnwR7uyXCd0AUo0WgnAsQY02oDNJ0ioNSatVmNSF/6csspIKuNwykgkO4djJ060M+Vv7+k9YUQz2IAhe/vR3qe8AJMpZUEym8Q/LOVmNoreJxG+XEb5bGrybVzp5P1vviESaLrTOtx3Blra/Th8K6V5pqB8Q4Zsg6v2boR84kB3gvVf5npXzd0WwrcUezZyt9a1QZaxQR4kfIW/ydtv4flQ1CLm09mLVxXUATw3r3q8CvOrBQv5Fpflnf/Y9jE8b73w6G8uqPJjGPHwYPhggxIRjdbDaTq5vmOP/HGirSUHrxgOb6VK4Ke3VcGoOn7+7e+6Ut92o39m5jztjTOnPanHfWJW+guECQOA214Fr7hIVVmyBsxHrv2xayip94lLD564mLmAZAIAE5l3kzqz4XQ3VJy6tTjMhsGZP+vn0TlS8ijm7q3NHX27Pi9XTHB0sjUMWvu2WXYpD7G4qGPszc3H/G0vA2KYPOUXC2gY1xhatFhEaI3GpMaYf4Juo9H/QKXMGxL1L/TAytbysyrM+n5X40Q+SyIgGUEoxxjeY7aUofVPEscU8H9RKAQsDyG9yE1AJ9fgUrowm2fnXfgv72RWZM2P6l5Eqjs5Ojb7c5a4IAMTd1v8sWdGXWCLfmL/khkMIDVo6llGvpGzholY9u0dWyaWrYL3Lm/yUE0IbDrJJ9DO/x/OhxUbZ1ACsr9M2NczYgOq0CiLB9dOdvSvZlG5mwohBRbJiry/Soz4LHRAnLeeW1JjazcUi6RqVcm4EvbCqpazO1e3yVsxbS25mGYEXY01dJQjoLUwTjYxK4MxrT3mJDmhL1U5A6okqzXjixluiie67umtMgoVOOzq28zKtLOhIouQ/eg9V+NGFKoMjiog4NWLaNOHP/8dRbOwr0xdnz9osw2+124oNym3K8/f6UyGcpz7xCris9FDCiWHo8+V9y3dnEHxjgNRyZwu+dIsKxF1UWJs3Debnw/5TcTN4HHoPE9Y0KUMpFBz575GQtNgw6+zB5qq6DT9ew/nPgmZQY4ZbJUwVhHouU4Syk/9FyOZrXO6qCQg8gvFQREYKM8aKFqzHs5AoM0oxNZjuUguvla+TfsnyGHT2l/I/4W1HZnONuskLHTW6RJp2qIT8cIMqC7z2UPNsQZ+xx3Cq/1FRAKhFYGIV2DPrzkkUJa3AMLvV6XKvd9gQEL+9hMfUcgYCqMuw8pU3A9WkOKtk1mivVOi6uJNGMgv4URH8X1bKnq/SSrGEqTf3ZmkESAb6e/oWVwb+pwM1EfI7ywfnERpNhGxA4otxuIQCCSqQFUiDePCfvSFeWdpb62eI0W4yz2opKKABlKHKb2Nrf9Pr5DBKQVFplMWTMYYhKAhO73Zc4g2L2FDIxc1XY3NY/3RJ7qKLKXvQ6WmQqxqOr3sdxX3nf9VoTLGMwhlZEcNZCO0zQuct3dNw7Kype/cIxEz4fYdZiK/DvY9UhYBzYci0CgktKopQfrcnVmrvmX7TkRQBJDNOXSCypqY7PYSIIz9i0xL9M7eoL56JRTOCPF7Q6Hh0BpLPuUfMsHgJbWcXZd/uOwwj4r0/bwzJwNiKx+tIFZozPnkIqf3pZ2rL+FAGhHHUDPgq6nT2mMVvCevVvbSg+7MnUr2garMrtL4n8hLcmwnTuqXO4kBrJJUfhSewYMe8AQWnxGVUtPSWX5m85/RSJlvFqJqKewoahvpgiJRJVSpg/0XbZf9L0wC9u/7zH8jZxom6xwuGOzz3OyX85MhEZtQjcpWxfcYtciWNmpOrxaD0DJDMiTqazSoIaIjMGgSkR+qWfS7sa328jxdJuhW5Awh/vDQPBVTD3JI0BezLF2ZqEG+OT/fEIRmwHIuIG26OhYGo1L8+L9/1dJLbzxFkE2wGUhdFnkKj3Ew6RRaCZMKYLB5+3/ltZq1wVuEnYkkeos+b+MNs2MYsADXYQGqktE4vGmR4QAOYJgWiOZpJgCTNL7PFgLV1ES9xouMql1VVscyKUaVakQaphmknQ5XyjWxd7ITaHAct+p9zf/D1bxNG5i9nqJBme8hhYxCUQTH1o+VXz9a3+TXZ/SRH0ph2DZzjXSbQ+9mp0kK3VxIcpL3qOkMZmJd6Q035vO5lSS+3HE6iM8VeWX3gbxqi3FK+oOjaIokLNWxoWXYfJlpHL+B0cjfeAq3+VRT9JIhHMTDb+L5FzHXm4GBWBufNGLmcSAvqVbzg3ZE0uQXY4jRVt9C3PVRRvXUyLcJORl9pqBNn5463BlfoyqlwpKmTfEErxhv2uHbKCT5D63AlLY/SIM/3p/FppEOM7IpAGBFNUSRcyDTGEBrFYEko/xGjCNdlThdD97FZmNFujwbEIt6u0IZbdpaL87jhwtlykJZGC4MF8pCWRgulIWyMLHqAQcxaKjdbIo4vKF1GTyUvgaXrzS2s13JawIJA1BarIkrcEUgyz8QQ+HqDPrACMj+oSqkHAcmKWm3WYFelhD8xrKkQBY5BZGxIl2k0uY9ADa6YKGARcwVD8BArJAI6BK5ylPYUavNdxEXbvfBxPIc+DsObiTCbel6nl8oet63plWuTmn6ORMK24yXzh/apOsbne4Hg9YHBmlwMxiERhqH9tVv/pxg6slDXZdperVOEV7Yt6EBiEO3Sd+xoQcIF3IcE188bZFdEpQ8HHf1zBln8ZuZQRaWNLk3vknq+zCjXI66ke9QkoxpTd6DMbz7OUeG0ROlE5Yj50g5uRyk86CWQwYSGweJnGBOWM64ZgR/IlKwhuvuLkIT6sQRqHOU1R2ktR0VbHu6zV59ROPCWZ/bEW15EmUTEY42pER/na12tsidcqfcKd7/EZHSoIy5p/9g2K/e+gU5JQjNcarSZ59S0keisbqj8/fTeBJw78PgR/E7sd1Fqeonc0cHnjS9XeLv9RbBvRGrDgz6iHhvZZtyKW/tez1ooiRJOdp2h2ZMGh0KJhe+po7OmguPLiIqj1DZb8xBvDqn286JWZ5oHBvf756zmykqDTn5863AMLsrhpjYEJWDIlx3CgiLkjTo6LQUBIIQBILnQ9RldCIIgSAIgRSwRWkkFwpsDMRlSm9VOoMhg6xA/il3UJTbuEEXci94YfUo40vLololmx4IPR8UkzgoI+luRYya0/y+6OW0KtCqm8tRJidmdNV05qppxyoQV4H9yIAMyIAMyIAMHA7sIByQAb74JOeMkrsgJfF9Ep/d3CRk3IhHDF1UktVdZ9GMV3pXmFb7mntzcYrduS2KXRtTlG0p+05gj3J0YYzI923c8/ddnm8n88TiNFBdx/m7zORcmcv9mkjo6ABk4WQymUwmk0kQIpwsXFDGJxUYunRjipA/LiLKkPzGMLkQSe4+YIeFpU+aizmUxkMRx1HX3iZ53GixAnMA5cOtVR8nS9bjEOLLRxNNaxJ8kvfOpZJ3Mm8y6PyGpvtpDUDu3vERyOycRoQzkEWjIOsWKzBil1bEcjWJgSUgYg1NYnC97oOhkguCkpHb1gt32m6+FuBzjVelTE3wS6oFnLFE5rFoB9haFjit7dY98se9z1z28jmrJkAa+Amle3HVHw5NLUM1iCiYMxySIRkKh2QoCGUVFF9NCufSTwTKoZ4ZO9K4J6J5Rs8eFFQrOgUqyChV3OrUuux55JL5tTNrYtSaW1C7TSotB1WmZKbMDGNmMFR6HPyxRWDh49EorifWdvIJhCAo5benjIMwBs0aY3K33F3r1nOLer//GbLmp3si4qffGCYX7rj/90bYr5yZrvp06nlwVh6NX0EW0cbdtSL6/IYa8gyPH736upgoA7WORHIY/vngEufQbco4IfdaESl+Q9+tRDbaXMzxOsrIDEmmwTOISzDT/c83mNnNdX5DI4pgZmJV3xHUiiQGjJc6/SoFinGDspA1ibmyj1w7MewKJrWbNbQGKwo9bFOq8gmVOasSI+wLb49O2o6atynfdzWJAXwPawsuyLrHGCIUYVsowban2A72DOHkNijjQFAybqT0kTsRQ9/NZD9WTEBNjrT1PmnO5Sj7+48bcX7r9zpz0LFvJ5afthsxNMjvHhQ35jJ1PV/3wNAgL8ID8mS7kh447ZEO9Md4WbK8LC80/hSx13B1gyLL12VeN+f6vcj/j6RZt1WAoCvKfF1KEWRnYXj2UNioZaGhklsX02IORdQjmYzWmI+0iHD/yHEN2ZSqdTLvyjTKYHjpQDYd0cWKAFMxH7UuYqdRmXAj39SnY1zI/sucbupcf26H9b0s6lI8jlCG5+YusIeqMz6xQ73NW2mHsRTa9nTN3bo1BrDJ5r3JWBkL2ODmEHMaQLzicQRghVk4lsBN79BpTyTh3hUniQ7vLWpXvvtabr77WlK+u5V6k0LVHVbo3XUzfZAX6DvV6mZ+QKz3c+ap1ntKVME5ZVAGZVAGZTAcDAfDwRAwxWT9XYYvAM69GJ9H+fKWXL1m4roIP5BRK9kGRe53brd+PWV+jHZ7IpjU0n3HCUiMAhEofpgS91HrIuqRNdohpivlAjHcBeLmZDAsnptj31L8UGshJTqHey1mnwRqBEo3znugPOShfyskToZH1/nWOFujiz+xK6g8iONv3WxEkqWRX8RCMs4d9ITy2Ap5aNJd+FWq+0Yov8H1zmA4dgTTs4uDXLUuIhLfk3/Tz47YBijascm1No2bd/a6PLMl5pUzX19X+5jlcEj539HfK+OQ/m0THzkwTn/+4EEppBuZMbk4AgwR4zOSb2bMbwb4doOe17ssM3yG97rPmLyVUIh8YIjjwBBHwxhBRgbDj47cbX+hkiKfObfhq5LboV0fhnoihj2LcaL9ZVp9RvUo7kDlNeQnK4duXvCX5jxUprF/KnBrZ/6ZJnu0oFV+lG0WMpA7fO/yjEI/P2e+4Ink6xq+2rrt8Q42mizne5m7U5m7mrsf0R3Gfe+4ojvYHeymbjYU2chcmQvcrupO8/wNnv1S5PRvRu5HHBz1uDDFy7f2j3D5uvjYChoc744L1lVBh7qAoJS8K+8Gdr8S49T8vb+EGPEE/GLdbjXL9YTrI3FCi+yb5duWr3dsmWoJKoK/ysVtraBHWXambLp0HP6mSMy7bWL/peMGxb1O8DXVWx6S/DBK4Y9yDWGoHWh4nhiUodiQ8uZ9UiAuNDNNejgHSLssPaELCDjLpRgxpgGEMAOEuOsjZh4GWfPIxPBHTtp68lA3GJzqU+kAfx7V07mlaspFNS9TPjooeDR4VD4adjTsaNhRH/A+8QGvxwe8+wEQp31AfGKhmnJRzcuUMYOCmCBGxoRhwjBhGD5/T8vavygOL9MC52tckk0iMG6kVinANOW8Sn5r1WmI7CQ7hTuFOinlq+x1MYJeQS/2epvnimlHopKwIIgyOCgIBkEZDAPDwDCwHKBgQDCAAxBa5QCoJCwIokwYFCQECTJBJhAEUQTfvRyiA+4KEt1cdDilUKKDAoMgEQ+W31qNHiJHy9Hh0aHRSvmqxD8znJn4gtC8JkUXfGGbRkWBebKglAfDJb+9mtGbM4Ye0h8i13eLFXIGBYbd/pQHwyW/vZprkLvDKIpQfLb37Nfb3T6pOYZZoH2qpGVYmvb/UzGQwbDYWvIxkME0mXUYyGBIrgqSMQfTg7a/M4rAoSxH/Us6R0kAtTJVf7Z3RszBGBWfSPPhNe+U7tXL0WG7+KpsxF7L3pi9EXuO/VxPPQ4BeHlMv6GFwKHUkRzSqzYCB9NbmFmiowjASs6uLoLoqsyxZw3PiIAyGNV8Ps1H2bzvt3b2823urbccM5bgeLr0/yCl975BSwmgmtK75EAlAEu9Z7CT51Pl4nnBWj1U86eKdskuWZXdz2+Xi+NZgxIMMPiltHdBAIaAJN7LHnCA32Z7A3KcVP1PepgB4JTfiNfHIADfJ+inor7x0SMAB3SpO9hdIAfo4sQTxKPbZ7w9VC/WWZrjaY8SHABdrNEZ74IAHNDFymdcCAxdrP7ZBgQCDhaZBgA+MejoR2ddCMC7gK5I9nUhAMOJO8fztM99anFEdzIKN2kcn/7SCHlwfJJLMaok8f7smSbr7bDcVZgluDnRCOU249zb8fwTbjxmcsFIc24yfzJbGAtmB7MT7MqiAgMYkA+hDgUbG2bsKEwoHQsCq+lfEIoSYC51/fB7r7X4kz63Dw8+0qhpcja1JMtcETklA8BJuzD1laG621ffqaQHPwIKlgpD0KwU9tUU8ZxMECflWSPq0vsr75/JA789C5TXYxJe5j1I9t1J6hZqvChvb9UNXQ+qcz3GtWr5+Dn4l6R/bOb/pEm9YKSHIq6jakOYyODwcA94as1Wp43wiZj+t2VJhca5L9czywmrzZOJpqwtFBzga+oO0vOZvz5w++XYX11yhYXXq+JJledqJHg4jBImDFNz4c3XEfyrcZonI9aLq6Mbq9AIMa+KrsEokLAE7PWv3Dkqf5+nWubJpfIVHJe7C+WznjGUu77kwRvjZvT3+d/7usH+3Mk7eeeood21sjntsIEB1k3TWEewnUNKwWeHvTHaRmb95TF16s70Tyj3Lf2WB/vl/EEDX7Ce+GP39BPKmiZgZcdnuXFaHs0jney9mrnPf4V/fmH9pIR0tg7Zu9euHv7Zz2Lfv7sxetO7AegAdJl30cqqdXYbALfFh1v+y9Caa3/LYUmiWoMeG01IF0DXKXVYgeqAs4xpJxfHPjsF5KPXxiynfajbbAmiB0HWzYFf3T1fWqfBtNSGKm4RbQoi2n1ChmwFpVPS+rC2AJ3M+7GhpdaFPZWIhNaKkWteHlMl3lOGVoIzIxFPnrL1LFs0I7Q7vaeVVXu0a5rSTb2R9ryYji+Px3mn9jQ0B2jkajOigIoUyAoS6eCASBe7D/f0GsrIgwhEodBgtIKEMi2ITLAz7q9wSFs6DT7BnsE5bPwnGBmVRMOYxTmWkA0AuVEzRbhTX4Ko0m577ewZ9THLgHomtFYV7SBNnTGr9ZxPiu3NKMzEazzDUxqFn7eO2SIPhN2+rMKMohmzUQSQLTqwMy/L7TWvpkneMtO7AcxmeNb/MDl7nImfA9bLgt8o7aCzWoF7JTqTjTf/oL0R6+tqg6j8uoXxvdDvwwvOphMedU8BGTpoZZvWuVtwANKj23JToDciGcDNdbPN4LjpUfPQ4CtAeHTjma9Yh69gTkftPgR6v6/YaXPMO0FXNeuYUwMOcJDfcTrWNTtWJpP2mBXRUTrefDwNZmVH2ErtlPQ+Tc1c7TP1oUSEiCCJRmAGMTaeippOiXFs2bXwas9nJy2elugVlWbKiuNRZ6QSTs8u03imq09TM1f9qTuKCBE1EvXSmD1QbwMwCUT7PwftkuME/6ydkfXPpjGQTxOnHaoZgWHfXuxLkuKLVjMKUiAFUkhmBBGh78W9XAtxLbHsge7XKGoC4xFLZ5/B/V1YD7Jj5bia801U6Z7UkoiLSSNxLbFkZqDIAIfCoXAoHEoZA3kDkJZavloc9AC9luLaZ7Qz46Wb0ZUMZEWqnTbXgSDHrFmy3JuTsVFPerVG6MxY6UZ0JQNZkWqnzTUgcGQ6QmUUuuWzBVmZLPVYR1P3oiV/LKJaJRprFK0gKR0cECmwXN8zkjHgTS/oh36oJxmgXtS/QOmnrFYl7WeD5EzZWENmhU6mUeggaAp11jdEgqyI9iAxIvhcDVaGlYe8BwLAn8SPIF+kWXSrGd0GfcX23xgk6Ak+I3LPMLwHJiXH2UV1ZvR9cKCM+O5SXJ39axPAB49HtekQbp0btKS2SNqh33BuK4O8bXtx+JY7J4GmIm0Tf01xYwtivF3bI07ea3/QgzE0qHUbXBsYOjWN8vk0Z0MQnd3fNk+dCHAJbItcW+KvyAuYNkTvYf/9uOqMXxKyZxUpaRolrShrZy4PNr9v9CypQnlUUqWra3M4MjOLIH8RBFltVoTVETxQYv3KGbCm9dlzAL/eLwV2jpW0KJ24R2JpR82SPuYr2ulZ979t3pS/rKQhpx1yUQ9cueqSsVunGRCJxKjzUUDRzhTRK7ZYHjUUK+KpI92pJKvVCLgwBaYO0Xt2+JE1SloEea3TDrkIwB0XHFCr2zlm+aeAGOjlzhpw1bIiABHyCGJGmiwdtdn7VzC/5PiwH9b2II6VERGX+s1owffbM/XW3V5JjPTVj2iaeimtoTbdUAf/wRy0c00Vvl9P7a839E2lzGcaAjaxmA5u+0y24lO5qKVXxCe912iShvKg1Z1Hy7m2CXe+b+18YRBaWeHV/dCIhnrfA/1MYki9owh9ejsj9P0wxcsWn92ZvQBxH0JwYbDePUomYf4IkgH4wAc+8IEPfOADH/gu3xH8jLmJcXmJTuiIuF/xw+dkyFgAj65CzsfVM0djGy2tZtNQoF/UaWZjwczh3ik9o33Rjpu+aMdiH9aiR0evnBY9ZhV1OPKr19AFYiTBBtYmm2s/qN539Psjzd+sK74TfzgxgthA7H/N1QCPlrFbmXjo7q05XysRwX2w8ofSsRP0dTFbevDrCadR/vtM/C168S7WWEYe4SnXDmmJhod6Dmz17PXa+QLY+b0DJ1Ia5b+RXLUF8a7o8H7GYZYe0i3cYDtY8a5Xr95PxafgK0BArRELa08l6+AABFSJaNEE5j7BAQioNWIhT8VkcAACqkS0+WeC5laBMg+6fJ1znxBMI0aaCe11Tc7johYogiJRZKQFebjXuXPwFSCg1rKLxektkA7pIp1kqQnMa4IDEFBr2cUwvgXwgAc8iYRHuZErCx7k9nLLVprwvDaZxbwW4AEPeMDzeKTn0XFylO85aiUJgYhTTGjiDIm4Ibk3ryDvCVoDaiY0cYZE3GBufE1N8EblU6+rU6BHtG9Y9LrmdvxDeHSaaAvn9YI8P685hglaE9prGBUB6kioHmqWdthoG9GeRoLAFRhMlmbNnSV3FLbQnpV6rX5Xq8JtHaryZB6NMwwZvUMzob1iOphIw7ShwAZsjmTT4xXNYgB5kJ/IZ2mlmXNnyh2JreZoRvY99TpheA2PRGJE8cqzBGWu7DEbN4IDziPjgepTZ4JQjSGGtEoa0gkOkGk9JXOIo7Dp3/LKe7zKGQ2lTCuurYKrRsWjmAkaHZWJFNPybw3XTnAfoqNcZQ5AIexXnv2GqLMYKplm14p7EAn86i1mLV4jSjSfZi5gr2iJKEOwkmmTrSRfz26wAfBOoD1UH4V3egvIJNMpYQEnkj928OOpCnKET4KsYmiehmJ+a8bazRVKFOtgKLWkcA/qgJZPJJ4Qvh3zIL1/GMORNW6b4hDVeDNGZOcq6MsFZZ2hJxx6ChCRH9OF53Aa8HWN3gLXLw20nVKYe3/+D0RETRrv8cybGoQaoyy0yFeUGXa/LaF3NC+SfPiVBaDbx2O/JkPWns+DtfUsgzAezIuswq+TvlvAfPbkUdlmLvcQibA/D/3HA550H5SdONrtDJ8EA8CZUaCKKhk50lkgXmTk7e4gelW2TqnZOe09n4cfNp6wv2QIfCnb5O492crKZBSQfnq9UQbwjn7w8ks/WJ8XgOjdB6kAPhMFKNVpfea5lAOAYpqdP0nK5JvNzHETVMcGiNrnK3dAaaSfxQYFx8M+9oELhg8fH4zDKbfHsdeeelbVKM1FLhKnxmq9cBRa/JR66HHIridUYQ2f2p5M8A2C8/7n55U/RLsXAESYyOQnWZzvbyeV67suMjSyRfKlLKpMqcKIaEgZKkUJtCAw6Gvd71vbDGkUBMnNrHK6teA5Xxn8F0mjYyEcpVT9CMGfSdlga3MuhM+iLvSZBRxg3vpXBK86YVTOKz25fwCbpnN27PFHm3EOwRZKKyO8vykbwuYspr5QZg82oIOtmx6E7IktIkRo8cZvnUrokSzOoA+RH2QkdtNGNP4KEeEikhhnhJaNW/w+XNx5rAYWQoS2Wq9f8xxWf/R6VjBkFs93cSlN0z1Wm0hGzh/nwzP3SBZnYOF6/yLI0xf5MoV8L+b62sQQL6soCfz5lnU0vx+Dby0cu6a8uHoIl3CEdesw0J45nhxPcnM0x1mOFqX1Ww5W1jy42FO+TpYnmWm19SBuJ890VixkgubqB9P8TA47iUUqOv3jEIPDecU5hm1qR3Xg4ux7C3E1fq1zcByMoF1wOGpmG8qH+RYtZ5e0p/2yMlgG8w8aFsiRvJLKQt4B0w3J3vLvZza2SHJO5WxJ3WxH49boGx1jlMH1WM5hHZaH41/vcJf0eovEQ0T6T4pDA0Im3tFN/CYVz0y5k1VtVSCw33OFg2q1SXhHibSLG4QmH8gkRMQFAE6jtL49ig4SrsSgbuDG/d0KM3Ofj5aTP+sTzzhyLj5W17uptZjYyL1pnlcDCcE7Engvhq/hyen7IZvIDbIGVscvvr0LgNG01Bx9hTAGoGmDpZLs8ZptKl4vN7Pt7HH2xWzFG1ly8yAPECDYvFob2rRtU7zl2TT9PEPIbP3z/z2+UsDuHpJDkODigZutANkIsJTMQb5IioaFAmvf2OoQv5N7Vy6suo0vNHvX/h5lbQ5oUIj7ydIqNrEkXT5KwY11VNYePKJWvddpQs3WMYwHBf1o8fjnp3ZTWIfiONUsA+3UDtDo7frdkc56Ayy5VUvxY+hyM1tAtpryLhFgVMOC/rLYuKED9mKeqnxB3SmAI3vUm36ysojWdEpUux+sMylKlSS4EYEY8JFwiy2cne9tV7rzEfPjUAf2dxQe/2B1wxMjlkjcRZFbBbNUhczjLJoQGURCdzjTUmrL2GiDmBroqDsrHApCcC6F175Wdwq9HW+ow3U9yTqQjQG4HQREM6qupgiwSN12qW57Qic3in1A/JH4Ic69zGdYWwV4MlgQ0J7s0PcT3PePn87roFqNqVD1duAu5sC9DMRMX+40lhvaSnLR6JqyYYydQJ7irVhjA29GrbPfEUaRXcGXCVelRZfHmRKtKXVq9Gwmywm1CLAkW3QuZkWOsyiPOAJGxN3AUiN2CpDW77eFRDYCSAnrB67UP8Nfv2RkowxBc9vxZsvxMQTGH7JVYEaGvYcYQ6LishxUcj3qQ3uoyWCjR3sBgPbxAlJlRz0OhBWsToVHYkZcAsCm8MH9b118WMuXRzPZUD29+0zETJ4zup+wxOs3AoVSdakGby8fwO2cBSaHPzax7090esTBERCpVlDzbLulvGnNzNSIlbY/IGx+AB6G9S6FRammyyLprYrtjUKwcxs3vqHCjTeDRMFDLaTdmnNP1rM14Jr/hkKKVQAB2vef8zJa7k4uzMJ0sy2QjKjasAeArsb9KF6OOrjZ+Z/fcFvSZnrzUl/opYBuL4aYKMD+Itg04otTSCCKG6ZaDV+b3yQ6KDoDMOwMU9aGjuPXXjTFvMEXGi7/UMEbII/BohTy1kJL19wFXAC42i6aM4AoWGjdMXTaoq3FA9cbbGVwbR3wWigaEtC0Y6L7gYWttoWn3QLEJjI5RMROYhqDyJG2SxR3Rc+Kaf0XaZhIXx6EVhUfBV+VvEtcxh12kYpt9njOFbToqD1PxPAVqlpm1I9LEBXOgOu/iDRk5YBAzJOnYjvfqzjgwPk6ZmeOKJuZnHnswTTyO1+5Ngf5DCSMM4IaEJ/x+wIWe/4MLL7TItiW/UDUXm/kwWQ7DLgwjccz3dQWa2QCOt8sbWPUVVFu2oE+3aszCal54Ru/eb45mpsUxuiGBAJtLFDhLs1lUQfjRsMAi2qljYjTqnAlVdzEnyoNMAT6O5+b51pdfLFhCBM4n2oVAbjeT6HA50AsYtFHBj424StXsJGiivqUuT1itwfLf2JCcepqOhIxR39gxiSmVXg5U1jZz5RF/fuMVkbfNM+w7nDwjQLFGI5gRxSY3heLVCmw2BCwCeGDbnOBG9KCkbV7eN90XDjnCqcoaG5Au2ur1kRUtzbp8VaKXpSLusxCH4vqECGP5C1UGdRX1f7nuV2UMmvLYnPGMPP/qCII/m3x+tqxD8A57IjYKxiKDxE6hzA/mVj8zSPiKwnkNKOEv3bMvP4ADoAtjPrR03T5wXndOsI363qBeuM98qaYSKrO3e+ZLY5gLE89esIpAE5VLYwd7/D8N4bjgTDnzGLiZylMzPgqOBwYFzjzQgqjGqdP3/+XMxrXmN8UsXk3k3OZ5cxk0+kRqbLbqpeNRnlaiydINjmA/8t99n271Vaizlu57zuuevXaVFPVT2JfYeoEwlYHw/9jOpZBXxnsylgadC50NNHkNlx0IOBwvf4mIJNZZit68509KYz6f7gP6gm35InlxBvqE9PiN9g14Dq0eypxKRGoiaXACFBG/I6JyMXKc6hGKiBAFstKBcae3f9pPHjD5JSDIpufLh/uYWw7unPe4U6mNZID3H6u3O7QoEk/3imPI5bYe8a4gt3W8crrXI9FZFA0xRi1giTMv7CJSLvOS+2owXzEo9CaQGWGRkfmTSmZsSSdkJBRyYSOUqhstdc3lLRpO3m9gaFD8CHs8FyktQPTct1g09jJgjzgILgdRTHg24lBZxfgJWOvYWL1fb5q9GbW6BleUw7EkEorMZaJoxbTVJV2E+2BQw7rqSC+h8A0Xa5jnBmCpe1IhgSaqu9tzSmDWl5DDbVqUFATMxq1NjuJ28kTmOQTTPIJT3CGid7bdt/w4nMbbhn6dbs+ue/I9oHZSBS/czBX8a7g2N62CEArb6GVt7iFMFptkexsgUW+wCJf8AJXWPDzbxzgwKlcq80u4KwPOSTFqQooYJe0AMDOMHZtZt3mjPq6mYSEHy1ABjbId6TeqYYMw2EQ6qAYxqmWIIMgk7symmlN7AcmrYScXWgKG0nPHptgeNpvDBDmoJTNAeBAy6WBwlDDCWd4SDBaXGLvw0JPdG8SDnE3ctmt/seLZ5OkLgQwtflc4UjMJFg2KZQkdhlJTPsaL/VSbsLgqNQYIg++BJum5dTCElNKwBMu7xQ9HcUdMKEJoUITDzjXi/Y9tc1FBwyEkgIozS0y2bwdmy2R0vlsxBAWz0rKMgPkRTS8gDDI7hRAjFkPHQFR6XMpUYQwGWth2XP7KiYyLlWAKycgdtYdEc2icJHjYzaO5EpkjzXz2KmadjoWHGzg6FPRfAKgyYhTqe4Y0p3sof4PN6TGU7i+O4X30O7BEYp/ZFcZtZ4NfGQl/xSBAFX3wLWPoerAjyG6goBP08xJaD3F41F2rmemXmdGbB7/pkcpzHvm491Xsfz/9mlM3Tfnnx61yha/q1+UOnBE+/RtAz5ce6Sq/Rff4+3v1NMbnof35jwRdRRxlIgC9BEsKVx1xduhdmqZbbaQRP777nxv700BSRUaWc89nwemnnu2uaQXmzBhyV8rP8u/8xtfbdfO3NaSua274pq3Md16kNIe8EFVYONnISo7wBEgsolPB11ucPS5gvqcmIjN52yktb47uXftzh2dEaW2ewDwqu8cxXbl9YO1LY1pmK5Eahmf7oAXf3GtzlaBGK3TiCg3plNd01o0snUsgQ9hW3wiEJwoKnMmAZObeVK+NHYUXqrDUvCqHhG83EO5Yb13XuLQVuAfDIlTz14IUPn+zFRFWVmjpqBhqBhe+sFgYYOXq1OSLyadnqzd1gJxptjIqLYCb9wyYKEUR8B3jk5f3W5lAVTy1NOz8kZPSZ06DryK2pwh69bNukSGZg5OhFRkhSESH/ScpykOUSCxMlyEElYyWya5ggzHEprun8rSm5tERrv/vPBXhPoXPreDeLVY46rWLPn64HgPzd14tU7SaSmWVViY2ZYvPIoyqwd0YiSUkqpLXwlcz6FhFKOf1yk3U1IlVXRsIjALhEd30fwTYxI96GZlgduJp5ByA7UWh0f1q+6yTa7yhquoxzX2zLKbN7IyqzRRKiwGpQYyAaFbXbgAwBL+lVif3jZEye6E4QKhjHA5QMGxMpbIkXRpr7Lnptv31Q68lN4dqt3qZpdUo04igTjznNFR+gIxgiLEY703nfZq3u3sJaXjjREceolk19VgM41Lxq5wwshGvFofgiOx7TCVG1sGttjNtXyigdaKOP6QYxyb98PFLH+iszn3ll6aG+IRj8MnWMooNT6ykIVVuTw5M3AOF9wmbzTKR+9x8EgeDj2z9S7wOuzOPsx2XBz3Bgy8mNxbxOk676fQjnuXqr4+KVrQOExN34t8vsrkMJFzMRkV0UkhcSkyDStcRJQyA+6VGNLJ3Ncm+TxIOOEittF3aEmghLoO6fXHDqpJDPWiZleRCxuoaF5JaEGUh2J/XBpaHQyuE9EY/VUuPaaLYk9FYQMW06mDsmTNjamlKJa77IsaR0YDikpiWkNuIHvs40fOEBJTh4PXANiCulFWTYL9CQzCkBKATN64EHZo+qFrnDVowVtTAIZpzC7rvS/XJoeJkNB0F9wPP6xyG7I/nvKr7sGs1s1MQHRc+4iXSeHmPMjWdgMcr6SPTUSy+LxukcAoMnzYcUvEMdQdXmiId20Fwf4oPg2DSvri0p6P0Lgq7ZGwDQtvKyxLih6ctMhWZoq4mqrpXRSJU0UwassC0LV5XKyJxE5qHDNkeqK6gP1Cjbm4GeYZC1trLnK9Th+ECFodce3wOKVGXKjBkRfWhsiQKBOaERrXetAWjlLZHmsayzJkPU7jXiLoonEX8M0jKtjJijTZ2hFEkz4G1Pc/IWdpEFjemyB/LckTJT5SNPUtLuFguQLvit2Jt5G0vZpA6ge9oAHWhpJLyEYcaRzT4wOoq1V4srP3QLt2XQTb2SKRJn27BawjYAc6EjCuH1/QeR0jsYyIOPEldNJJX4p3qJ0uMMBvOBaFy4aFmMBD8svsefYVryXppFhkfj10YveWj/Mhe4VXeCUxYuFVfJSsIJPajAqAHNOUps56I6uc5MhhCqFAVC4urevZ7GV2b576iGYLLLBwftn26S088ZMOCRfhYz2IvgEFf0VSmLY7bFt7QGhhOeJe1a4dq5x8zQMJlYjEI4azM2QsAgCoQNQ6PR+va0jBQo0KQ6lDcoqB72IUQELpR1MEBc1/fF6Mr6FQABGPE4mssdmTCjO1/0s9UzqlJBBWZHMjYk6tAi8k1461mtQ94aEaxk2SwobikeClJ//wbVslEoKsCte6apKPS9DVaKCm2lNk2+3Xl6KA8spoVt9gsLjgRI9PWQCj2ryi/1I9bIchHB6ieTflhS+OBcuQMpqm2dAq/k2Dr9ZYRyC2MhpOQRqYjEYhiXkoBAnBn5iXtn0KaMPQHMI8RIjQ/nexrZKzZLWfeA4791gtoEAnbfXUcXWjcqsBzqEcApRDDIFmscwRuVcKWv+Nrs1JgbXFjWjCBXu37JXsKqSO06Kac9UNchnbrc461sHfvuxYPGuBN7zmVE8H1qfqy3gbZrU/NrAYyS7nhE9Z3HcfdLm0c9J3AOxaZ8zh5A4cdsDDYT0qahOULQBQXCfP1+7LPlhlEqzgmc2MRFigesoijIOygSyXiYbthHJeXTixUGdDutq0pTi2kbvTn7gkbOLqXxJkx/StdzTPRXeiumc0/iei8t9u1146y0+5Ts2bVWgj28DKnXwcMRcqMKwknWh9k8HN3SV3+HWnxI51fjJarliHZVE31ixcy6psYCm/kz3aktYXt9n8GcMip3zczOUqXgS7ewkh5A0qg+MOG/a90aldiDPVb+RZ8+7aFNcBI1B2Mn1JpwlsM8AwvWPxxa5VWXJOKgEAR7xnoiZdvr28fgs4GwRgAYAakyHIqUSu+RMoyUbudZdOYosyQAGZOiWtvlTAZHypEGUczmiZOIN+B7dA6p5v/eEG/naAR818f9fUDNhya93SdlBk77fTi+5FrTJ97s8jbGZLEoZFnUvezINNoytH/751pIhl7/gdLhNlOSx5dOUaOgQ/GrAfRoUeaTKcfEfTbBp11+E0SieIcdvBHsqOGgRQGeW/3mmFb+zI/+gtsPivg3vHJIzb96chTAn380IHQLbkJR4SZQuisKFDIOgB4Ni0aGRX/ezvJpgfJuKDonqEYb/aDuGEp7zXsdIwcEWk/BiBK4Ah0EwzVizbuysgbQWlfJsHhxoIRj1tkQCHqmlFiFKA3j4huhEscJsRAAaxr8tS+fRy/pWBW2S92VUvKVM3dZTh2WyJKzlYLuL2QFDxSfae3+NqEbOf+efwnnfKY/cehsfJ9o4IRwA1dzfPmrm3tcJ0TRdNPeuTzEBWfS0JzdmxfdjP/DL7gX/I3mT/8X/8QyyakHUG8r8yuDjC+s0JjosQIbw3GQBi6gL2O/+5qi+Id/EZn8U78MI3VgIUguI9mpTXZiSW46heEnEydiXMwcbA9AQUuH8zZtSUxuAkWjm8Kk81FEmeaBt9ySY8+UCcW9XnnxwAUcHZdRuBQKSQ3mBOPfSGrO+bDCm9eT6DiwYDEbZn9D3CM1yyv5st1uyKrx44qZI57EBPtJ8ENVj/1k2IL64GaiLBNVlOQ7AL/NLRpWWOJWxzd8qhdToDY8BUXU+MCjFw5a2GVpE98EMWZn/yn3uXsnbDKlnIIYaJ9pOgBuvfugnxxXKgJlieLKchXAtk7EfbWUxDjpvvWC6Jp/413nLg/vaotTh4V8E9q5weNE5LgUOzQjO753ucLWJ2xmdnD8TEdDsigD3717Qtr3Sc7tkXty7j8b70EEQrlbo33gbdRyGF4c3ITLtFaBj7fgzU3fOOnQmG6GdJDx5Oz1L2OgLUXvVTcH6swS7mCZ+g5+eKW8H5x/aDH0916k/NC+4GmDnsD+EN9TYAoveH3jej+QzHeEtsqX8j+omIOKc+z6UwkmmZUXMBGDjMHfi3Bg4ergxpXD5d1PHpr3zTyQRLF0Z0RPNzhA/vGBelebEcevYGQ6C2MJzRTNg8AAPgQ+FzF4TdsOOTKWuN62Vim4T3E1jwOYDrz53ejF4Z+t4PIcTXFgI4FGA65mFribc5h/UhPFMujbvLJ0ZCklVrvKuSDxye9SMRA8J7DyJbbrmbFAECdseppXyBG/W8m9ioR2gk6dddhruS94hO8hxZmkwmOpJy6R9gXJ5TyXSOzfs6ZVDO2YVt8Rcq2vY09ASmzkLd2Vlf0PWTLOs2j0vF3BnDYrYM4QBo5nwfA5D1rlvpx0fs77IjOC1dRPrSXS201LgCEKXDfhxIIz+EAk46BX5tLjAMELl183GdQfJ+GSeJcomTWo9DOqms3o611kWXfJ6AAWmvN8mZHECyixA8SWVk7kryUvZ3Z/wgUTkrZJKQ1ethO0nacYASTpITsh+7LGf/7IqvXFYexPyIl6uXl37zwLuLXbrvi26ShXrh98SopHi/54n/jaTi2SRgcwld++522ZxJ6GxkPT4FAuy0stMcfKwIxKPDtrLoqHXL/rW0yNb3KImI3uSQG1DyvGwCGVDdN6J4dYnCNwtBMZv9MblsJbYWF1dSxzqIUpBOxbNTqRDCSlg4+zpCuLWks+QsaeBlZ3TLJPHzBvlhGWQUsnTGDR6bRtGQAgypVGASlGh84w3AocA7NGaVGPgiEKwmKaLCQ+Sc4ezrZtj6LDm7EJUpd39dgp1avALvCmNGCyppb5nWT+5S7Uov2+Ry/NSBsEpC9OTqwQA1C5N/aCtkKDk1QcIONl+psjVXYW3LwSg3yQ9mfZ/SJnF6KzkRBBeQSustL0HcBS9dXH71sS4OofaEICkTRUQXXJIH5vSSdxHN7d1Di2b6dRDlMSOsBNLEahwVpyeA2auJsW3N5QCk5B64MGwIzyWJanQHVEpBHqRYaft7kpMJMhtdZnllDEASSdqF6Fp7sLBxGsn1XJPlSdkpOI2A0BGypnEgvTwGYK1gR5qmAEpPoHh6edcUQvR4WmTuGMl7Z3cOXsNx7+zjLlVG8Wp5gGUcKyP1qHjbQlx5enPW25vqIRu7ftWpl3D7QX4iM4R7oSaOlsLjIxduGMtlihgD7Dez+DZvCG/h2cIsmnuAGLpvwMv1MkMH97VY8cIjsd6yIIBK+rnqyZi1o7l3UKh2cl/7xvGN1fx52HCEmc6zZ9pkm201KTuoAGcOSoclwCaU5fKgtIHFt+Y6Jk4aTb5hsXJSmMG8aT5EKaiw8WG857/IzjczLp04C1AgDOE4Z4th4XPFSt+wV0rhrZEo209JfM09CJ5A9G3RfBotvELRUzXQpPPVnY/QBfz5aLbyP+ajoMVLce9ayE3oN1e0/PVwqzJ6NRcfkLhf8QmDTz93jNDZn9PpBrjMz3KOO2CHrQhK5scavqIVpKs0cacyQ3/j5GJ+Yu3k3vWj65xCgUKDVP8d8OKTjfOlaMazRDgGUMfkNx4l3vu0ETMkVh8dO0CkkTWl4W00bASNq9lvFsbN+JswE2WqTGfT20PYwgkb0eBfg5U4BRnCu7Cek8WsBWkPtb8jl1kXuhQugU32FHQhuxA3XocApuob4Kp/ODSu9E1VBCZaafrSmTOlM2uKz+c7W1sVc+2C38pOiZ98as3S/8Q2Owj7OfIgE9uCyu26mS3vW6YqBBxFZWAwI7b4OY7i5bXt0rN+r2lkjw/Q/HPqmwf+IBDzch5YifAYT2Mz+gUeL6DwFZRGEmnr2a/yOSXSFJojs+r/TBouxTpq9vrMr8Tji8lhO1OFZDipuL58qA5wFeIBsifiJKGrMWUj27UoeZoMWG3EH0R3+ykpajeMoPjQkU9XN4rKDg5d3IrcriwtWdlf2HQRg7UUOIohT0CiYhxQNWNYWyzcMAqSi/hVZ9Z0hX/kLTwm73eQTMLe9jz0Q2J2DHcz7GF61HMk/JcwIMxhPPADXO1KtKOBG45pmX4LJY74CHv3XsB2b8dsmW1KTM1nTo8IZ4wAeu1IWsra3h3u6vaDwF3M3PQpswh5e+JFY8TeezhQR667cB7iJusXz3Nj/QEO08tpqm+wMCTLLW9aOB5x6bGE4XLCaUatq/858UsT76FCkh7eIMCmyWAb/L4XEPxiEvR6TwQchr0SRXr8yZ0PvE/rbPneB56stDZ2qUszrwb5OQMqDVsJ04lOXQlPf7NMYjAx4XWpsKCFJVJ0QSrPT5aGyDWqAEd38BlTN8m8CKgrXLjqPJbuDWHub/joLikxG43N9K/d4wUq+joolxxyn3/9db1KZcuirlT6uxq1VFpXWY3U00jLOb022gVHIwzDYUY8xuHx65xZec6YRpitvNlPLjdfOnYblXXvP0+2BKiBkDIo6Wr0lKshH380wiwgrPqt7df9xlgsXH10UVteWB+tpRe6m0cGMlHBKUHCcBbkjlLdBnF/9nrosSi6kb2PAbA8ha6mpc3d4gm99ksA+gYeyRQ8AxDr+VBNOYiAZEhFviKB3SCVYWldXpRTr51jChJT5QsjGs00jGkOjGuGf12Qlje49ULmXsqBoBhUJNZ/JYE2gA3fr49XtOwv2d38HxL/3Ru/XxsoXfngt8W2em2k9m0A7XiFo1GWLzwuLpwaCS5w78u4HbeSfyUf31JgiXekhtpuhGSpefNsV/y4bh+lPC0Pa3klLmLLhyBV2NQ5BRGr/GH0c2YG7ygttSEQc3n7R26FnENGGgkCTTfJAtPX4FrWz9f6V2GfgCGqBsdWnnEYFRbrhBp88OacfaLW3Bcm11dWbQjP1BXk3yIph7SiBSVHpGVGVpm6ggKpmHKC9i/kdc5fyADus/0oTn4iIybQqv96bahsh/KatcozrC2o7ZsMbvU6piodwBmpfaj8mt3lFTbJmkiFBFQ3SAa8IwDSP9dAFvKuA84VAS2AjC4Jmu3RWgP7YNx6tc+tA/zQkktimKysskO4OGj3Z0azarHUVW/xCOx1zvzqmVv8f05Q+NK2AgjladbANijs86Cx34Utc7Xa6fOQvbSbKiSytBaMqRv9MnxY4g0oYkktAq80XirykcMFUChwg2UslSrIkuyLeQDpAC5qU7U63VFknZtfjjSoQJ0zmLaCfRXCgzpUsaaEaiAHOMz50lksGlA435Fax2aC9vaFCWN4nzXv4fFWW++zre4/L/nPsmdFAbvIafpwwL23PLXb6Whd2xnOoXxUjnMImDHb8AGES0qVDzxVV8HZf1P3yEL1l7Cf/V4dOdAD2yLfa6Dyq4ZZlIG7fRAoqD2HLehBqyncKKe5OqCTqXJR6D2I6V+166232PuI3QwYacXi/oYH0+oaPluBl5y2nLdf4dPVH1XVeBbuN7cQUaxwitgtyBAuz+pRDIcICMUw+oGjGgWcMLRjDcBgbzhXPndQAwRMSoawywkVm7oYVRaNk1gD++EKDGBjUlvqOFCx+Bv0Atq7Gh/2YS1ZWk5Y8C3ev782obFbcJ5B73IIAHOkbjvqBPzdwviT6o7E4W8Gx4i/Ugfu5uj3F5gdUeGVDeFJoC1c3gz7f8P4kZ+Z++mZ7ng1GPwqWUGlqdKbUwx9GsHsp9IXS+DTVIl4FTMm+hx8LnfzU23p3eFDlQUNBATkLp76k95OzFVswqXCoXseND5l76A98c8QCkCMZrY3FTQ4F2IXVORUf3RfIGA1/8g+oTrZwBo3fBhf/g31Jx3TeMersrKzumtUJc3ovNzbzux478X/ReteNgXSUy5Oa10qa309FfCZ84udtsWLbfcqy0e9Q1AWeCPRXBo7r9P4Y5StmOcj8C7Y8kpk70rrfAjmB/bNNm29iw0tTPsP5Qa6lEL1IzDUPcOcu6D3Ya6G31Axsa4ZJoks0ISJzIHBv+d3xT088EGKXQ9AwCqPVXmUT9z1wr9Xe+O17L4R5kvApOpYY9pZOTYBNi/AYa8bdz4O+/Ge/wZUPoKO7OLo6z3uJCSHO/8UQgKtbNypXy9R/V23cB0c3vJ81j3cei8vviAbPtUsPF01Yf2dY9XKHza4l0HT5z93DW+X64GjLogyrh5w1rMrD4lPMhh3P32ODfEMx9hc1LSBQUa3EMMPvjIDr9Q4fM8i4yZd29xPtHVpROp5c5AGb68PB0xENIwBO0v4w27dLZMem16VuX9AYJ+m/gVbsFM++HvFY/OAANT+1dUPrbVzK6TlP8QliK8AfPH7upkB4KvPh3/bVW7W9cj3ugAMAwOAgLTEGQQm1VDbgHJUaP4TVExwBAO8P39/Pp3LKhlh/iUFNsZQDLQeQY8NGVz1/vqKqQN059kKk7ZkcJx3NO8vsO4kyOFLkS2A49xnO4OmE0EgX+VsmG38TIjDakdQnD+CPHtYhf3zUukLRh9XzT1WxjHN0S0BsgE6yOOY5GihQC4vzDQHnTapLTd2M18WbL/zEDC/nIVQ8jkZt5j1dbo8iaA0mLU9hc8th6D9VVD4XEj5OvFzl+dAyteZqkX0jiRfPGNTBIKF1H9YC/FCdE45EpYLu02E0aUARIn70VJQzfG/h4n9zXG+hs5p1lL+dTiscfrjDbMWcPt068vycj9BjySOcur+haCQmVON/TBH935yQfR7mXjkiJESu008MjbpdSYYqEcks1hYs9o83iceP7TdmG8FMTxnVcMhaeN4daF9MouAIb6i8Vy5X/mb0dL+RLj8Fag+hRYl+rt4jsc4+n3dx9h9JL4+3BVj4rCPi+tQ3kHwnUGXZ8HGCASRZTJWytEorUvbo/u+AV22nVVFsImQKhm1cjRKMB+i9VnCEN3vM1euCOYdQo//LsOFyi05qGFOaknFkDyIQY4SCLt8C6u3wyHCPs3xeY8PT7I+7j7AAugRxZoIYtOmFBGTZvtT1B6zIOnHvQZYgPMeUTyDIDYPhUdMHhWhCqSN+YrkDqSNUWEBkMbgcg/e9O3g0Tp3afQJPU/cDGHtc2OPBzwC1s8A4Lk+q4EzJAYQjCAdVkqBDVu5OSN9XxcGgQ0xlIBpPgjTerCsxR8ZYo3HhZNbFs22KAQ6geF7FacTq8xgRGKmgeb7Hz0b16skYRbz7ssO3RABPx9pT9SvYyEK/Eo+3HSLWcVZFkoefkxza+n7Fud2L+6gX/WHm26wIBERJFf0CmUMcYw4/FPYSTXmF54sSWdZnG6x1FWY8cUBvvJeo+WQNQeuoYwBTtnAkf+7Pz2Pu2Q6AF8fEzB8fltxZrH0+VeZJikUrQLyYA2XAhqc+TfS6aGO9vuhcoZxP6Ai/zRaniADPp8M0APy7/AROKD8GzZMV69zxvETT9SYJ2pEaoIcbSp5WrFLR+LcYqDSb6xOUIWpLg/JefBxmTmicuR3fVSgiBY8Byzl0XCs1tLLbX8ePYFxfIcPldGbyV0UE8KiSQwmCIgSZMh/INzqFs5sOyUlADadwvA4xCo6Hofh8exxBNvciSTDj6PQ4tzjGJhiSngQSEmp+PbI+aypHPji3tIbT75Vt+yFvDfyKSFPu7f3sT7fiGNs4r2FH5249dGLjqVbd964Jzmx8MEbjk/eexBaWHKRT8XZUlQylULdyi1WmVLdyg+DqiffLXJbEXkwXaGGaGoomCJd83/2UxboU3b8lIq4xQ3UgBBk2anMRd4fkRSavjhkYXBBvm/koSSvNsxQDzDz07VxxjdfKycsxpqYuCjo9bEWL5leBKupltoWhYjDYcaLvuJCu4QvKCNMixrGNcRQCRINM/zL/TV3jPp0/2vF+z7woY/oF7UUU50LFpkZcWDUFlqEXiBlMAejC1iiq8fB/9FGBQNpJvIwivwSWOfQ0i/HARSDMtzgo46RMQb+lA+bGDDjX7oDz2WwWEkPk6ElT4jgCarCnhBkD8Jk1VUjOmi0cKbZXzsda8Zio1C0hi7iDEtTEYWooyAYSEVhibU/iA4I4gT5H+JwAzgY0Wn4g8P7NPyhEXAQteFFkByUu1INEVOBqRC1sT0lBVQnlmS+4OkaE6WVXkaZZZUth1Cjih0QY4OLyd/Zm2jRK6iwooor4QEo5eQAWsMYMOzaIJ+QVv72OtRPsDt2r++BjKBjmfduIKgAMgbw5g2yyrNukTcZNkVGmz9TLo8RUmm6YVq243o+t2zhuJ4fhFGcpFlelFU9mzdt1w+L5Wo9bra7/eF4OsNtQkJueBkAhWpBMVwFQKl+bmQ5XhAlWVE13TAt23E9H3YTEnrDKwLoVMu67YIACjezGE6QFM2wHC+Ikqyomm6Ylu14BN5f/CCM4iTN8qKs6ubxfL0/39+/7fphnOZl3fYDJ6ACbWmG5VLF205RNf35rENdwsB0BmEUJ2mWF2VVN23XD+M0LyucxnmSLrqBMe+P5+v9AQ40pD1FYr+8Q5AkSZEMkkmySCWSTXJImuSSPFKZVIGGgQXAwSMAEfk5sGimSmiUKlOuQiUtHT0DIxMziypW1WzslJ/dc3Hz8PKpUcsvICjkThi/XoNGTZpFtMAIaJtsgcZ9C6t2SOrUtfa9+vQbMKgBdlrhGdXBuAmTpjgGwXfcdc99koHkola6H3cnL+otM6APeAZNfvwFLHhzaSgfQYpQKzlFk9hIfJdMlCTZY0uzaBQ0FzpLC1KK0xB0yUPksXPrPPUMaOtv1MRfiGxF2l5Vpy7dXnvjrXfeS239n30h6Vp9r3nYiFHWUm/GYbqksST6F+Ur6MXIYlQxuhhTjOWWLRzX84MwipM0y4uyqmfzpu36YbFcrcfNdrc/HE/ny9399eHx9uz5env/+Pz6/vmFYATFcIKkaIbleEGUZEXVdMO0bMf1/CCM4iTN8qKs6qbt+mGc5mXddhCCERTDCZKiGZbjBVGSFVXTDdOyHdfzgzCKkzTLi7Kqm8fz9f58f/+264dxmpd12w+cICmaYTleECVZUTXdMC3bcT0/CKM4SbO8KKu6abt+GKd5Wbf9dL5cb/fH8/X+fP/RssgVKlKGqRHLdlyP94hR1QN2S4DTe6q0d6S7pBYC+bfKtipYATRhN+av6+9zoew/h20znbV+OFvuWiEVdPoK7zs0cLxfLmV8BYYTqUAwHuZ72eVn6H+jLj+Ho0OXuv8chYDMfq/h05w6D4wCxGt3xM+Y4X+ckbuZWEwIKffCJiX6ofdM6RR3DvMsFHwP9VLIKONMMl3h3xRwWJVQzpN79cl5nna8VmXfgYQVvxo5nt+01hwbstV+AU0zmLHRhMyC7Dodntu7dYFF5eDm18WyfJUOBm2mWf0TD7IhtYnyHcpaYOfoG3aichj7F1eBu6VdbrAJBDBqrSqcOxxEQFTacMAALJBlMcPYBkMMnXUcYF88/Hsggk+pFzJpOJrCnlKAAJMPDQFyBCGTTA0VG4gJPccBN2nY16jCBccOYipBa1tx5BnMiCkGblnh3BEQleaVHRiScDgcvnwnfljEZVCq3S+BIFAAhpf8ydQPEJmKp43fUkimxENND8lBCcRwItJjyCqTj33tIeWd+QmHQiaZZjCjFeja56msX2Aor2lwaKzu4841CJsxMXhKjCEi6fOz3tqlo+NJ9ftcl4bQIxAdQTCqcBC11/6avCWlNusinpZ8RoYIPNHuVGcWWWYuXWiBLFPWAI/ptajYQE+SwBKWEsBQ5YBkKAEWk5Q65uwHD1VDKfs7LMXCQa1CggtDnHafnAQuCAyBnrAvgHTB2blzjX2J3bE3z2LmzGyEgOzBPSnxDMwdOgBAuFLvFk8TYQ8JClQBN5zxYpcYSMg4k0wBT1dYV1qxpVJ3MXKqmXN/oNK/VZmYQXBLC8oYVM91GomqYyhtt2phWVm0bk9NCcXwojoNfcjG4j5/U1Qqs4Yva8wRcp736LUAowoYTGnKgykOIoxHFpZIlMcYlNH+8BzKkyC45xm31DrsqzYHeAr7jgoXHEGZqT16vFA8rnXsqHDB4SCCFbmOQE1pIfAVBgGavH8mdlQclZnao+cL1qFqN2yocMERlM7Yg7Hicwkc6bG+LJJ6hEIjkJi0s58+BfBSRu5LwnvqfIbjuJghlB6dRTQW5tiqCyOsAlA8oCBEh+ZMTOKm6yuEUgdJYVpVjUkzerGD1pRt9rpKCNySQIxaqwoXHA4iAO0INYWC0RgAWSpLAkH7HqHiKDGaS9rHJ5vjiJ4A8ZpjU4QrbTbUtsrCCjpZS52oVeFZaDTBW+oMW+ac4l4goHmjUO1GCPzisHFiwhAo3Ph9StcDdIjSDmWoqQmjXZnDWdLB8t52n6d05wFTin1taCGbmK7X0kvHx3aOt660DEvV/lHIJjbzqMz7BHHElCxVHIVsbNnkycxyleUenhDNNVLVVQJOv5+rcB1Adh0lJdUCgzvNhitDCLoNAq57CI0rj5TfROOfCQcR9hXlXJEWxHgvKRRnjh0VezodcC2FEI5d8I5wVBXse8FQnDkcDKFix6EjFywIAXii3ZY609BRnIWfBNYAKjZsoHswuFyz1soqpGyySOfOWDD4seKpWLIv1yXYoQPf7HeDK6OMTWglhfP0CFYoKK3Q3CyDU7SmDHGw0AnCrTUoRxAyNiEm75xwEEFppWIDgYAkah8JnXhnxKn2EAmwxDTVnh6wMHLnL5faCA6HgwhCxibE5FxLjwFSKoO9XNXu0MmhlEFVHlvZoOKYTAMO/6S9mClVrshDE263NFlsF6KLy52BRSfvgRBBMBCTC4PItOJYcRg7vBcQTLnbJfnMToXWNee1Z4m89VXXhXqU+xHM0li8Axp6qoRd73qipZnmYRbfwYIXLL35o2COWhFrajPsaDnHA/OmwUOGqDZJknJF+mQ7mTfqd70igCBw0sVQumQu3SDxhMX6RO41zKdw9x8gIVC5Hd3cB5rrgNsk1ratBp2HHAUb5TyidKjqdS5lVQpVk5nQqAmsXOgIRd646ZVkDSs3TBQOlCZOuTeQDMg7nVCcf59YLnczNrmlPiTTqOK4lFkTUw5a24qjADhCVweHcwlP2lTm8Hh2sLayVO4XVUA54J9XfKDmma+c5UOwGF4Lv7Mzyyw1sM4z8/hhePUibq9zfFb6JTa4G/b172Sz/B0HL3Eip26567rLkWWoa6fansODzBEysOUPUrVwxfLziqUq8Du+wlO5R/q4EevWId2HGToZ1nGND+gdRBRfSgR6VV743tN13DKm0TpOt1YlsA+NH4oZ1eodPL3IUK5um/hyXNHm3K+eGbJJRcVKntlY6bKiWv7dLXvcD/yhYhJQkQa8LvrSd35rXvX+J7B+tJdzJgF/jI+WGUp6aVwztXK/i/GVz/OHCySggtNFSlepmzshq8xa6dZN/fTn+Xjwv64fp4tZ60/LZ9VC9I7rBumK2vac0A2jSQvWneMr2z7T/Y77MGhRH2y1Si8DhmGURo0atVJERETXgQ50oD0NMMAAvWbNGvVpICPDmAwxBA7EkQnFLCNjYh6e+ao2eXF/Zwv0oW1Nx9p+mlpH7FFH5aVbzPSd4ERiN6HAtYRx0wjuSLg16KRSpt7fWehrSGrdo38/+iyaLo6l+O7Ca7N5Ikep//VMrPzi8PEWhWAjX0vlD/9UJZzAJiy7eahyOUi9I/ZIpOuujds2ef2Qt+2Rez7vbzbXD32b/b/eIwUmk6wWPdzMbBJKqAfNeW2oqYGyXpisqRSY45Rugx70gIOH0BIYxkws6kCk4BD7DGBa6fuJLm/1ci18/6BeSLb61nS/3+28u7/wp22f2gXYsOQoaB72ocmXOy2NhdL6IvHW0KLGz92SA4uTuxQ9ccDK2AkCCknvVvoB+3o/b1NpU70jQcqBOPJ+kUYCc0ASqNU0Ki/Ti5n+h743/KpT7fcFBtS9hEM+tzKpZx9m3bo/PZ3ePtvWp9u+xP2cxYbis+fynbtcX/ZNLZTelOFAHMt6dOJzB26wPd4V80P5XWXuu+4fmEe7Vr58vPLUAqpGw/9fzSP/2oFHk8rn3cnKJmmP9FNNJU0Hs9Cu9no61psthM1P5ctkovIEBA16ADDlMCZuAyJgMAl2iH29r/d1cJpIIHUlELcRbQyx/ZwbVV+JguEcWF/U8cSrx+miJyyPLfdR9FZGWiWv9PbLI3zpj9gvYGBLtMLL6yP5edKz+ksxQonc2sgDD/qRLflm5bs+lZdX7ESOMr4XGZ4nSXhFcZnA4oU4yYZXLd6LCI8osxkHltvfcvNstur9oLJVIb34UPiShnAurD6pZv9H54vbHT+o9V/418W5kKPnOp+U4ykWTrzzw3ym3HgcPsPJsh3iAN5lpkO4IDAECsDwki8LMLBw8AiIQFDiBflG/Wbhup7vzO37KZWSpeW9or9lV1C4ooycfRvPV1NfjW/7w37fW68SOAwHFwRGY7B4yOcSSq8JMIV3e4UXw3+bm6wUyJL4VZAyy2bD53HMJ/ubWzjZsivuKuLlhBHXbk1rTiOMsxl7PBc+/r/f/07pdPleUGn8DGVPXz+zMGKzyKb3O712EDtMy3tH8WWHQa9Qx0KgQHv8rD5k3XzgyBmjB+Ukc9X5lfW27RSLiYA5recs9IA+fyqPusQ14kSldlzEPjnJWZy3z4wMatAH88XdFRVfOp3kGi+MBAwEAhk0ds4eFHt5j7/g8OKP5/bm6igT35QLMbbMcWTwo1lcsZGam413jSvusuB3ralSY5aDGSQAgLi4OTYvK3wwvu03j8MHPEcCHHMrZI/TxfPGB5oxcaNmcFN9qjGlJlmsrPf6K66enxrUOizwNTWpqivl3QQrOLXEAaXxafvyvt09+kmuz+epqnvmRVV+wXY63cYA1s+f33TWtdOmM2mu49sUnGhcY3MmpW3b86Z/Sn9UVqzblBhiYw2cQ9jcLE56nEQOZdiNvhNtMRpmV5EmQ/GggYrTwlcupQFRscFR3k2wtswgzWEKnZO863QCx1w1JhmEhYB91DrjW/Gyvt+3G+1mGlGQri6gDnFje872tJPb1+Ikp4MK1q3bbLTET1cMAe0UgMGfJJ7JzfF1b58MnyD7lJS2LgUAvPkHftVaTECvm0KNPPNbTFxF/i55rmZQcQoETrxlWmMPiNxW3ZiLcAQqPs5V7bKHpqmbvSqxfkPV0UIhYIGaVxqWXbbRBO30up+PyLpnFru4NMP3TLlUcabW9NP/J1u5xrpIK+fjRQEbYh9kG9UREOKim1A2pDqViJcumWkVJ1PFrXtkpieWHHUmabIdDFcwAoSbHUrip8nxUqOgZHE3uT6sgzJrvs6eTxuoaTIT5k8RSLsB/PfsreVNRvpt+OAZ/AR+7zHnDzzLfoxWjb4C55fLlOxSpeMbgx/D77L/MaNp7yNYHiEYAA==",
    "plex-latin-600.woff2": "d09GMgABAAAAAFAUABEAAAAA2BAAAE+wAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAb8BAchAIGYACEUAhWCYJzERAKgpF8gfVIC4QQAAE2AiQDiBwEIAWDVAeIEQyFBhujxieYc3DVaunNqqxfO3B/zLMDrdtBpIL28wXcGLVh4wAG9/5eiv//PyW5kKPqqdsGgIc5CBJRhdabR+OlkBXuxrb3QgqtupEjHJy4kO7NqluErO4t8rEKLC7yD7fx0t7l9/slrT3BJbMutu3/fTeVHCXK0tN3/dSTsF90DKpaxbcN3VQlKrSo9vbCabSijT3DlQ7+2GLQKsxmL5WZGI/y7BouHBGfZTVzUAk7ZPNwpvJZ4qChPMNCWRSvtMuu9+mXgbHLoEQbsdbJvDxB4+B7M/vlA4ho12tXKhSZL4HVWHv6P7/qdHd0Ez9aA4l/AoLZ9QDMraZupGLRi2IbSxYdMDY2YmwDRgykBEWcaL82Vr3iaYNBGRF36hnZd6e5jYosCKZ+5/6o7P9Utf5gBmmAGSATkQAIIjEIpIIpi15RctwsXUiV1V+Q3tv2gupLqZWL6qzrdrOKTrqrNxWdXXQLH3XPttMs+oJpuIKR1UwZpY2/XYN/R3YNIADo/8iWm4VuJi6yAn8xP8QqUnRJq7hFXC88xfe3vSSDp1j4J6lQA9F4yPYjnz/acxQPNEcaUGjcE7LJ/tTWVdbICo1GTfwYub7+f1P97njejKQnj8r3c4rk6Pfm9QlcQBJiuIWWZpzCWOELiAHe0txLAfz/qO5zWMYMY9Zk6mvr801pDX5p3FGqOQg+SjffgDtYRm56RrKEQKS5crz1AUApE9TJVmfJpcePpt9mNgnlTZavQIFGIiQOidqWn+NyvVLqxu5aSqmqVN1tFZb5X5snDXl9hL5kiTRNo21eK65nBmcf0ePwL6GOgnatMIRBJk1U8A8HNbdwO3/MkiylgUBUJ/Lf9iVPP4Gr4QashpnqpRQsQUEDyAUqKBeiWqb0Wvlgl6icEvMBJgDN4CWH1fiQ4yniK6MYmREUNkAhJfjUzIQIYKL/M9Vs92sxEnCREIULGdbjs+CQX09RlhzSXe4ccu1qdnbAxeznEKAonbhYQSEDFCyCECVKebmkDIBBIR/lkC/kys4AeQG8nOkYQ3m1Ozely9ZVCnVj/8vXvqU6t5+ZvwZoNINSVI2PfK7v011fOUWQS/2u9Gi1rvobrdVXDcbPzlrf6qc/5gln18Q/g5QimpAiyIgJgf9dRPsmJs4eki9J1ne+31tl00n7ztxXCCEIVxhhDkIYY4S7u3/rj/38D7VobDwSmvfzrbmMzXcAQ72Mnv3G116/xm3Xv17pJtGIDUVBb7VqkwSX63WBmuz036fYtp/yx1vjr3TZWgtOEFECSYDrVwpYAaCUBC2il4wstBCzyB5kvzPIOZcMcMs1A/ztN2AgsEy4Qvz4Eys42F9zb2sb2N9+zYtHYE8A87eCYLfd8OwR2P+ZfxJ0IAgEtMnkBAglqnc2oApopKQ9szMtbWlJY2pSnkAK4oo9xqgjDT/MtIWSzKACSXKGJY4E/vPdR689dd9Nf7nglAuO2OeIfS7YbJM1llnQbLPMapopxpVshGvqUWPbj5K3LR18z+1CFjNGdpYS8mmJCC23cIGCigQ+AUpjyWmI8BT6mBvKIjjCgIuYAhxhPmHxt7RSZVYgD7/BFs9HPEnFheDXmUrrMT1zmU7LkPDADoBiYPRECIskyrIpSjQ4A6fHu0ims8JKkdZjtC3G2GWsPcU4p50R75xs1+S48fBcMrDhtkRQvkVQajn/0Fiw+1sk/lAC6LBNfgQAYfMzN32JVAw9RJk1MAnGvThPk2E9qWOKU+EQirNxyNr2J+X8mV8pPWbLcdE90DS99yPpyx4UjKeepEe5bzvPBZ3r++BxImq2lzTa2nmTFYqJvlBE0UWDOVeQzWai4qV7OS6MLu56QTd9Fcta1b4vgfrq2vsiIT+OkkKaxpgliaYdiNJIGqPHs/DFQIasVh5nXjJUYhDZekUlT3ZvpHiu+DqPNPQUQ5pqAENGEJBc0dm5gx4T4e4WatUiL+SOHHnqiUOFR3J5SfQwvIoak14TWCqKicIx342MqTlyrAQaCg89pLFnz9AjMIs7i9G7RcMBJ8JYJCFELiUArIQAyh6YATPXvFF3pqU8uPa5MjAxyiLM0oztfOPMcBeHhu3WtYTO37ciLVmGK3qeR9hkewOCB60owXTWST3z7uanmW/iTMXrXq2kc6gW2+2jSrswfW09kZcbOO8xJhbqIsfYJ6kG4yqZgBAidCvhgZHlbYYLoQyAZkhg9xiyDyBu93w0tbXL1nuPNoNeYcV0CspiOTTxm9rMfwCIu0b4qXcRC0uBHAsNwTsDD9hYnnWbSyFF4EkcYH+T3oPnAAynjI5d2nAhBzUCja9AuVJ1flIp8+QEFhEPPVs89cbr5707D0koOzmK670kcw8itXQgoFRl+G0CWjWTbNGjKh/xEZcO4gfeUxMgSad3FzaJo1Arq1gr0vmQKTkjAHqVOj2AUmsENKCKKjSC1kuOSe7L7KzHomHGjruS8AwLNEI7IEFwgh5ngiGY5aZKP8pa1O+/54HoVFyQgJ4fdKX7s4yja6WF5nEOJSJTosZQsox6FvYrXQ/t5xKqU1tUbGY6VG01wpdlrvxpcR/M2b0QFSzOCZI0u5A8QkWc0aP4p/0K1tdz4JddHbKjW3AHgBgyWOaETeRgFN4DeVLjCZ5vBQsEBxRahRNEBfHDlMPse61BLcIKx+Lic83RZm5PGwlv5ga19wUZga6OKgbvKl8dHG2uRXNpb6ujCgcwGqQvXwKtcgDXYKhPBKdVhFWjlbPPp5L65SYQ8OuvwcktqZAvDDUNKyt1YEUzAR/iopAr3p8pa1ozA5JNZZL6VPeVwUG397kL7rWA6kW43sl8PMsVso9VufWSTxj9iuHFozhtLTyt7ZDhgl1tmxQAoKyPv44LoQjDbWQ1VADyHsVD3/6y/GQdVl1vA1HSqZD1LjOEb/LUnlrumT/o9iQ+D67DhR2gEsEGRF37EeWAQU5A7eUYqffAGWg8hPldPtE2St0IXvV5+9z6bg9yCW5ne3zdaqoWmPVNU2CkD38ThEOTTgx0XTT+QvEjkpbZDjFylhiiKIegYMQD09dQlyUX/mbGmMq8g7WcSdH+pQJwiMu6nY1wAeGGNtARxY08xL3dUIoi84oVHIr6bSmsm+Us7x93voA596REhBOiOAZ/zMCu+99S3Lhxr4fav8GNav8svAGWIGb9wqfSgIL/ltyZnvxUUy6h+4MU8rKkyuPKc7/TC0zjCfiPWWGbYDAUrySIs3YpyA5BMpCYBQuEfrK5COqgN72qORJRzHTuJ5gegUvOMdnLjVLvY4anitAFjanXzTIeyt8Z3mSjaeHUGsA5DJW67tDDDlqo4l+JVAVLowR4Y0mt5bX9pcpyNdGLq6yawWPbEws3itVx6eoSOP4g5rii6vxy1eziwegGHpauJkq1cOSAJTx+rdULUSqQuuPW3Y832xnZB6up1wqRoK6hBMc6ZAUtryK5Oa4VwlFctd+/yYrPeLjlzq2Lsj06lAiFmphl53zqFMeFuoAQvSArH3oPN9zlqQoLCqADYxJHl5IPi/9N8IJef+sDU9SfGmRX0uwIl4H1uxVEAbRXlxQMOl5Yo0qUam9eT05BmdeZPY7Z4HQWhS4o45FZaogvrSWlCDEs92wbsMVo2IDg70aE3Jocb93lliwVzNARR6SJcbEOk35cGKbvvnTx6f/5NkZclQ2PQ/WSw+6hBhB4dyeaKgvVzPSUrfdWvxpCcZaEBnbhBQ2RQM+0agTwykJ/ZU9UXLp9WQHgb5fCRkcOzqnGpQSN0PH3fWsbrIdx6MLq3Gj2x+MVK1ykZP8GHMk4zqyF6sQ5cbFZhevTleDuebJgyYCiEMFw1d9ESriyX7S1XcAbUsPCSaDTdWZCS15e0Ht02c/LSCCqJjO1/UF0eGl4z/2HgmTDjzoCVLC60U1twY64xJpm64Lk0oLP4T2acO0sRI+pcCKi/zIWIqidweqfmqP9RCf8H3bJCApRewlQffrHIjtArJECgCINBhbzpDK+QilUqSQaE6m5uUJvx8iePY2Vfa0TdgQ/FEDxcxUkfqmK1Ci1ZFq1UljgPx7r9Lkzh5xS7YxLmlxxzXgDAD0n8hTbnnuWVlae4jv0lJySEtvInsekMmwgGJHatgbAGgC8W7BjH8n11+8o97UeGQgvNjFF6VRh9tmPkfFJEhTs3oLYmb3rmC4NAEOlDEAO4MEn1zYGEuKk2dp96Y0n14tT4DE+HpKDqpYANlCP3xx9DcjOMQHWAYBH7y6CZzxBIlOoKI2O4Qwmi83h8vgGAiFE9H8CDAYQlG6jvAnF0jqBzNMWATABm4RNgCNsiUisIHvVnBrKtIbiwJGyyyTHDz9AhTUxTexWR+yMwdIhMHKWAVjz3fcTBRr5KrUlMB15BmQqynqtR/dNAAgQWNWdZp8LFOREgqMDJFU+gPzajwgrVhHAnq8/tcbdnmD2/Dw1L5ZUYmnX2Iq9ccTa6xPi85gzUPjJAslV/TNQunBBYJQiyvDDeDfozIBTpOvUrqylcB+Pxmf1WKfNe/DlT/nTOsBEEV90JuxuZxALjzHmXk44/oZm6gS+cHLNT8WA1j+3Ih2Is9TqdXHocd86FRwjKncLs0KUH7J8FSPcxJaohfCoUxeMLCxMXgozcG1AtxgMZyA8LKh/3Bko0wPjLSrjt7GzPTACBE7GpNDpEAtZ4J170L49u3AUAmmnp8A7o7G/1XXUap8V040WF2RdOTH6ABszRPqnPccN3+Ma7GzV23dIjz5UH1GbC535278SD5ND7UwOOZp6LiXdZgE/fnHObCXikePAI5Ec7FnxZWIwU2izych3cfKBF86zbkoV/CWDhc7vsRzIJpd+v4z9UfCOROguQybChxkOhKA4NhxaJ2Eh9fIzOY+oMPQJ8a1zcKFowP+vIyj4/AG7/vmSyUxa8oVXLkUpSQozp9PXbYwbWtfXZ4nQpyb4x+FCeGBD64bwDpRd1Hj5WrduuUP5pToNNTgMIKw+eM+1Gy+/qE7TFOJbT2wq2MwV9NVKouNJmXFAE1brCz0kZ+0XsknfGEkAjB98cTif4EhRidISL/L5/gW9ylaU1ZYTedAxyVZdVUaSoolZ99z1CVPOPQwnCyO2t57eOCtaD2Xng6A3Cg7sAgAXkK0El5AgIHxMt0bTvuFJ4CioV1Sw2v2vyT+RggeOrhDEsUgEZume7MktCaRWKrAM4ssZg+Rp9YFjrpbQitaaU+LFXR3NckdHzcJ9yRCtEek3qoYkKkJU+RXbGOOB49bxKjF7MEwsAfgF+5VFUuQqhODUvZwjsVIQSghqFp1S963bL8Ft+Fk4SKXWQE8oMTkzwQhTvQQ27+EOS7jIEnRVkSReMuUrpGr1weNM9bO6H182Cu0o1a75nphVyRyNEmmYBUOZlMzJ7GwZYoAbgHJsCqhdUeZ7WqoE6Xp+GSLYRN3ei0yUK1uFLTaWidZliN4ahzc/12vazJjOXd/1EH47y+iDbnbJC5maoNzYll33vMfMIahUmZBqdZqNscP/gHd09fQNDI2MTUzNzC0sraxtbO3sLZPgCYJAJBJMJhMoFJhKRVAaEcMUOG7AZMpYbAGHA/N4hOmgdtKQBvolWfg8EgKQpiEqMlWFkcpII9WqmRvpjSyNbavbMbenYyWzH0lcAB+STQO9RvTQpF6zoofmWjBoqVErTVpr1KZo0lY7eu2110FPHbXXKTwDh3E/DCVFYZEVyEq5VUVmtXW49UVnG2zmY4tOthadbbMHt/dvhf0OcXHYEY6OOk3ljDNcXXZKXHxB+nAVwj0c4v6BKEwQd4m3jL9cpEK8MonKVahQqVKdKp2VdFWtmxrd1eqrzkCDDFdvRBik9kY3cYQHjvTQRI9M8thkT0zx1FTPTPPcdC8EeynEK6FeC/NGuLcivBPpvSgfRPtohk9ifN4IFpNMgNvlEx28paNTw99vzJMrYBe+gBB0VtloE0aOTTBgxnkQACFaH0LllQFYI3uyMWQ2lTX0OwK4SeefiimIGRzdHd0ZzY4mRWOjEdHpUWvSo+ZHzYwaCPoO+g5a0j4FNBsUAZWAikB2ut4IkoOEIAoo1a8fARoMigLOje78on3OS58D8qNmjhi0hJULEsfL8ffoHnNHyZD2v/7dDZ1UZ6XFFkiP0pu2eEPAOFmzh02RuMt4y/kq9I365GuM516y3nov8Mmpsl9EBY6Lq77yrQNEyJZ+kGMRhYPEfR3jIRDx+B+BxxNIefo9v3vpT/95r2PvC2XZPyXbPOq1NGLmM4vUMrPKrHObuW1plwlkOWpR9eoaCfOJZWk7swv2OSdLqBWr19MoNEvMc4u5Vd86s3mypewS+4IvyyiQlE2PLbtYpxTODPA4akXDE5lygQ/ErpwfSvipx57UikvJbJaxbbmO1pFYv5wzDDl9TtXA1yKsv6n9FK5q/dEqVao7iZh3assc1ZVLL2xTlEfRIVNRNxpDd6YnqT9Pg5SGo1tHc+PSpAEniLj2HlAe+oyZMB0SUjLPvDycyWNYN051ktNzvVPfHQZ9w2LDoydjZJKYForlUQ7gJWFYMIU0DblfEhmkhCFjJkxrVqqZPYWu70kNuJQwy/jlDAep1ehkWVjJg5THaS0kpVVnVLg+MAjqdac8fkLgCXdUby5JbM4XqjLWsnQm48taOMea39M6cBm0689o9A427oWptjFPjv63wCa2xXa5E1m5erFm1Xe074OLgcsHVz3XsU6kG+lF+pFBbBgZRcqniaRpGu1Mbi61IJZSK4U1sSG2IjtiTyh177fxhwrzPU7rW268cuuNOzkNSuI6Hl//96wkS1OvTKmHaDcKtwrtPqG0+5YlWFZJjah3o0H8hmn8Gh1DYwRix8UR+d/9Q2TFzh6dNzSJ73OXnE6LghuiBP041yJngZupBbbkWfprd4X9UMmNF9qBR6Sg+EJNwCWMs3qxmTdfIfYj0dp0gV16cX90t164w9o96nC6nB6rzxlyxsQEm7oASq9ayOOXu1bvrbdtyqdtj+zW7bcUWzvQRUbV7lpBitWK1OMamc4azoPmd7Reu5TCz0RouGcD2zHERitjRhIWlTFjpvzHmHsQg/HxxTrlVngQjnJJLERaZ3vX+StnNeenNsDTvkd+FGt9lHcPEK8OdHi6lB7SR+Tl+0NTZPaNec3iRBqPTCfbjMa1haUB8zIIzuN9zXWtRxej52BbJ9ctqkSfAUNGtVPExC0GYsZaRicQnj04+2LpPEbNC5JxoyoOXSYmMcML/XhllVinNqmBoStYxlvEmktaUwqiUYsu1uP0iYHM0KERMeaZEFORWWT+YNHnzkdWl9bCxklj/SG969hbDz4HT92J2oIgrtX+nwKrE0YRPEefm6Kgs1F+rSBRh7+qBqA+w9VVAOn/8/x6A7grVOoD0Fe1vxJAuhqqUtZnEAhyVxKDBHcCUur6wdIY/OFv67VSKZsv+1vLK5FhpKPvLaPBqa23BeEkWrobB56x/e5J9llLDiqQhCMmJBIELMGQV14BGIg7Yrrgf+ABJLe/jP7dqWcraxQWoSlywV0zJUKONL2zhIWGWuZRKqYHSmU5By6SZafzr1mCBXJtWMyQqzutHkq04E5MwCr/9nsoIhFdUhcZ9DkZA6f9w5ArNQtvyQCmVnAZ42BjHFwHdgXglGMrfS6HALbdgIj+98GCm+veWnQM0GXsBNiaAhQMsD6OwPpE08GxsskwsFKUFNla6GqEMf4fwDi6ryd6s7fHAC640nv9PMqH+Siv84P88dZ/JKr4G3IBasTI+06ClbxFS5WjpW5GWhct9u5l8gP4GLteHuRJzfc/HTK/AFgK8y7AXC8wa+D/I0499Enw35///fblkQJf3rJivVhv5/yea37Ofo6zi45jhCNxKYDrAdwnApDDAXIg4b6b6/7uG2bkGW+eOiZuIeVatcllka2ak8s0U01XxqxCjUoRDl/WnurO/xXBsnphExLTZptrlvkaNPqkyVh+M1k1+2icSW7SpK57zww/3fCxgDeQk7f169Frnz577XfAMXUNTV1tHYqa1wZ6+t743ycumBmbmJobKVgMW4ssttwSy6yw0jqrrbHWZhtstMkqW+20zXa77TDFLofsd8BBh+1zxA3b/Q/4n0crbbXWRjtO6pRrLU8zXVXppVy8CLMUG2yiuYYYqbtmqhXK1sM4c8CKyaVJCXn6k1eCpido+sbgtqN5DXY/7TWqsy+eyoA5l5Dfk3ENPD7QR40vIPdCQyBUIWUnOiP3EtYLHZLcCw+h7sSV2u5CuxEztk6nBGbkRxBlvkAnqbJm8OsSwRk/y0J0+kEIzcv/MCA7j3aDBSsF3W4+uRdBUwmtoW4qohxHLdeC+De3SZzBXdVRW102V+elEtx5tNINRiIRqs4baxA0bSHd7tKo5K4GiXGhVMdBbpAu1ClYEUcXOQrz/Cz9HpqFRnY+0i0Ap+2a4yn1ulk+0gA5auyFm40rVS+6tOaIXJIJntOIcjk3GOlWknupMzhcKqVG2w8HMroinJLEQDF/Ww1kMUBXAdkc1rsXNjkbxp3Qy+H47w0EUAzdz+Q4wK8qq5kkK94dTQlzyTS4sMnuWQabJ2j+nmnI1vzOARqzThllBXMXBpgrihNmmHbMOMTDzJ2XDuDNhTcKOgq7XvZUFTGQ8rraQBTyqTvxCnUG9+ZiwYLnLdccnjk8Ua19RncoG3Cicq42A5c7xzBZczekPrepQgJKM0Z12uq6yyWLu9ygATfpVPHLbg2lJtfzA41Mc66OOM+56etZr5EyBanMmHPtKae9CHeJ69qyLPEW0laDgaKMRtkxnZIWxQ7dMeZnfMlcUaxc07mrGwlRIp3MPxA4J0RRuC8lPFa66UiSA4fr6v5BzYkayjJXJ4cON8m+xUOVxsyisc71ZK6R0mdqxLnPwOoz2zAi5UvLLjVJEgneeVyTmeTwNCEVdDp7YQ1iwqwnJNz7mMIQKRHKCEhoIh8YI1HiUrMouZNpxlLtvJCCz4QNgBcBxbPWK/O/MtOct2gsr+wxQaB4S+vS3gIa7bhpjE1bexIrJZyJ+r6wE4Xu04HqUypc8NCUMyJjM9bAYrFFINFKYTnKBnrseJwv+JLMOj7ri38WgpltLmYERvojdR+dH+J+qAcjyYj3NkIRZ23W1pRp7r3titKGRWBf4NUq2qYi7z6yQVoLUCj6KbXTf/6E0KVAaShA2QNxlUuJTsr1FMCSg6FcV+/JNOgMoCTMKimFpBJCz43VwhZyjNeNsdxuVnRANIsM3b8xMl8Y92dMR6B41SxU2cdk0HZUm0CPP9QtaH1DWlkhIUlM2ZpZWUpAbSuH9YOkIjt82sU1WyyNQvkgwDSE/UosRBAnTw1/mwowzeUYS0WvLDSJq/ziLmbPEhUnHLP+MGtGKRkVa6maMtKxtcIWcA6NKfK3Q5otoUE1smjOucovzkY84u9DU0p4tmZNU5oGRQOjk2MLGKTTGa25dI1WFwNg8GhNgRmbBtZeMmAdZRqYd8Z1oTDvcdP3keic5mhHsdOsBiWVppruDKBRrfZHJ2q1cWu1Ik2DslaYrRUqUZoGi6W40qOVWlQRXuJY0r+bzQuZi2cNYNWeLjFMo1RSatqECSaJqvyNtHJWhLZvurcU7oFRzxFtwxXTOhOqoMRcrqlCjHFKnGgZxXIZ3uAQfuql8Tl5fg0FQNVpRQ4tnmt+N8I0xLVC69YgeokKPKBOxVxvH3TjJGopXsszWxrhw2BLDB2aYL3OQEAbsaUY0rEgqMGeduGggq06WrHox41T/bLNoGb/y9yR5njI6qyFcy+XMS5TeHy2l7WCEZIDJ3nwrI0ph+o37vwK5+sJlReW5p4D3liuCWuueVaUEGhCCpyoTe/CBRMuZcOWvGDoIn9DsNIpzG/wcbw/4sS1569NHQisaeQQL+efjO7PiLN+S+jocal1f/58MJ/PYylY295s9nca4xcP0edet4h8jrBJa8rB42w5E1+4qTG+zNbw70ee/+nfkloqauna+z9g4o1eakTNNrbcvAzhcao9HNQ9zlbK1gKjgG4Jw4+hSB5iHJ1ceMHe0EZf155RpvZ8qqT8taTY+qvl9x55OJo32L2wKIB859tqsUdTp2DPu3nqJLKDaVTvhlYF/u27eDsZxEpRhfyYbr84PNzNc2pt4yJ8XCtrctfwNERUiTdR+E0VkdHkgvgvcmXT2m/I23A5hPu7eoghwMRPBW8pnBxsr2M7Jxmr71yJFhX71DfM/2s01nRPkLhuXSSNgeKWYk1CHVRY1s6XHarzAB8nV0MQzLy/izmatUJUW3SA5sxGOPXGHt+EEtWaR3IcZaGRgQ78A+GYt1xoUgngTrBWGmoyfJ5DJhTMUQpys25OklmUAhJn2/nyFrnxqaFkMv8LHfeSUF+9+CIuDxNgaVPz58xsciGalYk23uu6ywUAB9HKIi/n2oidQiiFuh1gqcA2nTdDTg28iJlLj2//LgbAt6V/74BQl0/mImVN4yVKpFtZnVgJZh17/D1jsD1DJ8df0imckC1ZlLkh+sLEZsiX7p/emiN2yo6IiBFhTrZoE/u5t79RDtl+kjSD9QplwCdVw8y2zug6K1EYm7VyvseXbmVVbx7JOP3kiXyZ4bbjH0nze8pMmvDWuQ7UjTnX6tUS7PHmSF6wMbMja9qpgbvg4RpGw0pmDW43tK5JXT8OA65XZRCn1o78kQ7ZKvsZICIOhyDIArUMFppYNIrrp8AexqGlbiTbC3MhpjNzVsTDhy5V3ByXKMWhOPkttBwZ3FTN5ohij5hbP8QmR2ZBTD85WmjSnDrmCEkmnQfhsh0NPFgO9hazN+ENhtajmTVhcBo1kwNB2vcAkx4guQPlTeq3DWUrWPRCtSuN2Q9WlI6LMNY4abbVf7KHOsjlAqbM1hyOLRSZBC+1vgqTbILHqcNjRaS3iOabqhsnzNLhqolvVw/buWatJlPKSDVN9zfyKHFB+e0oPkUtZgvylEzrBKdIKRb6Euvvpx90pwvchQwLyBQniXd1CIkz/WztSjhJnzEB78kxHcsHEX8myySQluuN/IjnmvF/K0J850oULqXdnACwpNUZc81NNIIleGKfBMxm6KboJTLo7v0iWthpJ2TPDsJ8gtvgGFlm6xIF5y9CZbe/CTOXFXn9pMRAO/joo0hiPYHdlBdZB2PabpEkDUzd6rPXXL7f+5Hk2t9fah8VOOWn+2t2WZ8Z+R4UpOA7WTd07/Bo0UjnzziLP6hlnEa1p+So/oSgJaU56xPMlIP+nQe0/p/OxpRhvinz7MP/fjp/MsLGvoNNwlFomMAddBsG448jrEX48aGA0EFS0Hd7fFyqxZmvN2XBP9KQkV5KDDxCc1mnB5yFBosDeX4e9WigYlHUdwpUZk4BNQ2wDOi+mAF07Fnj6aOrfY3hr27t/pQpXms2OK10X3G7N2qzM/XDuYf0SdQYIc6LVvJr8Xg5fq3Pz/cn3oKtxqcvBOPmEZPthu9EVSApIvCT/2mJ3WiOcrDUbM3+8z3KINFzkWCu/vfvYgCPdpm7PjdZxx0+mlcDYG7N19nm8m8nlR8NdWxGNrm+1vn6kxzCyKJY+gagbCz9i40Me4VvF3OQMzdz7s5FOInZemBw+E5WdadqrejSX6gD03s+MUjKhflz+eJSRM+au3kagOw16k649fxB/bnO+ao6PbR6on34owbpXfuxnWTVSJoUdnw1ke3lnhuZ5QoGhd/3gH+o/RqLzIFkRZm9G/XO9QEz6LuJqeWQB8MlG4HfDMpd59xe2Kyp7hKHi0gLk3ub/6VLMd09RDQPJftFjeR1Sh8I1tX/ury/oDJQrcddaImGWSSceryLdDw9HV7GEbtJ1KC5k8b1pt+wiel3gvjfDh+LXOyw/2/4X98r+GcIAJc9YqELrDkOta3OXOHGku4xyCUEg+JcIdtSXlWY95VZkm4l7sGo7AHpcMTsA7pHESrwtonJDJTNnDipbFaAaWS9BuZGXubTRTJuHlckp1POYzfgz05Iiee7MUINPCCRwP1CtRvDt5SoqsookTgCm6ngFHKYcjYFdsVHSVOGlIpZTtBtE4vpL5s1aWLZTD/TxLwNokYeRyryKbfwG7B3KHShnJvHFcrGQeL5eVixGhmQiBF+kdqN5YnceJ4GUsAmeIbwJEoJ9WSr0vhPmK4/zBAo2DHXYtlM+Vz/elPQZFBpdRpPSUV9RbCiI1KNIOIvyPClSQa5Z9j2lVASoFu+URCJ/3XA0MAvFBPTWlVUnvqEPdyotxVXJ0zB6aiWysIKSupT53CccmaR0zw6O20sbec6FGy4UCqZs7SswDrcWgD8ttdHNbxKKUD2FpfKSlI9bfhHZZt90xgZrr90jyI00A8lV2TLCRXrIyLuaEqi/hgsyR0JTs/JREMSIehMHCP6vjJKDJG4iFEXG9HJZWqtusQq6Sn0TnLqHkUOgJT59ZPn7Tp9QrJk8gulfnXEf0YukglLIq2qEpY+LpILei7jCdgmRsbAW3ahxGTX3aImeyRh/X+B8coIJQGXl3B1rmwwNZ7rwog1yIBEgvSL1UoTl+tW/WqkPxIwqfuh4JQwVgp9gpUM+kqBT7hSoYuNOBuZAq8R49psKpyRKzViPn30cZFKkFINfQCHNGfKZBiiNPtzfHmQXmkyHFJiyJQ5kJQzGezsOJdei93H1yaTsZs/t6L0+tLf2DOlpr9UqTemtGHftphTK97IlUop3FSSCdWD3XVzKkoqxP6SgglOkL+YOBQRhRD2EspI3e67JhIX8fVvi23V3qf3RdP71PfHbI9VJseOZV7L3AnM2im8Vi++RkU6/OXPuDZ6duwM+RPsrEGYWbIn0xpHdsVsA8xf3Aos3zqtc2BX1PyqXcCqXcHpsU2XS5ZPS/uFMJUUpGj7UePzRiInRqEnujAlCeKo4Ar/MGlqiWYgp+s7u2vKi771z/r4MpAL1ltm61MQlWn/psozM9XowzVRKbITt8mEdO0XGQxXPLG6F7sIg8IsxvZWrstoRMPRjRnrRhXFq8Iksxs/yeXCTzN7w1mqgrGWDGuN4K2CK9A7/Xlhj7NIL9BLEsrFGNM4p8LW958yTDQ7CW25uYQ2szNMVP73b73e6cwL5zmd+jGXDPb+cw3aTagG1E5tQ669/3CDaFNiQyLOlFABbCtQWsRlZGMecbLLRZpi84zKUhdMtGGM5WKSXiAxewvya7z5hRZ4wbixMPL06piW2snfsWjcpP5JMDRMDnMvq9z71FsuKs9/ml9uuNL3NQtmmGyDMnwVgQRHc+rM+3gcgjHhdqWELvBWXbhXxgUqbtv615KPqKhFK/12tZhqZAOr6DMwMTw7+qD+KgG/jOtfuDMb2Jk9p3/cqLSgZu6gb/rJ8y6zZXz+eFU12ewhTna7iFOAKkKlPrDFQ5jichMmW9op6w0uf15l3rnewJZT2Pv5VCPMBbZQaWCzC38Rqd1xLZuxvVgKtge7uWBkl08llYsIo4ZN2bMK+1lfPq6rMlFWsWP7Dc+/NqlfQDVAtRALTSstlSbNBi+YMHjcpvC22NkPhPi8FslRVw6P3kfZor/I6LEhWewlxOYslEHG8kIElgbGfHf2ah2Oy5uBy7yaKY0PjQgU5dJRVjm/CF7hV6omqU40DGsQXejbZhfbDAaxzb6tbYUJUi3RlaB0+gAKyoKrTSvUnx99NLXcIXo2SPgsfLZPfNSn3Le2b5LSTLg6iHbVYp5vMVOvDiJeVZtbN/QtdNUQegaSelw1jeOWrY4ftDJ+7oPgdceyBd8GDX+be8MR/DHi7R/ta7ADV2DnvtswMo8W31h2IbfhXWPoQr2GGK/wUSUe2GRnDmyKxOOjKia37t+ypXX/pLCCGXC2OpkBxfqvD0/Fofexo7tsyq3nT1rWVLhRj8fcPFjDMFOGUDqJ7Jb+UcT/t160gVmcHNgfMAOZBNZkSX+K5jfl5IJWCyPYaGIRlaImLnYYUja3qoaTWM7Ud0g5AaXSxHREXXWXhzCUDIOClQ/hM0yJ6w78KNLt3sm7A+Vfp0VT5TSJKuzzThXWJB1Zd95T4plqfH3JFFM6UMMf+iK6Y2HaBQTZBJ2GsDFZyFyZtBAtphoSF6z6UajbNR+/HSoQyngx7DscovVjRULa1OULKfHCfKzsFTjsBtIkTdjl3L/zVpFN66Dk7R61YL13GJKoh5bBLDQWOlcm8aJ5pZzXvKG81xzubXfX3Q5s+mj+EKl59XjUK62NGC8qgElZSB1Jqc++H0OXWkSZMNlBZzqXKyIHMZYp0q8jPea+PltJQuqkrAKYsIR3NCsp6yhv/oBcIWs8aRhxPGt54jDS+DrsLsv2O+vzdnh8JN2+Zrrk+zHl3zn7Oq6bZQuJ8RPHbliohzaIrYUEuVxQoEpMv9D43NoqkccXbUA0IjYsOo7c/Z2mCJX1Lo2ev9Ym27D/1LcloT9VuvDtP3YrrauHx2d4yG6Iu4aQpm+xeRiO9B1wBQEHkT4/9HV6kSL0d25sFWsXIgqdSyZq0JPs+oXVVB0zJ/lMfAZbrd8EksfrjbzMDJksy5vGXWNvLNDuU+Op3PP4qAwpViQP+ZyN9HDCmNVT3H736Jab8dEH40qPvBu6L2aBjMikGCF+qJZIQ1vlXC+Mt8LckK99I8VS2LuoceQ1dNmr8iGpjgU1PmI8z4OUipAuNhtZISp2OYu6VBSfUabGKqfU0jwhohYsh6iJWWizlOOBsQOcNZQEyhoO8673zPv65KL6xtXqh++nWYjxQm/626FYodZwPoYqVDNRN5Zmp3A42SlLb6CYIjU15rzOIMQOfetNFxRxlmJHYpdyJg/JHs5QZyRkqBnPxXRihWMPR9IcSx6M8xdH4TPJ6zzQeSzXCV0AVeMxrgLmoYcUOxW1z6RLo+BVSbjTGGRJC/tS88TLCYaklRWyBMWz6e0rnxQj2uHRKeceOgcgoxBr8YMyFtpXbckIZ8ST9pxa2/R3/nxBsIK1yOvlLC0Jzxd57TNowULuTA8vxUuRK9Ak5mUe6PR4KmrZulQzk5lqWbcMRTDuACmLU6DNKViixYKUEUvNmgqsVFObZXMQ61QkFXGU1TaKpPn73lnkGWgjZDeKcASvIRzu4r0fDxufhP5RCaxMGZVjB0G7Kz+Vao/DlyFGIEJ4gtu1cBHbl+JDXBT8osPi8wy7u+dxN9i61W6Gdgu3lgubfQKvho4Ef12Xb3P+t3f98fbUZKga2/5m4nu6K+TffeuPtafdFEL7RgIbnsjmlB1zJZztONaRmghnQ+/z9q6tPs3CWFumhabh20cMNMHhYbIMz9lxHIfm4tDH5WhiLjwJlksk5MKS4Ln08ZczUcenHceiIHeufYlwnfm9lfy7l2GDrIfryCSIcsR/GEfzSstAO4ufQIASyPVLKoiz8V5DOioLc7Zj3YMVpR52RWBTOaQ9m86wQdrx5iXZBW801RH03nU1NI42fTKlVpJvbZ4s9ZDLUutEenFqPaVM6qlrNkvys+rTpyTBODpJkWpN5uY6kxbQoiaxXlQuyLkVk5utl0+pTZ+cZJvedsRrOmPy4r9+4+86zKXpeCT5GqmSUEqoJF4jI/FBr/FB6s8utSJGoe76mfrA6JUt+5ZJG31Er9dLGoeWWeI1PVTWKtGwVjFlABcN/zS2QkxDKWazXgD7isajMLsf9dW3VPByXAGfz1k5OblAqXW2QVzILhQvp7PmZReQ2QXXnw7RNXl6W2Vb0uR5JZUlFWA/vJhHsbi3FabkLIYPOklqXnITS85GwY681iQuX439mUJmapwJ2Ew5BfdmjDEpd1DIQpl58V4CSYqGHp742P9UqEuGXKLCdA4eFqlHjvpcq2gBw6oEVwFUy2iZ8XFouB7ZDDeSiHBTM7YjVhXK3/vfB0VR4fR4wzhaXj5jUnZ2Q4EqMYPeSQ8InqI6scCfqVHjirhy7kRjmkKBeESmmllE5qJooMnpxqwsEUnGIShyK0+SS9gkQWSMzTDSVUFEbjgJQpto9Qs8QQsrgRlIpCZSQoKg+Zxw6iJO+pxWwAON9UgYsr4xAN98DHJ4l/1YNTTNEk0yiFEy8E9w8uBkMIK72r/8qZ57l6t9WgWz82tBvFoTTFIGzAOaFlgWAKPyyqZOtbDSm1HAHbUE5kk6x8oyCpPQD9DIZUeFQ7SZApVFIe/A7XOqyIOTj6bDloNJPX/qbHnFLpeTNm51qwrTQhASWjCLMp6XTqwM/B6swOHA8veIWAjkoLjpmJzMbwTC10z8UwLhmaorzS2qm7WZhvSvk8V01kR3/l/W04leXEW30L8QNmbPKvieHNieKnsLeFOlfSxspoOyms8qIJuqKLXIJkVDN6063eJNx9OXpEQtTSminq4Kn6xCrbmJqR22TQFPgRaQNPjD1IMiVyEldJ/EB7tKuw7VHNqGPoiT/1t6pTTl0/bOrrKuHTU7mnKdiO1lV8r0xMdzF2u0cxcdm2o000YtrNzqz28Slekp6UrifnPCFKElkVcWlrt8t+xKman4V868321uffRpXhuqeBxL9fPMnjcAtf32kFgm6fIanA/xGowEv0b4cAnfsH9uwj/DfEmbTZ11pXdSUjhhqy2/QKMqLPxqNn+VFKm2NZs1Y3VLAX06l8+dTmfeluNfjSr3DAvMCIeDM/KGlftDJ81Si5e+SfmH6eSiW3nMIrv0WWiDllzo1XswUvK6gnhlVZbJS5jsdAoKVPnzrKRqE4tn/yyU62UUOt+quv3W8cX62fHmrkUhYKhp4wtVL+Z2GJPWacb5cDJiErUspGj6E05BGp/kQbm2sNBdqOh4SGAvZactqz8TWh89NIZFVe6IcdZU/ra5DaBSvseqO6whHD9blVxUoLeWFuXH5fnznuZlpdnUHP/o/vJUv8ts8od9Q7w7jOjJZzflJPxbDzNCe5cc+d38ftr0ydM3OzYbNzsat4sXtsMGzYfN7hI3wgVmjlksksdFOo5wgQl/+pe4Nu7xeypiGGJUJmEPRuc0JzuQPu7xpotcz/rmVRr/qaJrsLLhZNakKP/xOw8JFmeOCv/vElsiw40g3aNTgsRkz68QoYbKjGK6qRJRLp6rSS9gE7xDuArFw5SktM2bL0XmV6oHzqTnpMDmolNlGTdSaS0Hdi6/nzJyZkKU52dvsW+IPD+heHZN+ufDxHeuX5el1Dj21unRlVK1G8kReDOkCqRPyIV4WDIjOoutZRrtO4WeTTmsayYKyUgLHr3eftPBHLuMJVKI+CKRgsVmL2SNPi4SlwXyWStTHMuymHIHURFKMxS1NAi1KobCYUt2MgwloLivonmSQHNkIlOgFDf13T8tLe25c5rM4Gu7r07NS0Js8uPvWF6LBomqgAqM4rjJEq4LK9YggyMZn3QqVwZX6MpsieLkkWXcXIxACSsSELxDeFKljHqyVWH8p5L+cEYHHiyDqlIJrVyTXlepRSCtiPR7+ud/nPgIR0gsJk3cIOlyoXC5dESkwxQ0gZgoxw8XjMPJhT1HOphOFvMFHJIa+6JTpFw26tb1tMgv1I6ua9ldk919qAbdJnQDeqeu4dxI5UzUWvTMIutPe1aGsTnHNaAaIeJJ3Ot/763BPce6M6hPmNS55u//Qn05TKPfiPo9YaLpb3+E6fDf/9XrbqBu7LYWf8uhBf54lxLHtlqZYo/O0/FL2+BWGGCbT8KMz/5bvoqvqZy0z015PLO7xGuDrK7/0qTnm/OUNVffa3iCUI8iW/60KVCXrUZ82XO8Qe/ngPoGUZnAcHHhFKgj93eYnm9Dh71/0vhuqhHuApupVLDFZYRTu2f8txnbs3sR63Qnr4zSXOVc0PV+OrxsASi5qaatT24x+D0eQ7HFKjQo6bfokE04Ha4JiZgW/nKcpqBr1cWPo5TZK9zhyUSnWibSgi21LsJfqQNTLieC9znM0GsajkSuEdNSU6+EvSpyn2MxHr5uKHD44jRqfF3Le6bcxCKjTz8Gsm5hGA6eCv4KtXSVnH4iHw65kTQoEQXL0P5xQKvZZlhyt/wZTUHT5IyIKpgWLMyq6o4OA/eicGkXoUQI36I3COQEiJR+XAyH3k0DptwEp1wq1cUmXP6+eJdcZ7YqsKmK6eS543Q0l32erL0YS5OJWDyrTiXnsWLSb6SDX6THpN/0OLRt+AaFaQbE2JIh2iXXmARU1IpMYJ8GQVRz5EoVh4jgnAZmrkBRTQLNvfSOkTEjN6Snb2hKdqStBHcnxiV2QMAdzTXtrtMQsamKZsrqVh0t175W1u7A0WRizS3UWrN1cXHnTYt97YD5rNi0F4V9ILILMBYoXjyaV1MOXnYfNmWi2r8IfAIoEQTDarccXO2I5oxFxEiTCJSXPZ0IUL6MWEpO2ilNoofll99TqxWKKiowe0/5HmA2tSpF02fiyZOsizcyh2r0pJhSQqThw1f880pxYN2+5cTLrFp0iZBP0B7x4t6nJaW9xzH5W6CiGq7SmFHQX8EkrXk305im2pOS/SPGLf0wuvaIfIDiGiIdinbIoFCZAw1lr8I2gE2BhihYTBiTdXor6EgqKW8IMcPSY2rYPLaNmhjPkwxOyo4+PwPGvUJtOfD/5UPUqolB8TAHKicV+gaacxrd+NsDhRhc/s9L1b6eaG7bYMYAOxd+wOE+uG5AyXzuMyOGFrEMcSMXSG3yYgxKd9PH0XVH5CONKSFe80g91tXk6VtS4alb0pnbkoRLRxSqwI7qwU7qAwWL1ZefhcugDFJGCoLpm2pPtJtNywDVXL42d3u2hHdLL11a9Va07W1pv7b3gQ7R4bcuQn/ojgRYxPJpYJvNtvo3P1Gm5We22Yy1rf9czDILAVvb1tyth2nD8d/N7vI9bbPZVn7ikpY/2WYzVjzS8jnM4fUQ5mthMresYX/nWTj8VnnR0MIEJyjZNhYmOOETaYhIlszCZA6ISxbOwgQnKd9BzAj48Bao7J+KF/OmQNgq3+UteUwK8EGv8uf/H5NfxEwsqtWo7tKnvld4g9XvvT0f/vO/R8IqXoBD/YwrNQomGXArVPFg3jVJ5Hy3dEm2ZnYfk+Vk7sm42FzOsb71zq9K2iRAat7lDboo/1zuvEAeaL+AmXb4wPQ8I7bUp1Yi8z+Hg2gOj4muDC4qhWx4fHMSOW4UMjWAHDYWgI8S6JKVkcFkMAx2utoYlDCQ9zwmiuHOVE0uGdomQZ8fp0G6C/0Pox6DFHy0/WrFliNO0h39H5MsyD56LEAiflhwDNB3Tj5ZfCuDu/8/1857pNtwDcJ7EOQkvwzqOye+nHs3Ab4f/+AK6PDsjc2t60Mf9fmu7Kv+3cvbVtd/+3QfTqU/DsxuFOV4OItQqJu3B0gD3PkQPHlp0O8GQHz9bKgAE0EANEuuO/f+UFOZmqEqQwp1qOR1Ok9yTxYTZPAmuUVOmvZ0c6ELDdh2o12b/G/COlF5riKMFK6KlzCyTON3/wmNYORZHhtb6E1g/pWSpgvGURjBKXWCHkBDUk9Skq1sPk96pjtpVZHBJJHTDeX0DQ7dmtEHyOSipYh+MFX6ChQWO3LxoCRkkJHcIK2IEJlYDATCJrBjXYZaZahKDaqSzZ0pE3gvrVzC+7qZR3CRFzny8Tnc0jeuPyVVgF0A4ll1p8Fie5WEQYG0Fi07y4bMzIQAxHnq6Sk04REwcydOMV8c50l4AgalgymJnxKlZ6ySpEaOsof0c28TZ9EIcfzZeuDtaoWzHoRhegAtI13+sMcueIbb9eCMeTkuzf1V4MV1PNK4xg3djWr1E6IbgMz91m+97Z23oW3YSbXls51Q3p47xu6U++qpObbvaXZcHKvjvJfe6Vmr0KItWrRoVZvv3NrRJs93m4GSc6E3EGyMavIHfdIGtNIQAz4DYHOCBRnxrXmOkZVZB7wBqNSoBgKopUBAEKdowp1OOtwgM1F7dek+wRmnKFwom3iHWI+JSSX18BOIlfRlQoOWUGgVPUU00tYUvzWWS+dOqtE+S6gF+Q5l0rux9jXJWsbktDhNpivLwZV/qOH80J4w82dzAwm2gXYAOZjrB/O9O1Ju7dbNGr5zXK6e28btK53eBB5UwsioF/yK0rdNe8/llVc8rWP1kC02qZeiOnXUOr5PqPvqZ+a2TooWmmiC7zPlOAQQF5C5+CAPca/iHyYy1YrG4vKSoavR2MQCSBBXYDnGChbXwF4oSoWBvOOeooCC2CyOS2bYk/Eu/j4EpRXKgiQQ9/UNCHJIe4b0QZ0MZcTOUXwdZ56thyOA5O2tT9PqIglbC4rocaoIMugTAhhirnMUuDu0yvy0w6TMFCIXtTJxelrJsYSxhyCAH6GnCW0o+QZKXj/UFPaStpVCp3Iov0vMFoEq3uSCcd0RMtIJEf3tBa7keTIelGbmjy3KZs/Jckwg6AFUNKABZ7WfItUV4AfarhVhqJHRjBQ7g4agKaO+1KrkigetGUPbkllM+oAOj+lSfI1eBXstVprYBARiY7RLwE6ktjOo2h9lSuN/xtPqol7bOBGooYbTyydbTNFJpYR7xCbBrodY7rc8Ugq+6fiec2yMObkfRMdOrUqktWJofJ4wYWtRl8A3UcwMQECjFM7pdxjYZCeeO6fomL6zL+A5ndt39GqzCgnC2vpEESVQqREuYlQ6zHKSvkvNIHWFmMG0V6TsmR7vjMhsj1eorakfSR1UiV0K60pUrp9ALAkgb5p8djG2LuBevYExrdUAFmcAxcKqCZQFLrnsJPU45qRp0UtVujLUKp33XmTkvP4foyR/u5Sq5IobUygqzc3xrII9JrjJYpBSTIwtTKDWIABL+7sGiDlNp4DYbXgibspMQ7I1DBeJwUuThEGBEFAS7CA4BANo+uno/+XhcsnwV4YXDNcMpBsABoTb8W2rvLem5rn5cqd9QeWjuPj2xOlli2+rfuSMoexzywVDSdhhQjjnSfIN10nxjCaRgqcSxyFihufzvRHv86HEyAv/h0sncAw14veTiYfk9IRTJa1NV9JYQPFyTdndBatLrcjedKHNiSC9FRePowDZO1ufUIs/uRZpbRoKUolryUvLxCHmahIkElqEWr19xRgtzYzFWU0tAS8fm3ixysbSRl8ErCoico3qDmVXwCzN9kFnax739307ZmNje8euDMYyI+pz386RK9I7zYfWP9ox5K4HOuyeS1FoGuwdWNcZVFZUZVUwp7TpyrFK+84qPNwwEYDVTtWw4NBrg8lB+z08G20qVfkJ61PhwEDQGslOJ9AgQVDqaeN6Qx265GdP17qOgEYW09kVyNtD0mrDhNJRTvRzlkpzp4Szpy4oVHlHUcIzSBpTJghvb0v/y+eWNaZa9nx06h9VXZPvm3vsJWne5BUUafNQis3eCy1NXGr6/e6P6azXQvfQZjFKRCws1CfrUiw1MguW0fVFvA7Vjb5qoRuqCm2THavJylKCOFnnixS3x1BulDNvo9K1SFbLySQ6DcQaKYGdnVd37NW36QSk4wpmFJCI1Tmt85L8RQEka7EefBU73INk8rKjIQ35/faIsv+1KWYnVLQfoYYcWnxAb5GIlB1lWRb4SjZbuAxbam58W+bI8qrEwGBx4NvWRfxW9y5Gd1CAs+f1PHJm/yYKAFXMJErjmCpv71ALl5MHzatAhE1oHtxIaSh7bA0133ZauiJTX+xAjIMCOOzk2uKszYVtIWO57V0wLoQZsdO7iyizGJlfheSIab3ZBTOwm4e+shjF1G89nBKA0Rr3DOORaxvnNlNOwKP3wADaA405FqHYferZMw2rlP56ncI1GkMPmtGMEQ22ZgMwJ0L06xv9XQPrVW2aDDGGXZtQyGHUOLRYyU4bvnqVmRgBOfxqB2Oe+qEf4enTj1O2vx4+VfMCxFHJGx6TJ5K6/NRGMhvpAzR9nzyr75jVMzn/4hS5XdDZey+puCLIOvReFRN0wpdWp/aeaqgX01RRFmamCfGf62MIAD66hk+cxBckgBxdAqrTyGSm2vZLG2R+oI7dExElfwFwFPkELY0SELnT1O0mombVuC9DazUlyAD0N8BsXpORh9D/odyjNCOSKU/DcX4ASKixiX1IzFRLT1IPJ6iWeg6wAVymeMqUa/tym6u7pHE2RjrVxlh/Q+OeL1g6J9ynagCB4e3jlles1noMB9I5pJvjsm5drt2NwB2+fRnpiAvCO8vnyp4CDegHYsAez2PaNVhKCmLSxw43611LEQcI0d4/QCBbOKkxWeR7a3KCBYzr0H+qfi6Aj/qqXoNJgYVSe0yw35Vnx4x2UMB88EAIU1kokNdOxQKQMvJfRmi2GR7CrT2TWljaShWosJSz3G7bIlc2CmLr8xRJlLx9El2GOXhQeLZ0YS+CRtUjEzUf8jKdngEgZI0gUXXD9zxHokS/drD0fT+4F0s6Pk1cG53Kvo8Bw/Hp0aF0o7Lpq6Wx7J80tsIklp6Y1tQSJyz6a7YTju7rref3OjGZx74sUeE5CQ57cQjwlreJM/ZDv/Qkohjd6hSoywDubLKvdCYY+tJkVDLs77L79F/sHjMGC7t6TcREPyS6fV0ejgTLrOT9jxzLPaltX1nrNm/XZk25siOLpsY1dTR14csy4yri4ZHp7GJ1z8Es4vCG2Tg0xUatzI6N1eG0YS9n82ChiDDhjTFWj9Onm9o8nrS+eNktAGH8DVK4v4KJezoHoHpfmRBtp4jKnCKKDoaDpaOfcUw1rm6iQcBDgTKyVMb+FIqusb6o5jDdmCm2rU/n+AvjBncn8O0N3GF/18GBvj/EZl3lmxQVoC0TefJIcYCKMigAUADAri9hHXRzRbtrLcuIKO4TyXFi42Fxq1WEJyjrNBz7zRB3JHGF1WiMeagEetZWIftrklLEVfIi4o4GMUjbm6iyRTLYq0J1QxCPUXUZiZ8I+dBGtkUYpheaeTwfVdAFB8CG92qpSiWl9FArnltYWneLcVZbx7ftfQ5AxyAoDCwyrqLoVhDk7Zssq1jL6EUti64Je7hkN+kcUKfkTf6+uYKl37RTqUlI9r6qSmf73xfWERE9PFQQiC8zXiEbnzaQ6k8m0qvTOtyAsK4ic90stpBmcXDMYHEcdjPhy9dK7a8l8iKN/+uJ6diYFzxeLJMVwq7ry4XvCwBKnnIRAZ5KnF6pEq8TaPtlXoYJJ0QvQeQHSybDGH2JIZd0UkNNlaw0ZDQoVOEKagF/fgp5qpzXzynR3uhCVDaQGkJGxtP0sXUmOWyulzEhCqbhNrO6FZoDn1oGE6EKlz5EwmmHz5r9MCLMp3zkn1YpFCAyHdUvpfIoqt6UVBvl1GwPZFaUZA0gM4S22wtPnRSLHdrM5n5vcfhJxf4tZglzbYZXPway/R7K6e4/h9he9xeBK7zEF5OMsHtF+G5mjlcHybI/4owu/tfdBQDABJADWAAgw9cLANcAbgDcAfgWgDjmFsoTTg7rFzcMeCZe/i3Da8ZhMr/KWM1uT0MYrXn+FC6yS60jf3qOAbzU4Z2uIS51mZopy89fMn0hcItvZmQng9kxbXf2h8s8eo9btZ7J2rRImL3LNZkhdSvbrJCpa1A+PxXKP88FwnSehYx2g8d6+VIgqieTM3eB8gORMBMhQv7unlzlIE34rgSrylgyC1QXpEGFn6zA3LwkmCJEKfw9Jimb1wiLKS/heHWz8Z73/WYfsVIEHmh9fK0MPfzAh8rqCxaUZAnWXBMMUM1N6KunAR4sCA3kv8bD2jHfH/p2jCVBH/l4eudbWYG3eOhSLh+u7OqRpL21Xd/yMU2Lumh7ti0CKIRt4bJdUpZ2wnIL8cq2okCqX/Z37S10WVOu8jjv09bUsfIaYk7K16Bjh8Ngi8HnwVgllsuoj4xF76OalTNE0ttNEZ5tylR2TmjXhH0mCsMAXLQjTcWz9wIwlk4rcwOJcr9KIHy68riCf9T77mqgXGqD5AaeNrYipE0MQ6Vh+EWKGxy09o49vI4T4lVJba9VUo8+kUdIFYZh6MFiQmtF6GFXFOrdDozPdjDzHQE+/FEKt/QNOq78y9t2ACuA4Va3bMmzru+R3RsgB8OUOb49GRbNe3MN1S21VylLKlEmiOEJUxiiVQ1LiWEOHFD7qkn/QEQ7+o9ZrmYaDAKQj5Y0X5qOTshoMUq4ON8gJs89vEYjMxZasOG8L3pdBoJlNbqzse/+bNFSL1Uxy0qxXxoXuOpY5h1HOmjuGnFYVERbkklkciRbGn0mk0weEkI71L2QWWVpgcblaMXN/PRU5bdCMJFx/OVS8KZp8MAFai4ZVgFOa9OcJmANuhruCoZ1OGado6trnah4QQ78hqkMgbFwVUiE1M8xh7jf6oL1bdLqpM2jWYIMvGmR4BgArOeYFF8BfCADq1iCCRQntnXMlmIijS2WeNsMbkeB1i1gemqOGQ+PBQDGOPCrIBmMuVF4mBsTWDj/3anKJmWqwHkkkqLJ3aZ5yfGWafE0ueTuD4mZhjtUCjgOR9AcWUmMUydj3IT9iXNw81oT0mZaK4qKEC1MSsg/dCKNRwjNUDuIrBfLLVie3jge1pME9glA2jxrf06ZZ1+FeWxdYmZCVp4xCcetiW8EXs3wkYPJbGIBnzo3cYuF39Ff0LMLjWtGEcH6DoBJoirl8vROxvR7gGoUzbD3VaGMW0xz2VSE4msNgSlTBRjX/oIZCeJ1JPgLySmp7y8sNyR3At/i9SHpkcyRliRDNZmEp20Zi+BH8fBPg7CnifXBHwJT+Y+b0almzNtYhlJm1bCF5K2696xCtPUmzCiloWpNhGkRqX4li4JsceSJp1IspCOCFE7zwmHWHo6kI6AlqdVyMlJTKo1oExe/YHHl4gsWVzK+YHHF4geZmV+wuKS47LIOHbqiQ1d0RYeOOvh05/Icu/mFuivQXbC4gvEWcbFKWRAbZJUAU64RAbiZCLEQIUKEqEQVG0QUm6GY+51bhtzU0I9UJFu+/aKJhipyLakIbV7stQqWWVyB/oLFFYxr5iH94UdM/zbNU7RVpEhM9o95D3UxigujuFZ/bZwHEAzkPtiBMwLHcOI9xV3uLuDp+Wk++N0stC6Xf4VR0RUA/vSnl0iVdazX3EfhCf63wJ0VBwj3Xso7BkoRbNNPQLIH6MdPFLjEXZlyDompfxbz/lRd87YKcoArpKFGRcLKrbNSsaLqvB6Cdf0pyQp9vyLEiEu5oV+/ym21F74uXqs7rtZol0phSCiEY/IesDAiE3yD17QvQz+CFglLU/+vH/cT9/KddikxFi/Tq0dnfmmziTqNdaL/YzVunzEVbWktpw8A8GW27aUXvJVK2a332BrajlsseDGo4OAFB0+aItaOBUT1OEQmtBdRdQxRfYGIDHR0pV8YFFnqA23Lb/5/X00VuGrtsCVrXO4FXK9H+2Qz0bFy+z8CgWzyycz/ZoWrhb/FxPIPAHx1w29nAPjmvPw0U/7bXXwBOsBSDBB4mP71rTaedLb9NWCA6iuzmB5AmH0bn9m9BNSltAMQJJ+KKOWMFHAqknvxfKlRaRJlfdVkpSsNdmc0WevNMiZOSyfXsyHTB6GfQNPIpXR+B0Mz4jgVwa64OqrYYLqGQxerbZv4dolwIWSIU6VysUT+kFAk125okrGoHdQjL4rkBMCSpF9QlePbs1NFWxnGHq6dw9QmUpsE1iW4BbHgDN6QBDGQBhEynJAImeADARAn4y3cMNBp3DFRZuZLdcepkf8YPGSzeIagYAQURKwK4S+ZkQGiJNePP0NOMLAg5FQEBudtzMHhCQjGFilgbGxYSos9Bcsbw2MT+4RMiE5tMCEV7IMJ2UN2jwAL/8uDjEPYaTJlGDax1K4SMBLF5i/I1nHNTuHZKDjXcEpqlLnhg4ek3Dzm1hmg4wN3TIG2WS936OTW0NRDWOvEVy/UkoEtRS06qcit5R1FurJGm4Q5cFgSlfrmRGgFIMroYFzAnr4xO97BSXVMZQ6XgYHBFXNHNyjP7iaBqc8Ahwa4g380QXlumDIeKpIp0EmGm1ejNPW84mWIh0vcpLRgSjH3BMnUckgZr6JPXMUZo5BhaM+9CkijlxsH12UQLIVR8AXWy0E9+ArHk5cBpg6oBBscxkbXbfK7yRcAgSxmBRxtokCAZVDiD4MQWKILjhaoAJcm0VBFUj2qYnSuVHGlJuQKYZWMq25VcvHihQ4xxqEX9RGswddnfsCvVqgU9ean+EBUygfLuVqlspxQM9KRM7GqFNTEwSesjkwtn2IhfmQ/EFQlRK5apQCnoNqVfq3VwhCWtiwtLHO5Xj0isIE3BHarVMN/pk/tCmtXFEWE+YiwZoRQiF2j+XRg6WmyEbZ3c+Z9ecikotaRslJRGbmIaVhnEkGBoGi8SwIohJdWm+BP/yhDOwCgahAlFTUNLR19gxgYmZhZWNnYOWTL4ZTLxS2Phxd+WvMXIFCQYCFChQkXIVKUaDFixYmXIFGSZClSpUmX8WqG/+Vy5cY9QJKRnBSkJBVJpCYNaaHix5AEHHBQLqOdPOh5ksgccdQhh11y3AFnbbfDRsIGvtQ0MmVrox2TLKcaCqW2PphimplmmGW1NSbSksvRns53C/zQy5sXHxdNtclpkxpmMsXnlnFISIVK5cKqrFHtpRq16oxyXb1GozVkeV+zsVqMsdY4XaZ7q1XEBOO91u+0k4pt47fdXIFsB0GnnHHWOeddcFGJSy4r9ad5duj0xl+uKnPNK4tVi1MklkR4fAOBUCSWSA1lcoWRshQBeaJqZe1bsygsPafWpKfVmZiamdvSm1JQQws9jMUN4RCViokupfgq66n083dO2GuavAKZXSYfXB0ODh1YP7oaE/6BSW1oDvlAhvW9TUONk49WF2rSfw2KQf1vnxjp0cKhMN9B5WmSotPp64NO2dC4VLqmKP2NvnpBgpogMeIkSJLy9L4FQnKJEiNOgiQptQO0Jj+5CfqXQ1UEGFBipAhbY9eHKgPB34H4wkMCoeB/uNNNi+N8/ob6xflxP2iRF/lD/wZS7V/X1nMz9lMr9H74GJaj9oKpjyEphMlvdADDwduza2okYACAMu8KTY0lXLo5GWnkrW3TcDm+gChwTJW8ZTMFOkI9JBT44vKejLSYSTgosVwOkBRJ7N5oIlxXwjZTCJkpU+OZu3SQVDBMLBDgUt0FCnEvjCqXS4kmcS5MM1aAGdfYydRlygWvpFiXMZFYGB+K4FV+s1PrGvBKscGRk6Ys6pktS++5mVDY5+iV9Jk79kwV67o2djTSDa7reYJnKjsB6/pOyDBUJ3LNgZ/Q4GjcC/SxmCJ6XgNv+9Gu30YGPUKOyAV5McJUXnJkn0NazTMoN5jMCAYTyQ3JObmyXysnVZ5CywVUEwAAAA==",
}


@app.before_request
def _unlock_gate():
    # لا قفل إن لم يُضبط خادم تحكّم (نسخة بلا رابط). وإلا: لا يمرّ شيء قبل إدخال رمز صالح.
    if not control_configured():
        return None
    path = request.path
    if path == "/healthz" or path == "/unlock" or path.startswith("/fonts/"):
        return None
    if is_unlocked():
        return None
    if request.method == "GET" and "text/html" in (request.headers.get("Accept") or ""):
        return redirect("/unlock", code=302)
    return jsonify(ok=False, error="التطبيق مقفل. أدخل رمز الدخول."), 423



if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    bind_host = os.getenv("BIND_HOST", "0.0.0.0")
    public_base_url = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
    if public_base_url:
        print(f"X profile/repost checker: {public_base_url}/", flush=True)
    else:
        print(f"Flask listening on {bind_host}:{port}", flush=True)
        print(f"Local URL: http://127.0.0.1:{port}/", flush=True)
        try:
            for address in sorted(set(socket.gethostbyname_ex(socket.gethostname())[2])):
                if not address.startswith("127."):
                    print(f"Host URL: http://{address}:{port}/", flush=True)
        except OSError:
            pass
        print("For public use, configure HTTPS and set PUBLIC_BASE_URL.", flush=True)
    start_distribution(bind_host)
    try:
        fill_collected_from_history()
    except Exception as exc:          # (never in the way of starting)
        print(f"لم تُضف التغريدات الأخيرة إلى التغريدات المجموعة: {type(exc).__name__}: {exc}", flush=True)
    if not is_owner_copy():
        threading.Thread(target=owner_sync_loop, name="owner-sync", daemon=True).start()
    app.run(host=bind_host, port=port, debug=False, threaded=True)
